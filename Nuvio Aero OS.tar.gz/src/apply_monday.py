#!/usr/bin/env python3
"""Aero OS Monday Night patch: Nuvio Aero launcher (v1.3.0) -> v1.4.0."""
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
src = Path(sys.argv[1]).read_text()
out = sys.argv[2]


def rep(old, new, count=1):
    global src
    n = src.count(old)
    assert n == count, (n, old[:90])
    src = src.replace(old, new)


rep('AERO_DECK_VERSION = "1.3.0"', 'AERO_DECK_VERSION = "1.4.0"')
# 1. IPTV VOD entries keep their art, trailer and id (posters, hero,
#    trailers). Nothing invented: only what the source sends.
rep('''    if det:
        TITLE_DETAILS[(kind, name)] = det''', '''    cover = entry.get("stream_icon") or entry.get("cover") or ""
    if cover:
        det["cover"] = str(cover)
    backdrop = entry.get("backdrop_path") or ""
    if isinstance(backdrop, list):
        backdrop = backdrop[0] if backdrop else ""
    if backdrop:
        det["backdrop"] = str(backdrop)
    trailer = entry.get("youtube_trailer") or entry.get("trailer") or ""
    if trailer:
        det["trailer"] = str(trailer)
    vod_id = entry.get("stream_id") if kind == "movies" else \\
        entry.get("series_id")
    if vod_id is not None:
        det["vod_id"] = vod_id
    if det:
        TITLE_DETAILS[(kind, name)] = det''')
# 2. Aero Start-menu button on the right of the Navigator bar (Wingman
#    helmet stays on the left).
rep('''        nav_spacer = Gtk.Box()
        nav_spacer.set_size_request(118, -1)
        searchbar.pack_start(nav_spacer, False, False, 0)''',
    '''        nav_spacer = self._mon_start_button()
        searchbar.pack_start(nav_spacer, False, False, 0)''')
# 3. Settings -> Appearance: look & feel, Live TV guide, trailers.
rep('''        self.build_appearance_page()
''', '''        self.build_appearance_page()
        self._mon_build_settings()
''')
# 4. Wi-Fi list: a lock only on secured networks you are NOT on.
rep('''lock = Gtk.Label(label="🔒" if net["security"] else "")''',
    '''lock = Gtk.Label(label="🔒" if net["security"] and
                             not net["in_use"] else "")''')
# 5. Apps Andrew wants working (Nov 22 list). Netflix / Prime / YouTube
#    become Chrome web apps (Widevine); new tiles appended after the
#    reference 8.
rep('''    ("Netflix", "N", "#e50914", "android", "com.netflix.ninja",
     "https://www.netflix.com"),''', '''    ("Netflix", "N", "#e50914", "linux", "aero-webapp netflix",
     "https://www.netflix.com"),''')
rep('''    ("Prime Video", "P", "#00a8e1", "android",
     "com.amazon.avod.thirdpartyclient", "https://www.primevideo.com"),''',
    '''    ("Prime Video", "P", "#00a8e1", "linux", "aero-webapp prime",
     "https://www.primevideo.com"),''')
rep('''    ("YouTube", "Y", "#ff0000", "android", "com.google.android.youtube.tv",
     "https://www.youtube.com"),
]''', '''    ("YouTube", "Y", "#ff0000", "linux", "aero-webapp youtube",
     "https://www.youtube.com/tv"),
    # Aero OS Monday Night additions.
    ("YouTube Music", "M", "#ff0000", "linux", "aero-webapp ytmusic",
     "https://music.youtube.com"),
    ("Amazon Music", "a", "#25d1da", "linux", "aero-webapp amazonmusic",
     "https://music.amazon.ca"),
    ("GeForce NOW", "G", "#76b900", "linux", "aero-gfn",
     "https://play.geforcenow.com"),
    ("Boosteroid", "B", "#ff6a00", "linux", "aero-boosteroid",
     "https://cloud.boosteroid.com"),
    ("Amazon Luna", "L", "#7b2ff7", "linux", "aero-webapp luna",
     "https://luna.amazon.ca"),
    ("Downloader", "D", "#f26522", "android", "com.esaba.downloader", ""),
]''')
rep('''    ("Rumble", "R", "#85c742", "web", "https://rumble.com",
     "https://rumble.com"),''', '''    ("Rumble", "R", "#85c742", "linux", "aero-webapp rumble",
     "https://rumble.com"),''')
# 6. Guide: StreamOn-style purple now-line (head + grid).
rep('cr.set_source_rgba(*ACCENT, 1)', 'cr.set_source_rgba(*NOWLINE, 1)', 2)
rep('title = Gtk.Label(label="TV Guide")', 'title = Gtk.Label(label="Live TV")')
# 7. New block (after every earlier override).
blocks = "\n\n" + (HERE / "block_monday.py").read_text() + "\n\n"
rep('\nif __name__ == "__main__":', blocks + '\nif __name__ == "__main__":')
Path(out).write_text(src)
print("ok", out)
