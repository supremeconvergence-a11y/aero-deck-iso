

# ===========================================================================
# Aero OS Monday Night (2): input device rules, AI (Wingman) key, remote mic
# ===========================================================================
# Last used input decides the on-screen keyboard (aero-deck-inputwatch
# writes /run/aero-deck/last-input from evdev device types):
#   touchscreen finger -> keyboard pops up; touchpad / mouse click or a
#   real keyboard -> no pop-up; remote / controller -> pops up, D-pad
#   highlight + OK types.
LAST_INPUT_FILE = Path("/run/aero-deck/last-input")


def last_input():
    try:
        return LAST_INPUT_FILE.read_text().strip()
    except Exception:
        return ""


def _desk_input():
    return last_input() in ("keyboard", "touchpad", "mouse")


def _l_on_entry_tapped_mon(self, entry, event):
    src = None
    try:
        src = event.get_source_device().get_source()
    except Exception:
        pass
    if src is not None and src != Gdk.InputSource.TOUCHSCREEN and \
            LAST_INPUT_FILE.exists():
        return False     # touchpad / mouse click: no on-screen keyboard
    return _orig_on_entry_tapped(self, entry, event)


_orig_on_entry_tapped = AltTVLauncher._on_entry_tapped
AltTVLauncher._on_entry_tapped = _l_on_entry_tapped_mon

_orig_dock_popup_for = DockKeyboard.popup_for


def _l_dock_popup_for(self, entry):
    ev = Gtk.get_current_event()
    if ev is not None and ev.type == Gdk.EventType.KEY_PRESS and \
            last_input() == "keyboard":
        return           # Enter on a real keyboard: just type, no pop-up
    return _orig_dock_popup_for(self, entry)


DockKeyboard.popup_for = _l_dock_popup_for


def _l_show_keyboard_mon(self, target_entry):
    _orig_show_keyboard_mon(self, target_entry)
    try:   # desk input: the search panel without the key grid
        card = self.kb.grid.get_parent()
        card.set_visible(not _desk_input())
    except Exception:
        pass


_orig_show_keyboard_mon = AltTVLauncher.show_keyboard
AltTVLauncher.show_keyboard = _l_show_keyboard_mon


def _helmet_image(px):
    p = ASSETS_DIR / "wingman-helmet.png"
    try:
        return Gtk.Image.new_from_pixbuf(
            GdkPixbuf.Pixbuf.new_from_file_at_scale(str(p), px, px, True))
    except Exception:
        return None


# Wingman = the flight helmet (bar button + both keyboards).
_orig_init_j = AltTVLauncher.__init__


def _l_init_j(self, *a, **kw):
    _orig_init_j(self, *a, **kw)
    try:
        inner = self.ask_btn.get_child()
        old = inner.get_children()[0]
        img = _helmet_image(22)
        if img is not None:
            inner.remove(old)
            inner.pack_start(img, False, False, 0)
            inner.reorder_child(img, 0)
            img.show()
    except Exception:
        pass
    try:   # Navigator (bar search) keyboard: helmet = ask Wingman
        bar = self.kb.entry.get_parent()
        b = Gtk.Button()
        img = _helmet_image(20)
        b.add(img if img is not None else Gtk.Label(label="Wingman"))
        b.set_tooltip_text("Ask Wingman (the AI) with what's typed")
        b.set_can_focus(False)
        b.connect("clicked", lambda w: self.on_ask_ai_button(w))
        bar.pack_start(b, False, False, 0)
        b.show_all()
    except Exception:
        pass


AltTVLauncher.__init__ = _l_init_j

# Full grid keyboard: helmet key = talk to the AI. Type, speak (Mic / the
# remote's mic) or mix both, then Enter sends it to Wingman.
_orig_dock_init = DockKeyboard.__init__


def _l_dock_init(self, launcher):
    _orig_dock_init(self, launcher)
    self.ai_mode = False
    self.ai_btn = Gtk.Button()
    img = _helmet_image(18)
    box = Gtk.Box(spacing=4)
    if img is not None:
        box.pack_start(img, False, False, 0)
    box.pack_start(Gtk.Label(label="AI"), False, False, 0)
    self.ai_btn.add(box)
    self.ai_btn.get_style_context().add_class("mon-kb-tool")
    self.ai_btn.set_tooltip_text("Talk to Wingman: type or speak, Enter sends")
    self.ai_btn.connect("clicked", lambda b: self.toggle_ai())
    bar = self.mode_btn.get_parent()
    bar.pack_end(self.ai_btn, False, False, 0)


def _l_toggle_ai(self):
    self.ai_mode = not self.ai_mode
    ctx = self.ai_btn.get_style_context()
    (ctx.add_class if self.ai_mode else ctx.remove_class)("osk-mic-live")
    self._voice_status("Wingman: type or speak (Mic), Enter sends"
                       if self.ai_mode else "")


_orig_dock_press = DockKeyboard._press


def _l_dock_press(self, button, action):
    if getattr(self, "ai_mode", False) and action == "done" and \
            self.entry is not None:
        q = self.entry.get_text()
        self.ai_mode = False
        self.ai_btn.get_style_context().remove_class("osk-mic-live")
        self.popdown()
        self.launcher.ask_ai(q)
        return
    return _orig_dock_press(self, button, action)


DockKeyboard.__init__ = _l_dock_init
DockKeyboard.toggle_ai = _l_toggle_ai
DockKeyboard._press = _l_dock_press


# Remote mic (G10S) / Search key: voice typing into whichever keyboard is
# open; otherwise Aero voice search as before.
_orig_on_voice_button_j = AltTVLauncher.on_voice_button


def _l_on_voice_button_j(self):
    kb = getattr(self, "entry_kb", None)
    if kb is not None and kb.is_open():
        kb._toggle_dictation()
        return
    if getattr(self, "kb_visible", False):
        self.kb.toggle_dictation()
        return
    return _orig_on_voice_button_j(self)


AltTVLauncher.on_voice_button = _l_on_voice_button_j

# Settings tile (Linux Apps) -> the Flight Deck.
_orig_on_open_app_j = AltTVLauncher.on_open_app


def _l_on_open_app_j(self, widget, kind, target, fallback, name):
    if target == "aero:settings":
        return self.open_settings_panel()
    return _orig_on_open_app_j(self, widget, kind, target, fallback, name)


AltTVLauncher.on_open_app = _l_on_open_app_j
