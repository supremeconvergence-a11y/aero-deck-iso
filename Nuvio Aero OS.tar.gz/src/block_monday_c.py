

# -- Live TV guide (StreamOn-style, Aero colours) ----------------------------
def _l_nv_metrics5(self, width):
    """~5 channel rows fill the grid whatever the screen / Interface size."""
    s = UI_SCALE
    chan_w = int(max(150, min(260, _dz(width) * 0.2)) * s)
    gap = int(8 * s)
    vis_h = 0
    try:
        vis_h = self.nv_scroll.get_allocated_height()
    except Exception:
        vis_h = 0
    row_h = int((vis_h - gap) / 5.0 - gap) if vis_h > 100 else int(88 * s)
    row_h = max(int(52 * s), min(int(170 * s), row_h))
    return {"s": s, "chan_w": chan_w, "row_h": row_h, "gap": gap,
            "pad": int(14 * s), "grid_w": max(10, width - chan_w - int(14 * s))}


_orig_build_epg_view_nv = AltTVLauncher.build_epg_view


def _l_build_epg_view_mon(self):
    _orig_build_epg_view_nv(self)
    # "Live TV" heading top-left of the clock column (not "Guide").
    try:
        box = self.epg_clock_label.get_parent()
        head = Gtk.Label(label="Live TV")
        head.get_style_context().add_class("mon-guide-head")
        head.set_halign(Gtk.Align.END)
        box.pack_start(head, False, False, 0)
        box.reorder_child(head, 0)
    except Exception:
        pass
    # Live muted preview inside the panel (behind the LIVE badge and the
    # expand button). Falls back to the channel logo when GStreamer
    # cannot play the stream.
    self.nv_video = AeroVideo(muted=True,
                              on_playing=lambda: self._nv_video_show(True),
                              on_end=lambda: self._nv_video_show(False))
    if self.nv_video.ok:
        w = self.nv_video.widget
        w.set_no_show_all(True)
        w.hide()
        self.nv_prev.add_overlay(w)
        try:
            self.nv_prev.reorder_overlay(w, 0)
        except Exception:
            pass
        w.add_events(Gdk.EventMask.BUTTON_RELEASE_MASK)
        w.connect("button-release-event", lambda *a: self.epg_play_focused())
    self._nv_prev_timer = None
    self._nv_apply_prefs()
    # Scrolled height changes -> row height changes.
    self.nv_scroll.connect("size-allocate", lambda w, a: (
        self.nv_grid.queue_draw(), self._nv_scroll_to_focus()))


def _l_nv_video_show(self, on):
    v = getattr(self, "nv_video", None)
    if v is None or not v.ok:
        return
    if on and getattr(self, "epg_open", False):
        v.widget.show()
    else:
        v.widget.hide()


def _l_nv_apply_prefs(self):
    """Preview panel on/off + size (Settings -> Appearance)."""
    if getattr(self, "nv_prev", None) is None:
        return
    on = bool(mset(self.settings, "mon_guide_preview"))
    self.nv_prev.set_visible(on)
    if not on:
        self._nv_preview_stop()
    self._nv_prev_w = -1
    try:
        a = self.epg_view.get_allocation()
        if a.width > 1:
            self._nv_on_alloc(self.epg_view, a)
    except Exception:
        pass


def _l_nv_on_alloc_mon(self, view, alloc):
    f = GUIDE_PREVIEW_SIZES.get(mset(self.settings, "mon_guide_preview_size"),
                                0.38)
    dw, dh = _dz(alloc.width), _dz(alloc.height)
    pw = int(max(260, min(820, dw * f, dh * (f * 0.72) * 16 / 9)))
    if pw != self._nv_prev_w:
        self._nv_prev_w = pw
        GLib.idle_add(lambda: (self.nv_prev.set_size_request(
            pw, int(pw * 9 / 16)), False)[1])


_orig_epg_update_preview_nv = AltTVLauncher.epg_update_preview


def _l_epg_update_preview_mon(self):
    _orig_epg_update_preview_nv(self)
    if not getattr(self, "epg_open", False) or \
            not mset(self.settings, "mon_guide_preview"):
        return
    if getattr(self, "_nv_prev_timer", None):
        GLib.source_remove(self._nv_prev_timer)
    self._nv_prev_timer = GLib.timeout_add(900, self._nv_preview_start)


def _l_nv_preview_start(self):
    self._nv_prev_timer = None
    v = getattr(self, "nv_video", None)
    if v is None or not v.ok or not getattr(self, "epg_open", False):
        return False
    ch, _p = self._nv_focused()
    url = (ch or {}).get("url") or ""
    if not url or getattr(self, "player_open", False):
        return False
    if v.uri != url:
        self._nv_video_show(False)
        v.play(url)
    return False


def _l_nv_preview_stop(self):
    if getattr(self, "_nv_prev_timer", None):
        GLib.source_remove(self._nv_prev_timer)
        self._nv_prev_timer = None
    v = getattr(self, "nv_video", None)
    if v is not None and v.ok:
        v.stop()
        v.widget.hide()


_orig_epg_play_focused_nv = AltTVLauncher.epg_play_focused
_orig_close_epg = AltTVLauncher.close_epg


def _l_epg_play_focused_mon(self):
    # One IPTV connection at a time: stop the preview first.
    self._nv_preview_stop()
    return _orig_epg_play_focused_nv(self)


def _l_close_epg_mon(self):
    self._nv_preview_stop()
    return _orig_close_epg(self)


_nv_metrics = _l_nv_metrics5          # module-level helper used by the grid
for _n, _f in (("build_epg_view", _l_build_epg_view_mon),
               ("_nv_video_show", _l_nv_video_show),
               ("_nv_apply_prefs", _l_nv_apply_prefs),
               ("_nv_on_alloc", _l_nv_on_alloc_mon),
               ("epg_update_preview", _l_epg_update_preview_mon),
               ("_nv_preview_start", _l_nv_preview_start),
               ("_nv_preview_stop", _l_nv_preview_stop),
               ("epg_play_focused", _l_epg_play_focused_mon),
               ("close_epg", _l_close_epg_mon)):
    setattr(AltTVLauncher, _n, _f)
