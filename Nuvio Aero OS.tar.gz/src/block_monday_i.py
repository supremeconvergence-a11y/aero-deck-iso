

# ===========================================================================
# Aero OS Monday Night (2): the "next time" list
#   new tiles (Fibe TV, Muse, Grok Bot, Proton VPN, Phone, Web Apps), a logo
#   on every tile, Web Apps page, Game Mode switch + "Start in" + first-boot
#   question, Task Manager, Speed Test, moving screensaver with photo
#   categories.
# ===========================================================================
APPS.extend([
    ("Web Apps", "W", "#2b6fe3", "linux", "aero:webapps", ""),
    ("Fibe TV", "F", "#00549a", "linux", "aero-webapp fibe",
     "https://tv.bell.ca"),
    ("Muse", "M", "#0866ff", "linux", "aero-webapp muse", "https://muse.ai"),
    ("Grok Bot", "G", "#111111", "linux", "aero-grokbot",
     "https://cursor.com/download/bot"),
    ("Proton VPN", "P", "#6d4aff", "linux", "aero-protonvpn",
     "https://protonvpn.com"),
    ("Phone", "P", "#1d99f3", "linux", "aero-phone", ""),
])
MONDAY_DEFAULTS.update({"ss_cats": ["nova-scotia", "canada", "mountains",
                                    "wildlife", "tropical", "cities", "usa"],
                        "ss_pan": True, "ss_every": 20})
SS_CATEGORIES = [("nova-scotia", "Nova Scotia"), ("canada", "Canada"),
                 ("usa", "United States"), ("mountains", "Mountains"),
                 ("wildlife", "Wildlife"), ("tropical", "Tropical"),
                 ("cities", "Cities")]
AERO_CFG = Path.home() / ".config" / "aero-deck"
WEBAPPS_FILE = CONFIG_DIR / "webapps.json"
WEBAPPS_DEFAULT = [
    {"name": "Google", "url": "https://www.google.com/"},
    {"name": "Gmail", "url": "https://mail.google.com/"},
    {"name": "Google Maps", "url": "https://maps.google.com/"},
    {"name": "Weather", "url": "https://weather.gc.ca/"},
    {"name": "Wikipedia", "url": "https://en.wikipedia.org/"},
    {"name": "MyBell", "url": "https://www.bell.ca/MyBell"},
]
FAVICON_DIR = Path.home() / ".cache" / "aero-deck" / "favicons"


def load_webapps():
    try:
        d = json.loads(WEBAPPS_FILE.read_text())
        if isinstance(d, list):
            return [x for x in d if isinstance(x, dict) and x.get("url")]
    except Exception:
        pass
    return [dict(x) for x in WEBAPPS_DEFAULT]


def save_webapps(lst):
    try:
        WEBAPPS_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = WEBAPPS_FILE.with_suffix(".part")
        tmp.write_text(json.dumps(lst, indent=1))
        os.replace(tmp, WEBAPPS_FILE)
    except Exception:
        pass


def _norm_url(u):
    u = (u or "").strip()
    if u and not re.match(r"^[a-z]+://", u, re.I):
        u = "https://" + u
    return u


def _host(u):
    try:
        return urllib.parse.urlparse(_norm_url(u)).hostname or ""
    except Exception:
        return ""


_FAV_BUSY = set()


def favicon_path(url):
    h = _host(url)
    return FAVICON_DIR / (re.sub(r"[^a-z0-9.-]+", "-", h.lower()) + ".png") \
        if h else None


def favicon_fetch(url, done=None):
    """The site's own icon (apple-touch-icon / <link rel=icon> / favicon.ico),
    fetched once in the background and cached as PNG."""
    p = favicon_path(url)
    if p is None or p.exists() or str(p) in _FAV_BUSY:
        return
    _FAV_BUSY.add(str(p))

    def job():
        ua = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AeroDeck/1.4"}
        base = _norm_url(url)
        cands = []
        try:
            html = urllib.request.urlopen(urllib.request.Request(
                base, headers=ua), timeout=10).read(400000).decode(
                    "utf-8", "replace")
            for m in re.finditer(r"<link\b[^>]*>", html, re.I):
                tag = m.group(0)
                rel = re.search(r'rel=["\']([^"\']+)', tag, re.I)
                href = re.search(r'href=["\']([^"\']+)', tag, re.I)
                if not rel or not href or "icon" not in rel.group(1).lower():
                    continue
                sz = re.search(r'sizes=["\'](\d+)', tag)
                score = int(sz.group(1)) if sz else (
                    180 if "apple" in rel.group(1).lower() else 32)
                cands.append((score, urllib.parse.urljoin(base,
                                                          href.group(1))))
        except Exception:
            pass
        cands.sort(reverse=True)
        root = "https://%s" % _host(url)
        urls = [u for _s, u in cands] + [root + "/apple-touch-icon.png",
                                          root + "/favicon.ico"]
        for u in urls:
            try:
                data = urllib.request.urlopen(urllib.request.Request(
                    u, headers=ua), timeout=10).read(2000000)
                loader = GdkPixbuf.PixbufLoader()
                loader.write(data)
                loader.close()
                pb = loader.get_pixbuf()
                if pb is None or pb.get_width() < 16:
                    continue
                FAVICON_DIR.mkdir(parents=True, exist_ok=True)
                tmp = str(p) + ".part"
                pb.savev(tmp, "png", [], [])
                os.replace(tmp, p)
                break
            except Exception:
                continue
        _FAV_BUSY.discard(str(p))
        if done is not None:
            GLib.idle_add(done)
    threading.Thread(target=job, daemon=True).start()


def _pb_from_file(path, w, h):
    try:
        return GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path), w, h, True)
    except Exception:
        return None


# -- a logo on every tile ----------------------------------------------------
def _l_load_app_icon_mon(self, name, target, kind, size=96, width=None,
                         height=None, icon_name=None):
    pb = _orig_load_app_icon(self, name, target, kind, size, width, height,
                             icon_name)
    if pb is not None:
        return pb
    w = width or size
    h = height or size
    if kind == "android" and target:
        # Waydroid keeps each installed app's own icon here.
        for d in (Path.home() / ".local/share/waydroid/data/icons",
                  Path("/var/lib/waydroid/data/icons")):
            f = d / (target + ".png")
            if f.exists():
                pb = _pb_from_file(f, w, h)
                if pb is not None:
                    return pb
    url = ""
    if kind == "web":
        url = target
    elif kind == "linux" and target.startswith("aero-webapp "):
        url = target.split(None, 1)[1]
        if not url.startswith("http"):
            url = ""
    if url:
        fp = favicon_path(url)
        if fp is not None and fp.exists():
            pb = _pb_from_file(fp, w, h)
            if pb is not None:
                return pb
        favicon_fetch(url)
    # Last resort: the theme's generic icon for the kind of app.
    theme = Gtk.IconTheme.get_default()
    for cand in (("android",) if kind == "android" else ()) + (
            "web-browser" if kind == "web" else "application-x-executable",
            "applications-other", "system-run"):
        try:
            info = theme.lookup_icon(cand, max(w, h), 0)
            if info is not None:
                return info.load_icon()
        except Exception:
            continue
    return None


_orig_load_app_icon = AltTVLauncher.load_app_icon
AltTVLauncher.load_app_icon = _l_load_app_icon_mon


# -- internal tiles (Web Apps, Game Mode) -----------------------------------
def _l_on_open_app_mon(self, widget, kind, target, fallback, name):
    if target == "aero:webapps":
        return self.mon_open_webapps()
    if target == "aero:gamemode":
        return self.mon_switch_gamemode()
    return _orig_on_open_app(self, widget, kind, target, fallback, name)


_orig_on_open_app = AltTVLauncher.on_open_app
AltTVLauncher.on_open_app = _l_on_open_app_mon


# -- Web Apps page -------------------------------------------------------------
_WEBAPPS_CSS = b"""
.mon-webapps { background: rgba(14,18,28,0.97); }
.mon-wa-title { font-size: 30px; font-weight: bold; color: white; }
.mon-wa-search { font-size: 22px; min-height: 52px; border-radius: 26px;
                 padding: 0 22px; }
.mon-wa-tile { border-radius: 18px; padding: 14px; min-width: 150px;
               background: rgba(255,255,255,0.08); color: white; }
.mon-wa-tile:focus, .mon-wa-tile:hover { background: rgba(80,140,255,0.45); }
.mon-wa-name { color: white; font-size: 17px; }
.mon-wa-tile label { color: white; font-size: 19px; font-weight: bold; }
.mon-wa-btn { font-size: 17px; padding: 8px 18px; border-radius: 12px; }
"""


def _l_mon_open_webapps(self):
    if getattr(self, "mon_wa_page", None) is not None:
        self.mon_wa_page.show()
        self._mon_wa_fill()
        return
    page = Gtk.EventBox()
    page.get_style_context().add_class("mon-webapps")
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
    for m in ("start", "end"):
        getattr(col, "set_margin_" + m)(60)
    col.set_margin_top(30)
    col.set_margin_bottom(30)
    top = Gtk.Box(spacing=12)
    t = Gtk.Label(label="Web Apps")
    t.get_style_context().add_class("mon-wa-title")
    top.pack_start(t, False, False, 0)
    back = Gtk.Button(label="‹ " + tr("Back"))
    back.get_style_context().add_class("mon-wa-btn")
    back.connect("clicked", lambda b: self.mon_close_webapps())
    self.mon_wa_edit = Gtk.ToggleButton(label="Edit")
    self.mon_wa_edit.get_style_context().add_class("mon-wa-btn")
    self.mon_wa_edit.connect("toggled", lambda b: self._mon_wa_fill())
    add = Gtk.Button(label="+ " + tr("Add"))
    add.get_style_context().add_class("mon-wa-btn")
    add.connect("clicked", lambda b: self._mon_wa_form(None))
    for b in (back, self.mon_wa_edit, add):
        top.pack_end(b, False, False, 0)
    col.pack_start(top, False, False, 0)
    se = Gtk.Entry()
    se.set_placeholder_text("Search Google or type a web address")
    se.get_style_context().add_class("mon-wa-search")
    se.set_halign(Gtk.Align.CENTER)
    se.set_size_request(760, -1)

    def go(e):
        q = e.get_text().strip()
        if not q:
            return
        if " " not in q and "." in q:
            url = _norm_url(q)
        else:
            url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(q)
        _spawn(["aero-webapp", url])
        e.set_text("")
    se.connect("activate", go)
    self.mon_wa_search = se
    col.pack_start(se, False, False, 6)
    self.mon_wa_form_box = Gtk.Box(spacing=10)
    self.mon_wa_form_box.set_halign(Gtk.Align.CENTER)
    self.mon_wa_form_box.set_no_show_all(True)
    col.pack_start(self.mon_wa_form_box, False, False, 0)
    flow = Gtk.FlowBox()
    flow.set_selection_mode(Gtk.SelectionMode.NONE)
    flow.set_max_children_per_line(6)
    flow.set_min_children_per_line(3)
    flow.set_column_spacing(18)
    flow.set_row_spacing(18)
    flow.set_homogeneous(True)
    flow.set_valign(Gtk.Align.START)
    self.mon_wa_flow = flow
    sc = Gtk.ScrolledWindow()
    sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sc.add(flow)
    col.pack_start(sc, True, True, 0)
    hint = Gtk.Label(label="Pick a logo to open the site full screen. "
                           "Home / Steam button comes back to Aero.")
    hint.get_style_context().add_class("mon-wa-name")
    col.pack_start(hint, False, False, 0)
    page.add(col)
    self.overlay.add_overlay(page)
    self.mon_wa_page = page
    page.show_all()
    self._mon_wa_fill()


def _mon_wa_css():
    prov = Gtk.CssProvider()
    prov.load_from_data(_WEBAPPS_CSS)
    scr = Gdk.Screen.get_default()
    if scr is not None:
        Gtk.StyleContext.add_provider_for_screen(
            scr, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)


_mon_wa_css()


def _l_mon_wa_fill(self):
    flow = self.mon_wa_flow
    for c in flow.get_children():
        flow.remove(c)
    editing = self.mon_wa_edit.get_active()
    lst = load_webapps()
    first = None
    for i, app in enumerate(lst):
        b = Gtk.Button()
        b.get_style_context().add_class("mon-wa-tile")
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        fp = favicon_path(app["url"])
        pb = _pb_from_file(fp, 96, 96) if fp is not None and fp.exists() \
            else None
        if pb is None:
            favicon_fetch(app["url"], done=lambda: (
                self._mon_wa_fill() if getattr(self, "mon_wa_page", None)
                and self.mon_wa_page.get_visible() else None, False)[1])
            ll = Gtk.Label()
            ll.set_markup("<span size='40000' weight='bold' color='white'>%s"
                          "</span>" % _esc((app.get("name") or "?")[:1].upper()))
            ll.set_size_request(96, 96)
            v.pack_start(ll, False, False, 0)
        else:
            v.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        nl = Gtk.Label(label=app.get("name") or _host(app["url"]))
        nl.get_style_context().add_class("mon-wa-name")
        nl.set_ellipsize(3)
        nl.set_max_width_chars(16)
        v.pack_start(nl, False, False, 0)
        if editing:
            row = Gtk.Box(spacing=6, halign=Gtk.Align.CENTER)
            ed = Gtk.Button(label="✎")
            rm = Gtk.Button(label="✕")
            ed.connect("clicked", lambda w, k=i: self._mon_wa_form(k))

            def remove(w, k=i):
                cur = load_webapps()
                if 0 <= k < len(cur):
                    cur.pop(k)
                    save_webapps(cur)
                self._mon_wa_fill()
            rm.connect("clicked", remove)
            row.pack_start(ed, False, False, 0)
            row.pack_start(rm, False, False, 0)
            v.pack_start(row, False, False, 0)
        b.add(v)
        b.connect("clicked", lambda w, u=app["url"]: (
            None if self.mon_wa_edit.get_active()
            else _spawn(["aero-webapp", _norm_url(u)])))
        flow.add(b)
        first = first or b
    flow.show_all()
    if first is not None and not self.mon_wa_search.has_focus():
        first.grab_focus()


def _l_mon_wa_form(self, idx):
    box = self.mon_wa_form_box
    for c in box.get_children():
        box.remove(c)
    lst = load_webapps()
    cur = lst[idx] if idx is not None and 0 <= idx < len(lst) else {}
    ne = Gtk.Entry()
    ne.set_placeholder_text("Name")
    ne.set_text(cur.get("name", ""))
    ue = Gtk.Entry()
    ue.set_placeholder_text("Web address (e.g. tv.bell.ca)")
    ue.set_text(cur.get("url", ""))
    ue.set_size_request(380, -1)
    save = Gtk.Button(label="Save")
    cancel = Gtk.Button(label="Cancel")

    def do_save(*_a):
        url = _norm_url(ue.get_text())
        if not _host(url):
            ue.grab_focus()
            return
        name = ne.get_text().strip() or _host(url).replace("www.", "")
        cur2 = load_webapps()
        if idx is not None and 0 <= idx < len(cur2):
            cur2[idx] = {"name": name, "url": url}
        else:
            cur2.append({"name": name, "url": url})
        save_webapps(cur2)
        box.hide()
        self._mon_wa_fill()
    save.connect("clicked", do_save)
    ue.connect("activate", do_save)
    cancel.connect("clicked", lambda b: box.hide())
    for w in (ne, ue, save, cancel):
        box.pack_start(w, False, False, 0)
        w.show()
    box.show()
    ne.grab_focus()


def _l_mon_close_webapps(self):
    if getattr(self, "mon_wa_page", None) is not None:
        self.mon_wa_page.hide()
    try:
        self.entry_kb.popdown()
    except Exception:
        pass


for _n, _f in (("mon_open_webapps", _l_mon_open_webapps),
               ("_mon_wa_fill", _l_mon_wa_fill),
               ("_mon_wa_form", _l_mon_wa_form),
               ("mon_close_webapps", _l_mon_close_webapps)):
    setattr(AltTVLauncher, _n, _f)


def _l_on_key_mon_i(self, widget, event):
    page = getattr(self, "mon_wa_page", None)
    if page is not None and page.get_visible() and \
            event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace) and \
            not (getattr(self, "entry_kb", None) is not None
                 and self.entry_kb.is_open()) and \
            not isinstance(self.get_focus(), Gtk.Entry):
        self.mon_close_webapps()
        return True
    return _orig_on_key_mon_i(self, widget, event)


_orig_on_key_mon_i = AltTVLauncher.on_key
AltTVLauncher.on_key = _l_on_key_mon_i


# -- Game Mode ---------------------------------------------------------------
def gamemode_available():
    return bool(shutil.which("gamescope") and shutil.which("steam"))


def _start_in_get():
    try:
        v = (AERO_CFG / "start-in").read_text().strip()
        return v if v in ("aero", "gamemode") else ""
    except Exception:
        return ""


def _start_in_set(v):
    try:
        AERO_CFG.mkdir(parents=True, exist_ok=True)
        (AERO_CFG / "start-in").write_text(v + "\n")
    except Exception:
        pass


def is_handheld():
    try:
        prod = Path("/sys/class/dmi/id/product_name").read_text().strip()
    except Exception:
        prod = ""
    return prod in ("Jupiter", "Galileo") or "ROG Ally" in prod or \
        "Legion Go" in prod


def _l_mon_switch_gamemode(self):
    if not gamemode_available():
        _l_show_toast_safe(self, "Game Mode needs gamescope + Steam "
                                 "(not in this build)")
        return
    _l_show_toast_safe(self, "Switching to Game Mode…")
    GLib.timeout_add(250, lambda: (_spawn(["aero-deck-gamemode"]), False)[1])


AltTVLauncher.mon_switch_gamemode = _l_mon_switch_gamemode


def _l_mon_open_start_menu_i(self):
    _orig_mon_open_start_menu_i(self)
    pop = getattr(self, "mon_start_pop", None)
    if pop is None:
        return
    outer = pop.get_child()
    row = Gtk.Box(spacing=10)
    row.set_margin_start(8)
    row.set_margin_end(8)
    for label, fn in (("🎮 " + tr("Game Mode"), self.mon_switch_gamemode),
                      ("🌐 " + tr("Web Apps"), self.mon_open_webapps),
                      ("⚙ " + tr("Task Manager"),
                       lambda: _spawn(["aero-deck-taskman"]))):
        b = Gtk.Button(label=label)
        b.get_style_context().add_class("mon-start-item")
        b.connect("clicked", lambda w, f=fn: (pop.popdown(), f()))
        if label.startswith("🎮") and not gamemode_available():
            b.set_sensitive(False)
        row.pack_start(b, False, False, 0)
    outer.pack_start(row, False, False, 0)
    outer.reorder_child(row, 0)
    row.show_all()


_orig_mon_open_start_menu_i = AltTVLauncher.mon_open_start_menu
AltTVLauncher.mon_open_start_menu = _l_mon_open_start_menu_i


def _l_x_power_mon(self):
    _orig_x_power(self)
    page = self._page("power")
    if page is None:
        return
    page.pack_start(self._xheading("Game Mode (Steam, like a Steam Deck)"),
                    False, False, 0)
    ok = gamemode_available()
    page.pack_start(self._xlabel(
        "Start in: what Aero opens to when it turns on. Steam's power menu "
        "-> Switch to Desktop comes back to Aero; Aero's Start menu -> Game "
        "Mode goes the other way." if ok else
        "Game Mode isn't in this build (needs gamescope + Steam)."),
        False, False, 0)
    row = Gtk.Box(spacing=12)
    rb_a = Gtk.RadioButton.new_with_label_from_widget(None, "Aero")
    rb_g = Gtk.RadioButton.new_with_label_from_widget(rb_a, "Game Mode")
    (rb_g if _start_in_get() == "gamemode" else rb_a).set_active(True)
    rb_a.connect("toggled", lambda b: b.get_active() and _start_in_set("aero"))
    rb_g.connect("toggled", lambda b: b.get_active() and
                 _start_in_set("gamemode"))
    go = Gtk.Button(label="Switch to Game Mode now")
    go.connect("clicked", lambda b: self.launcher.mon_switch_gamemode())
    for w in (rb_a, rb_g, go):
        w.set_sensitive(ok)
        row.pack_start(w, False, False, 0)
    page.pack_start(row, False, False, 0)
    page.pack_start(self._xheading("Tools"), False, False, 0)
    trow = Gtk.Box(spacing=12)
    for label, cmd in (("Task Manager", "aero-deck-taskman"),
                       ("Speed Test", "aero-deck-speedtest")):
        b = Gtk.Button(label=label)
        b.connect("clicked", lambda w, c=cmd: _spawn([c]))
        trow.pack_start(b, False, False, 0)
    page.pack_start(trow, False, False, 0)
    page.pack_start(self._xlabel(
        "Task Manager also opens with Ctrl+Alt+Delete or Super+Escape."),
        False, False, 0)
    page.show_all()


_orig_x_power = SettingsPanel._x_power
SettingsPanel._x_power = _l_x_power_mon


def _l_mon_first_boot_ask(self):
    """First start: Steam Deck style (Game Mode) or Desktop (Aero)?"""
    if _start_in_get() or not gamemode_available() or \
            self.settings.get("start_in_asked"):
        return False
    hand = is_handheld()
    box = Gtk.EventBox()
    box.get_style_context().add_class("mon-webapps")
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
    col.set_halign(Gtk.Align.CENTER)
    col.set_valign(Gtk.Align.CENTER)
    t = Gtk.Label(label="How should Aero start?")
    t.get_style_context().add_class("mon-wa-title")
    col.pack_start(t, False, False, 0)
    s = Gtk.Label(label="You can change this any time: Flight Deck -> "
                        "Power -> Start in.")
    s.get_style_context().add_class("mon-wa-name")
    col.pack_start(s, False, False, 0)
    row = Gtk.Box(spacing=18, halign=Gtk.Align.CENTER)

    def pick(v):
        _start_in_set(v)
        self.settings["start_in_asked"] = True
        save_settings(self.settings)
        box.destroy()
        if v == "gamemode":
            self.mon_switch_gamemode()
    bg = Gtk.Button(label="Steam Deck style (Game Mode)")
    ba = Gtk.Button(label="Desktop (Aero)")
    for b, v in ((bg, "gamemode"), (ba, "aero")):
        b.get_style_context().add_class("mon-wa-tile")
        b.connect("clicked", lambda w, vv=v: pick(vv))
        row.pack_start(b, False, False, 0)
    col.pack_start(row, False, False, 0)
    box.add(col)
    self.overlay.add_overlay(box)
    box.show_all()
    (bg if hand else ba).grab_focus()
    return False


AltTVLauncher.mon_first_boot_ask = _l_mon_first_boot_ask


# -- Speed test in Flight Deck -> Network ------------------------------------
def _l_settings_init_mon_i(self, *a, **kw):
    _orig_settings_init_i(self, *a, **kw)
    eth = getattr(self, "eth_status", None)
    page = eth.get_parent() if eth is not None else None
    if page is None:
        return
    row = Gtk.Box(spacing=12)
    b = Gtk.Button(label="Speed Test")
    res = Gtk.Label(label="")
    res.set_halign(Gtk.Align.START)

    def run(_b):
        b.set_sensitive(False)
        res.set_text(tr("Testing… (about 20 s)"))

        def job():
            try:
                out = subprocess.run(["aero-deck-speedtest", "--json"],
                                     capture_output=True, text=True,
                                     timeout=90).stdout
                r = json.loads(out.strip().splitlines()[-1])
                if "error" in r:
                    txt = tr("Speed test failed") + ": " + r["error"][:80]
                else:
                    txt = "↓ %.1f Mbps   ↑ %.1f Mbps   %s %.0f ms" % (
                        r["down_mbps"], r["up_mbps"], tr("Ping"), r["ping_ms"])
            except Exception as e:     # noqa: BLE001
                txt = tr("Speed test failed") + ": %s" % e
            GLib.idle_add(res.set_text, txt)
            GLib.idle_add(b.set_sensitive, True)
        threading.Thread(target=job, daemon=True).start()
    b.connect("clicked", run)
    row.pack_start(b, False, False, 0)
    row.pack_start(res, True, True, 0)
    page.pack_start(row, False, False, 0)
    kids = page.get_children()
    if eth in kids:
        page.reorder_child(row, kids.index(eth) + 1)
    row.show_all()


_orig_settings_init_i = SettingsPanel.__init__
SettingsPanel.__init__ = _l_settings_init_mon_i


# -- Screensaver: photo categories, slow pan, cross-fade, moving clock -------
SS_DIRS = [Path(os.environ.get("AERO_DECK_SCREENSAVER",
                               "/usr/local/share/aero-deck/screensaver"))]


def screensaver_photos(cats):
    out = []
    for base in SS_DIRS:
        for c in cats:
            d = base / c
            if d.is_dir():
                out += sorted(str(p) for p in d.glob("*.jp*g"))
    own = Path.home() / "Pictures" / "Screensaver"
    if own.is_dir():
        out += sorted(str(p) for p in own.glob("*")
                      if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
    return out


def _l_screensaver_show_mon(self):
    if getattr(self, "_ss_win", None) is not None:
        return
    st = self.settings
    cats = mset(st, "ss_cats") or []
    photos = screensaver_photos(cats)
    if not photos:
        photos = [str(ASSETS_DIR / "backdrop.jpg")]
    import random
    random.shuffle(photos)
    pan = bool(mset(st, "ss_pan"))
    every = max(8, int(mset(st, "ss_every") or 20))
    win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
    win.set_title("Aero Deck screensaver")
    win.set_transient_for(self)
    win.set_decorated(False)
    ov = Gtk.Overlay()
    area = Gtk.DrawingArea()
    S = {"i": 0, "cur": None, "prev": None, "t0": time.time(),
         "fade0": 0.0, "dir": 1, "size": (0, 0)}

    def load(i, w, h):
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(photos[i % len(photos)])
        except Exception:
            return None
        zoom = 1.12 if pan else 1.0
        sc = max(w * zoom / pb.get_width(), h * zoom / pb.get_height())
        pb = pb.scale_simple(max(1, int(pb.get_width() * sc)),
                             max(1, int(pb.get_height() * sc)),
                             GdkPixbuf.InterpType.BILINEAR)
        surf = Gdk.cairo_surface_create_from_pixbuf(pb, 1, None)
        return (surf, pb.get_width(), pb.get_height(), random.random())

    def paint_one(cr, img, w, h, t, alpha):
        surf, iw, ih, seed = img
        ex, ey = iw - w, ih - h
        f = min(1.0, t / float(every + 2)) if pan else 0.5
        # each photo drifts a different way
        dx = ex * (f if seed < 0.5 else 1 - f)
        dy = ey * ((seed * 2) % 1.0 if not pan else
                   (f if seed < 0.25 or seed > 0.75 else 1 - f))
        cr.set_source_surface(surf, -dx, -dy)
        cr.paint_with_alpha(alpha)

    def draw(_a, cr):
        w, h = area.get_allocated_width(), area.get_allocated_height()
        cr.set_source_rgb(0, 0, 0)
        cr.paint()
        if S["size"] != (w, h) or S["cur"] is None:
            S["size"] = (w, h)
            S["cur"] = load(S["i"], w, h)
            S["prev"] = None
        now = time.time()
        fa = min(1.0, (now - S["fade0"]) / 1.5)
        if S["prev"] is not None and fa < 1.0:
            paint_one(cr, S["prev"], w, h, now - S["t0"] + every, 1.0)
        if S["cur"] is not None:
            paint_one(cr, S["cur"], w, h, now - S["t0"],
                      fa if S["prev"] is not None else 1.0)
        return False
    area.connect("draw", draw)
    ov.add(area)
    clock = Gtk.Label()
    clock.get_style_context().add_class("ss-clock")
    ov.add_overlay(clock)
    spots = [(Gtk.Align.START, Gtk.Align.END), (Gtk.Align.END, Gtk.Align.END),
             (Gtk.Align.END, Gtk.Align.START), (Gtk.Align.START,
                                                Gtk.Align.START)]

    def place(k):
        ha, va = spots[k % len(spots)]
        clock.set_halign(ha)
        clock.set_valign(va)
        for m in ("start", "end", "top", "bottom"):
            getattr(clock, "set_margin_" + m)(56)
        clock.set_justify(Gtk.Justification.RIGHT if ha == Gtk.Align.END
                          else Gtk.Justification.LEFT)
    place(0)
    self._ss_win = win

    def tick():
        if self._ss_win is not win:
            return False
        now = datetime.datetime.now()
        clock.set_markup(
            "<span size='72000' weight='bold' foreground='white'>%s</span>\n"
            "<span size='20000' foreground='white'>%s</span>"
            % (now.strftime("%-I:%M"), _esc(now.strftime("%A, %B %-d"))))
        return True
    tick()
    GLib.timeout_add_seconds(10, tick)

    def frame():
        if self._ss_win is not win:
            return False
        if time.time() - S["t0"] >= every and len(photos) > 1:
            S["i"] += 1
            S["prev"] = S["cur"]
            w, h = S["size"]
            S["cur"] = load(S["i"], w, h) if w else None
            S["t0"] = S["fade0"] = time.time()
            place(S["i"])        # the clock moves too (no burn-in)
        area.queue_draw()
        return True
    GLib.timeout_add(50 if pan else 500, frame)
    win.add(ov)
    win.add_events(Gdk.EventMask.KEY_PRESS_MASK |
                   Gdk.EventMask.BUTTON_PRESS_MASK |
                   Gdk.EventMask.TOUCH_MASK |
                   Gdk.EventMask.POINTER_MOTION_MASK)
    self._ss_shown_at = time.time()

    def wake(*_a):
        if time.time() - self._ss_shown_at < 1.0:
            return True
        self.screensaver_hide()
        return True
    for sig in ("key-press-event", "button-press-event", "touch-event",
                "motion-notify-event"):
        win.connect(sig, wake)
    self._ss_win = win
    a = self.get_allocation()
    if a.width > 1:
        win.set_default_size(a.width, a.height)
    win.fullscreen()
    win.show_all()


AltTVLauncher.screensaver_show = _l_screensaver_show_mon


def _l_x_screensaver_mon(self):
    _orig_x_screensaver(self)
    page = self._page("screensaver")
    st = self.launcher.settings
    page.pack_start(self._xheading("Photos"), False, False, 0)
    grid = Gtk.FlowBox()
    grid.set_selection_mode(Gtk.SelectionMode.NONE)
    grid.set_max_children_per_line(4)
    cur = list(mset(st, "ss_cats") or [])

    def tog(b, key):
        c = list(mset(st, "ss_cats") or [])
        if b.get_active() and key not in c:
            c.append(key)
        elif not b.get_active() and key in c:
            c.remove(key)
        st["ss_cats"] = c
        save_settings(st)
    for key, label in SS_CATEGORIES:
        cb = Gtk.CheckButton(label=label)
        cb.set_active(key in cur)
        cb.connect("toggled", tog, key)
        grid.add(cb)
    page.pack_start(grid, False, False, 0)
    page.pack_start(self._xswitch_row(
        "Slow pan + cross-fade", bool(mset(st, "ss_pan")),
        lambda on: (st.__setitem__("ss_pan", bool(on)),
                    save_settings(st)))[0], False, False, 0)
    page.pack_start(self._xlabel(
        "Your own photos: put them in Pictures/Screensaver and they join "
        "the show. The clock moves to a new corner with every photo."),
        False, False, 0)
    page.show_all()


_orig_x_screensaver = SettingsPanel._x_screensaver
SettingsPanel._x_screensaver = _l_x_screensaver_mon


def _l_launcher_init_mon_i(self, *a, **kw):
    _orig_launcher_init_i(self, *a, **kw)
    GLib.timeout_add(2500, lambda: self.mon_first_boot_ask())


_orig_launcher_init_i = AltTVLauncher.__init__
AltTVLauncher.__init__ = _l_launcher_init_mon_i
