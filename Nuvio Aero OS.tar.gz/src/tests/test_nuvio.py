"""Nuvio Aero checks (run under xvfb-run). Uses a fake Xtream server."""
import importlib.util, json, os, sys, time, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fake_xtream
home = tempfile.mkdtemp(prefix="nvtest")
os.environ["HOME"] = home
srv = fake_xtream.start(0)
base = "http://127.0.0.1:%d" % srv.server_port
cfg = os.path.join(home, ".config", "tv-launcher")
os.makedirs(cfg)
L = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "aero-deck-launcher.py")
spec = importlib.util.spec_from_file_location("adl", L)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
from gi.repository import Gtk, GLib
ok = fail = 0
def check(name, cond):
    global ok, fail
    if cond: ok += 1; print("PASS", name)
    else: fail += 1; print("FAIL", name)

# M3U parser keeps guide fields
import urllib.request
txt = urllib.request.urlopen(base + "/test.m3u").read().decode()
chs = m._parse_m3u(txt)
check("m3u 7 channels", len(chs) == 7)
check("m3u tvg fields", chs[0]["epg_id"] == "ch101" and chs[0]["num"] == "101"
      and chs[0]["logo"].endswith("/logo/101.png") and chs[0]["tvg_url"].endswith("/xmltv.php"))
check("m3u group", chs[2]["group"] == "Sports")
# Xtream loader carries sid / epg id / num
src = {"name": "Fake", "url": base, "type": "xtream", "username": "u", "password": "test"}
xc, _mv, _sh, err = m._load_xtream(src)
check("xtream channels", err is None and len(xc) == 7)
check("xtream guide fields", xc[0]["sid"] == 101 and xc[0]["epg_id"] == "ch101" and xc[0]["num"] == 101)
for c in xc: c["src"] = 0
# XMLTV path
now = time.time()
epg = m.guide_load_epg(xc, [src], now)
check("xmltv epg for all", len(epg) == 7)
p = [x for x in epg[m.guide_channel_key(xc[0])] if x["s"] <= now < x["e"]]
check("xmltv now programme", p and p[0]["t"] == "Cosmos: Exploring the Universe")
# short_epg fallback
fake_xtream.H.no_xmltv = True
epg2 = m.guide_load_epg(xc, [src], now)
check("short_epg fallback", len(epg2) == 7)
check("short_epg base64 decoded", any("Cosmos" in x["t"] for x in epg2[m.guide_channel_key(xc[0])]))
fake_xtream.H.no_xmltv = False
# M3U url-tvg path
for c in chs: c["src"] = 0
epg3 = m.guide_load_epg(chs, [{"name": "M", "url": base + "/test.m3u", "type": "m3u"}], now)
check("m3u url-tvg epg", len(epg3) == 7)
# Gzip XMLTV
import gzip
raw = urllib.request.urlopen(base + "/xmltv.php").read()
check("xmltv gzip", len(m.parse_xmltv(gzip.compress(raw))) == 8)
# no-data fallback block
check("no data -> Live block", m.guide_progs_for({"name": "X"}, now, now + 9000)[0].get("nodata"))
# no credentials in error text
bad = dict(src, password="SeCrEt-999")
_a, _b, _c, err = m._load_xtream(bad)
check("refused login, no secret in error", err and "SeCrEt-999" not in err)

# Launcher flow
json.dump([src], open(os.path.join(cfg, "playlists.json"), "w"))
st = m.iptv_load_now(); m._IPTV_STATE = st if hasattr(m, "_IPTV_STATE") else None
m.iptv_source_state = lambda refresh=False, _s=st: _s
played = []
_w = m.shutil.which
m.shutil.which = lambda x, _w=_w: "/usr/bin/mpv" if x == "mpv" else _w(x)
m.AltTVLauncher._play_video = lambda self, *a, **k: played.append(a)
w = m.AltTVLauncher()
m._main_window = w
w.on_open_live(None, xc[1]["url"], "NewsNow")
check("live tile opens guide underneath", w.epg_open)
check("live tile plays fullscreen", w.player_open)
check("focused on that channel", w.epg_focused_channel()["name"] == "NewsNow")
w.close_player()
check("back from playback -> guide", w.epg_open and not w.player_open)
m._GUIDE_EPG["data"].update(epg)
w.epg_move_focus(1)
check("down moves channel", w.epg_focused_channel()["name"] == "Live Sports")
before = w.epg_focused_channel()["program"]
w.epg_shift_time(30)
check("right moves programme", w.epg_focused_channel()["program"] != before)
w.epg_shift_time(-30)
check("left moves back", w.epg_focused_channel()["program"] == before)
for _ in range(12): w.epg_shift_time(30)
check("time window follows focus", w.nv_ws > now - 3600)
fav = w.epg_toggle_favorite()
check("add to library toggles", fav is True and m.is_epg_favorite("Live Sports"))
w.epg_toggle_favorite()
from gi.repository import Gdk
def key(kv):
    ev = Gdk.Event.new(Gdk.EventType.KEY_PRESS); ev.keyval = kv; ev.window = w.get_window()
    return w.on_key(w, ev)
w.set_focus(None)
r0 = w.nv_focus_row
key(Gdk.KEY_Down)
check("d-pad down (key event)", w.nv_focus_row == r0 + 1)
key(Gdk.KEY_Up)
check("d-pad up (key event)", w.nv_focus_row == r0)
key(Gdk.KEY_F13)
check("Y button = library", m.is_epg_favorite(w.epg_focused_channel()["name"]))
key(Gdk.KEY_F13)
key(Gdk.KEY_Return)
check("A = watch (key event)", w.player_open)
key(Gdk.KEY_Escape)
check("B from player -> guide (key event)", w.epg_open and not w.player_open)
class E: pass
while Gtk.events_pending(): Gtk.main_iteration()
w.nv_grid.queue_draw()
while Gtk.events_pending(): Gtk.main_iteration()
cells = [c for c in getattr(w, "_nv_cells", []) if c[4] == 2]
ev = E(); ev.x = cells[0][0] + 10; ev.y = cells[0][1] + 10
w._nv_press(w.nv_grid, ev); w._nv_release(w.nv_grid, ev)
check("tap selects programme cell", w.nv_focus_row == 2 and not w.player_open)
w._nv_press(w.nv_grid, ev); w._nv_release(w.nv_grid, ev)
check("second tap watches", w.player_open)
w.close_player()
ev2 = E(); ev2.x = ev.x; ev2.y = ev.y + 80
w._nv_press(w.nv_grid, ev); w._nv_release(w.nv_grid, ev2)
check("swipe is not a tap", not w.player_open)
key(Gdk.KEY_Escape)
check("back again -> home", not w.epg_open)
# Nuvio app tile
check("nuvio desktop first among linux apps",
      "p.stem != \"nuvio\"" in open(L).read())
check("version", m.AERO_DECK_VERSION == "1.4.0")
# Slider rebuild
old = w
m.aero_set_ui_scale(1.0)
check("slider rebuild new window", m._main_window is not old and abs(m.UI_SCALE - 1.0) < 1e-6)
check("old listener removed", old._iptv_landed not in m._IPTV_LISTENERS)
m.aero_set_ui_scale("auto")
check("reset to auto saved", json.load(open(os.path.join(cfg, "settings.json"))).get("ui_scale") == "auto")
print("%d passed, %d failed" % (ok, fail))
sys.exit(1 if fail else 0)
