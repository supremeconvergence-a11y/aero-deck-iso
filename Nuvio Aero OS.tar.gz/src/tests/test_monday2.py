"""Aero OS Monday Night (2) checks + screenshots: docked/floating keyboard,
French menus, EPUB pictures, logos on tiles, Web Apps, Game Mode switch,
Task Manager / Speed Test, moving screensaver. Run under xvfb-run.
  LANG_TEST=French -> runs the menu-translation checks instead."""
import importlib.util, json, os, sys, time, tempfile, subprocess, zipfile, io
HERE = os.path.dirname(os.path.abspath(__file__))
home = tempfile.mkdtemp(prefix="mon2test")
os.environ["HOME"] = home
cfg = os.path.join(home, ".config", "tv-launcher")
os.makedirs(cfg)
LANG = os.environ.get("LANG_TEST", "")
if LANG:
    json.dump({"language": LANG}, open(os.path.join(cfg, "settings.json"), "w"))
L = sys.argv[1]
SHOTS = sys.argv[2] if len(sys.argv) > 2 else ""
TAG = os.environ.get("TAG", "1280x800")
spec = importlib.util.spec_from_file_location("adl", L)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
from gi.repository import Gtk, GLib, Gdk, GdkPixbuf
ok = fail = 0


def check(name, cond):
    global ok, fail
    if cond:
        ok += 1; print("PASS", name, flush=True)
    else:
        fail += 1; print("FAIL", name, flush=True)


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        time.sleep(0.02)


def shot(name):
    if SHOTS:
        pump(0.6)
        subprocess.run(["import", "-window", "root",
                        os.path.join(SHOTS, "%s-%s.png" % (name, TAG))])


def walk(x, cls, out):
    if isinstance(x, cls):
        out.append(x)
    if isinstance(x, Gtk.Container):
        for c in x.get_children():
            walk(c, cls, out)
    return out


spawned = []
m._spawn = lambda cmd, **k: (spawned.append(cmd), object())[1]
w = m.AltTVLauncher()
pump(4)

if LANG:
    check("tr() French", m.tr("Your Apps") == "Vos apps" and m.tr("Back") == "Retour")
    labels = [l.get_text() for l in walk(w, Gtk.Label, [])]
    check("home row titles in French", "Vos apps" in labels and "Films" in labels)
    shot("home-fr")
    w.open_settings_panel(); pump(1)
    labels = [l.get_text() for l in walk(w.settings_panel, Gtk.Label, [])]
    check("Flight Deck in French", any(t == "Alimentation" for t in labels))
    shot("flight-deck-fr")
    print("%d passed, %d failed" % (ok, fail), flush=True)
    sys.exit(1 if fail else 0)

# -- keyboard: docked default ---------------------------------------------------
check("EntryKeyboard is the dock keyboard", isinstance(w.entry_kb, m.DockKeyboard))
check("centred full grid is the default", w.entry_kb.mode() == "centered")
w.open_settings_panel(); pump(0.8)
w.settings_panel.show_page("language"); pump(0.5)
ents = [e for e in walk(w.settings_panel, Gtk.Entry, []) if e.get_mapped()]
if not ents:
    ents = walk(w.settings_panel, Gtk.Entry, [])
e = ents[0] if ents else Gtk.Entry()
w.entry_kb.popup_for(e); pump(1)
kb = w.entry_kb
a = kb.host.get_allocation(); cy = kb.host.translate_coordinates(w, 0, 0)[1]
W, H = w.get_allocated_width(), w.get_allocated_height()
check("centred: middle of the screen (%dx%d at y=%d)" % (a.width, a.height, cy),
      abs((cy + a.height / 2) - H / 2) <= 4 and a.width < W)
shot("keyboard-centred")
kb.popdown(); pump(0.3)
w.settings["kb_mode"] = "docked"
w.entry_kb.popup_for(e); pump(1)
a = kb.host.get_allocation()
ky = kb.host.translate_coordinates(w, 0, 0)[1]
W, H = w.get_allocated_width(), w.get_allocated_height()
check("docked: full width at the bottom (%dx%d at y=%d)" % (a.width, a.height, ky),
      a.width >= W - 2 and abs((ky + a.height) - H) <= 2 and 0.3 * H <= a.height <= 0.5 * H)
top = kb._overlay_child_of(e)
pt = top.translate_coordinates(w, 0, 0) if top is not None else None
check("panel being typed in moves up, top still on screen",
      top is not None and top.get_margin_bottom() >= int(0.3 * H) and pt[1] >= 0
      and pt[1] + top.get_allocated_height() <= ky + 2)
shot("keyboard-docked")
kb._bump_height(+0.1); pump(0.5)
check("docked height adjustable + saved", abs(float(w.settings["kb_dock_frac"]) - 0.5) < 0.01)
kb._bump_height(-0.1); pump(0.3)
# -- floating
kb.toggle_mode(); pump(1)
check("toggle -> floating", kb.mode() == "floating" and kb.is_open())
a = kb.host.get_allocation()
check("floating is smaller than the screen", a.width < W * 0.8)
kb._drag_begin(None, 0, 0); kb._drag_update(None, -150, -120); pump(0.3)
kb._size_begin(None, 0, 0); kb._size_update(None, 80, 0); pump(0.3)
x, y, fw = w.settings["kb_float_x"], w.settings["kb_float_y"], w.settings["kb_float_w"]
check("floating drag + resize remembered", x >= 0 and y >= 0 and fw >= 360)
shot("keyboard-floating")
kb.popdown(); pump(0.3)
w.entry_kb.popup_for(e); pump(0.6)
check("floating comes back where it was",
      abs(kb.host.get_margin_start() - x) <= 2 and abs(kb.host.get_margin_top() - y) <= 2)
kb.toggle_mode(); pump(0.3)
check("floating -> centred", kb.mode() == "centered")
e.set_text("")
kb.first_key.grab_focus(); pump(0.2)
fk = kb.first_key.get_label()
kb.first_key.clicked(); pump(0.2)
check("OK on the highlighted key types it (%r -> %r)" % (fk, e.get_text()), e.get_text() != "")
kb.popdown(); pump(0.3)
check("Back closes without wiping the text", e.get_text() != "")
check("closed -> panel back down", kb._lifted is None)
w.settings_panel.show_page("keyboard"); pump(0.5)
labels = [l.get_text() for l in walk(w.settings_panel, Gtk.Label, [])] + \
    [b.get_label() or "" for b in walk(w.settings_panel, Gtk.Button, [])]
check("Flight Deck keyboard style choice", any("Docked" in t for t in labels)
      and any("Floating" in t for t in labels))
w.settings_panel.show_page("power"); pump(0.5)
labels = [b.get_label() or "" for b in walk(w.settings_panel, Gtk.Button, [])]
check("Power page: Start in + Task Manager + Speed Test",
      "Game Mode" in labels and "Task Manager" in labels and "Speed Test" in labels)
w.close_settings_panel(); pump(0.5)

# -- logos on every tile ------------------------------------------------------------
missing = []
for app in m.assemble_apps():
    if app["source"] != "builtin":
        continue
    if w.load_app_icon(app["name"], app["target"], app["kind"], width=112, height=80) is None:
        missing.append(app["name"])
for row in (m.SOCIAL_APPS,):
    for name, _l, _c, kind, target, _f in row:
        if w.load_app_icon(name, target, kind, width=112, height=80) is None:
            missing.append(name)
check("every built-in tile has a logo (missing: %s)" % missing, not missing)
check("new tiles present", all(any(a["name"] == n for a in m.assemble_apps())
                               for n in ("Fibe TV", "Muse", "Grok Bot", "Proton VPN", "Phone", "Web Apps")))
w.mon_open_start_menu(); pump(1)
labels = [b.get_label() or "" for b in walk(w.mon_start_pop, Gtk.Button, [])]
check("Start menu: Game Mode / Web Apps / Task Manager", any("Game Mode" in t for t in labels)
      and any("Web Apps" in t for t in labels) and any("Task Manager" in t for t in labels))
shot("start-menu")
w.mon_start_pop.popdown(); pump(0.4)

# -- Web Apps page --------------------------------------------------------------------
w.on_open_app(None, "linux", "aero:webapps", "", "Web Apps"); pump(1.5)
check("Web Apps page opens", w.mon_wa_page.get_visible())
check("Web Apps default shortcuts", len(w.mon_wa_flow.get_children()) == len(m.WEBAPPS_DEFAULT))
w._mon_wa_form(None); pump(0.3)
ents = w.mon_wa_form_box.get_children()
ents[0].set_text("Fibe"); ents[1].set_text("tv.bell.ca"); ents[2].clicked(); pump(0.5)
check("Web Apps add saves", any(x["url"] == "https://tv.bell.ca" for x in m.load_webapps()))
w.mon_wa_search.set_text("nova scotia weather"); w.mon_wa_search.activate(); pump(0.2)
check("Web Apps search -> Google in app window",
      spawned and spawned[-1][0] == "aero-webapp" and "google.com/search?q=nova+scotia+weather" in spawned[-1][1])
pump(4)
shot("web-apps")
w.mon_close_webapps(); pump(0.3)

# -- Game Mode ----------------------------------------------------------------------
real_which = m.shutil.which
m.shutil.which = lambda x: "/usr/bin/" + x if x in ("gamescope", "steam") else real_which(x)
spawned.clear()
w.mon_switch_gamemode(); pump(0.6)
check("Game Mode switch runs aero-deck-gamemode", ["aero-deck-gamemode"] in spawned)
w.settings.pop("start_in_asked", None)
w.mon_first_boot_ask(); pump(0.8)
btns = [b for b in walk(w.overlay, Gtk.Button, []) if b.get_label() == "Desktop (Aero)"]
check("first boot asks Game Mode / Aero", bool(btns))
shot("first-boot-start-in")
if btns:
    btns[0].clicked(); pump(0.3)
check("Start in saved", m._start_in_get() == "aero")
m.shutil.which = real_which

# -- EPUB with a picture ------------------------------------------------------------
pb = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, False, 8, 400, 240)
pb.fill(0x2b6fe3ff)
ok_png, png = pb.save_to_bufferv("png", [], [])
ep = os.path.join(home, "pics.epub")
with zipfile.ZipFile(ep, "w") as z:
    z.writestr("mimetype", "application/epub+zip")
    z.writestr("META-INF/container.xml", '<container><rootfiles><rootfile full-path="OEBPS/content.opf"/></rootfiles></container>')
    z.writestr("OEBPS/content.opf", '<package><manifest><item id="c1" href="text/ch1.xhtml" media-type="application/xhtml+xml"/>'
               '<item id="i1" href="images/blue.png" media-type="image/png"/></manifest><spine><itemref idref="c1"/></spine></package>')
    z.writestr("OEBPS/text/ch1.xhtml", "<html><body><h1>Chapter One</h1><p>Before the picture.</p>"
               '<p><img src="../images/blue.png" alt="blue"/></p><p>After the picture.</p></body></html>')
    z.writestr("OEBPS/images/blue.png", png)
ch = m.epub_content(ep)
check("epub_content finds the picture", any(k == "img" for _t, segs in ch for k, _v in segs))
w.open_reader(ep) if hasattr(w, "open_reader") else m._launcher_open_reader(w, ep)
pump(2)
rw = w._reader_win
buf = rw.text_view.get_buffer()
it = buf.get_start_iter(); pics = 0
while True:
    if it.get_pixbuf() is not None:
        pics += 1
    if not it.forward_char():
        break
check("EPUB picture shown in the reader", pics == 1)
txt = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
check("EPUB text around the picture", "Before the picture." in txt and "After the picture." in txt)
shot("epub-picture")
rw.destroy(); pump(0.5)

# -- screensaver ----------------------------------------------------------------------
ssd = os.environ.get("SS_SAMPLE")
if ssd:
    m.SS_DIRS[:] = [__import__("pathlib").Path(ssd)]
check("screensaver photos found", len(m.screensaver_photos(["wildlife"])) >= 1 if ssd else True)
w.settings["ss_every"] = 8
print("STEP ss", flush=True)
try:
    w.screensaver_show(); pump(3)
except BaseException:
    import traceback; traceback.print_exc()
print("STEP ss up", flush=True)
check("screensaver up", w._ss_win is not None)
shot("screensaver")
w._ss_shown_at = 0; w.screensaver_hide(); pump(0.4)

# -- Task Manager / Speed Test scripts exist + compile ------------------------------
B = os.path.join(os.path.dirname(L), "profile-monday", "airootfs", "usr", "local", "bin")
for s in ("aero-deck-taskman", "aero-deck-speedtest"):
    p = os.path.join(B, s)
    check(s + " compiles", os.path.exists(p) and subprocess.run(
        [sys.executable, "-c", "import ast,sys;ast.parse(open(sys.argv[1]).read())", p]).returncode == 0)
print("%d passed, %d failed" % (ok, fail), flush=True)
sys.exit(1 if fail else 0)
