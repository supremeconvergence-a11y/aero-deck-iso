"""Aero OS Monday Night checks + screenshots (run under xvfb-run).
Fake Xtream server only (tests/fake_xtream.py) -- no real logins."""
import importlib.util, json, os, sys, time, tempfile, subprocess, faulthandler
faulthandler.enable()
import traceback as _tb, atexit
_oe = os._exit
def _ox(c):
    _tb.print_stack(); sys.stderr.flush(); _oe(c)
os._exit = _ox
atexit.register(lambda: print("ATEXIT", flush=True))
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import fake_xtream
home = tempfile.mkdtemp(prefix="montest")
os.environ["HOME"] = home
srv = fake_xtream.start(0)
base = "http://127.0.0.1:%d" % srv.server_port
cfg = os.path.join(home, ".config", "tv-launcher")
os.makedirs(cfg)
L = sys.argv[1]
SHOTS = sys.argv[2] if len(sys.argv) > 2 else ""
TAG = os.environ.get("TAG", "1280x800")
spec = importlib.util.spec_from_file_location("adl", L)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
from gi.repository import Gtk, GLib, Gdk
ok = fail = 0


def check(name, cond):
    global ok, fail
    if cond:
        ok += 1; print("PASS", name, flush=True)
    else:
        fail += 1; print("FAIL", name, flush=True)


def pump(sec):
    end = time.time() + sec
    while time.time() < end:
        while Gtk.events_pending():
            Gtk.main_iteration_do(False)
        time.sleep(0.02)


def shot(name):
    if SHOTS:
        pump(0.6)
        subprocess.run(["import", "-window", "root",
                        os.path.join(SHOTS, "%s-%s.png" % (name, TAG))])


src = {"name": "Test IPTV", "type": "xtream", "url": base, "username": "demo",
       "password": "test"}
json.dump([src], open(os.path.join(cfg, "playlists.json"), "w"))
st = m.iptv_load_now()
m.iptv_source_state = lambda refresh=False, _s=st: _s
check("vod movies loaded", len(st.get("movies") or []) == 6)
check("vod shows loaded", len(st.get("shows") or []) == 4)
d = m.TITLE_DETAILS.get(("movies", "Aurora Drift")) or {}
check("movie cover + id kept", d.get("cover", "").endswith("/poster/9001.png") and d.get("vod_id") == 9001)
d2 = m.TITLE_DETAILS.get(("shows", "Fundy Nights")) or {}
check("series backdrop kept", d2.get("backdrop", "").endswith("/backdrop/8002.png"))
_which = m.shutil.which
m.shutil.which = lambda x, _w=_which: None if x == "yt-dlp" else ("/usr/bin/mpv" if x == "mpv" else _w(x))
check("trailer from Xtream get_vod_info", m.trailer_find("movies", "Aurora Drift") == "dQw4w9WgXcQ")
check("yt id parse", m._yt_id("https://www.youtube.com/watch?v=abcdefghijk") == "abcdefghijk")
played = []
m.AltTVLauncher._play_video = lambda self, *a, **k: played.append(a)
spawned = []
m._spawn = lambda cmd, **k: (spawned.append(cmd), object())[1]
w = m.AltTVLauncher()
m._main_window = w

pump(4)
check("hero carousel: 6 dots", getattr(w, "_mon_n", 0) == 6)
check("Start button present", getattr(w, "mon_start_btn", None) is not None)
shot("home")
# Hero slides
w._mon_hero_show(1, True); pump(1.5); shot("hero-full")
w._mon_hero_show(2, True); pump(1.5); shot("hero-split")
w._mon_hero_show(0, True); pump(0.8)
# Poster focus -> hero follows
posters = []
def walk(x):
    if isinstance(x, Gtk.Button) and getattr(x, "_title_kind", None) == "movies":
        posters.append(x)
    if isinstance(x, Gtk.Container):
        for c in x.get_children():
            walk(c)
walk(w)
check("movies row = IPTV VOD posters", len(posters) == 6)
lives = []
def walk2(x):
    if getattr(x, "_mon_live_tile", False):
        lives.append(x)
    if isinstance(x, Gtk.Container):
        for c in x.get_children():
            walk2(c)
walk2(w)
check("live tiles in Live TV / Movies / Shows", len(lives) == 3)
check("no demo titles", not any(getattr(p, "_title_name", "") in ("Oppenheimer", "Barbie") for p in posters))
if posters:
    posters[1].grab_focus()
    pump(2.5)
    check("hero follows focus", w._mon_stack.get_visible_child_name() == "focus")
    shot("poster-focus")
# Start menu
w.mon_open_start_menu(); pump(1.5)
heads = []
def walk3(x):
    if isinstance(x, Gtk.Label) and x.get_style_context().has_class("mon-start-head"):
        heads.append(x.get_text())
    if isinstance(x, Gtk.Container):
        for c in x.get_children():
            walk3(c)
walk3(w.mon_start_pop)
check("start menu Linux Apps / Droid Apps", heads == ["Linux Apps", "Droid Apps"])
shot("start-menu")
ents = []
def walk4(x):
    if isinstance(x, Gtk.SearchEntry):
        ents.append(x)
    if isinstance(x, Gtk.Container):
        for c in x.get_children():
            walk4(c)
walk4(w.mon_start_pop)
fl = []
def walk5(x):
    if isinstance(x, Gtk.FlowBoxChild):
        fl.append(x)
    if isinstance(x, Gtk.Container):
        for c in x.get_children():
            walk5(c)
if ents:
    ents[0].set_text("boost"); pump(0.8)
    walk5(w.mon_start_pop)
    vis = [c.get_child()._mon_name for c in fl if c.get_child_visible()]
    check("start menu search filters (boost -> Boosteroid)", vis == ["boosteroid"])
    ents[0].set_text(""); pump(0.3)
else:
    check("start menu search filters (boost -> Boosteroid)", False)
w.mon_start_pop.popdown(); pump(0.5)
# Long-press menu / Remove from home
app = [a for a in m.assemble_apps() if a["name"] == "YouTube Music"][0]
check("options have Remove from home", ("Remove from home", "remove") in w.options_for_app(app))
w.options_app = app
w.on_option_chosen(None, "remove"); pump(1)
check("remove hides the app", app["key"] in m.load_apps_hidden() and
      not [a for a in m.assemble_apps() if a["key"] == app["key"]])
check("web app tiles", any(a["target"] == "aero-webapp netflix" for a in m.assemble_apps()))
# Remote keys
def key(kv):
    ev = Gdk.Event.new(Gdk.EventType.KEY_PRESS); ev.keyval = kv; ev.window = w.get_window()
    return w.on_key(w, ev)
toggled = []
w.player_toggle_pause = lambda: toggled.append(1)
w.player_open = True
key(Gdk.KEY_AudioPlay)
w.player_open = False
check("Play/Pause key -> player pause", toggled == [1])
voice = []
orig_voice = w.on_voice_button
w.on_voice_button = lambda: voice.append(1)
key(Gdk.KEY_Search)
check("Search key -> Aero voice search", voice == [1])
w.on_voice_button = orig_voice
homed = []
ob = w.back_to_aero
w.back_to_aero = lambda *a: homed.append(1)
key(Gdk.KEY_HomePage)
w.back_to_aero = ob
check("Home key -> Aero home", homed == [1])
# Cloud row native first
spawned.clear()
w.on_open_cloud(None, "GeForce Now", "https://play.geforcenow.com")
check("GeForce NOW -> native launcher", spawned and spawned[0] == ["aero-gfn"])
# Guide
m._GUIDE_EPG["data"].update(m.guide_load_epg(st["channels"], [src]))
w.open_epg(); pump(2)
mm = m._nv_metrics(w, w.nv_grid.get_allocated_width())
vis = w.nv_scroll.get_allocated_height()
rows_fit = (vis - mm["gap"]) / float(mm["row_h"] + mm["gap"])
check("guide shows ~5 rows (%.2f)" % rows_fit, 4.6 <= rows_fit <= 5.4)
check("guide heading Live TV", any(isinstance(c, Gtk.Label) and c.get_text() == "Live TV"
                                   for c in w.epg_clock_label.get_parent().get_children()))
shot("live-tv")
w.settings["mon_guide_preview_size"] = "large"; w._nv_apply_prefs(); pump(1); shot("live-tv-large-preview")
w.settings["mon_guide_preview"] = False; w._nv_apply_prefs(); pump(1)
check("preview panel off", not w.nv_prev.get_visible())
shot("live-tv-no-preview")
w.settings["mon_guide_preview"] = True; w.settings["mon_guide_preview_size"] = "medium"; w._nv_apply_prefs()
w.close_epg(); pump(0.5)
# Appearance
w.settings["aero_accent"] = "#8b5cf6"; m.aero_apply_look(w)
check("accent applied", abs(m.ACCENT[0] - 0x8b / 255.0) < 0.01)
w.settings["aero_accent"] = m.MONDAY_DEFAULTS["aero_accent"]; m.aero_apply_look(w)
print("STEP open panel", flush=True)
w.open_settings_panel(); pump(0.5)
print("STEP opened", flush=True)
w.settings_panel.show_page("appearance"); print("STEP page", flush=True)
for _i in range(30):
    pump(0.05); print("tick", _i, flush=True)
pg = w.settings_panel.stack.get_child_by_name("appearance")
try:
    sc = pg.get_parent()
    while sc is not None and not isinstance(sc, Gtk.ScrolledWindow):
        sc = sc.get_parent()
    if sc is not None:
        adj = sc.get_vadjustment(); adj.set_value(adj.get_upper())
except Exception:
    pass
print("STEP scrolled", flush=True)
pump(1)
print("STEP pumped", flush=True)
shot("settings-appearance")
print("STEP shot", flush=True)
try:
    w.close_settings_panel(); pump(0.5)
    w.settings["mon_bg_dim"] = 40; w.settings["mon_bg_blur"] = 4; m.aero_apply_look(w); pump(1)
    shot("home-blur-dim")
    check("no IPTV login in title details", "password=" not in repr(m.TITLE_DETAILS) and "username=" not in repr(m.TITLE_DETAILS))
except BaseException:
    import traceback; print(traceback.format_exc(), flush=True); fail += 1
print("%d passed, %d failed" % (ok, fail), flush=True)
sys.exit(1 if fail else 0)
