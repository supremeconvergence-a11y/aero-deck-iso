import subprocess, sys, time, threading, re, os
cmd = ["qemu-system-x86_64", "-machine", "q35,smm=on", "-m", "1024", "-nographic", "-no-reboot" if os.environ.get("NOREBOOT") else "-name", "aero",
       "-global", "driver=cfi.pflash01,property=secure,value=on",
       "-drive", "if=pflash,format=raw,unit=0,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.ms.fd",
       "-drive", "if=pflash,format=raw,unit=1,file=/tmp/sbsim/vars.fd",
       "-drive", "format=raw,file=/tmp/sbsim/efi.img,if=virtio",
       "-serial", "mon:stdio", "-net", "none"]
p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
buf = bytearray()
def rd():
    while True:
        b = p.stdout.read1(4096) if hasattr(p.stdout, "read1") else p.stdout.read(1)
        if not b: break
        buf.extend(b)
threading.Thread(target=rd, daemon=True).start()
def text():
    return re.sub(r"\x1b\[[0-9;?]*[A-Za-z]", " ", buf.decode("latin1"))
def wait(pat, t):
    end = time.time() + t
    while time.time() < end:
        if re.search(pat, text()): return True
        time.sleep(0.5)
    return False
def send(s, pause=1.5):
    p.stdin.write(s.encode() if isinstance(s, str) else s); p.stdin.flush(); time.sleep(pause)
script = sys.argv[1] if len(sys.argv) > 1 else ""
exec(open(script).read()) if script else time.sleep(float(os.environ.get("T", "60")))
open("/tmp/sbsim/out-%s.txt" % (os.path.basename(script) or "plain"), "w").write(text())
p.kill()
