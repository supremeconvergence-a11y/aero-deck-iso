"""Fake Xtream + XMLTV server for Aero guide tests (no real data)."""
import base64, datetime, http.server, json, sys, threading
from urllib.parse import urlsplit, parse_qs
CH = [(101, "Science Channel", "Science", ["Cosmos: Exploring the Universe", "The Planets: Inner Worlds", "Space's Deepest Secrets", "Black Holes"]),
      (205, "NewsNow", "News", ["The World Tonight", "Beyond the Headlines", "Global Business", "Weather Now"]),
      (305, "Live Sports", "Sports", ["Champions League Live", "Post-Match", "Highlights", "Sports Desk"]),
      (405, "Comedy Central", "Comedy", ["Friends: The Reunion", "The Office (US)", "Stand-Up Night", "Late Laughs"]),
      (505, "DocuWorld", "Docs", ["Wild Earth", "Ocean Mysteries", "Lost Cities", "Desert Life"]),
      (606, "Kids Zone", "Kids", ["Cartoon Hour", "Puzzle Time", "Story Club", "Science Kids"]),
      (707, "Music Hits", "Music", ["Top 40 Countdown", "Rock Classics", "Acoustic Live", "Night Mix"])]
PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==")
MOV = [(9001, "Aurora Drift", "2025", "#1d4e89", "#f2a65a"), (9002, "Harbour Lights", "2024", "#0b3954", "#bfd7ea"),
       (9003, "Granite Coast", "2026", "#3d2c8d", "#c7b8ea"), (9004, "Northern Tide", "2023", "#14532d", "#a7f3d0"),
       (9005, "Glass Orchard", "2025", "#7c2d12", "#fed7aa"), (9006, "Cobalt Run", "2026", "#1e3a8a", "#93c5fd")]
SER = [(8001, "Lighthouse Keepers", "2024", "#4c1d95", "#ddd6fe"), (8002, "Fundy Nights", "2025", "#134e4a", "#99f6e4"),
       (8003, "Signal Hill", "2026", "#7f1d1d", "#fecaca"), (8004, "Maritime Ridge", "2023", "#1f2937", "#e5e7eb")]
_ART = {}
_LOCK = threading.Lock()
def art(kind, vid, w, h):
    with _LOCK:
        return _art(kind, vid, w, h)
def _art(kind, vid, w, h):
    key = (kind, vid, w, h)
    if key in _ART:
        return _ART[key]
    import io
    from PIL import Image, ImageDraw, ImageFont
    row = [r for r in MOV + SER if r[0] == vid][0]
    a = tuple(int(row[3][i:i+2], 16) for i in (1, 3, 5)); b = tuple(int(row[4][i:i+2], 16) for i in (1, 3, 5))
    im = Image.new("RGB", (w, h))
    d = ImageDraw.Draw(im)
    for y in range(h):
        t = y / float(h)
        d.line([(0, y), (w, y)], fill=tuple(int(a[k] * (1 - t) + b[k] * t) for k in range(3)))
    for k in range(6):
        d.ellipse([w * (0.1 + 0.15 * k), h * (0.2 + 0.08 * k), w * (0.3 + 0.15 * k), h * (0.2 + 0.08 * k) + w * 0.2], outline=(255, 255, 255), width=3)
    try:
        f = ImageFont.truetype("/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf", 36 if w < 800 else 64)
    except Exception:
        f = ImageFont.load_default()
    d.text((w * 0.06, h * 0.78), row[1], fill=(255, 255, 255), font=f)
    bio = io.BytesIO(); im.save(bio, "PNG"); _ART[key] = bio.getvalue()
    return _ART[key]
def progs(i):
    now = datetime.datetime.now(datetime.timezone.utc).replace(second=0, microsecond=0)
    start = now.replace(minute=0) - datetime.timedelta(minutes=30 if i % 2 else 0)
    out = []
    t = start
    for k, title in enumerate(CH[i][3] * 3):
        dur = datetime.timedelta(minutes=[60, 30, 90, 60][(i + k) % 4])
        out.append((title, t, t + dur, "About %s on %s." % (title, CH[i][1])))
        t += dur
    return out
class H(http.server.BaseHTTPRequestHandler):
    no_xmltv = False
    def log_message(self, *a): pass
    def send(self, body, ct="application/json"):
        b = body if isinstance(body, bytes) else body.encode()
        self.send_response(200); self.send_header("Content-Type", ct); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        u = urlsplit(self.path); q = parse_qs(u.query); a = (q.get("action") or [""])[0]
        host = "http://%s" % self.headers["Host"]
        if u.path.startswith("/poster/") or u.path.startswith("/backdrop/"):
            vid = int(u.path.rsplit("/", 1)[1].split(".")[0]); kind = "p" if u.path.startswith("/poster/") else "b"
            return self.send(art(kind, vid, 400 if kind == "p" else 1280, 600 if kind == "p" else 720), "image/png")
        if u.path.startswith("/logo/"):
            return self.send(PNG, "image/png")
        if u.path == "/test.m3u":
            x = ['#EXTM3U url-tvg="%s/xmltv.php"' % host]
            for num, name, g, _p in CH:
                x.append('#EXTINF:-1 tvg-id="ch%d" tvg-chno="%d" tvg-logo="%s/logo/%d.png" group-title="%s",%s' % (num, num, host, num, g, name))
                x.append("%s/stream/%d.ts" % (host, num))
            return self.send("\n".join(x), "audio/x-mpegurl")
        if u.path == "/xmltv.php" and H.no_xmltv:
            self.send_response(404); self.end_headers(); return
        if u.path == "/xmltv.php":
            x = ['<?xml version="1.0"?><tv>']
            for i, (num, name, _g, _p) in enumerate(CH):
                x.append('<channel id="ch%d"><display-name>%s</display-name></channel>' % (num, name))
                for title, s, e, d in progs(i):
                    f = lambda t: t.strftime("%Y%m%d%H%M%S +0000")
                    x.append('<programme start="%s" stop="%s" channel="ch%d"><title>%s</title><desc>%s</desc></programme>' % (f(s), f(e), num, title, d))
            x.append("</tv>")
            return self.send("".join(x), "application/xml")
        if u.path == "/player_api.php":
            if q.get("password") != ["test"]:
                return self.send(json.dumps({"user_info": {"auth": 0}}))
            if a == "":
                return self.send(json.dumps({"user_info": {"auth": 1, "status": "Active"}}))
            if a == "get_live_categories":
                return self.send(json.dumps([{"category_id": str(i), "category_name": c[2]} for i, c in enumerate(CH)]))
            if a == "get_live_streams":
                return self.send(json.dumps([{"num": c[0], "name": c[1], "stream_id": c[0], "category_id": str(i),
                                              "epg_channel_id": "ch%d" % c[0], "stream_icon": host + "/logo/%d.png" % c[0]} for i, c in enumerate(CH)]))
            if a == "get_short_epg":
                sid = int(q["stream_id"][0]); i = [c[0] for c in CH].index(sid)
                lst = [{"title": base64.b64encode(t.encode()).decode(), "description": base64.b64encode(d.encode()).decode(),
                        "start_timestamp": str(int(s.timestamp())), "stop_timestamp": str(int(e.timestamp()))} for t, s, e, d in progs(i)]
                return self.send(json.dumps({"epg_listings": lst}))
            if a == "get_vod_categories" or a == "get_series_categories":
                return self.send(json.dumps([{"category_id": "1", "category_name": "Featured"}]))
            if a == "get_vod_streams":
                return self.send(json.dumps([{"stream_id": v, "name": n, "category_id": "1", "category_name": "Featured", "year": y,
                    "stream_icon": host + "/poster/%d.png" % v, "rating": "7.%d" % (v % 10), "container_extension": "mp4",
                    "plot": "%s: a test title from the fake IPTV server (no real data)." % n} for v, n, y, _a, _b in MOV]))
            if a == "get_series":
                return self.send(json.dumps([{"series_id": v, "name": n, "category_id": "1", "year": y, "cover": host + "/poster/%d.png" % v,
                    "backdrop_path": [host + "/backdrop/%d.png" % v], "plot": "%s: a test series from the fake IPTV server." % n,
                    "youtube_trailer": ""} for v, n, y, _a, _b in SER]))
            if a in ("get_vod_info", "get_series_info"):
                return self.send(json.dumps({"info": {"youtube_trailer": "dQw4w9WgXcQ"}}))
            return self.send("[]")
        self.send_response(404); self.end_headers()
def start(port=0):
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv
if __name__ == "__main__":
    s = start(int(sys.argv[1]) if len(sys.argv) > 1 else 8765); print("fake xtream on", s.server_port); threading.Event().wait()
