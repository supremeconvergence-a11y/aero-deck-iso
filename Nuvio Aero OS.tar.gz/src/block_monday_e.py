

# -- Live TV row: a Live Tile first -------------------------------------------
_orig_build_row_live_mon = AltTVLauncher.build_row_live


def _mon_find_tile_row(widget):
    if isinstance(widget, Gtk.Box) and \
            widget.get_orientation() == Gtk.Orientation.HORIZONTAL:
        for c in widget.get_children():
            if isinstance(c, Gtk.Button) and \
                    c.get_style_context().has_class("live-tile"):
                return widget
    if isinstance(widget, Gtk.Container):
        for c in widget.get_children():
            r = _mon_find_tile_row(c)
            if r is not None:
                return r
    return None


def _l_build_row_live_mon(self):
    section = _orig_build_row_live_mon(self)
    chans = (iptv_source_state().get("channels") or [])[:12]
    if not chans:
        return section
    row = _mon_find_tile_row(section)
    if row is None:
        return section
    tile = _mon_live_tile_button(
        "Live TV", [c.get("name") or "" for c in chans],
        [c.get("logo") for c in chans], 302, 185,
        lambda: self.open_epg(), logo_mode=True, live_badge=True)
    row.pack_start(tile, False, False, 0)
    row.reorder_child(tile, 0)
    return section


# -- Hero: 6-dot carousel, full + split slides, follows focus -----------------
HERO_ROTATE_S = 9


def _steam_hero_art(appid):
    for root in STEAM_ROOTS:
        base = root / "appcache" / "librarycache"
        for cand in (base / ("%d_library_hero.jpg" % appid),
                     base / str(appid) / "library_hero.jpg"):
            if cand.is_file():
                return str(cand)
    p = steam_cover_path(appid)
    return str(p) if p else None


def mon_hero_candidates():
    """Up to 5 featured slides: IPTV movies / shows with art and installed
    Steam games, interleaved. Never demo titles."""
    movies = [("movies", n, g, d) for n, g, d in mon_vod_items("movies", 80)
              if d.get("backdrop") or d.get("cover")][:6]
    shows = [("shows", n, g, d) for n, g, d in mon_vod_items("shows", 80)
             if d.get("backdrop") or d.get("cover")][:6]
    games = []
    try:
        for name, meta in games_row_items():
            if meta.get("installed") and meta.get("appid"):
                art = _steam_hero_art(int(meta["appid"]))
                if art:
                    games.append(("games", name, meta, {"backdrop": art}))
    except Exception:
        pass
    out = []
    pools = [movies, shows, games[:4]]
    while len(out) < 5 and any(pools):
        for pool in pools:
            if pool and len(out) < 5:
                out.append(pool.pop(0))
    return out


class _ArtArea(Gtk.DrawingArea):
    """Paints one picture cover-cropped with rounded corners; asks for no
    size, so the hero layout (full / split) stays exactly as designed."""

    def __init__(self, radius=30):
        super().__init__()
        self.pb = None
        self.radius = radius
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.connect("draw", self._draw)

    def set_pixbuf(self, pb):
        self.pb = pb
        self.queue_draw()

    def _draw(self, w, cr):
        if self.pb is None:
            return False
        W, H = self.get_allocated_width(), self.get_allocated_height()
        pw, ph = self.pb.get_width(), self.pb.get_height()
        sc = max(W / float(pw), H / float(ph))
        _nv_rrect(cr, 0, 0, W, H, self.radius * UI_SCALE)
        cr.clip()
        cr.translate((W - pw * sc) / 2, (H - ph * sc) / 2)
        cr.scale(sc, sc)
        Gdk.cairo_set_source_pixbuf(cr, self.pb, 0, 0)
        cr.paint()
        return False


def _l_mon_hero_slide(self, kind, name, meta, det, layout):
    """One featured slide. layout "full": art fills the hero, service +
    title + button on the left (no synopsis). "split": text panel left
    (service, title, synopsis, button), art on the right."""
    service = {"movies": "IPTV · MOVIE", "shows": "IPTV · SERIES",
               "games": "STEAM"}.get(kind, "AERO")
    art_src = det.get("backdrop") or det.get("cover")
    art = _ArtArea()
    if art_src:
        art_load(art_src, art.set_pixbuf)

    def act(*a):
        if kind == "games":
            self.on_open_game(None, name, meta)
        else:
            self.open_title_detail(kind, name, meta if isinstance(meta, str)
                                   else "")
    btn = Gtk.Button(label="▶  Play" if kind == "games" else "ⓘ  Details")
    btn.get_style_context().add_class("mon-hero-btn")
    btn.set_halign(Gtk.Align.START)
    btn.connect("clicked", act)
    srv = Gtk.Label(label=service)
    srv.get_style_context().add_class("mon-hero-service")
    srv.set_halign(Gtk.Align.START)
    ttl = Gtk.Label(label=name)
    ttl.get_style_context().add_class("mon-hero-title")
    ttl.set_halign(Gtk.Align.START)
    ttl.set_line_wrap(True)
    ttl.set_max_width_chars(22)
    ttl.set_lines(2)
    ttl.set_ellipsize(3)
    ttl.set_xalign(0)
    if layout == "full":
        ov = Gtk.Overlay()
        ov.add(art)
        txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        txt.set_valign(Gtk.Align.END)
        txt.set_halign(Gtk.Align.START)
        txt.set_margin_start(40)
        txt.set_margin_bottom(36)
        for w in (srv, ttl, btn):
            txt.pack_start(w, False, False, 0)
        ov.add_overlay(txt)
        root = ov
    else:
        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        root.set_homogeneous(True)
        txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        txt.set_margin_start(30)
        txt.set_valign(Gtk.Align.CENTER)
        syn = Gtk.Label(label=(det.get("plot") or "")[:260])
        syn.get_style_context().add_class("mon-hero-sub")
        syn.set_line_wrap(True)
        syn.set_max_width_chars(48)
        syn.set_lines(4)
        syn.set_ellipsize(3)
        syn.set_xalign(0)
        syn.set_halign(Gtk.Align.START)
        for w in (srv, ttl, syn, btn):
            txt.pack_start(w, False, False, 0)
        root.pack_start(txt, True, True, 0)
        root.pack_start(art, True, True, 0)
    return root


_orig_build_hero_mon = AltTVLauncher.build_hero


def _l_build_hero_mon(self):
    _orig_build_hero_mon(self)
    hero = self.hero_card
    slide1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
    for k in hero.get_children():
        expand, fill, pad, _pt = hero.query_child_packing(k)
        hero.remove(k)
        slide1.pack_start(k, expand, fill, pad)
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    stack = Gtk.Stack()
    stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
    stack.set_transition_duration(600)
    stack.set_homogeneous(True)
    slide1.show_all()
    stack.add_named(slide1, "s0")
    col.pack_start(stack, True, True, 0)
    dots = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    dots.set_halign(Gtk.Align.CENTER)
    dots.set_margin_bottom(12)
    dots.set_margin_top(4)
    col.pack_start(dots, False, False, 0)
    hero.pack_start(col, True, True, 0)
    col.show_all()
    self._mon_stack = stack
    self._mon_dots = dots
    self._mon_slide_i = 0
    self._mon_hold_until = 0
    self._mon_refresh_hero()
    if getattr(self, "_mon_rot_id", None):
        GLib.source_remove(self._mon_rot_id)
    self._mon_rot_id = GLib.timeout_add_seconds(HERO_ROTATE_S,
                                                self._mon_hero_rotate)


def _l_mon_refresh_hero(self):
    stack = getattr(self, "_mon_stack", None)
    if stack is None:
        return
    for c in stack.get_children():
        if stack.child_get_property(c, "name") != "s0":
            stack.remove(c)
            c.destroy()
    cands = mon_hero_candidates()
    for i, (kind, name, meta, det) in enumerate(cands):
        layout = "full" if i % 2 == 0 else "split"
        sl = self._mon_hero_slide(kind, name, meta, det, layout)
        sl.show_all()
        stack.add_named(sl, "s%d" % (i + 1))
    self._mon_n = 1 + len(cands)
    for c in self._mon_dots.get_children():
        self._mon_dots.remove(c)
    self._mon_dot_btns = []
    for i in range(self._mon_n):
        d = Gtk.Button()
        d.get_style_context().add_class("mon-dot")
        d.set_can_focus(False)
        d.connect("clicked", lambda w, i=i: self._mon_hero_show(i, True))
        self._mon_dots.pack_start(d, False, False, 0)
        self._mon_dot_btns.append(d)
    self._mon_dots.set_visible(self._mon_n > 1)
    self._mon_dots.show_all()
    self._mon_hero_show(min(self._mon_slide_i, self._mon_n - 1))


def _l_mon_hero_show(self, i, user=False):
    self._mon_slide_i = i
    self._mon_stack.set_visible_child_name("s%d" % i)
    for j, d in enumerate(getattr(self, "_mon_dot_btns", [])):
        ctx = d.get_style_context()
        (ctx.add_class if j == i else ctx.remove_class)("on")
    if user:
        self._mon_hold_until = time.time() + 20


def _l_mon_hero_rotate(self):
    if getattr(self, "_aero_dead", False):
        return False
    if time.time() < getattr(self, "_mon_hold_until", 0) or \
            getattr(self, "_mon_tr", None) is not None or \
            getattr(self, "_mon_n", 1) < 2:
        return True
    self._mon_hero_show((self._mon_slide_i + 1) % self._mon_n)
    return True


def _l_mon_hero_follow(self, kind, name, meta, det):
    """Hero follows the focused poster (a full slide for that title)."""
    stack = getattr(self, "_mon_stack", None)
    if stack is None or not (det.get("backdrop") or det.get("cover")):
        return
    old = stack.get_child_by_name("focus")
    sl = self._mon_hero_slide(kind, name, meta, det, "full")
    sl.show_all()
    stack.add_named(sl, "focus")
    stack.set_visible_child(sl)
    if old is not None:
        GLib.timeout_add(700, lambda: (stack.remove(old) if old.get_parent()
                                       else None, old.destroy(), False)[2])
    for d in getattr(self, "_mon_dot_btns", []):
        d.get_style_context().remove_class("on")
    self._mon_hold_until = time.time() + 15


_orig_iptv_landed_mon = AltTVLauncher._iptv_landed


def _l_iptv_landed_mon(self, state):
    _orig_iptv_landed_mon(self, state)
    if getattr(self, "_aero_dead", False):
        return
    try:
        self._mon_refresh_hero()
    except Exception:
        pass


for _n, _f in (("build_row_live", _l_build_row_live_mon),
               ("_mon_hero_slide", _l_mon_hero_slide),
               ("build_hero", _l_build_hero_mon),
               ("_mon_refresh_hero", _l_mon_refresh_hero),
               ("_mon_hero_show", _l_mon_hero_show),
               ("_mon_hero_rotate", _l_mon_hero_rotate),
               ("_mon_hero_follow", _l_mon_hero_follow),
               ("_iptv_landed", _l_iptv_landed_mon)):
    setattr(AltTVLauncher, _n, _f)
