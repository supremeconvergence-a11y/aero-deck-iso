# Fetch each service's OWN app icon (apple-touch-icon / web-app manifest icon
# published on its official site) for the Aero tiles. Falls back to the site's
# favicon. Output: <slug>.png (square, RGBA) + SOURCES.txt
import re, json, sys, io, urllib.request, urllib.parse
from PIL import Image
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36",
      "Accept-Language": "en-CA,en;q=0.9"}
SITES = {
 "netflix": "https://www.netflix.com/", "hulu": "https://www.hulu.com/", "prime-video": "https://www.primevideo.com/",
 "disney": "https://www.disneyplus.com/", "hbo-max": "https://www.max.com/", "peacock": "https://www.peacocktv.com/",
 "apple-tv": "https://tv.apple.com/", "youtube": "https://www.youtube.com/", "youtube-music": "https://music.youtube.com/",
 "amazon-music": "https://music.amazon.ca/", "geforce-now": "https://play.geforcenow.com/", "boosteroid": "https://boosteroid.com/",
 "amazon-luna": "https://luna.amazon.ca/", "rumble": "https://rumble.com/", "facebook": "https://www.facebook.com/",
 "xbox-cloud-gaming": "https://www.xbox.com/en-CA/play", "tiktok": "https://www.tiktok.com/", "instagram": "https://www.instagram.com/",
 "x": "https://x.com/", "twitch": "https://www.twitch.tv/", "snapchat": "https://www.snapchat.com/", "reddit": "https://www.reddit.com/",
 "pinterest": "https://www.pinterest.com/", "steam": "https://store.steampowered.com/", "brave": "https://brave.com/",
 "proton-vpn": "https://protonvpn.com/", "muse": "https://muse.ai/", "fibe-tv": "https://tv.bell.ca/",
 "kde-connect": "https://kdeconnect.kde.org/", "protonup-qt": "https://davidotek.github.io/protonup-qt/",
 "grok-bot": "https://cursor.com/", "google-chrome": "https://www.google.com/chrome/", "firefox": "https://www.mozilla.org/firefox/",
 "aurora-store": "https://auroraoss.com/", "downloader": "https://www.aftvnews.com/downloader/",
}
def get(url, n=4_000_000):
    r = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=20)
    return r.geturl(), r.read(n)
def cands(base, html):
    out = []
    for m in re.finditer(r'<link[^>]+>', html, re.I):
        t = m.group(0)
        rel = re.search(r'rel=["\']([^"\']+)', t, re.I); href = re.search(r'href=["\']([^"\']+)', t, re.I)
        if not rel or not href: continue
        rel = rel.group(1).lower(); href = urllib.parse.urljoin(base, href.group(1).replace("&amp;", "&"))
        size = re.search(r'sizes=["\'](\d+)', t)
        s = int(size.group(1)) if size else 0
        if "apple-touch-icon" in rel: out.append((max(s, 180), href))
        elif rel == "icon" or "shortcut" in rel: out.append((s or 32, href))
        elif rel == "manifest":
            try:
                mu, mb = get(href)
                for ic in json.loads(mb).get("icons", []):
                    ss = max([int(x.split("x")[0]) for x in ic.get("sizes", "0x0").split() if "x" in x] or [0])
                    out.append((ss, urllib.parse.urljoin(mu, ic["src"])))
            except Exception: pass
    out.sort(reverse=True)
    return out
def load(url):
    _, b = get(url)
    im = Image.open(io.BytesIO(b)); im.load()
    if getattr(im, "n_frames", 1) > 1 or im.format == "ICO":
        try: im.size = max(im.info.get("sizes", [im.size]))
        except Exception: pass
    return im.convert("RGBA")
only = sys.argv[1:]
src = open("SOURCES.txt", "a")
for slug, site in SITES.items():
    if only and slug not in only: continue
    best = None
    try:
        base, html = get(site)
        for s, u in cands(base, html.decode("utf-8", "ignore")):
            if u.lower().endswith(".svg"): continue
            try:
                im = load(u)
                if im.width >= 96: best = (im, u); break
                if best is None or im.width > best[0].width: best = (im, u)
            except Exception: continue
    except Exception as e:
        print(slug, "site error", str(e)[:80])
    if best is None or best[0].width < 96:
        try:
            host = urllib.parse.urlsplit(site).hostname
            u = "https://www.google.com/s2/favicons?domain=%s&sz=256" % host
            im = load(u)
            if best is None or im.width > best[0].width: best = (im, u + " (site favicon via Google)")
        except Exception: pass
    if best is None: print(slug, "NONE"); continue
    im, u = best
    sz = max(im.size); sq = Image.new("RGBA", (sz, sz), (0, 0, 0, 0)); sq.paste(im, ((sz - im.width) // 2, (sz - im.height) // 2))
    sq.resize((256, 256), Image.LANCZOS).save(slug + ".png", optimize=True)
    print(slug, im.size, u[:100]); src.write("%s\t%s\n" % (slug, u))
