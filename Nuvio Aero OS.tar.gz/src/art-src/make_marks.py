"""Aero's own marks (drawn here, not third-party art):
  aero-a-white.png / aero-a-blue.png : the Aero symbol -- a sharp "A" with
      a tilted Saturn-like orbit swish around it
  wingman-helmet.png : the Wingman aviator flight helmet (AI button)"""
import cairo, math, sys
D = sys.argv[1]

def aero(path, rgb, size=256):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size); cr = cairo.Context(s)
    cr.scale(size / 256.0, size / 256.0)
    cr.set_source_rgb(*rgb)
    cr.set_line_cap(cairo.LINE_CAP_ROUND); cr.set_line_join(cairo.LINE_JOIN_ROUND)
    # back half of the orbit (behind the A)
    def orbit(a0, a1, w):
        cr.save(); cr.translate(128, 140); cr.rotate(-0.42); cr.scale(1.0, 0.34)
        cr.arc(0, 0, 112, a0, a1); cr.restore()
        cr.set_line_width(w); cr.stroke()
    orbit(math.pi * 1.08, math.pi * 1.92, 11)
    # the A: sharp apex, slim legs, crossbar
    cr.move_to(128, 22); cr.line_to(206, 226); cr.line_to(172, 226)
    cr.line_to(128, 104); cr.line_to(84, 226); cr.line_to(50, 226); cr.close_path()
    cr.fill()
    cr.rectangle(92, 160, 72, 18); cr.fill()
    # front half of the orbit (in front of the A), with a gap so it reads
    cr.set_operator(cairo.OPERATOR_CLEAR)
    cr.save(); cr.translate(128, 140); cr.rotate(-0.42); cr.scale(1.0, 0.34)
    cr.arc(0, 0, 112, math.pi * 0.02, math.pi * 0.98); cr.restore()
    cr.set_line_width(26); cr.stroke()
    cr.set_operator(cairo.OPERATOR_OVER); cr.set_source_rgb(*rgb)
    orbit(math.pi * 0.02, math.pi * 0.98, 11)
    # swish tip
    cr.save(); cr.translate(128, 140); cr.rotate(-0.42)
    cr.arc(112, 0, 9, 0, 2 * math.pi); cr.restore(); cr.fill()
    s.write_to_png(path)

def helmet(path, size=256):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size); cr = cairo.Context(s)
    cr.scale(size / 256.0, size / 256.0)
    shell = (0.17, 0.23, 0.33)
    # dome
    cr.set_source_rgb(*shell)
    cr.move_to(40, 170); cr.curve_to(30, 70, 110, 22, 160, 30)
    cr.curve_to(222, 40, 236, 110, 222, 170)
    cr.line_to(200, 214); cr.line_to(70, 214); cr.close_path(); cr.fill()
    # visor (tinted, raised on the front of the dome)
    g = cairo.LinearGradient(80, 60, 230, 140)
    g.add_color_stop_rgb(0, 0.36, 0.62, 1.0); g.add_color_stop_rgb(1, 0.10, 0.32, 0.80)
    cr.set_source(g)
    cr.move_to(92, 70); cr.curve_to(140, 48, 210, 60, 230, 112)
    cr.curve_to(232, 136, 220, 146, 200, 146)
    cr.curve_to(170, 120, 130, 104, 96, 108); cr.close_path(); cr.fill()
    # visor glint
    cr.set_source_rgba(1, 1, 1, 0.55); cr.set_line_width(7); cr.set_line_cap(cairo.LINE_CAP_ROUND)
    cr.move_to(122, 74); cr.curve_to(150, 64, 186, 70, 204, 90); cr.stroke()
    # ear cup
    cr.set_source_rgb(0.85, 0.88, 0.93); cr.arc(104, 162, 30, 0, 2 * math.pi); cr.fill()
    cr.set_source_rgb(*shell); cr.arc(104, 162, 15, 0, 2 * math.pi); cr.fill()
    # oxygen-mask hose / chin strap
    cr.set_source_rgb(0.85, 0.88, 0.93); cr.set_line_width(12)
    cr.move_to(132, 180); cr.curve_to(160, 200, 200, 196, 214, 176); cr.stroke()
    s.write_to_png(path)

aero(D + "/aero-a-white.png", (1, 1, 1))
aero(D + "/aero-a-blue.png", (0.17, 0.43, 0.89))
helmet(D + "/wingman-helmet.png")
