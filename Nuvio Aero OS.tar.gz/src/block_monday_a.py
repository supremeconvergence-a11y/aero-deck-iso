# ---------------------------------------------------------------------------
# Aero OS Monday Night (launcher 1.4.0, Nov 23 2026)
#  * Live TV guide: "Live TV" heading, ~5 rows fill the grid, purple
#    now-line, live muted preview in the panel (GStreamer), preview on/off
#    + size (Settings -> Appearance).
#  * Trailers: Xtream youtube_trailer -> yt-dlp YouTube search; muted
#    trailer inside a focused poster card (card grows a little), Trailer
#    button on the details page (mpv, full screen).
#  * Hero: 6-dot carousel (1 = last watched/played, 2-6 = IPTV movies /
#    shows / installed Steam games), full + split slides; the hero follows
#    the focused poster.
#  * Live Tiles (animated art) first in Live TV / Movies / TV Shows.
#  * Movies / TV Shows rows = the IPTV source's VOD (no demo titles).
#  * Look & feel: accent colour, background static/dynamic + blur + dim,
#    panel opacity -- each with a Default button.
#  * Aero Start menu (A button, opposite Wingman): Linux Apps / Droid Apps.
#  * Long-press / right-click on app tiles; "Remove from home".
#  * Remote: Play/Pause, Home, Search/voice -> Aero voice search.
# Everything is sized in design px (UI_SCALE patches set_size_request), so
# it still fits 1024x600 .. 1080p at any Interface size.
# ---------------------------------------------------------------------------
try:
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst
    Gst.init(None)
except Exception:            # pragma: no cover
    Gst = None

AERO_DECK_MONDAY = True
MONDAY_DEFAULTS = {
    "aero_accent": "#2b6fe3",
    "mon_bg_mode": "static",          # static | dynamic
    "mon_bg_blur": 0,                 # 0..10
    "mon_bg_dim": 0,                  # 0..70 (%)
    "mon_panel_opacity": 20,          # 0..90 (%) frosted cards / tiles
    "mon_guide_preview": True,
    "mon_guide_preview_size": "medium",   # small | medium | large
    "mon_card_trailers": True,
}
ACCENT_CHOICES = [("Aero blue", "#2b6fe3"), ("Sky", "#4da3ff"),
                  ("Teal", "#2bb673"), ("Purple", "#8b5cf6"),
                  ("Pink", "#e85d8a"), ("Red", "#e50914"),
                  ("Amber", "#f5a623"), ("Aluminum", "#aab4c3")]
NOWLINE = (0.545, 0.361, 0.965)       # StreamOn-style purple now-line
GUIDE_PREVIEW_SIZES = {"small": 0.30, "medium": 0.38, "large": 0.46}
ART_CACHE = Path.home() / ".cache" / "aero-deck" / "art"
_ART_MEM = {}
_TRAILER_IDS = {}
_LOOK_PROVIDER = None
_SIGUSR2_SRC = None


def mset(settings, key):
    v = (settings or {}).get(key)
    return MONDAY_DEFAULTS[key] if v is None else v


def _hex_rgb(h):
    h = (h or "#2b6fe3").lstrip("#")
    try:
        return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except Exception:
        return (0.17, 0.43, 0.89)


def _rgba_css(h, a):
    r, g, b = _hex_rgb(h)
    return "rgba(%d,%d,%d,%.2f)" % (r * 255, g * 255, b * 255, a)


def _lighter(h, f=0.25):
    r, g, b = _hex_rgb(h)
    return "#%02x%02x%02x" % tuple(int(255 * min(1, c + (1 - c) * f))
                                   for c in (r, g, b))


# -- art (posters / backdrops / logos) ---------------------------------------
def _cover_crop(pb, w, h):
    if pb is None or w <= 0 or h <= 0:
        return pb
    sw, sh = pb.get_width(), pb.get_height()
    sc = max(w / float(sw), h / float(sh))
    dw, dh = max(1, int(sw * sc + 0.5)), max(1, int(sh * sc + 0.5))
    s = pb.scale_simple(dw, dh, GdkPixbuf.InterpType.BILINEAR)
    return s.new_subpixbuf((dw - w) // 2, (dh - h) // 2, min(w, dw),
                           min(h, dh))


def _round_pb(pb, r):
    """Rounded corners (cairo); returns the input on any failure."""
    if pb is None or r <= 0:
        return pb
    try:
        import cairo as _c
        import math
        w, h = pb.get_width(), pb.get_height()
        surf = _c.ImageSurface(_c.FORMAT_ARGB32, w, h)
        cr = _c.Context(surf)
        r = min(r, w / 2.0, h / 2.0)
        cr.new_sub_path()
        cr.arc(w - r, r, r, -math.pi / 2, 0)
        cr.arc(w - r, h - r, r, 0, math.pi / 2)
        cr.arc(r, h - r, r, math.pi / 2, math.pi)
        cr.arc(r, r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()
        cr.clip()
        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
        cr.paint()
        out = Gdk.pixbuf_get_from_surface(surf, 0, 0, w, h)
        return out or pb
    except Exception:
        return pb


def art_pixbuf_now(src):
    """Full-size pixbuf if the art (URL or local path) is already here."""
    if not src:
        return None
    src = str(src)
    if src in _ART_MEM:
        return _ART_MEM[src]
    path = Path(src) if not src.startswith(("http://", "https://")) else \
        ART_CACHE / (_hashlib.sha1(src.encode()).hexdigest() + ".img")
    if path.is_file():
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(str(path))
            _ART_MEM[src] = pb
            return pb
        except Exception:
            return None
    return None


_ART_WAIT = {}


def art_load(src, cb):
    """cb(pixbuf) on the main loop -- right away when cached, else after
    one shared background download (atomic write, every waiting caller
    is called back). Never raises; cb never gets None."""
    pb = art_pixbuf_now(src)
    if pb is not None:
        cb(pb)
        return
    if not src or not str(src).startswith(("http://", "https://")):
        return
    src = str(src)
    if src in _ART_WAIT:
        _ART_WAIT[src].append(cb)
        return
    _ART_WAIT[src] = [cb]

    def done():
        cbs = _ART_WAIT.pop(src, [])
        pb = art_pixbuf_now(src)
        if pb is not None:
            for f in cbs:
                try:
                    f(pb)
                except Exception:
                    pass
        return False

    def work():
        try:
            ART_CACHE.mkdir(parents=True, exist_ok=True)
            p = ART_CACHE / (_hashlib.sha1(src.encode()).hexdigest() + ".img")
            tmp = p.with_name(p.name + ".%d.part" % threading.get_ident())
            tmp.write_bytes(_fetch_bytes(src, 12, 6 * 1024 * 1024))
            os.replace(str(tmp), str(p))
        except Exception:
            pass
        GLib.idle_add(done)
    threading.Thread(target=work, daemon=True).start()


def _px(v):
    return max(1, int(v * UI_SCALE))


# -- video (GStreamer playbin -> gtksink widget) -----------------------------
class AeroVideo(object):
    """A muted (by default) video widget. .ok is False when GStreamer or
    gtksink is missing -- callers then simply keep the still art."""

    def __init__(self, muted=True, on_playing=None, on_end=None):
        self.ok = False
        self.widget = None
        self.pipe = None
        self.uri = None
        self.on_playing = on_playing
        self.on_end = on_end
        if Gst is None:
            return
        try:
            sink = Gst.ElementFactory.make("gtksink", None)
            pipe = Gst.ElementFactory.make("playbin", None)
            if sink is None or pipe is None:
                return
            pipe.set_property("video-sink", sink)
            pipe.set_property("mute", bool(muted))
            sink.set_property("force-aspect-ratio", True)
            self.widget = sink.get_property("widget")
            self.pipe = pipe
            bus = pipe.get_bus()
            bus.add_signal_watch()
            bus.connect("message", self._on_msg)
            self.ok = True
        except Exception:
            self.ok = False

    def play(self, uri):
        if not self.ok or not uri:
            return False
        try:
            self.pipe.set_state(Gst.State.NULL)
            self.uri = uri
            self.pipe.set_property("uri", uri)
            self.pipe.set_state(Gst.State.PLAYING)
            return True
        except Exception:
            return False

    def stop(self):
        self.uri = None
        if self.ok:
            try:
                self.pipe.set_state(Gst.State.NULL)
            except Exception:
                pass

    def _on_msg(self, bus, msg):
        t = msg.type
        if t == Gst.MessageType.STATE_CHANGED and msg.src == self.pipe:
            old, new, _p = msg.parse_state_changed()
            if new == Gst.State.PLAYING and self.on_playing:
                self.on_playing()
        elif t in (Gst.MessageType.ERROR, Gst.MessageType.EOS):
            # Never print the URI (IPTV stream URLs carry the login).
            self.stop()
            if self.on_end:
                self.on_end()


# -- trailers ----------------------------------------------------------------
def _yt_id(v):
    v = str(v or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", v):
        return v
    m = re.search(r"(?:v=|youtu\.be/|/embed/|/shorts/)([A-Za-z0-9_-]{11})", v)
    return m.group(1) if m else None


def _xtream_vod_trailer(kind, vod_id):
    """get_vod_info / get_series_info -> youtube_trailer (any Xtream
    source that answers). Blocking; never raises; no credentials logged."""
    action = "get_vod_info&vod_id" if kind == "movies" else \
        "get_series_info&series_id"
    for src in load_playlists():
        if (src.get("type") or "").lower() != "xtream":
            continue
        try:
            url = "%s/player_api.php?username=%s&password=%s&action=%s=%s" % (
                (src.get("url") or "").rstrip("/"),
                urllib.parse.quote(src.get("username", "")),
                urllib.parse.quote(src.get("password", "")), action,
                urllib.parse.quote(str(vod_id)))
            data = json.loads(_fetch_bytes(url, 15, 4 * 1024 * 1024)
                              .decode("utf-8", "replace"))
            info = (data or {}).get("info") or {}
            vid = _yt_id(info.get("youtube_trailer") or info.get("trailer"))
            if vid:
                return vid
        except Exception:
            continue
    return None


def trailer_find(kind, name, year=""):
    """YouTube video id of the title's official trailer, or None.
    Order: the IPTV entry's youtube_trailer, Xtream get_*_info, then a
    YouTube search "<title> <year> official trailer" (yt-dlp)."""
    key = (kind, name)
    if key in _TRAILER_IDS:
        return _TRAILER_IDS[key]
    det = TITLE_DETAILS.get(key) or {}
    vid = _yt_id(det.get("trailer"))
    if not vid and det.get("vod_id") is not None and kind in ("movies",
                                                              "shows"):
        vid = _xtream_vod_trailer(kind, det["vod_id"])
    if not vid and shutil.which("yt-dlp"):
        year = year or det.get("year") or ""
        word = "game trailer" if kind == "games" else "official trailer"
        q = re.sub(r"\s+", " ", "%s %s %s" % (name, year, word)).strip()
        try:
            out = subprocess.run(
                ["yt-dlp", "--no-warnings", "--skip-download", "--get-id",
                 "--no-playlist", "ytsearch1:" + q],
                capture_output=True, text=True, timeout=30).stdout
            vid = _yt_id(out.strip().splitlines()[0] if out.strip() else "")
        except Exception:
            vid = None
    _TRAILER_IDS[key] = vid
    return vid


def trailer_stream_url(vid):
    """Direct (progressive, <=480p) stream URL for the in-card preview."""
    if not vid or not shutil.which("yt-dlp"):
        return None
    try:
        out = subprocess.run(
            ["yt-dlp", "--no-warnings", "-g", "-f",
             "best[height<=480][ext=mp4]/best[height<=480]/best",
             "https://www.youtube.com/watch?v=" + vid],
            capture_output=True, text=True, timeout=40).stdout
        lines = [l for l in out.splitlines() if l.startswith("http")]
        return lines[0] if lines else None
    except Exception:
        return None
