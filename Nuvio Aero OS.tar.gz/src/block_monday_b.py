

# -- look & feel -------------------------------------------------------------
def aero_apply_look(win):
    """Accent colour, panel opacity (frosted cards / tiles) and the
    guide's accent, from the settings. One provider, replaced each time."""
    global _LOOK_PROVIDER, ACCENT
    st = win.settings if win is not None else {}
    acc = mset(st, "aero_accent")
    op = max(0, min(90, int(mset(st, "mon_panel_opacity")))) / 100.0
    ACCENT = _hex_rgb(acc)
    css = """
button.app-tile:focus, button.poster-tile:focus, button.live-tile:focus,
button.mon-live-tile:focus, button.mon-start-item:focus {
    box-shadow: 0 0 0 4px %(acc)s, 0 0 22px %(glow)s; }
.card { background: rgba(255,255,255,%(op).2f); }
button.app-tile:not(.app-tile-icon) { background: rgba(255,255,255,%(op).2f); }
.nv-primary { background: %(acc)s; }
.nv-primary:focus, .nv-primary:hover { background: %(light)s; }
.nv-preview { border-color: %(half)s; }
button.mon-dot { min-width: 12px; min-height: 12px; padding: 0;
    border-radius: 7px; border: none; box-shadow: none;
    background: rgba(255,255,255,0.55); }
button.mon-dot.on { background: %(acc)s; min-width: 30px; }
button.mon-swatch { min-width: 40px; min-height: 40px; padding: 0;
    border-radius: 20px; border: 3px solid rgba(255,255,255,0.7); }
button.mon-swatch.on { border: 4px solid #ffffff;
    box-shadow: 0 0 0 3px %(acc)s; }
.mon-trailer-on { box-shadow: 0 0 0 4px %(acc)s, 0 10px 30px rgba(0,0,0,0.45); }
label.mon-hero-service { color: %(light)s; font-weight: bold; font-size: 22px;
    text-shadow: 0 1px 4px rgba(0,0,0,0.8); }
label.mon-hero-title { color: white; font-weight: bold; font-size: 44px;
    text-shadow: 0 2px 8px rgba(0,0,0,0.85); }
label.mon-hero-sub { color: rgba(255,255,255,0.92); font-size: 19px;
    text-shadow: 0 1px 4px rgba(0,0,0,0.85); }
button.mon-hero-btn { background: %(acc)s; color: white; border: none;
    font-size: 18px; padding: 8px 22px; }
button.mon-hero-btn label { color: white; text-shadow: none; }
button.mon-start-btn { padding: 2px 12px; }
label.mon-start-label { color: #1d2733; font-weight: bold; font-size: 16px; }
popover.mon-start { background: rgba(236,240,246,0.97); border-radius: 22px;
    border: 1px solid rgba(255,255,255,0.9); padding: 16px; }
popover.mon-start label { color: #1d2733; text-shadow: none; }
label.mon-start-head { font-size: 20px; font-weight: bold; color: #1d2733; }
button.mon-start-item { background: rgba(255,255,255,0.85); border-radius: 16px;
    border: 1px solid rgba(160,172,190,0.6); box-shadow: none; padding: 6px; }
button.mon-start-item:hover { background: #ffffff; }
label.mon-start-name { font-size: 14px; color: #1d2733; }
label.mon-guide-head { color: white; font-size: 26px; font-weight: bold; }
""" % {"acc": acc, "glow": _rgba_css(acc, 0.55), "light": _lighter(acc),
       "half": _rgba_css(acc, 0.55), "op": op}
    try:
        prov = Gtk.CssProvider()
        prov.load_from_data(css.encode())
        screen = Gdk.Screen.get_default()
        if _LOOK_PROVIDER is not None:
            Gtk.StyleContext.remove_provider_for_screen(screen, _LOOK_PROVIDER)
        _LOOK_PROVIDER = prov
        Gtk.StyleContext.add_provider_for_screen(
            screen, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 3)
    except Exception:
        pass
    if win is not None:
        try:
            win._backdrop_alloc = (0, 0)
            a = win.backdrop_image.get_allocation()
            if win.backdrop_pixbuf is not None and a.width > 1:
                win._scale_backdrop(a.width, a.height)
            win._update_backdrop_visibility()
            if getattr(win, "epg_view", None) is not None:
                win.epg_render()
                win._nv_apply_prefs()
        except Exception:
            pass


def _l_scale_backdrop(self, width, height):
    """Backdrop: cover-crop + optional blur (down/up-scale) + dim."""
    src = self.backdrop_pixbuf
    if src is None:
        return
    cropped = _cover_crop(src, width, height)
    if cropped is None:
        return
    blur = int(mset(self.settings, "mon_bg_blur"))
    if blur > 0:
        # Smooth blur: halve a few times, then double back up (bilinear
        # at 2x steps never shows blocks).
        steps = 1 + (blur + 1) // 2
        w2, h2, cur = width, height, cropped
        sizes = []
        for _i in range(steps):
            sizes.append((w2, h2))
            w2, h2 = max(4, w2 // 2), max(4, h2 // 2)
            cur = cur.scale_simple(w2, h2, GdkPixbuf.InterpType.BILINEAR)
        for (sw, sh) in reversed(sizes):
            cur = cur.scale_simple(sw, sh, GdkPixbuf.InterpType.BILINEAR)
        cropped = cur
    dim = max(0, min(70, int(mset(self.settings, "mon_bg_dim"))))
    if dim > 0:
        out = cropped.copy()
        black = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, False, 8,
                                     out.get_width(), out.get_height())
        black.fill(0x000000ff)
        black.composite(out, 0, 0, out.get_width(), out.get_height(),
                        0, 0, 1, 1, GdkPixbuf.InterpType.NEAREST,
                        int(255 * dim / 100.0))
        cropped = out
    self.backdrop_image.set_from_pixbuf(cropped)


_orig_update_backdrop_visibility = AltTVLauncher._update_backdrop_visibility


def _l_update_backdrop_visibility(self):
    if mset(self.settings, "mon_bg_mode") == "dynamic" and \
            getattr(self, "_mon_dyn_pb", None) is not None:
        self.backdrop_image.set_visible(True)
        return
    _orig_update_backdrop_visibility(self)


def _l_mon_dynamic_backdrop(self, pb):
    """Background "Dynamic": the backdrop follows the focused title."""
    if pb is None or mset(self.settings, "mon_bg_mode") != "dynamic":
        return
    if getattr(self, "_mon_static_pb", None) is None:
        self._mon_static_pb = self.backdrop_pixbuf
    self._mon_dyn_pb = pb
    self.backdrop_pixbuf = pb
    self._backdrop_alloc = (0, 0)
    a = self.backdrop_image.get_allocation()
    if a.width > 1:
        self._scale_backdrop(a.width, a.height)
    self._update_backdrop_visibility()


def _mon_restore_static_backdrop(win):
    if getattr(win, "_mon_static_pb", None) is not None:
        win.backdrop_pixbuf = win._mon_static_pb
    win._mon_dyn_pb = None
    win._mon_static_pb = None


# -- Settings -> Appearance: Look & feel, Live TV guide, Trailers -------------
def _p_mon_build_settings(self):
    page = self.stack.get_child_by_name("appearance")
    if page is None:
        return
    win = self.launcher
    st = win.settings

    def save(key, value, relook=True):
        st[key] = value
        save_settings(st)
        if relook:
            aero_apply_look(win)

    def heading(text):
        lab = Gtk.Label()
        lab.set_markup("<b>%s</b>" % _esc(text))
        lab.set_halign(Gtk.Align.START)
        lab.set_margin_top(14)
        page.pack_start(lab, False, False, 0)

    def default_btn(cb):
        b = Gtk.Button(label="Default")
        b.connect("clicked", lambda w: cb())
        return b

    def line(label, widget, reset):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        lab = Gtk.Label(label=label)
        lab.set_halign(Gtk.Align.START)
        lab.set_size_request(170, -1)
        lab.set_xalign(0)
        row.pack_start(lab, False, False, 0)
        row.pack_start(widget, True, True, 0)
        if reset is not None:
            row.pack_end(default_btn(reset), False, False, 0)
        page.pack_start(row, False, False, 0)
        return row

    heading("Look & feel")
    # Accent colour swatches
    sw_box = Gtk.FlowBox()
    sw_box.set_selection_mode(Gtk.SelectionMode.NONE)
    sw_box.set_max_children_per_line(8)
    sw_box.set_min_children_per_line(4)
    swatches = []

    def mark_on():
        cur = mset(st, "aero_accent")
        for b, hx in swatches:
            ctx = b.get_style_context()
            (ctx.add_class if hx == cur else ctx.remove_class)("on")
    for name, hx in ACCENT_CHOICES:
        b = Gtk.Button()
        b.get_style_context().add_class("mon-swatch")
        b.set_tooltip_text(name)
        prov = Gtk.CssProvider()
        prov.load_from_data(("button { background: %s; }" % hx).encode())
        b.get_style_context().add_provider(
            prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 4)
        b.connect("clicked", lambda w, h=hx: (win.apply_accent(h),
                                              save("aero_accent", h),
                                              mark_on()))
        swatches.append((b, hx))
        sw_box.add(b)
    mark_on()
    line("Accent colour", sw_box,
         lambda: (win.apply_accent("#e50914"),
                  save("aero_accent", MONDAY_DEFAULTS["aero_accent"]),
                  mark_on()))
    # One accent control: the older Red / Blue / Purple combo is folded
    # into the swatches above (it set the same hero / LIVE accent).
    try:
        old = getattr(self, "accent_combo", None)
        if old is not None:
            for c in page.get_children():
                if isinstance(c, Gtk.Label) and c.get_text() in ("Accent colour", tr("Accent colour")):
                    c.set_no_show_all(True)
                    c.hide()
            old.set_no_show_all(True)
            old.hide()
    except Exception:
        pass

    mode = Gtk.ComboBoxText()
    for key, text in (("static", "Static (your backdrop)"),
                      ("dynamic", "Dynamic (follows the focused title)")):
        mode.append(key, text)
    mode.set_active_id(mset(st, "mon_bg_mode"))

    def mode_changed(c):
        v = c.get_active_id() or "static"
        if v != "dynamic":
            _mon_restore_static_backdrop(win)
        save("mon_bg_mode", v)
    mode.connect("changed", mode_changed)
    line("Background", mode,
         lambda: mode.set_active_id(MONDAY_DEFAULTS["mon_bg_mode"]))

    def slider(label, key, lo, hi, step, fmt):
        sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, lo, hi,
                                      step)
        sc.set_value(float(mset(st, key)))
        sc.set_hexpand(True)
        sc.connect("format-value", lambda s, v: fmt % v)
        state = {"id": None}

        def commit():
            state["id"] = None
            save(key, int(round(sc.get_value())))
            return False

        def changed(s):
            if state["id"]:
                GLib.source_remove(state["id"])
            state["id"] = GLib.timeout_add(350, commit)
        sc.connect("value-changed", changed)
        line(label, sc, lambda: sc.set_value(float(MONDAY_DEFAULTS[key])))
        return sc
    self.mon_blur = slider("Background blur", "mon_bg_blur", 0, 10, 1, "%.0f")
    self.mon_dim = slider("Background dim", "mon_bg_dim", 0, 70, 5, "%.0f%%")
    self.mon_opacity = slider("Panel opacity", "mon_panel_opacity", 0, 90, 5,
                              "%.0f%%")

    heading("Live TV guide")
    prev_sw = Gtk.Switch()
    prev_sw.set_active(bool(mset(st, "mon_guide_preview")))
    prev_sw.set_halign(Gtk.Align.START)
    prev_sw.connect("notify::active",
                    lambda s, p: save("mon_guide_preview", s.get_active()))
    line("Preview panel", prev_sw,
         lambda: prev_sw.set_active(MONDAY_DEFAULTS["mon_guide_preview"]))
    size = Gtk.ComboBoxText()
    for key, text in (("small", "Small"), ("medium", "Medium"),
                      ("large", "Large")):
        size.append(key, text)
    size.set_active_id(mset(st, "mon_guide_preview_size"))
    size.connect("changed", lambda c: save("mon_guide_preview_size",
                                           c.get_active_id() or "medium"))
    line("Preview size", size,
         lambda: size.set_active_id(MONDAY_DEFAULTS["mon_guide_preview_size"]))

    heading("Trailers")
    tr_sw = Gtk.Switch()
    tr_sw.set_active(bool(mset(st, "mon_card_trailers")))
    tr_sw.set_halign(Gtk.Align.START)
    tr_sw.connect("notify::active",
                  lambda s, p: save("mon_card_trailers", s.get_active(), False))
    line("Trailer in the card", tr_sw,
         lambda: tr_sw.set_active(MONDAY_DEFAULTS["mon_card_trailers"]))
    hint = Gtk.Label(label="Rest on a movie or show poster for a moment and "
                           "its trailer plays inside the card, muted. The "
                           "Trailer button on a title's page plays it full "
                           "screen with sound.")
    hint.set_line_wrap(True)
    hint.set_xalign(0)
    hint.set_halign(Gtk.Align.START)
    page.pack_start(hint, False, False, 0)


SettingsPanel._mon_build_settings = _p_mon_build_settings
AltTVLauncher._scale_backdrop = _l_scale_backdrop
AltTVLauncher._update_backdrop_visibility = _l_update_backdrop_visibility
AltTVLauncher._mon_dynamic_backdrop = _l_mon_dynamic_backdrop
