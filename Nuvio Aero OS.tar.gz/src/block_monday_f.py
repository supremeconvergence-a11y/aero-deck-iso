

# -- Aero Start menu (A button, opposite Wingman) -----------------------------
def _l_mon_start_button(self):
    btn = Gtk.Button()
    btn.get_style_context().add_class("ask-nova-btn")
    btn.get_style_context().add_class("mon-start-btn")
    inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    try:
        # The real Aero symbol (A + orbit swish), same size as the
        # Wingman helmet so the bar buttons match.
        mark = self.mark_image("aero-a-blue.png", "#2b6fe3", size=22)
    except Exception:
        mark = Gtk.Label(label="A")
    inner.pack_start(mark, False, False, 0)
    lab = Gtk.Label(label="Apps")
    lab.get_style_context().add_class("wingman-label")
    inner.pack_start(lab, False, False, 0)
    inner.set_halign(Gtk.Align.CENTER)
    btn.add(inner)
    btn.set_tooltip_text("Aero Start menu: Linux Apps / Droid Apps")
    btn.connect("clicked", lambda w: self.mon_open_start_menu())
    self.mon_start_btn = btn
    return btn


def _l_mon_open_start_menu(self):
    btn = self.mon_start_btn
    pop = Gtk.Popover.new(btn)
    pop.set_position(Gtk.PositionType.BOTTOM)
    pop.get_style_context().add_class("mon-start")
    a = self.get_allocation()
    sc = Gtk.ScrolledWindow()
    sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sc.set_propagate_natural_height(True)
    sc.set_min_content_width(min(_dz(a.width) * 0.8, 980) if a.width > 1
                             else 900)
    maxh = int(a.height * 0.72) if a.height > 1 else 560
    sc.set_max_content_height(maxh)
    sc.set_min_content_height(min(maxh, int(a.height * 0.55)) if a.height > 1
                              else 420)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    box.set_margin_start(8)
    box.set_margin_end(8)
    apps = assemble_apps()
    linux = [x for x in apps if x["kind"] in ("linux", "web")]
    droid = [x for x in apps if x["kind"] == "android"]
    first = None
    flows = []
    search = Gtk.SearchEntry()
    search.set_placeholder_text("Search apps")
    search.get_style_context().add_class("mon-start-search")
    for head, items in (("Linux Apps", linux), ("Droid Apps", droid)):
        h = Gtk.Label(label=head)
        h.get_style_context().add_class("mon-start-head")
        h.set_halign(Gtk.Align.START)
        box.pack_start(h, False, False, 4)
        flow = Gtk.FlowBox()
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_max_children_per_line(6)
        flow.set_min_children_per_line(3)
        flow.set_homogeneous(True)
        flow.set_column_spacing(12)
        flow.set_row_spacing(12)
        for app in items:
            b = Gtk.Button()
            b.get_style_context().add_class("mon-start-item")
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            icon = None
            try:
                icon = self.load_app_icon(app["name"], app["target"],
                                          app["kind"], width=112, height=80,
                                          icon_name=app.get("icon", ""))
            except Exception:
                icon = None
            if icon is not None:
                v.pack_start(CoverImage(icon, 112, 80), False, False, 0)
            else:
                ll = Gtk.Label()
                ll.set_markup("<span size='xx-large' weight='bold' "
                              "color='%s'>%s</span>" % (
                                  _esc(app.get("colour") or "#2b6fe3"),
                                  _esc(app.get("letter") or "?")))
                ll.set_size_request(112, 80)
                v.pack_start(ll, False, False, 0)
            nl = Gtk.Label(label=app["name"])
            nl.get_style_context().add_class("mon-start-name")
            nl.set_ellipsize(3)
            nl.set_max_width_chars(14)
            v.pack_start(nl, False, False, 0)
            b.add(v)
            b._mon_name = app["name"].lower()
            b.connect("clicked", lambda w, ap=app: (
                pop.popdown(), self.on_open_app(
                    w, ap["kind"], ap["target"], ap["fallback"], ap["name"])))
            flow.add(b)
            first = first or b
        if not items:
            e = Gtk.Label(label="Nothing here yet." if head == "Linux Apps"
                          else "Android apps you install (Aurora Store, "
                               "Downloader) show up here.")
            e.set_halign(Gtk.Align.START)
            box.pack_start(e, False, False, 0)
        else:
            box.pack_start(flow, False, False, 0)
            flows.append(flow)

    def match(child):
        q = search.get_text().strip().lower()
        b = child.get_child()
        return not q or q in getattr(b, "_mon_name", "")
    for f in flows:
        f.set_filter_func(match)
    search.connect("search-changed",
                   lambda e: [f.invalidate_filter() for f in flows])
    sc.add(box)
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    search.set_margin_start(8)
    search.set_margin_end(8)
    search.set_margin_top(6)
    outer.pack_start(search, False, False, 0)
    outer.pack_start(sc, True, True, 0)
    pop.add(outer)
    pop.show_all()
    pop.popup()
    if first is not None:
        GLib.idle_add(lambda: (first.grab_focus(), False)[1])
    self.mon_start_pop = pop


_orig_nav_bar_open = AltTVLauncher._nav_bar_open


def _l_nav_bar_open_mon(self, widget, event):
    try:
        b = self.mon_start_btn
        pos = b.translate_coordinates(widget, 0, 0)
        al = b.get_allocation()
        if pos is not None and pos[0] <= event.x < pos[0] + al.width and \
                pos[1] <= event.y < pos[1] + al.height:
            return False      # the Start button handles its own click
    except Exception:
        pass
    return _orig_nav_bar_open(self, widget, event)


# -- App tiles: long-press / right-click menu, Remove from home ---------------
_orig_options_for_app = AltTVLauncher.options_for_app
_orig_on_option_chosen = AltTVLauncher.on_option_chosen
_orig_build_row_apps = AltTVLauncher.build_row_apps


def _l_options_for_app_mon(self, app):
    opts = list(_orig_options_for_app(self, app))
    i = 1 if opts and opts[0][1] == "move" else 0
    opts.insert(i, ("Remove from home", "remove"))
    return opts


def _l_on_option_chosen_mon(self, widget, action):
    if action != "remove":
        return _orig_on_option_chosen(self, widget, action)
    app = self.options_app
    self.close_options_panel(restore=False)
    if app is None:
        return
    hidden = list(load_apps_hidden())
    if app["key"] not in hidden:
        hidden.append(app["key"])
        save_apps_hidden(hidden)
    try:
        play_ui_sound("click")
    except Exception:
        pass
    GLib.idle_add(lambda: (self.build_rows(), False)[1])


def _l_build_row_apps_mon(self):
    section = _orig_build_row_apps(self)
    for btn in getattr(self, "app_tile_buttons", []):
        g = Gtk.GestureLongPress.new(btn)
        g.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        g.set_touch_only(False)

        def pressed(gest, x, y, b=btn):
            gest.set_state(Gtk.EventSequenceState.CLAIMED)
            self.open_options_panel(b._app, b)
        g.connect("pressed", pressed)
        btn._mon_lp = g
        btn.connect("button-press-event", lambda b, e: (
            self.open_options_panel(b._app, b), True)[1]
            if e.button == 3 else False)
    return section


# -- Remote (G10S etc.): Play/Pause, Home, Search/voice ------------------------
_orig_on_key_mon = AltTVLauncher.on_key
_VOICE_KEYS = {getattr(Gdk, n) for n in ("KEY_Search", "KEY_Voice",
                                         "KEY_AudioMicMute")
               if hasattr(Gdk, n)}


def _l_on_key_mon(self, widget, event):
    k = event.keyval
    play_keys = {getattr(Gdk, n) for n in ("KEY_AudioPlay", "KEY_AudioPause",
                                           "KEY_AudioMedia") if hasattr(Gdk, n)}
    if k in play_keys:
        if getattr(self, "player_open", False):
            self.player_toggle_pause()
            return True
        return False
    if k == getattr(Gdk, "KEY_HomePage", -1):
        try:
            if getattr(self, "epg_open", False):
                self.close_epg()
            if self.panel_open:
                self.close_settings_panel()
        except Exception:
            pass
        self.back_to_aero()
        return True
    if k in _VOICE_KEYS and not self.kb_visible:
        self.on_voice_button()
        return True
    return _orig_on_key_mon(self, widget, event)


def _l_on_voice_button_mon(self):
    """Remote mic / Search key: Aero voice search (Navigator + dictation
    from the default microphone -- the G10S USB dongle mic is made the
    default source by WirePlumber). Finds channels, apps and titles."""
    try:
        if self.panel_open:
            self.close_settings_panel()
        if getattr(self, "epg_open", False):
            self.close_epg()
        self.show_keyboard(self.search_entry)
        GLib.timeout_add(300, lambda: (self.kb.toggle_dictation(), False)[1])
    except Exception:
        pass


# -- Cloud gaming row: native apps first, Chrome web apps as fallback ---------
CLOUD_LAUNCH = {
    "GeForce Now": "aero-gfn",
    "Boosteroid": "aero-boosteroid",
    "Xbox Cloud Gaming": "aero-webapp xbox",
    "Amazon Luna": "aero-webapp luna",
}


def _l_on_open_cloud_mon(self, widget, name, url):
    cmd = CLOUD_LAUNCH.get(name)
    if cmd and _spawn(cmd.split()):
        return
    open_url(url)


_orig_stage1_install_mon = AltTVLauncher._stage1_install


def _l_stage1_install_mon(self):
    _orig_stage1_install_mon(self)
    aero_apply_look(self)
    try:
        import signal
        global _SIGUSR2_SRC
        if _SIGUSR2_SRC:
            GLib.source_remove(_SIGUSR2_SRC)
        _SIGUSR2_SRC = GLib.unix_signal_add(
            GLib.PRIORITY_DEFAULT, signal.SIGUSR2,
            lambda: (self.present(), self.on_voice_button(), True)[2])
    except Exception:
        pass


for _n, _f in (("_mon_start_button", _l_mon_start_button),
               ("mon_open_start_menu", _l_mon_open_start_menu),
               ("_nav_bar_open", _l_nav_bar_open_mon),
               ("options_for_app", _l_options_for_app_mon),
               ("on_option_chosen", _l_on_option_chosen_mon),
               ("build_row_apps", _l_build_row_apps_mon),
               ("on_key", _l_on_key_mon),
               ("on_voice_button", _l_on_voice_button_mon),
               ("on_open_cloud", _l_on_open_cloud_mon),
               ("_stage1_install", _l_stage1_install_mon)):
    setattr(AltTVLauncher, _n, _f)
