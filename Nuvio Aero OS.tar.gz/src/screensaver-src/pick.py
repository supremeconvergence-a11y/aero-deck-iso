import json, urllib.request, urllib.parse, re, time, sys
API="https://commons.wikimedia.org/w/api.php"
UA={"User-Agent":"AeroDeckBuild/1.0 (personal project; screensaver picker)"}
Q={
 "wildlife":["incategory:Quality_images wildlife animal portrait", "Featured picture deer forest", "Featured picture fox snow","Featured picture humpback whale breach", "Featured picture moose"],
 "cities":["Featured picture city skyline night","Featured picture Toronto skyline","Featured picture New York skyline","Featured picture Montreal skyline","Featured picture Vancouver skyline"],
 "tropical":["Featured picture tropical beach palm","Featured picture Maldives","Featured picture Bora Bora lagoon","Featured picture Caribbean beach","Featured picture coral reef"],
 "mountains":["Featured picture Moraine Lake","Featured picture alps panorama","Featured picture Mount Rainier","Featured picture Matterhorn","Featured picture Rocky Mountains lake"],
 "nova-scotia":["Peggy's Cove lighthouse","Cabot Trail Cape Breton","Halifax waterfront Nova Scotia","Lunenburg Nova Scotia harbour","Bay of Fundy Hopewell"],
 "canada":["Featured picture Banff","Featured picture Niagara Falls","Featured picture Quebec City","Featured picture aurora borealis Yukon","Featured picture Lake Louise"],
 "usa":["Featured picture Grand Canyon","Featured picture Yosemite valley","Featured picture Golden Gate Bridge","Featured picture Monument Valley","Featured picture Arches National Park"],
}
OK=re.compile(r"^(CC0|CC BY(-SA)? [0-9.]+|Public domain|PD.*|CC BY [0-9.]+)$",re.I)
def api(**p):
    p.update(format="json")
    r=urllib.request.Request(API+"?"+urllib.parse.urlencode(p),headers=UA)
    return json.load(urllib.request.urlopen(r,timeout=30))
out={}
seen=set()
for cat,qs in Q.items():
    picks=[]
    for q in qs:
        if len(picks)>=5: break
        d=api(action="query",generator="search",gsrsearch=q+" filetype:bitmap",gsrnamespace=6,gsrlimit=12,
              prop="imageinfo",iiprop="url|size|extmetadata|mime",iiurlwidth=1920)
        pages=sorted((d.get("query",{}).get("pages",{}) or {}).values(),key=lambda p:p.get("index",0))
        for p in pages:
            ii=(p.get("imageinfo") or [{}])[0]
            if ii.get("mime")!="image/jpeg": continue
            w,h=ii.get("width",0),ii.get("height",0)
            if w<1920 or h<1000 or not (1.3<=w/h<=2.0): continue
            md=ii.get("extmetadata",{})
            lic=md.get("LicenseShortName",{}).get("value","")
            if not OK.match(lic.strip()): continue
            if p["title"] in seen: continue
            art=re.sub("<[^>]+>","",md.get("Artist",{}).get("value","")).strip()
            picks.append({"title":p["title"],"thumb":ii.get("thumburl"),"page":ii.get("descriptionurl"),"license":lic,"author":art[:80]})
            seen.add(p["title"])
            break  # one per query for variety
        time.sleep(0.3)
    out[cat]=picks
    print(cat,len(picks),[x["title"] for x in picks],file=sys.stderr)
json.dump(out,open("screensaver.json","w"),indent=1)
