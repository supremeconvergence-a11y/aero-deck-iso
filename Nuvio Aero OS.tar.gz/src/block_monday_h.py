

# ===========================================================================
# Aero OS Monday Night (2): French / Spanish menus + EPUB pictures
# ===========================================================================
# Flight Deck -> Language picks English / French / Spanish for Aero's own
# menus (Aero restarts in ~2 s). Strings live in i18n/strings.tsv
# (English <TAB> French <TAB> Spanish); anything not in the table stays in
# English. Settings values (combo choices etc.) are never translated, so
# nothing that compares text breaks.
_I18N = {}
_I18N_EN = {
    "Aero Deck's own menus are English-only for now. This sets the "
    "language websites, the browser and apps you open from here ask for.":
    "Aero Deck's menus follow this language (Aero restarts in about 2 s). "
    "It also sets the language websites, the browser and apps you open "
    "from here ask for.",
}
_LANG_COL = {"French": 1, "Spanish": 2}


def _i18n_load():
    try:
        lang = (load_settings() or {}).get("language", "English")
    except Exception:
        lang = "English"
    col = _LANG_COL.get(lang)
    if not col:
        return
    for d in (ASSETS_DIR.parent / "i18n", Path(__file__).resolve().parent / "i18n",
              Path("/usr/local/share/aero-deck/i18n")):
        f = d / "strings.tsv"
        if f.is_file():
            for line in f.read_text(encoding="utf-8").splitlines():
                parts = line.split("\t")
                if len(parts) == 3 and parts[0] and parts[col]:
                    _I18N[parts[0]] = parts[col]
            break


def tr(s):
    if not isinstance(s, str) or not s:
        return s
    if not _I18N:
        return _I18N_EN.get(s, s)
    t = _I18N.get(s)
    if t is not None:
        return t
    st = s.strip()
    if st != s and st in _I18N:
        return s.replace(st, _I18N[st])
    return _I18N_EN.get(s, s)


def _tr_markup(m):
    if not isinstance(m, str) or "<" not in m:
        return tr(m)
    return re.sub(r">([^<>]+)<", lambda g: ">" + tr(g.group(1)) + "<", m)


_i18n_load()


def _i18n_patch():
    def wrap_init(cls):
        orig = cls.__init__

        def init(self, *a, **kw):
            if "label" in kw:
                kw["label"] = tr(kw["label"])
            elif a and isinstance(a[0], str):
                a = (tr(a[0]),) + tuple(a[1:])
            orig(self, *a, **kw)
        cls.__init__ = init

    def wrap_m(cls, name, fn=tr):
        orig = getattr(cls, name)

        def m(self, s, *a):
            return orig(self, fn(s), *a)
        setattr(cls, name, m)
    for cls in (Gtk.Label, Gtk.Button, Gtk.CheckButton, Gtk.ToggleButton):
        wrap_init(cls)
    wrap_m(Gtk.Label, "set_text")
    wrap_m(Gtk.Label, "set_label")
    wrap_m(Gtk.Label, "set_markup", _tr_markup)
    wrap_m(Gtk.Button, "set_label")
    wrap_m(Gtk.Widget, "set_tooltip_text")
    wrap_m(Gtk.Entry, "set_placeholder_text")
    orig_rb = Gtk.RadioButton.new_with_label_from_widget

    def rb(group, label):
        return orig_rb(group, tr(label))
    Gtk.RadioButton.new_with_label_from_widget = staticmethod(rb)


if _I18N:
    _i18n_patch()


def _l_on_language_changed_mon(self, combo):
    before = self.launcher.settings.get("language", "English")
    _orig_on_language_changed(self, combo)
    after = self.launcher.settings.get("language", "English")
    if after != before:
        save_settings(self.launcher.settings)
        try:
            _l_show_toast_safe(self.launcher,
                               "Language: %s -- Aero restarts…" % after)
        except Exception:
            pass
        GLib.timeout_add(1500, lambda: (Gtk.main_quit(), False)[1])


_orig_on_language_changed = SettingsPanel.on_language_changed


def _l_x_language_mon(self):
    page = self._page("language")
    page.pack_start(self._xlabel(
        "Aero Deck's menus follow this language (Aero restarts in about "
        "2 s). It also sets the language websites, the browser and apps "
        "you open from here ask for."), False, False, 0)
    self._apply_language(self.launcher.settings.get("language", "English"))


SettingsPanel._x_language = _l_x_language_mon
SettingsPanel.on_language_changed = _l_on_language_changed_mon


# -- EPUB pictures -------------------------------------------------------------
def epub_content(path):
    """[(chapter title, [("text", str) | ("img", bytes)])] in reading order.
    Pictures (<img>, SVG <image>) come out where they sit in the text."""
    import zipfile
    import html.parser
    import posixpath
    z = zipfile.ZipFile(path)
    cont = z.read("META-INF/container.xml").decode("utf-8", "replace")
    opf_path = re.search(r'full-path="([^"]+)"', cont).group(1)
    opf = z.read(opf_path).decode("utf-8", "replace")
    base = posixpath.dirname(opf_path)
    manifest = dict(re.findall(
        r'<item\b[^>]*?id="([^"]+)"[^>]*?href="([^"]+)"', opf))
    manifest.update({i: h for h, i in re.findall(
        r'<item\b[^>]*?href="([^"]+)"[^>]*?id="([^"]+)"', opf)})
    spine = re.findall(r'<itemref\b[^>]*?idref="([^"]+)"', opf)

    class P(html.parser.HTMLParser):
        BLOCK = {"p", "div", "br", "h1", "h2", "h3", "h4", "li", "tr",
                 "section", "blockquote"}

        def __init__(self, here):
            super().__init__()
            self.here = here
            self.segs, self.buf, self.skip, self.title = [], [], 0, ""
            self.in_h = False

        def _flush(self):
            if self.buf:
                self.segs.append(("text", "".join(self.buf)))
                self.buf = []

        def handle_starttag(self, tag, a):
            if tag in ("script", "style", "head"):
                self.skip += 1
            if tag in self.BLOCK:
                self.buf.append("\n")
            if tag in ("h1", "h2", "h3"):
                self.in_h = True
            if tag in ("img", "image") and not self.skip:
                ad = dict(a)
                src = ad.get("src") or ad.get("xlink:href") or ad.get("href")
                if src and not src.startswith(("http:", "https:", "data:")):
                    p = posixpath.normpath(posixpath.join(
                        self.here, urllib.parse.unquote(src.split("#")[0])))
                    try:
                        data = z.read(p)
                        if len(data) < 15 * 1024 * 1024:
                            self._flush()
                            self.segs.append(("img", data))
                    except KeyError:
                        pass

        def handle_endtag(self, tag):
            if tag in ("script", "style", "head"):
                self.skip = max(0, self.skip - 1)
            if tag in self.BLOCK:
                self.buf.append("\n")
            if tag in ("h1", "h2", "h3"):
                self.in_h = False

        def handle_data(self, d):
            if self.skip:
                return
            if self.in_h and not self.title:
                self.title = d.strip()
            self.buf.append(d)

    chapters = []
    for idref in spine:
        href = manifest.get(idref)
        if not href:
            continue
        full = posixpath.normpath(posixpath.join(base,
                                                 urllib.parse.unquote(href)))
        try:
            raw = z.read(full).decode("utf-8", "replace")
        except KeyError:
            continue
        p = P(posixpath.dirname(full))
        p.feed(raw)
        p._flush()
        segs = []
        for kind, v in p.segs:
            if kind == "text":
                v = re.sub(r"[ \t\r\f\v]+", " ", v)
                v = re.sub(r"\n\s*\n\s*(\n\s*)+", "\n\n", v)
                if v.strip():
                    segs.append(("text", v))
            else:
                segs.append((kind, v))
        if segs:
            chapters.append((p.title or "Chapter %d" % (len(chapters) + 1),
                             segs))
    return chapters


def _epub_pixbuf(data, max_w, max_h):
    try:
        loader = GdkPixbuf.PixbufLoader()
        loader.write(data)
        loader.close()
        pb = loader.get_pixbuf()
    except Exception:
        return None
    if pb is None:
        return None
    w, h = pb.get_width(), pb.get_height()
    sc = min(1.0, max_w / float(w), max_h / float(h))
    if sc < 1.0:
        pb = pb.scale_simple(max(1, int(w * sc)), max(1, int(h * sc)),
                             GdkPixbuf.InterpType.BILINEAR)
    return pb


def _l_open_book_mon(self, path):
    _orig_open_book(self, path)
    if getattr(self, "kind", "") != "text" or \
            not str(path).lower().endswith(".epub"):
        return
    try:
        chapters = epub_content(path)
    except Exception:
        return
    if not any(k == "img" for _h, segs in chapters for k, _v in segs):
        return       # text-only book: the plain view is already right
    a = self.text_view.get_allocation()
    W = (a.width if a.width > 100 else self.get_allocated_width() or 1280)
    H = (a.height if a.height > 100 else self.get_allocated_height() or 800)
    max_w, max_h = max(200, W - 200), max(200, int(H * 0.8))
    buf = self.text_view.get_buffer()
    buf.set_text("")
    ctag = buf.get_tag_table().lookup("epub-img") or buf.create_tag(
        "epub-img", justification=Gtk.Justification.CENTER)
    it = buf.get_end_iter()
    first = True
    for title, segs in chapters:
        joined = "".join(v for k, v in segs if k == "text").lstrip()
        if not first:
            buf.insert(it, "\n\n\n")
        first = False
        if not joined.startswith(title):
            buf.insert(it, title + "\n\n")
        for kind, v in segs:
            if kind == "text":
                buf.insert(it, v)
            else:
                pb = _epub_pixbuf(v, max_w, max_h)
                if pb is not None:
                    buf.insert(it, "\n")
                    mark = buf.create_mark(None, it, True)
                    buf.insert_pixbuf(it, pb)
                    buf.insert(it, "\n")
                    buf.apply_tag(ctag, buf.get_iter_at_mark(mark), it)
                    buf.delete_mark(mark)
    self._epub_has_images = True


_orig_open_book = ReaderWindow.open_book
ReaderWindow.open_book = _l_open_book_mon
