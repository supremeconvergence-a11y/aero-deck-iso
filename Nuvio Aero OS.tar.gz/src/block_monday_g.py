

# ===========================================================================
# Aero OS Monday Night (2): docked / floating keyboard
# ===========================================================================
# Centred (default, Andrew Nov 23 6:58 PM): the full key grid pops up in
# the middle of the screen; the panel being typed in moves above it.
# Search boxes get the Fire TV-style search keyboard instead (query and
# live results inside the keyboard panel) -- see popup_for.
# Docked: full-width bar at the bottom like the Steam Deck
# keyboard, keys fitted (centred, never stretched past ~1400 px design),
# height adjustable (drag the top bar or use the ▲ ▼ keys), and the panel
# being typed in moves up so the field stays visible.
# Floating: a small keyboard you drag by its top bar and resize from the
# corner; it remembers its size and place. The ⇱ / ⇲ key switches modes.
# Fields in other windows (reader, dialogs) keep the old drop-down.
MONDAY_DEFAULTS.update({"kb_mode": "centered", "kb_dock_frac": 0.40,
                        "kb_float_x": -1, "kb_float_y": -1,
                        "kb_float_w": 0})

_OrigEntryKeyboard = EntryKeyboard


def _R(v):
    """Real px (from allocations / getters) -> design px for the setters,
    which scale by UI_SCALE themselves."""
    try:
        return _dz(v) if v > 0 else v
    except Exception:
        return v


class DockKeyboard(_OrigEntryKeyboard):

    def __init__(self, launcher):
        super().__init__(launcher)
        self.card = self.get_child()
        self._lifted = None          # (widget, old margin_bottom)
        self._in_host = False
        host = Gtk.EventBox()
        host.get_style_context().add_class("mon-kb-host")
        host.set_no_show_all(True)
        host.connect("key-press-event", self._on_key)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.get_style_context().add_class("mon-kb-bar")
        self.grip = Gtk.EventBox()
        gl = Gtk.Label(label="⠿  " + tr("Keyboard"))
        gl.get_style_context().add_class("mon-kb-grip")
        self.grip.add(gl)
        bar.pack_start(self.grip, True, True, 0)
        self.up_btn = Gtk.Button(label="▲")
        self.down_btn = Gtk.Button(label="▼")
        self.mode_btn = Gtk.Button()
        hide_btn = Gtk.Button(label=tr("Hide") + " ▾")
        for b in (self.up_btn, self.down_btn, self.mode_btn, hide_btn):
            b.get_style_context().add_class("mon-kb-tool")
            b.set_can_focus(True)
            bar.pack_end(b, False, False, 0)
        hide_btn.connect("clicked", lambda b: self.popdown())
        self.mode_btn.connect("clicked", lambda b: self.toggle_mode())
        self.up_btn.connect("clicked", lambda b: self._bump_height(+0.05))
        self.down_btn.connect("clicked", lambda b: self._bump_height(-0.05))
        col.pack_start(bar, False, False, 0)
        self.slot = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        col.pack_start(self.slot, True, True, 0)
        self.resize = Gtk.EventBox()
        rl = Gtk.Label(label="◢")
        rl.get_style_context().add_class("mon-kb-resize")
        self.resize.add(rl)
        self.resize.set_halign(Gtk.Align.END)
        col.pack_start(self.resize, False, False, 0)
        host.add(col)
        self.host = host
        self._col = col
        # Drag (move / docked height) and resize gestures.
        self._g_move = Gtk.GestureDrag.new(self.grip)
        self._g_move.connect("drag-begin", self._drag_begin)
        self._g_move.connect("drag-update", self._drag_update)
        self._g_move.connect("drag-end", lambda g, x, y: save_settings(
            self.launcher.settings))
        self._g_size = Gtk.GestureDrag.new(self.resize)
        self._g_size.connect("drag-begin", self._size_begin)
        self._g_size.connect("drag-update", self._size_update)
        self._g_size.connect("drag-end", lambda g, x, y: save_settings(
            self.launcher.settings))

    # -- mode / geometry -----------------------------------------------------
    def mode(self):
        m = mset(self.launcher.settings, "kb_mode")
        return m if m in ("centered", "docked", "floating") else "centered"

    def _win(self):
        a = self.launcher.get_allocation()
        return max(a.width, 320), max(a.height, 240)

    def _apply_geometry(self):
        W, H = self._win()
        st = self.launcher.settings
        mode = self.mode()
        nxt = {"centered": "⇲ " + tr("Dock"), "docked": "⇱ " + tr("Float"),
               "floating": "⊡ " + tr("Centre")}[mode]
        if mode == "centered":
            w = min(W - 24, int(W * 0.72), int(1400 * UI_SCALE))
            h = int(H * 0.50)
            self.host.set_halign(Gtk.Align.CENTER)
            self.host.set_valign(Gtk.Align.CENTER)
            self.host.set_margin_start(0)
            self.host.set_margin_top(0)
            self.host.set_size_request(_R(w), _R(h))
            self.card.set_size_request(-1, -1)
            self.card.set_halign(Gtk.Align.FILL)
            self.up_btn.hide()
            self.down_btn.hide()
            self.resize.hide()
            ctx = self.host.get_style_context()
            ctx.add_class("mon-kb-floating")
            ctx.remove_class("mon-kb-docked")
            # the panel being typed in sits above the keyboard
            self._dock_h = (H + h) // 2
        elif mode == "docked":
            h = int(H * max(0.25, min(0.6, float(mset(st, "kb_dock_frac")))))
            self.host.set_halign(Gtk.Align.FILL)
            self.host.set_valign(Gtk.Align.END)
            self.host.set_margin_start(0)
            self.host.set_margin_top(0)
            self.host.set_size_request(-1, _R(h))
            self.card.set_size_request(_R(min(W - 24, int(1400 * UI_SCALE))), -1)
            self.card.set_halign(Gtk.Align.CENTER)
            self.up_btn.show()
            self.down_btn.show()
            self.resize.hide()
            self.host.get_style_context().add_class("mon-kb-docked")
            self.host.get_style_context().remove_class("mon-kb-floating")
            self._dock_h = h
        else:
            w = int(st.get("kb_float_w") or 0) or int(W * 0.48)
            w = max(360, min(W, w))
            x, y = int(st.get("kb_float_x", -1)), int(st.get("kb_float_y", -1))
            if x < 0 or y < 0:
                x, y = (W - w) // 2, int(H * 0.40)
            x = max(0, min(W - 120, x))
            y = max(0, min(H - 80, y))
            self.host.set_halign(Gtk.Align.START)
            self.host.set_valign(Gtk.Align.START)
            self.host.set_margin_start(_R(x))
            self.host.set_margin_top(_R(y))
            self.host.set_size_request(_R(w), -1)
            self.card.set_size_request(-1, -1)
            self.card.set_halign(Gtk.Align.FILL)
            self.up_btn.hide()
            self.down_btn.hide()
            self.resize.show_all()
            self.host.get_style_context().add_class("mon-kb-floating")
            self.host.get_style_context().remove_class("mon-kb-docked")
            self._dock_h = 0
        self.mode_btn.set_label(nxt)
        homog = mode in ("docked", "centered")
        self.grid.set_row_homogeneous(homog)
        self.grid.set_vexpand(homog)

    def toggle_mode(self):
        self.launcher.settings["kb_mode"] = {
            "centered": "docked", "docked": "floating",
            "floating": "centered"}[self.mode()]
        save_settings(self.launcher.settings)
        if self.is_open() and self.entry is not None:
            e = self.entry
            self.popdown()
            self.popup_for(e)

    def _bump_height(self, d):
        st = self.launcher.settings
        st["kb_dock_frac"] = round(max(0.25, min(0.6, float(
            mset(st, "kb_dock_frac")) + d)), 2)
        save_settings(st)
        self._apply_geometry()
        self._lift()

    def _drag_begin(self, g, x, y):
        self._d0 = (self.host.get_margin_start(), self.host.get_margin_top(),
                    float(mset(self.launcher.settings, "kb_dock_frac")))

    def _drag_update(self, g, dx, dy):
        W, H = self._win()
        st = self.launcher.settings
        x0, y0, f0 = getattr(self, "_d0", (0, 0, 0.4))
        if self.mode() == "docked":
            st["kb_dock_frac"] = round(max(0.25, min(0.6, f0 - dy / H)), 3)
            self._apply_geometry()
            self._lift()
        else:
            st["kb_float_x"] = int(max(0, min(W - 120, x0 + dx)))
            st["kb_float_y"] = int(max(0, min(H - 80, y0 + dy)))
            self.host.set_margin_start(_R(st["kb_float_x"]))
            self.host.set_margin_top(_R(st["kb_float_y"]))

    def _size_begin(self, g, x, y):
        self._s0 = self.host.get_allocated_width()

    def _size_update(self, g, dx, dy):
        W, _H = self._win()
        st = self.launcher.settings
        st["kb_float_w"] = int(max(360, min(W, getattr(self, "_s0", 600) + dx)))
        self.host.set_size_request(_R(st["kb_float_w"]), -1)

    # -- the panel being typed in moves up ------------------------------------
    def _overlay_child_of(self, w):
        ov = self.launcher.overlay
        while w is not None and w.get_parent() is not None:
            if w.get_parent() is ov:
                return w
            w = w.get_parent()
        return None

    def _unlift(self):
        if self._lifted is not None:
            w, old = self._lifted[0], self._lifted[1]
            try:
                w.set_margin_bottom(_R(old))
            except Exception:
                pass
        self._unshrink()
        self._lifted = None

    def _unshrink(self):
        for wd, req in getattr(self, "_shrunk", []):
            try:
                wd.set_size_request(*[_R(v) for v in req])
            except Exception:
                pass
        self._shrunk = []

    def _lift(self):
        e = self.entry
        h = getattr(self, "_dock_h", 0)
        if h and self.host.get_visible() and self.mode() == "docked":
            h = max(h, self.host.get_allocated_height())
        if e is None:
            return
        top = self._overlay_child_of(e)
        if self._lifted is not None and self._lifted[0] is not top:
            self._unlift()
        if top is not None and top is not getattr(self.launcher, "main", None):
            if self._lifted is None:
                self._lifted = (top, top.get_margin_bottom())
            top.set_margin_bottom(_R(self._lifted[1] + h))
            # Never push the panel's top off the screen: shrink it (its
            # content scrolls) so it fits above the keyboard.
            _W, H = self._win()
            room = max(160, H - h - self._lifted[1] - top.get_margin_top() - 8)
            self._unshrink()
            if h:
                ws = [top]
                if isinstance(top, Gtk.Bin) and top.get_child() is not None:
                    ws.append(top.get_child())
                for wd in ws:
                    rw, rh = wd.get_size_request()
                    if rh > room or (wd is top and
                                     top.get_allocated_height() > room):
                        self._shrunk.append((wd, (rw, rh)))
                        wd.set_size_request(_R(rw), _R(room))
        GLib.timeout_add(260, self._scroll_entry_into_view)

    def _scroll_entry_into_view(self):
        e = self.entry
        if e is None:
            return False
        p = e.get_parent()
        while p is not None and not isinstance(p, Gtk.ScrolledWindow):
            p = p.get_parent()
        if p is None:
            return False
        try:
            child = p.get_child()
            r = e.translate_coordinates(child, 0, 0)
            if r is None:
                return False
            y = r[1]
            adj = p.get_vadjustment()
            page = adj.get_page_size()
            if y < adj.get_value() or y + e.get_allocated_height() > \
                    adj.get_value() + page:
                adj.set_value(max(0, min(adj.get_upper() - page,
                                         y - page / 3)))
        except Exception:
            pass
        return False

    # -- show / hide -------------------------------------------------------
    def _move_card_to_host(self):
        if self._in_host:
            return
        if self.card.get_parent() is self:
            self.remove(self.card)
        self.slot.pack_start(self.card, True, True, 0)
        self._in_host = True

    def _move_card_to_popover(self):
        if not self._in_host:
            return
        self.slot.remove(self.card)
        self.add(self.card)
        self._in_host = False

    def popup_for(self, entry):
        if entry is None:
            return
        if entry.get_toplevel() is not self.launcher:
            self.host.hide()
            self._move_card_to_popover()
            return super().popup_for(entry)
        self.entry = entry
        self._move_card_to_host()
        ov = self.launcher.overlay
        if self.host.get_parent() is ov:
            ov.remove(self.host)
        ov.add_overlay(self.host)
        try:
            ov.set_overlay_pass_through(self.host, False)
        except Exception:
            pass
        self._apply_geometry()
        self.host.show()
        self._col.show()
        for wdg in self._col.get_children():
            wdg.show_all()
        self.voice_label.set_visible(bool(self.voice_label.get_text()))
        docked = self.mode() == "docked"
        self.resize.set_visible(self.mode() == "floating")
        self.up_btn.set_visible(docked)
        self.down_btn.set_visible(docked)
        self._lift()
        # once the keyboard has its real height, fit the panel to it
        GLib.timeout_add(220, lambda: (self._lift()
                                       if self.host.get_visible() else None,
                                       False)[1])
        if self.first_key is not None:
            self.first_key.grab_focus()

    def popdown(self):
        if self._in_host:
            was = self.host.get_visible()
            self.host.hide()
            self._unlift()
            if was:
                self._on_closed(self)
            return
        super().popdown()

    def is_open(self):
        return self.host.get_visible() or super().is_open()


EntryKeyboard = DockKeyboard


def _l_build_keyboard_page_mon(self):
    _orig_build_keyboard_page(self)
    page = self.stack.get_child_by_name("keyboard")
    if page is None:
        return
    st = self.launcher.settings
    head = Gtk.Label(label=tr("Keyboard style"))
    head.set_halign(Gtk.Align.START)
    head.get_style_context().add_class("mon-set-head")
    page.pack_start(head, False, False, 6)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    rb_c = Gtk.RadioButton.new_with_label_from_widget(
        None, tr("Centred (full keys, middle of the screen)"))
    rb_d = Gtk.RadioButton.new_with_label_from_widget(
        rb_c, tr("Docked (full width at the bottom)"))
    rb_f = Gtk.RadioButton.new_with_label_from_widget(
        rb_d, tr("Floating (drag and resize)"))
    cur = mset(st, "kb_mode")
    {"floating": rb_f, "docked": rb_d}.get(cur, rb_c).set_active(True)

    def setm(rb, m):
        if rb.get_active():
            st["kb_mode"] = m
            save_settings(st)
    rb_c.connect("toggled", setm, "centered")
    rb_d.connect("toggled", setm, "docked")
    rb_f.connect("toggled", setm, "floating")
    row.pack_start(rb_c, False, False, 0)
    row.pack_start(rb_d, False, False, 0)
    row.pack_start(rb_f, False, False, 0)
    page.pack_start(row, False, False, 0)
    hl = Gtk.Label(label=tr("Docked keyboard height"))
    hl.set_halign(Gtk.Align.START)
    page.pack_start(hl, False, False, 0)
    hrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 25, 60, 1)
    sc.set_value(float(mset(st, "kb_dock_frac")) * 100)
    sc.connect("format-value", lambda s, v: "%d%%" % v)

    def seth(s):
        st["kb_dock_frac"] = round(s.get_value() / 100.0, 2)
        save_settings(st)
    sc.connect("value-changed", seth)
    hrow.pack_start(sc, True, True, 0)
    dflt = Gtk.Button(label=tr("Default"))

    def reset(b):
        for k in ("kb_mode", "kb_dock_frac", "kb_float_x", "kb_float_y",
                  "kb_float_w"):
            st.pop(k, None)
        save_settings(st)
        rb_c.set_active(True)
        sc.set_value(MONDAY_DEFAULTS["kb_dock_frac"] * 100)
    dflt.connect("clicked", reset)
    hrow.pack_start(dflt, False, False, 0)
    page.pack_start(hrow, False, False, 0)
    tip = Gtk.Label(label=tr("Tip: the mode key on the keyboard's top bar "
                             "switches Centred -> Docked -> Floating. "
                             "Floating remembers where you put it and its "
                             "size. Search boxes always get the Fire TV-"
                             "style search keyboard."))
    tip.set_line_wrap(True)
    tip.set_halign(Gtk.Align.START)
    page.pack_start(tip, False, False, 0)
    page.show_all()


_orig_build_keyboard_page = SettingsPanel.build_keyboard_page
SettingsPanel.build_keyboard_page = _l_build_keyboard_page_mon

_MON_KB_CSS = b"""
.mon-kb-host { background: rgba(236,240,246,0.96); }
.mon-kb-docked { border-top: 1px solid rgba(0,0,0,0.12);
                 box-shadow: 0 -6px 24px rgba(0,0,0,0.18); }
.mon-kb-floating { border-radius: 18px; border: 1px solid rgba(0,0,0,0.15);
                   box-shadow: 0 10px 34px rgba(0,0,0,0.30); }
.mon-kb-bar { padding: 4px 10px 0 10px; }
.mon-kb-grip { color: #4a5568; font-weight: bold; padding: 6px; }
.mon-kb-resize { color: #4a5568; padding: 0 8px 4px 0; }
.mon-kb-tool { padding: 2px 10px; min-height: 0; border-radius: 10px; }
"""


def _mon_kb_css_install():
    prov = Gtk.CssProvider()
    prov.load_from_data(_MON_KB_CSS)
    scr = Gdk.Screen.get_default()
    if scr is not None:
        Gtk.StyleContext.add_provider_for_screen(
            scr, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 3)


_mon_kb_css_install()
