

# -- Live Tiles (animated art) -----------------------------------------------
class LiveTileArt(Gtk.DrawingArea):
    """Slow pan + cross-fade through a few pictures (posters, channel
    logos), with the row name and a LIVE badge. Animates only while
    mapped (and at ~12 fps), so idle rows cost nothing."""

    def __init__(self, title, subtitle_list, art_list, logo_mode=False,
                 live_badge=False):
        super().__init__()
        self.title = title
        self.subs = subtitle_list or [""]
        self.arts = [a for a in (art_list or []) if a][:8]
        self.logo_mode = logo_mode
        self.live_badge = live_badge
        self.pbs = {}
        self.t0 = time.time()
        self.tick_id = None
        self.connect("draw", self._draw)
        self.connect("map", lambda w: self._start())
        self.connect("unmap", lambda w: self._stop())
        for a in self.arts:
            art_load(a, lambda pb, a=a: (self.pbs.__setitem__(a, pb),
                                         self.queue_draw()))

    def _start(self):
        if self.tick_id is None:
            self.tick_id = GLib.timeout_add(80, self._tick)

    def _stop(self):
        if self.tick_id is not None:
            GLib.source_remove(self.tick_id)
            self.tick_id = None

    def _tick(self):
        self.queue_draw()
        return True

    def _paint_pb(self, cr, pb, W, H, prog, alpha):
        if pb is None:
            return
        pw, ph = pb.get_width(), pb.get_height()
        if self.logo_mode:
            sc = min(W * 0.46 / pw, H * 0.5 / ph)
            x = (W - pw * sc) / 2
            y = H * 0.40 - ph * sc / 2
        else:
            sc = max(W / float(pw), H / float(ph)) * (1.08 + 0.06 * prog)
            x = (W - pw * sc) / 2 - (W * 0.04) * (prog - 0.5)
            y = (H - ph * sc) / 2
        cr.save()
        cr.translate(x, y)
        cr.scale(sc, sc)
        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
        cr.paint_with_alpha(alpha)
        cr.restore()

    def _draw(self, w, cr):
        W, H = self.get_allocated_width(), self.get_allocated_height()
        s = UI_SCALE
        _nv_rrect(cr, 0, 0, W, H, 18 * s)
        cr.clip()
        r, g, b = ACCENT
        try:
            import cairo as _c
            grad = _c.LinearGradient(0, 0, W, H)
            grad.add_color_stop_rgb(0, r * 0.35, g * 0.35, b * 0.45)
            grad.add_color_stop_rgb(1, 0.06, 0.08, 0.14)
            cr.set_source(grad)
        except Exception:
            cr.set_source_rgb(0.08, 0.1, 0.16)
        cr.paint()
        n = len(self.arts)
        el = time.time() - self.t0
        per = 5.0
        idx = int(el // per)
        prog = (el % per) / per
        if n:
            cur = self.arts[idx % n]
            self._paint_pb(cr, self.pbs.get(cur), W, H, prog, 1.0)
            if prog > 0.8 and n > 1:
                nxt = self.arts[(idx + 1) % n]
                self._paint_pb(cr, self.pbs.get(nxt), W, H, 0.0,
                               (prog - 0.8) / 0.2)
        try:
            import cairo as _c
            sh = _c.LinearGradient(0, H * 0.45, 0, H)
            sh.add_color_stop_rgba(0, 0, 0, 0, 0)
            sh.add_color_stop_rgba(1, 0, 0, 0, 0.78)
            cr.set_source(sh)
            cr.rectangle(0, 0, W, H)
            cr.fill()
        except Exception:
            pass
        sub = self.subs[idx % len(self.subs)] if self.subs else ""
        _nv_text(cr, self.title, 16 * s, H - 66 * s, W - 32 * s, 26 * s,
                 bold=True)
        _nv_text(cr, sub, 16 * s, H - 34 * s, W - 32 * s, 17 * s,
                 color=(1, 1, 1, 0.85))
        if self.live_badge:
            cr.set_source_rgba(0.88, 0.19, 0.23, 1)
            _nv_rrect(cr, 14 * s, 14 * s, 74 * s, 28 * s, 8 * s)
            cr.fill()
            _nv_text(cr, "● LIVE", 14 * s, 17 * s, 74 * s, 16 * s,
                     bold=True, align_center=True)
        else:
            cr.set_source_rgba(1, 1, 1, 0.9)
            _nv_rrect(cr, 14 * s, 14 * s, 64 * s, 26 * s, 8 * s)
            cr.fill()
            _nv_text(cr, "LIVE TILE", 14 * s, 18 * s, 64 * s, 12 * s,
                     bold=True, color=(0.1, 0.12, 0.18, 1),
                     align_center=True)
        return False


def _mon_live_tile_button(title, subs, arts, w, h, on_click, logo_mode=False,
                          live_badge=False):
    btn = Gtk.Button()
    btn.get_style_context().add_class("live-tile")
    btn.get_style_context().add_class("mon-live-tile")
    btn.set_size_request(w, h)
    art = LiveTileArt(title, subs, arts, logo_mode, live_badge)
    btn.add(art)
    btn.connect("clicked", lambda b: on_click())
    btn._mon_live_tile = True
    return btn


# -- VOD rows (Movies / TV Shows from the IPTV source) -----------------------
def mon_vod_items(kind, limit=40):
    st = iptv_source_state()
    out = []
    for e in (st.get(kind) or [])[:limit]:
        name = e.get("name") or ""
        if not name:
            continue
        det = TITLE_DETAILS.get((kind, name)) or {}
        out.append((name, e.get("group") or "", det))
    return out


def _l_mon_vod_row(self, kind, title, page_cb):
    section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    tb = Gtk.EventBox()
    tb.add(self.row_title(title))
    tb.connect("button-press-event", lambda w, e: page_cb(w))
    section.pack_start(tb, False, False, 0)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=60)
    items = mon_vod_items(kind)
    if items:
        arts = [d.get("backdrop") or d.get("cover") for _n, _g, d in items]
        row.pack_start(_mon_live_tile_button(
            title, [n for n, _g, _d in items[:8]], arts, 280, 392,
            lambda: page_cb(None)), False, False, 0)
    for name, group, det in items[:30]:
        row.pack_start(self._mon_poster_tile(kind, name, group, det),
                       False, False, 0)
    if not items:
        btn = Gtk.Button()
        btn.get_style_context().add_class("live-tile")
        btn.set_size_request(640, 185)
        lab = Gtk.Label()
        lab.set_line_wrap(True)
        lab.set_justify(Gtk.Justification.CENTER)
        lab.set_markup("<span weight='bold' size='large'>%s</span>\n%s" % (
            _esc(title), _esc("Your IPTV source's %s show up here."
                              % title.lower()) if load_playlists() else
            "Add your IPTV login in Flight Deck -> IPTV"))
        btn.add(lab)
        btn.connect("clicked", lambda w: self.open_panel_page("iptv")
                    if not load_playlists() else page_cb(w))
        row.pack_start(btn, False, False, 0)
    visible = (self.ROW_VISIBLE_COUNT * 280
               + (self.ROW_VISIBLE_COUNT - 1) * 60)
    section.pack_start(self.scrollable_row(row, visible), False, False, 0)
    return section


def _l_mon_poster_tile(self, kind, name, group, det):
    cell = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    btn = Gtk.Button()
    btn.get_style_context().add_class("poster-tile")
    btn.set_size_request(280, 392)
    ov = Gtk.Overlay()
    img = Gtk.Image()
    lab = Gtk.Label()
    lab.set_markup("<span weight='bold' size='large'>%s</span>" % _esc(name))
    lab.set_line_wrap(True)
    lab.set_max_width_chars(14)
    lab.set_justify(Gtk.Justification.CENTER)
    base = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    base.pack_start(lab, True, True, 0)
    base.pack_start(img, True, True, 0)
    ov.add(base)
    btn.add(ov)
    btn._title_kind = kind
    btn._title_name = name
    btn._title_meta = group
    btn._mon_det = det
    btn._mon_ov = ov
    cover = det.get("cover")

    def got(pb):
        pw, ph = _px(280), _px(392)
        img.set_from_pixbuf(_round_pb(_cover_crop(pb, pw, ph), _px(28)))
        lab.hide()
        lab.set_no_show_all(True)
    if cover:
        art_load(cover, got)
    btn.connect("clicked", lambda b: self.open_title_detail(kind, name, group))
    btn.connect("focus-in-event", lambda b, e: (self._mon_poster_focus(b),
                                                False)[1])
    btn.connect("focus-out-event", lambda b, e: (self._mon_poster_blur(b),
                                                 False)[1])
    cell.pack_start(btn, False, False, 0)
    nl = Gtk.Label(label=name)
    nl.get_style_context().add_class("app-name")
    nl.set_line_wrap(True)
    nl.set_max_width_chars(28)
    cell.pack_start(nl, False, False, 0)
    return cell


def _l_mon_poster_focus(self, btn):
    det = getattr(btn, "_mon_det", {}) or {}
    art = det.get("backdrop") or det.get("cover")
    kind, name = btn._title_kind, btn._title_name
    # Hero follows focus; Dynamic background follows too.
    self._mon_hero_follow(kind, name, btn._title_meta, det)
    if art:
        art_load(art, lambda pb: self._mon_dynamic_backdrop(pb)
                 if self.get_focus() is btn else None)
    self._mon_trailer_cancel()
    if mset(self.settings, "mon_card_trailers"):
        self._mon_tr_timer = GLib.timeout_add(
            1500, lambda: self._mon_trailer_start(btn))


def _l_mon_poster_blur(self, btn):
    self._mon_trailer_cancel()


def _l_mon_trailer_cancel(self):
    if getattr(self, "_mon_tr_timer", None):
        GLib.source_remove(self._mon_tr_timer)
    self._mon_tr_timer = None
    self._mon_tr_token = getattr(self, "_mon_tr_token", 0) + 1
    cur = getattr(self, "_mon_tr", None)
    self._mon_tr = None
    if cur is not None:
        btn, vid = cur
        vid.stop()
        try:
            btn._mon_ov.remove(vid.widget)
        except Exception:
            pass
        btn.set_size_request(280, 392)
        btn.get_style_context().remove_class("mon-trailer-on")


def _l_mon_trailer_start(self, btn):
    self._mon_tr_timer = None
    token = self._mon_tr_token = getattr(self, "_mon_tr_token", 0) + 1
    kind, name = btn._title_kind, btn._title_name
    year = (getattr(btn, "_mon_det", {}) or {}).get("year", "")

    def work():
        vid = trailer_find(kind, name, year)
        url = trailer_stream_url(vid) if vid else None
        GLib.idle_add(lambda: (self._mon_trailer_show(btn, url, token),
                               False)[1])
    threading.Thread(target=work, daemon=True).start()
    return False


def _l_mon_trailer_show(self, btn, url, token):
    if not url or token != getattr(self, "_mon_tr_token", 0) or \
            self.get_focus() is not btn:
        return
    v = AeroVideo(muted=True, on_end=lambda: self._mon_trailer_cancel())
    if not v.ok:
        return
    v.widget.set_size_request(int(280 * 1.08), int(392 * 1.08))
    btn._mon_ov.add_overlay(v.widget)
    v.widget.show()
    btn.set_size_request(int(280 * 1.08), int(392 * 1.08))
    btn.get_style_context().add_class("mon-trailer-on")
    self._mon_tr = (btn, v)
    v.play(url)


def _l_mon_play_trailer_full(self, kind, name, year=""):
    """Trailer button: the exact YouTube video, full screen in mpv."""
    self._show_toast_safe("Finding the trailer…")

    def work():
        vid = trailer_find(kind, name, year)
        GLib.idle_add(lambda: (self._mon_trailer_full_go(vid, name), False)[1])
    threading.Thread(target=work, daemon=True).start()


def _l_mon_trailer_full_go(self, vid, name):
    if not vid:
        self._show_message("No trailer found",
                           "No trailer was found for %s." % name)
        return
    self._mon_trailer_cancel()
    if not _spawn(["mpv", "--fs", "--force-window=immediate",
                   "--ytdl-format=bestvideo[height<=1080]+bestaudio/best",
                   "https://www.youtube.com/watch?v=" + vid],
                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL):
        open_url("https://www.youtube.com/watch?v=" + vid)


def _l_show_toast_safe(self, text):
    try:
        self._voice_status(text)
    except Exception:
        pass


_orig_render_title_detail = AltTVLauncher.render_title_detail


def _l_render_title_detail_mon(self, kind, name, meta):
    _orig_render_title_detail(self, kind, name, meta)
    try:
        top = self.title_detail_content.get_children()[0]
        right = top.get_children()[-1]
        btn = Gtk.Button(label="▶  Trailer")
        btn.get_style_context().add_class("mon-hero-btn")
        btn.set_halign(Gtk.Align.START)
        year = (title_details(kind, name) or {}).get("year", "")
        btn.connect("clicked", lambda w: self._mon_play_trailer_full(
            kind, name, year))
        right.pack_start(btn, False, False, 6)
        right.reorder_child(btn, 1)
        btn.show()
        # The page's poster comes from the IPTV art when no local one.
        det = TITLE_DETAILS.get((kind, name)) or {}
        kids = top.get_children()
        if det.get("cover") and kids and isinstance(kids[0], Gtk.Box):
            holder = kids[0]

            def got(pb):
                for c in holder.get_children():
                    holder.remove(c)
                holder.pack_start(Gtk.Image.new_from_pixbuf(_round_pb(
                    _cover_crop(pb, _px(360), _px(504)), _px(28))),
                    False, False, 0)
                holder.show_all()
            art_load(det["cover"], got)
    except Exception:
        pass


for _n, _f in (("_mon_vod_row", _l_mon_vod_row),
               ("_mon_poster_tile", _l_mon_poster_tile),
               ("_mon_poster_focus", _l_mon_poster_focus),
               ("_mon_poster_blur", _l_mon_poster_blur),
               ("_mon_trailer_cancel", _l_mon_trailer_cancel),
               ("_mon_trailer_start", _l_mon_trailer_start),
               ("_mon_trailer_show", _l_mon_trailer_show),
               ("_mon_play_trailer_full", _l_mon_play_trailer_full),
               ("_mon_trailer_full_go", _l_mon_trailer_full_go),
               ("_show_toast_safe", _l_show_toast_safe),
               ("render_title_detail", _l_render_title_detail_mon),
               ("build_row_movies", lambda self: self._mon_vod_row(
                   "movies", "Movies", self.on_open_movies_page)),
               ("build_row_shows", lambda self: self._mon_vod_row(
                   "shows", "TV Shows", self.on_open_shows_page))):
    setattr(AltTVLauncher, _n, _f)


# Remove demo content: the built-in sample movies / shows (Oppenheimer,
# The Bear, ...) are gone everywhere (pages, search). Movies / Shows come
# only from the IPTV source now; with none set up the rows say so.
MOVIES[:] = []
SHOWS[:] = []
MOVIE_GENRES.clear()
