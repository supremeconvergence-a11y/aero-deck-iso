# Aero OS Monday Night -- app fetchers, sourced by build-aero-deck.sh.
# Every download is checked before it goes into the image:
#   Chrome      : Google's apt repo. InRelease signature (gpgv) against
#                 Google's Linux signing key (primary fingerprint pinned)
#                 -> Packages SHA256 -> .deb SHA256.  Includes Widevine.
#   Boosteroid  : official .deb + Boosteroid's own .md5.
#   GeForce NOW : NVIDIA's official Flatpak repo (flatpak checks the
#                 repo's GPG signature itself). Optional: AERO_GFN=0 skips.
# Nothing here ever reads /workspace/.secrets or any IPTV login.

CHROME_KEY_URL="https://dl.google.com/linux/linux_signing_key.pub"
CHROME_KEY_FPR="EB4C1BFD4F042F6DDDCCEC917721F63BD38B4796"
CHROME_REPO="https://dl.google.com/linux/chrome/deb"
BOOSTEROID_DEB_URL="https://boosteroid.com/linux/installer/boosteroid-install-x64.deb"
BOOSTEROID_MD5_URL="https://boosteroid.com/linux/installer/boosteroid-install-x64.md5"
GFN_REPO_URL="https://international.download.nvidia.com/GFNLinux/flatpak/geforcenow.flatpakrepo"
GFN_APP_ID="com.nvidia.geforcenow"

_af_die() { echo "!! $*" >&2; exit 1; }

# aero_fetch_chrome DLDIR AIROOTFS
aero_fetch_chrome() {
    local dl="$1" root="$2" fpr pk_sha filename deb_sha
    mkdir -p "$dl/chrome" && cd "$dl/chrome" || _af_die "chrome: no dir"
    curl -fsSL "$CHROME_KEY_URL" -o key.pub || _af_die "chrome: key download failed"
    fpr="$(gpg --show-keys --with-colons key.pub 2>/dev/null | awk -F: '/^fpr/{print $10; exit}')"
    [[ "$fpr" == "$CHROME_KEY_FPR" ]] || _af_die "chrome: signing key fingerprint mismatch ($fpr)"
    rm -f kr.gpg && gpg --dearmor < key.pub > kr.gpg
    curl -fsSL "$CHROME_REPO/dists/stable/InRelease" -o InRelease || _af_die "chrome: InRelease download failed"
    gpgv --keyring ./kr.gpg InRelease >/dev/null 2>&1 || _af_die "chrome: InRelease signature BAD"
    pk_sha="$(awk '/^SHA256:/{f=1;next} /^[A-Za-z]/{f=0} f && $3=="main/binary-amd64/Packages"{print $1}' InRelease)"
    [[ -n "$pk_sha" ]] || _af_die "chrome: no Packages hash in InRelease"
    curl -fsSL "$CHROME_REPO/dists/stable/main/binary-amd64/Packages" -o Packages || _af_die "chrome: Packages download failed"
    echo "$pk_sha  Packages" | sha256sum -c --quiet - || _af_die "chrome: Packages hash mismatch"
    read -r filename deb_sha < <(awk '/^Package: /{p=$2} p=="google-chrome-stable" && /^Filename: /{f=$2} p=="google-chrome-stable" && /^SHA256: /{print f, $2; exit}' Packages)
    [[ -n "$filename" && -n "$deb_sha" ]] || _af_die "chrome: google-chrome-stable not in Packages"
    if ! { [[ -f chrome.deb ]] && echo "$deb_sha  chrome.deb" | sha256sum -c --quiet - 2>/dev/null; }; then
        curl -fL --retry 3 "$CHROME_REPO/$filename" -o chrome.deb || _af_die "chrome: .deb download failed"
        echo "$deb_sha  chrome.deb" | sha256sum -c --quiet - || _af_die "chrome: .deb hash mismatch"
    fi
    rm -rf x && mkdir x && (cd x && bsdtar -xf ../chrome.deb && bsdtar -xf data.tar.*) || _af_die "chrome: extract failed"
    [[ -x x/opt/google/chrome/chrome ]] || _af_die "chrome: binary missing in .deb"
    [[ -d x/opt/google/chrome/WidevineCdm ]] || echo "   (warning: WidevineCdm folder not in this Chrome build)"
    mkdir -p "$root/opt/google" "$root/usr/bin"
    rm -rf "$root/opt/google/chrome"
    cp -a x/opt/google/chrome "$root/opt/google/chrome"
    ln -sf /opt/google/chrome/google-chrome "$root/usr/bin/google-chrome-stable"
    # chrome-sandbox must be setuid root (profiledef.sh sets 4755 too).
    chmod 4755 "$root/opt/google/chrome/chrome-sandbox" 2>/dev/null || true
    rm -rf x
    echo "   Chrome $(echo "$filename" | sed 's/.*_\([0-9.]*-[0-9]*\)_.*/\1/') verified (repo signature + SHA256), Widevine: $([[ -d "$root/opt/google/chrome/WidevineCdm" ]] && echo yes || echo no)"
    cd - >/dev/null
}

# aero_fetch_boosteroid DLDIR AIROOTFS
aero_fetch_boosteroid() {
    local dl="$1" root="$2" want got
    mkdir -p "$dl/boosteroid" && cd "$dl/boosteroid" || _af_die "boosteroid: no dir"
    curl -A Mozilla -fsSL "$BOOSTEROID_MD5_URL" -o b.md5 || _af_die "boosteroid: md5 download failed"
    want="$(awk '{print $1; exit}' b.md5)"
    [[ "$want" =~ ^[0-9a-f]{32}$ ]] || _af_die "boosteroid: md5 file looks wrong"
    got=""
    if [[ -f b.deb ]]; then got="$(md5sum b.deb | awk '{print $1}')"; fi
    if [[ "$got" != "$want" ]]; then
        curl -A Mozilla -fL --retry 3 "$BOOSTEROID_DEB_URL" -o b.deb || _af_die "boosteroid: .deb download failed"
        got="$(md5sum b.deb | awk '{print $1}')"
        [[ "$got" == "$want" ]] || _af_die "boosteroid: .deb md5 mismatch"
    fi
    rm -rf x && mkdir x && (cd x && bsdtar -xf ../b.deb && bsdtar -xf data.tar.*) || _af_die "boosteroid: extract failed"
    local bin
    bin="$(cd x && ls -d opt/*/bin/Boosteroid 2>/dev/null | head -1)"
    [[ -n "$bin" ]] || _af_die "boosteroid: binary missing in .deb"
    mkdir -p "$root/opt"
    rm -rf "${root:?}/${bin%%/bin/Boosteroid}"
    cp -a "x/${bin%%/bin/Boosteroid}" "$root/${bin%%/bin/Boosteroid}"
    [[ ! -f x/usr/share/icons/Boosteroid/icon.svg ]] || install -Dm644 x/usr/share/icons/Boosteroid/icon.svg "$root/usr/share/icons/hicolor/scalable/apps/boosteroid.svg"
    printf '%s\n' "/$bin" > "$root/etc/aero-deck/boosteroid.path"
    rm -rf x
    echo "   Boosteroid verified (md5 $want) -> /$bin"
    cd - >/dev/null
}

# aero_fetch_gfn AIROOTFS   (flatpak installed into the image; optional)
aero_fetch_gfn() {
    local root="$1"
    [[ "${AERO_GFN:-1}" == "1" ]] || { echo "   GeForce NOW skipped (AERO_GFN=0) -- tile opens the web version"; return 0; }
    command -v flatpak >/dev/null || pacman -S --needed --noconfirm flatpak >/dev/null || { echo "   (flatpak missing -- GeForce NOW tile will use the web version)"; return 0; }
    mkdir -p "$root/var/lib/flatpak"
    if FLATPAK_SYSTEM_DIR="$root/var/lib/flatpak" flatpak remote-add --system --if-not-exists GeForceNOW "$GFN_REPO_URL" &&
       FLATPAK_SYSTEM_DIR="$root/var/lib/flatpak" flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo &&
       FLATPAK_SYSTEM_DIR="$root/var/lib/flatpak" flatpak install --system -y --noninteractive GeForceNOW "$GFN_APP_ID"; then
        echo "   GeForce NOW (native, NVIDIA Flatpak) installed into the image"
    else
        echo "   (GeForce NOW Flatpak install failed -- tile falls back to the web version; build continues)"
    fi
}

# aero_extra_packages PROFILE
# Optional extras that may or may not be in the repos this build machine
# sees (CachyOS / Arch). Only added when pacman knows them, so a missing
# one never breaks the build.
AERO_EXTRA_PKGS="proton-vpn-gtk-app kdeconnect lxtask galculator thunar thunar-archive-plugin tumbler gvfs mousepad gnome-clocks gnome-calendar xpad grim slurp ristretto evince xarchiver 7zip unzip unrar mcomix mupdf-tools geoclue"
aero_extra_packages() {
    local prof="$1" p
    pacman -Sy >/dev/null 2>&1 || true
    for p in $AERO_EXTRA_PKGS; do
        if grep -qx "$p" "$prof/packages.x86_64"; then continue; fi
        if pacman -Si "$p" >/dev/null 2>&1; then
            echo "$p" >> "$prof/packages.x86_64"; echo "   + $p"
        else
            echo "   (not in the repos here, skipped: $p -- its tile shows a short message)"
        fi
    done
}

# aero_fetch_protonup AIROOTFS   (ProtonUp-Qt Flatpak from Flathub; optional)
aero_fetch_protonup() {
    local root="$1"
    [[ "${AERO_PROTONUP:-1}" == "1" ]] || { echo "   ProtonUp-Qt skipped (AERO_PROTONUP=0) -- tile installs it on first use"; return 0; }
    command -v flatpak >/dev/null || { echo "   (no flatpak -- ProtonUp-Qt tile installs it on first use)"; return 0; }
    mkdir -p "$root/var/lib/flatpak"
    if FLATPAK_SYSTEM_DIR="$root/var/lib/flatpak" flatpak remote-add --system --if-not-exists flathub https://dl.flathub.org/repo/flathub.flatpakrepo &&
       FLATPAK_SYSTEM_DIR="$root/var/lib/flatpak" flatpak install --system -y --noninteractive flathub net.davidotek.pupgui2; then
        echo "   ProtonUp-Qt installed into the image"
    else
        echo "   (ProtonUp-Qt install failed -- tile installs it on first use; build continues)"
    fi
}

# aero_fetch_screensaver AIROOTFS
# Screensaver photos (Wikimedia Commons, free licences -- author + licence
# for each are in screensaver/list.tsv and CREDITS.txt). 1920 px JPEGs from
# upload.wikimedia.org. A failed one is skipped; the screensaver uses
# whatever arrived (and always has the Aero backdrop).
aero_fetch_screensaver() {
    local root="$1" d list cat num url lic author page n=0
    d="$root/usr/local/share/aero-deck/screensaver"
    list="$d/list.tsv"
    [ -f "$list" ] || { echo "   (no screensaver list)"; return 0; }
    : > "$d/CREDITS.txt"
    while IFS=$'\t' read -r cat num url lic author page; do
        [ -n "$url" ] || continue
        mkdir -p "$d/$cat"
        if curl -fsSL --retry 2 -m 60 -A "AeroDeckBuild/1.0 (personal build)" "${url%%\?*}" -o "$d/$cat/$num.jpg.part" &&
           [ "$(head -c 3 "$d/$cat/$num.jpg.part" | od -An -tx1 | tr -d ' \n')" = "ffd8ff" ]; then
            mv -f "$d/$cat/$num.jpg.part" "$d/$cat/$num.jpg"; n=$((n + 1))
            printf '%s/%s.jpg  %s  (%s)  %s\n' "$cat" "$num" "$author" "$lic" "$page" >> "$d/CREDITS.txt"
        else
            rm -f "$d/$cat/$num.jpg.part"
        fi
        sleep 0.3
    done < "$list"
    chmod -R a+rX "$d"
    echo "   screensaver photos: $n"
}
