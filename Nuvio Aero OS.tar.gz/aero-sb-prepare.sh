# Aero Deck -- Secure Boot preparation (sourced by build-aero-deck.sh).
# 1) Aero's MOK key pair, made ONCE and kept on drive D next to work.img
#    (D:\Aero\secureboot). The same key signs every future build, so the
#    one-time MOK enroll on a machine stays valid for every new USB.
#    The private key never goes into the ISO or the tarball.
# 2) shim + MokManager: Fedora's Microsoft-signed shim 15.8 (pinned hash).
# 3) /root/mkarchiso-aero: a copy of mkarchiso with hook calls added
#    (aero_mkarchiso_patch below).
SHIM_RPM_URL=https://kojipkgs.fedoraproject.org/packages/shim/15.8/3/x86_64/shim-x64-15.8-3.x86_64.rpm
SHIM_RPM_SHA256=28958d75333c42b0341b727a2b697edf02f0cfaec18dbd25ae62c9a8164faabe

aero_sb_prepare() {   # $1 = dir for keys + shim (kept on drive D)
    local SB="$1"
    mkdir -p "$SB" || return 1
    chmod 700 "$SB" 2>/dev/null || true   # (NTFS ignores this)
    if [[ ! -f "$SB/aero-mok.key" ]]; then
        openssl req -new -x509 -newkey rsa:2048 -nodes -sha256 -days 7300 \
            -subj "/CN=Aero Deck Secure Boot (MOK)/" \
            -keyout "$SB/aero-mok.key" -out "$SB/aero-mok.crt" >/dev/null 2>&1 \
            || { echo "openssl failed"; return 1; }
        chmod 600 "$SB/aero-mok.key" 2>/dev/null || true
        echo "[aero-secureboot] new MOK key made in $SB (keep it -- reused by every build)"
    fi
    openssl x509 -in "$SB/aero-mok.crt" -outform DER -out "$SB/aero-mok.cer" || return 1
    if [[ ! -f "$SB/shimx64.efi" || ! -f "$SB/mmx64.efi" ]]; then
        local tmp; tmp=$(mktemp -d)
        curl -fL --retry 3 -o "$tmp/shim.rpm" "$SHIM_RPM_URL" || return 1
        echo "$SHIM_RPM_SHA256  $tmp/shim.rpm" | sha256sum -c - || return 1
        bsdtar -xf "$tmp/shim.rpm" -C "$tmp" ./boot/efi/EFI/fedora/shimx64.efi ./boot/efi/EFI/fedora/mmx64.efi || return 1
        install -m 0644 "$tmp/boot/efi/EFI/fedora/shimx64.efi" "$SB/shimx64.efi" || return 1
        install -m 0644 "$tmp/boot/efi/EFI/fedora/mmx64.efi" "$SB/mmx64.efi" || return 1
        rm -rf "$tmp"
    fi
    return 0
}

# Patched COPY of mkarchiso (the system /usr/bin/mkarchiso is never edited).
# Four hook calls; every anchor is checked and the build stops with a clear
# message if this archiso version does not have it.
aero_mkarchiso_patch() {   # $1 = hook file, $2 = mkarchiso in, $3 = mkarchiso out
    local HOOK="$1" IN="$2" OUT="$3"
    cp -f "$IN" "$OUT"
    grep -q '^\s*_run_once _copy_boot_out_of_pacstrap_dir$' "$OUT" || { echo "mkarchiso anchor 1 missing"; return 1; }
    grep -q '^\s*"${isofs_dir}/EFI/BOOT/BOOT${target_arch}.EFI"$' "$OUT" || { echo "mkarchiso anchor 2 missing"; return 1; }
    grep -q '^\s*for filename in "${!file_permissions\[@\]}"; do$' "$OUT" || { echo "mkarchiso anchor 3 missing"; return 1; }
    local n; n=$(grep -n '^set -e' "$OUT" | head -1 | cut -d: -f1)
    sed -i "${n:-1}a source '$HOOK'" "$OUT"
    sed -i 's|^\(\s*\)_run_once _copy_boot_out_of_pacstrap_dir$|&\n\1aero_sb_sign_kernels|' "$OUT"
    sed -i 's|^\(\s*\)"${isofs_dir}/EFI/BOOT/BOOT${target_arch}.EFI"$|&\n\1aero_sb_shim "${target_arch}"|' "$OUT"
    sed -i '0,/^\(\s*\)for filename in "${!file_permissions\[@\]}"; do$/s||\1aero_fix_modes "${profile}/airootfs" "${pacstrap_dir}"\n&|' "$OUT"
    [[ $(grep -c '^\s*aero_sb_sign_kernels$' "$OUT") == 1 && \
       $(grep -c 'aero_sb_shim "${target_arch}"' "$OUT") == 1 && \
       $(grep -c '^\s*aero_fix_modes ' "$OUT") == 1 ]] || { echo "mkarchiso patch failed"; return 1; }
    chmod 755 "$OUT"
    bash -O extglob -n "$OUT"
}
