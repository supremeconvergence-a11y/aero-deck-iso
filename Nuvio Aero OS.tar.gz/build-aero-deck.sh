#!/bin/bash
# Aero OS Monday Night -- build the Aero Deck live ISO (launcher v1.4.0) in
# live CachyOS on the Dell. Same method as last time: an ext4 work.img on
# drive D (mounted at /mnt/d) mounted at /mnt/work, pacman's package cache
# bind-mounted into it so nothing fills the live session's RAM.
#
#   sudo bash build-aero-deck.sh ~/Downloads/"Nuvio Aero OS.tar.gz"
#
# New in this build:
#  * SECURE BOOT: the USB boots with Secure Boot ON (no BIOS change).
#    shim (Microsoft-signed, from Fedora) -> systemd-boot + kernel signed
#    with Aero's own key. First boot on a machine shows ONE blue "MOK"
#    screen to enroll Aero's key from the USB (README, "FIRST BOOT").
#    The key pair is made once and kept in D:\Aero\secureboot; the private
#    key never goes into the ISO.
#  * Google Chrome (Widevine DRM) for the web-app tiles, the native
#    Boosteroid app and NVIDIA's native GeForce NOW app -- every download
#    is checked (signature / hash) before it goes into the ISO.
#  * Nuvio Desktop as before (pinned SHA-256).
#
# Env overrides: AERO_DIR (default /mnt/d/Aero), WORK_SIZE (default 30G),
#   AERO_ISO_VERSION (default 2026.11.23-monday), AERO_SECUREBOOT=0 (plain
#   build without the shim, NOT recommended), AERO_GFN=0 (skip the GeForce
#   NOW app; its tile then opens the web version), NUVIO_APPIMAGE.
set -euo pipefail
TARBALL="${1:-}"
AERO_DIR="${AERO_DIR:-/mnt/d/Aero}"
WORK_IMG="$AERO_DIR/work.img"
WORK=/mnt/work
WORK_SIZE="${WORK_SIZE:-30G}"
export AERO_ISO_VERSION="${AERO_ISO_VERSION:-2026.11.23-monday}"
AERO_SECUREBOOT="${AERO_SECUREBOOT:-1}"
SB_DIR="$AERO_DIR/secureboot"
APP_CACHE="$AERO_DIR/apps-cache"
MKARCHISO_AERO=/root/mkarchiso-aero
NUVIO_VER=0.1.38-alpha
NUVIO_FILE=Nuvio-Linux-x86_64-$NUVIO_VER.AppImage
NUVIO_URL=https://github.com/NuvioMedia/NuvioDesktop/releases/download/$NUVIO_VER
NUVIO_SHA256=4efcd0575c6cb8c212895209327766fa76e9dcdd9dd863023b9ce445f6a610cd
NUVIO_CACHE="$AERO_DIR/nuvio-$NUVIO_VER"

say() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "run with sudo:  sudo bash $0 \"$TARBALL\""
[ -n "$TARBALL" ] && [ -f "$TARBALL" ] || die "give the path to 'Nuvio Aero OS.tar.gz'"
[ -d "$AERO_DIR" ] || die "$AERO_DIR not found -- mount drive D at /mnt/d first (see README step 2)"
touch "$AERO_DIR/.write-test" 2>/dev/null && rm -f "$AERO_DIR/.write-test" \
    || die "$AERO_DIR is read-only -- remount D with ntfs3 read-write (README step 2)"
TARBALL="$(readlink -f "$TARBALL")"

say "1/8  Build tools (archiso, Secure Boot signing tools, flatpak)"
pacman -Sy --needed --noconfirm archiso squashfs-tools curl sbsigntools \
    libarchive mtools openssl gnupg flatpak e2fsprogs

say "2/8  Work disk $WORK_IMG ($WORK_SIZE ext4) at $WORK"
mountpoint -q /var/cache/pacman/pkg && umount /var/cache/pacman/pkg || true
mountpoint -q "$WORK" && umount "$WORK" || true
if [ ! -f "$WORK_IMG" ]; then
    truncate -s "$WORK_SIZE" "$WORK_IMG"
    mkfs.ext4 -q -F "$WORK_IMG"
else
    # Last time's 25 GB image is reused; grow it to $WORK_SIZE (Chrome,
    # GeForce NOW and Boosteroid need a few GB more). Never shrinks.
    want=$(numfmt --from=iec "$WORK_SIZE")
    have=$(stat -c %s "$WORK_IMG")
    if [ "$have" -lt "$want" ]; then
        truncate -s "$WORK_SIZE" "$WORK_IMG"
        e2fsck -fy "$WORK_IMG" >/dev/null 2>&1 || true
        resize2fs "$WORK_IMG" >/dev/null
        echo "work.img grown to $WORK_SIZE"
    fi
fi
mkdir -p "$WORK"
mount -o loop "$WORK_IMG" "$WORK"
# Fresh build every time, but keep downloaded packages (saves ~3 GB).
find "$WORK" -mindepth 1 -maxdepth 1 ! -name pkg ! -name lost+found -exec rm -rf {} +
mkdir -p "$WORK/pkg"
mount --bind "$WORK/pkg" /var/cache/pacman/pkg
cleanup() {
    umount /var/cache/pacman/pkg 2>/dev/null || true
    umount "$WORK" 2>/dev/null || true
}
trap cleanup EXIT

say "3/8  Unpacking the Aero profile to $WORK/src"
SRC="$WORK/src"
mkdir -p "$SRC"
tar xzf "$TARBALL" -C "$SRC"
PROFILE=$(find "$SRC" -maxdepth 3 -name profiledef.sh -path '*profile-monday*' -printf '%h\n' | head -1)
[ -n "$PROFILE" ] || die "profile-monday not found in the tarball"
HELP=$(dirname "$(find "$SRC" -maxdepth 2 -name aero-sb-hook.sh | head -1)")
[ -f "$HELP/aero-sb-hook.sh" ] && [ -f "$HELP/aero-sb-prepare.sh" ] && [ -f "$HELP/aero-fetch-apps.sh" ] \
    || die "Secure Boot / app helper scripts missing from the tarball"
A="$PROFILE/airootfs"
echo "profile: $PROFILE"
# shellcheck source=/dev/null
source "$HELP/aero-sb-prepare.sh"
# shellcheck source=/dev/null
source "$HELP/aero-fetch-apps.sh"

say "4/8  Secure Boot (shim + Aero's signing key, kept in $SB_DIR)"
if [ "$AERO_SECUREBOOT" = 1 ]; then
    aero_sb_prepare "$SB_DIR" || die "Secure Boot preparation failed (internet? see the message above)"
    # Only the PUBLIC certificate goes into the image (for the helper).
    install -Dm644 "$SB_DIR/aero-mok.cer" "$A/usr/local/share/aero-deck/secureboot/aero-mok.cer"
    export AERO_SB_DIR="$SB_DIR"
    echo "Secure Boot: ON  (key: $SB_DIR/aero-mok.key -- keep it, never share it)"
else
    unset AERO_SB_DIR || true
    echo "Secure Boot: OFF for this build (AERO_SECUREBOOT=0) -- the USB will NOT boot with Secure Boot on"
fi
# Patched copy of mkarchiso: Secure Boot signing + the execute-bit fix.
aero_mkarchiso_patch "$HELP/aero-sb-hook.sh" "$(command -v mkarchiso)" "$MKARCHISO_AERO" \
    || die "this archiso version is different from the one Aero was made for -- tell Andrew's helper the message above"

say "5/8  Nuvio Desktop $NUVIO_VER (official release, SHA-256 checked)"
mkdir -p "$NUVIO_CACHE"
cd "$NUVIO_CACHE"
curl -fL --retry 3 -o SHA256SUMS.txt "$NUVIO_URL/SHA256SUMS.txt"
if [ -n "${NUVIO_APPIMAGE:-}" ]; then
    cp -f "$NUVIO_APPIMAGE" "$NUVIO_FILE"
elif ! echo "$NUVIO_SHA256  $NUVIO_FILE" | sha256sum -c --status 2>/dev/null; then
    curl -fL --retry 3 -o "$NUVIO_FILE.part" "$NUVIO_URL/$NUVIO_FILE"
    mv -f "$NUVIO_FILE.part" "$NUVIO_FILE"
fi
grep -E "[[:space:]]\*?$NUVIO_FILE\$" SHA256SUMS.txt | sha256sum -c - \
    || die "Nuvio AppImage does not match the release SHA256SUMS.txt"
echo "$NUVIO_SHA256  $NUVIO_FILE" | sha256sum -c - \
    || die "Nuvio AppImage does not match the pinned SHA-256"
X="$WORK/nuvio-x"; rm -rf "$X"; mkdir -p "$X"
cp -f "$NUVIO_FILE" "$X/"; cd "$X"; chmod +x "$NUVIO_FILE"
if ! ./"$NUVIO_FILE" --appimage-extract >/dev/null 2>&1; then
    OFF=$(./"$NUVIO_FILE" --appimage-offset 2>/dev/null || true)
    [ -n "$OFF" ] || OFF=$(python3 - "$NUVIO_FILE" <<'PY'
import sys
d = open(sys.argv[1], "rb").read(4 * 1024 * 1024)
print(d.find(b"hsqs"))
PY
)
    unsquashfs -q -o "$OFF" -d squashfs-root "$NUVIO_FILE" \
        || die "could not unpack the Nuvio AppImage"
fi
[ -x squashfs-root/AppRun ] || die "Nuvio AppImage unpacked without AppRun"
rm -rf "$A/opt/nuvio"; mkdir -p "$A/opt"
cp -a squashfs-root "$A/opt/nuvio"
chown -R 0:0 "$A/opt/nuvio"; chmod -R a+rX,go-w "$A/opt/nuvio"
install -Dm644 squashfs-root/Nuvio.png "$A/usr/share/icons/hicolor/256x256/apps/nuvio.png"
install -Dm644 squashfs-root/Nuvio.png "$A/usr/share/pixmaps/nuvio.png"
install -Dm644 squashfs-root/Nuvio.png "$A/usr/local/share/aero-deck/assets/icons/nuvio.png"
cd /; rm -rf "$X"
echo "Nuvio unpacked to /opt/nuvio ($(du -sh "$A/opt/nuvio" | cut -f1))"

say "6/8  Chrome (Widevine), Boosteroid, GeForce NOW, ProtonUp-Qt, extras, screensaver photos"
mkdir -p "$APP_CACHE" "$A/etc/aero-deck"
aero_fetch_chrome "$APP_CACHE" "$A"
aero_fetch_boosteroid "$APP_CACHE" "$A"
aero_fetch_gfn "$A"
aero_fetch_protonup "$A"
aero_extra_packages "$PROFILE"
aero_fetch_screensaver "$A"

say "7/8  Building aero-deck-$AERO_ISO_VERSION (25-45 min)"
"$MKARCHISO_AERO" -v -w "$WORK/build" -o "$AERO_DIR" "$PROFILE"

ISO="$AERO_DIR/aero-deck-$AERO_ISO_VERSION-x86_64.iso"
[ -f "$ISO" ] || ISO=$(ls -t "$AERO_DIR"/aero-deck-*-x86_64.iso | head -1)

say "8/8  Checks + checksum"
if [ "$AERO_SECUREBOOT" = 1 ]; then
    C="$WORK/sbcheck"; rm -rf "$C"; mkdir -p "$C"
    bsdtar -xf "$ISO" -C "$C" EFI/BOOT/BOOTX64.EFI EFI/BOOT/grubx64.efi EFI/BOOT/mmx64.efi EFI/aero-mok.cer 'aero/boot/x86_64/vmlinuz-*' 2>/dev/null || true
    ok=1
    cmp -s "$C/EFI/BOOT/BOOTX64.EFI" "$SB_DIR/shimx64.efi" || { echo "  shim missing"; ok=0; }
    [ -f "$C/EFI/BOOT/mmx64.efi" ] || { echo "  MokManager missing"; ok=0; }
    [ -f "$C/EFI/aero-mok.cer" ] || { echo "  aero-mok.cer missing"; ok=0; }
    sbverify --cert "$SB_DIR/aero-mok.crt" "$C/EFI/BOOT/grubx64.efi" >/dev/null 2>&1 || { echo "  boot loader not signed"; ok=0; }
    for k in "$C"/aero/boot/x86_64/vmlinuz-*; do
        sbverify --cert "$SB_DIR/aero-mok.crt" "$k" >/dev/null 2>&1 || { echo "  kernel ${k##*/} not signed"; ok=0; }
    done
    bsdtar -tf "$ISO" > "$C/list.txt" 2>/dev/null || true
    if grep -q 'aero-mok\.key' "$C/list.txt"; then echo "  PRIVATE KEY IN ISO"; ok=0; fi
    # The USB stick boots from the ISO's EFI partition (what Rufus "DD image
    # mode" and balenaEtcher write) -- check shim is in there too.
    esp_start=$(sfdisk -d "$ISO" 2>/dev/null | awk -F'[=,]' '/[Tt]ype=(ef|C12A7328|c12a7328)/{gsub(/ /,"",$2); print $2; exit}')
    if [ -n "$esp_start" ]; then
        mcopy -n -i "$ISO@@$((esp_start * 512))" ::/EFI/BOOT/BOOTX64.EFI "$C/esp-boot.efi" 2>/dev/null || true
        cmp -s "$C/esp-boot.efi" "$SB_DIR/shimx64.efi" || { echo "  shim missing from the ISO's EFI partition"; ok=0; }
        mdir -i "$ISO@@$((esp_start * 512))" ::/EFI/aero-mok.cer >/dev/null 2>&1 || { echo "  aero-mok.cer missing from the EFI partition"; ok=0; }
    else
        echo "  no EFI partition in the ISO (not hybrid?)"; ok=0
    fi
    rm -rf "$C"
    [ "$ok" = 1 ] || die "Secure Boot check failed -- do not burn this ISO"
    echo "Secure Boot check: shim + MokManager + signed boot loader + signed kernel -- OK"
fi
# Hybrid check: MBR boot signature + partition table, so Rufus (DD image
# mode) and balenaEtcher make a bootable stick.
sig=$(dd if="$ISO" bs=1 skip=510 count=2 2>/dev/null | od -An -tx1 | tr -d ' \n')
[ "$sig" = "55aa" ] && sfdisk -d "$ISO" >/dev/null 2>&1 \
    || die "the ISO is not hybrid -- Rufus/Etcher would not boot it"
echo "Hybrid ISO: OK (MBR + EFI partition; Rufus DD mode / Etcher ready)"
( cd "$(dirname "$ISO")" && sha256sum "$(basename "$ISO")" | tee "$(basename "$ISO").sha256" )

say "Done: $ISO"
echo
echo "Copy the ISO to Windows (it is on drive D: D:\\Aero\\$(basename "$ISO")) and burn it with"
echo "Rufus (pick DD Image mode when it asks) or balenaEtcher -- see the README."
echo
echo "Free the 30 GB on D afterwards (optional):  sudo rm \"$WORK_IMG\""
echo "Keep $SB_DIR -- the next builds reuse that key, so no new MOK screen."
