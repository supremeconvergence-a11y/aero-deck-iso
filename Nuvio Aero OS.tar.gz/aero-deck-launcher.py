#!/usr/bin/env python3
"""
Aero Deck (Alt TV launcher)
Matches the Alt TV home screen: featured hero, frosted app tiles with names
underneath, Live TV, Movies, TV Shows, Games. Supports remote, trackpad
and touch, with smooth scrolling.

Design (locked by Drew, Nov 15 2026 -- matches the Alt TV desktop preview):
- Interface (main screen): "Aero Deck" top-left. The Navigator --
  the search bar, top-centred right above the hero: one unified
  bar with the helmet (Co-pilot) mark on the left (pressing it asks
  the AI at the helm) and "Navigator" centred, no "Search" text,
  no divider line. Clicking the bar opens the Navigator keyboard.
  Top-right is empty:
  no search pill, no Settings button, no clock/weather, no avatar,
  no Home button.
- Bottom-right fixed dock: just the blue circle button with the
  white Aero "A" on it that opens the Flight Deck. It stays put no
  matter what the rows/menus scroll. Wi-Fi,
  Bluetooth and every option live inside the Flight Deck -- nothing else
  sits on the home screen.
- Flight Deck (settings panel, slides up from the bottom): LIGHT/WHITE
  frosted panel by default (dark text), dark navy only in Dark Mode
  (Flight Deck -> Appearance). Rounded corners, floating tall height,
  it scrolls. Clock on the left, calendar visual in the center,
  weather with its icon on the right across the top, the IPTV section
  full-width right underneath (username, xxxx-ed password, URL),
  then the instrument panels in a two-column grid of rounded tiles
  (even on both sides, focused tile bright blue), Power and Restart
  at the bottom right. One panel, no second page. No search bar
  inside it -- searching happens from the Navigator bar.
- Backdrop: blue cherry-blossom sky; pink and white ONLY from the
  blossom flowers and petals. No pink wash.
- Hero: Stranger Things, kids on bikes under the red sky, frosty and
  almost translucent so the blossom backdrop shows through faintly.
- Rows: frosty translucent, app names fully readable underneath the
  icons, gaps between rows show the blossom backdrop and petals.
  Order: Your Apps, Live TV, Movies, Social Media, TV Shows, Games,
  Cloud Gaming.
- Clock: only inside the Flight Deck when it is opened. No clock
  on the desktop, tray or top bar.
- The A triangle is the Alt TV mark: frosty white triangle pointing
  up (reads as an A, not a play button), soft rounded corners.
- Hero sits up a tad.
- Portability (Drew, Nov 15 2026): the app runs anywhere Python 3
  + GTK 3 (PyGObject) is -- CachyOS TV box AND the Steam Deck in
  Desktop Mode (SteamOS is Arch-based too). No CachyOS-only or
  ISO-only dependency: the only hard requirements are Python 3,
  GTK 3, and the assets/ folder next to this file. Everything else
  (Waydroid, nmcli, bluetoothctl, pactl, mpv/ffplay, protonvpn-cli,
  systemctl) is best-effort with a graceful fallback when it isn't
  there. On the Deck the one setup step is installing PyGObject
  (sudo pacman -S python-gobject gtk3 after steamos-readonly
  disable); pacman installs may not survive a SteamOS update, so
  they may need reinstalling after one.
- Rows evenly spaced (same gap hero->apps and apps->Live TV).
- App icons: square frosted-glass tiles, name written underneath.
- Apps come from BOTH sides: Android apps through Waydroid, Linux apps
  run natively. No Google Play Store -- APKs install directly from the
  Apps page and nothing is blocked.
- Social Media row: real content, not app icons. The latest videos
  from the YouTube / Rumble channels Drew watches -- thumbnail + title,
  tap to watch. Channels are added in the Flight Deck -> Apps -> Social feeds.
- Flight Deck is a slide-in panel (A button, bottom-right dock): clock /
  weather split, IPTV section, instrument-panel tiles, Power and
  Restart at the bottom. IPTV sources (M3U / Xtream) and row order
  live in the panel.
  Back from the panel (or any sub-page) takes you home.
- Rows are reorderable: pick which row is 1st, 2nd, 3rd... (rows.json).
- Steam Controller: trackpads work as a mouse cursor (right pad moves
  it, right pad click = left click), Steam Input on by default.
- Remote: the Alexa Voice Remote (Bluetooth). D-pad navigates, Back goes
  back, Home goes home, Menu opens the Flight Deck, and the Alexa
  button is push-to-talk voice.

The content below (apps, channels, movies, shows, games) is the demo
lineup from the Alt TV video. Swap in real sources/posters as they land.
App tiles use a real icon when one is available (assets/icons or the
icon theme); the letter is only a last-resort fallback. The Social
Media row shows real video content, not app icons.
"""

import gi
gi.require_version('Gtk', '3.0')
gi.require_version('GdkPixbuf', '2.0')
from gi.repository import Gtk, Gdk, GLib, GdkPixbuf
try:
    # Registers the cairo.Context converter, so the ATriangle draw
    # handler receives a real cairo context instead of failing with
    # "Couldn't find foreign struct converter for 'cairo.Context'".
    # Without it the A mark never paints (search bar logo, dock
    # button). Guarded: the app still runs if pycairo is absent.
    import cairo  # noqa: F401
except ImportError:
    cairo = None
import subprocess
import json
import re
import shutil
import datetime
import threading
import time
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path
import os
import sys

# Aero Deck version of THIS launcher file. The self-updater compares it
# with the version published at the update URL (see aero-deck-update).
AERO_DECK_VERSION = "1.4.0"

# Artwork folder. The session exports AERO_DECK_ASSETS; when it is not
# set, assets/ next to this file. (A self-updated launcher lives in
# ~/.local/share/aero-deck/, so it must not look next to itself.)
ASSETS_DIR = Path(os.environ.get("AERO_DECK_ASSETS")
                  or (Path(__file__).resolve().parent / "assets"))


def _esc(text):
    """Escape dynamic text for Pango markup so titles with & or < cannot
    crash a label."""
    return GLib.markup_escape_text("" if text is None else str(text))


def _spawn(cmd, **kwargs):
    """Best-effort process start. Missing binaries (waydroid, mpv, steam,
    xdg-open, pactl, ...) must not take down the launcher."""
    try:
        if not cmd:
            return None
        binary = cmd[0]
        if not shutil.which(binary) and not Path(str(binary)).is_file():
            return None
        return subprocess.Popen(cmd, **kwargs)
    except Exception:
        return None

CONFIG_DIR = Path.home() / ".config" / "tv-launcher"
CONFIG_FILE = CONFIG_DIR / "playlists.json"
ROWS_FILE = CONFIG_DIR / "rows.json"
CUSTOM_APPS_FILE = CONFIG_DIR / "custom_apps.json"
# Your Apps row order (Drew's order, new installs at the front) and the
# apps he has removed/uninstalled from the row (so a built-in doesn't
# silently come back as a web tile after he uninstalls it).
APPS_ORDER_FILE = CONFIG_DIR / "apps_order.json"
APPS_HIDDEN_FILE = CONFIG_DIR / "apps_hidden.json"
CONFIG_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Stage 1 (Nov 22 2026): screen fit, crash safety, Steam, persistence.
# ---------------------------------------------------------------------------
# The home screen was designed in "design pixels" for a 1920x1080 TV.
# UI_SCALE maps design pixels to real pixels for THIS screen, so the
# same layout fits a Steam Deck (1280x800 -> 0.667), a 1366x768 laptop,
# a 1080p TV (1.0) or a 4K TV (capped at 1.0 here; the compositor's
# output scale handles HiDPI). Every fixed size the launcher sets
# (widget sizes, margins, spacing, CSS px, icon/poster pixbufs, Pango
# point sizes) goes through it -- see _install_ui_scale(). A manual
# override lives in Flight Deck -> Display -> Interface size
# (settings.json "ui_scale": "auto" | 0.5 .. 1.5).
UI_SCALE = 1.0
UI_PROFILE = "tv"          # "deck" | "handheld" | "laptop" | "tv"
_UI_SCALE_READY = False
UI_SCALE_CHOICES = [("auto", "Auto (fit this screen)"), ("0.55", "55%"),
                    ("0.6", "60%"), ("0.667", "67% (Steam Deck)"),
                    ("0.75", "75%"), ("0.85", "85%"), ("1.0", "100% (TV)"),
                    ("1.25", "125%")]
_HANDHELD_DMI = {"Jupiter": "deck", "Galileo": "deck"}


def detect_device_profile(width=None, height=None):
    """Layout profile from the hardware (DMI) and the screen size."""
    try:
        product = Path("/sys/class/dmi/id/product_name").read_text().strip()
    except Exception:
        product = ""
    if product in _HANDHELD_DMI:
        return "deck"
    if product.startswith("ROG Ally") or product in (
            "83E1", "83N0", "83N1", "G1618-04", "G1617-01"):
        return "handheld"
    if width and height:
        if width <= 1366 or height <= 800:
            return "laptop" if width >= 1280 else "handheld"
    return "tv"


def compute_ui_scale(width, height, override=None):
    """Design 1920x1080 -> this screen. Pure function (unit-tested)."""
    if override not in (None, "", "auto"):
        try:
            v = float(override)
            if 0.4 <= v <= 2.0:
                return round(v, 3)
        except (TypeError, ValueError):
            pass
    if not width or not height or width <= 0 or height <= 0:
        return 1.0
    # Fit both directions; the Deck's 16:10 panel is width-bound.
    s = min(width / 1920.0, height / 1080.0)
    return round(max(0.45, min(1.0, s)), 3)


def _S(v):
    """Design px -> real px (ints stay ints; -1 / 0 pass through)."""
    try:
        if v is None or v <= 0:
            return v
    except TypeError:
        return v
    if UI_SCALE == 1.0:
        return v
    return max(1, int(round(v * UI_SCALE)))


def _dz(px):
    """Real px -> design px (for sizes computed from allocations)."""
    try:
        return int(round(px / UI_SCALE)) if UI_SCALE else px
    except Exception:
        return px


_PX_RE = re.compile(rb"(?<![\w.#-])(-?\d+(?:\.\d+)?)px")


def scale_css(css):
    """Scale every 'NNpx' in a stylesheet by UI_SCALE (1px borders stay
    1px so hairlines never vanish)."""
    if UI_SCALE == 1.0:
        return css
    is_str = isinstance(css, str)
    data = css.encode() if is_str else css

    def rep(m):
        v = float(m.group(1))
        if abs(v) <= 1.0:
            return m.group(0)
        nv = v * UI_SCALE
        out = ("%d" % round(nv)) if abs(nv) >= 2 else ("%.1f" % nv)
        return out.encode() + b"px"
    out = _PX_RE.sub(rep, data)
    return out.decode() if is_str else out


def _install_ui_scale():
    """Route fixed sizes through UI_SCALE (monkeypatches GTK setters)."""
    if getattr(Gtk.Widget, "_aero_scaled", False):
        return
    Gtk.Widget._aero_scaled = True
    W = Gtk.Widget
    _orig = {}

    def wrap(cls, name, conv):
        f = getattr(cls, name, None)
        if f is None or (cls, name) in _orig:
            return
        _orig[(cls, name)] = f

        def patched(self, *args):
            return f(self, *conv(args))
        patched.__name__ = name
        setattr(cls, name, patched)

    both = lambda a: tuple(_S(x) if isinstance(x, (int, float)) else x
                           for x in a)
    wrap(W, "set_size_request", both)
    for side in ("start", "end", "top", "bottom", "left", "right"):
        wrap(W, "set_margin_" + side, both)
    wrap(Gtk.Box, "set_spacing", both)
    wrap(Gtk.Grid, "set_row_spacing", both)
    wrap(Gtk.Grid, "set_column_spacing", both)
    wrap(Gtk.FlowBox, "set_row_spacing", both)
    wrap(Gtk.FlowBox, "set_column_spacing", both)
    for n in ("set_min_content_width", "set_min_content_height",
              "set_max_content_width", "set_max_content_height"):
        wrap(Gtk.ScrolledWindow, n, both)
    wrap(Gtk.Container, "set_border_width", both)

    keys = ("spacing", "row_spacing", "column_spacing", "margin",
            "margin_start", "margin_end", "margin_top", "margin_bottom",
            "width_request", "height_request", "border_width")
    for cls in (Gtk.Box, Gtk.Grid, Gtk.FlowBox, Gtk.ButtonBox):
        init = cls.__init__

        def make(init):
            def __init__(self, *a, **kw):
                for k in keys:
                    if isinstance(kw.get(k), (int, float)):
                        kw[k] = _S(kw[k])
                init(self, *a, **kw)
            return __init__
        cls.__init__ = make(init)

    css_load = Gtk.CssProvider.load_from_data

    def load_from_data(self, data, *rest):
        return css_load(self, scale_css(data), *rest)
    Gtk.CssProvider.load_from_data = load_from_data

    P = GdkPixbuf.Pixbuf
    at_scale = P.new_from_file_at_scale
    at_size = P.new_from_file_at_size

    def new_from_file_at_scale(path, w, h, keep=True):
        return at_scale(path, _S(w), _S(h), keep)

    def new_from_file_at_size(path, w, h):
        return at_size(path, _S(w), _S(h))
    P.new_from_file_at_scale = staticmethod(new_from_file_at_scale)
    P.new_from_file_at_size = staticmethod(new_from_file_at_size)
    # Pango point sizes in markup (size='24576') and the default font
    # follow the DPI, so scaling the DPI scales all text that is not
    # already sized in CSS px.
    try:
        st = Gtk.Settings.get_default()
        if st is not None:
            st.set_property("gtk-xft-dpi", int(96 * 1024 * UI_SCALE))
    except Exception:
        pass


def init_ui_scale(force=None):
    """Pick UI_SCALE for this screen once, before the first window."""
    global UI_SCALE, UI_PROFILE, _UI_SCALE_READY
    if _UI_SCALE_READY:
        return UI_SCALE
    _UI_SCALE_READY = True
    w = h = 0
    try:
        display = Gdk.Display.get_default()
        mon = display.get_primary_monitor() or display.get_monitor(0)
        geo = mon.get_geometry()
        w, h = geo.width, geo.height
    except Exception:
        pass
    override = force or os.environ.get("AERO_UI_SCALE")
    if not override:
        try:
            override = json.loads((CONFIG_DIR / "settings.json")
                                  .read_text()).get("ui_scale")
        except Exception:
            override = None
    UI_PROFILE = detect_device_profile(w, h)
    UI_SCALE = compute_ui_scale(w, h, override)
    try:
        print("aero-deck: screen %dx%d profile=%s ui_scale=%s"
              % (w, h, UI_PROFILE, UI_SCALE), file=sys.stderr, flush=True)
    except Exception:
        pass
    _install_ui_scale()
    return UI_SCALE


# -- Crash safety -------------------------------------------------------------
# A Python error inside a GTK callback (touch, swipe, timers) is logged
# and swallowed -- it must never take the launcher down. Hard crashes
# (segfaults) dump a traceback to the log; aero-deck-loop restarts the
# launcher within 2 s either way.
def _install_crash_guard():
    log_dir = Path.home() / ".cache"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        import faulthandler
        fh = open(log_dir / "aero-deck-crash.log", "a")
        faulthandler.enable(file=fh, all_threads=True)
        _install_crash_guard._fh = fh
    except Exception:
        pass

    def hook(etype, value, tb):
        try:
            import traceback
            with open(log_dir / "aero-deck-crash.log", "a") as f:
                f.write("%s uncaught %s\n" % (
                    datetime.datetime.now().isoformat(), etype.__name__))
                traceback.print_exception(etype, value, tb, file=f)
        except Exception:
            pass
    sys.excepthook = hook


_install_crash_guard()


# -- Persistent data (live USB) ------------------------------------------------
# On the live ISO the home folder lives in RAM, so ~/.config is wiped at
# power-off. aero-deck-persist.service mounts a partition labelled
# AERO_DATA (any USB stick / SD card / spare partition, ext4/exFAT/FAT)
# at /run/aero-data; the launcher mirrors the IPTV sources and its
# settings there and restores them at start. Installed systems keep
# ~/.config as normal (the mirror is then just a backup).
PERSIST_DIRS = [Path(os.environ.get("AERO_DATA_DIR", "/run/aero-data"))]
PERSIST_FILES = ["playlists.json", "settings.json", "rows.json",
                 "custom_apps.json", "apps_order.json", "apps_hidden.json",
                 "iptv_cache.json"]


def _persist_targets():
    out = []
    for d in PERSIST_DIRS:
        try:
            if d.is_dir() and os.access(str(d), os.W_OK):
                t = d / "tv-launcher"
                t.mkdir(exist_ok=True)
                out.append(t)
        except Exception:
            continue
    return out


def persist_save(name):
    """Mirror one config file to the persistent store(s). Private
    (0600): playlists.json holds IPTV logins."""
    src = CONFIG_DIR / name
    for d in _persist_targets():
        try:
            dst = d / name
            tmp = d / (name + ".tmp")
            tmp.write_bytes(src.read_bytes())
            os.chmod(str(tmp), 0o600)
            os.replace(str(tmp), str(dst))
        except Exception:
            continue


def persist_restore():
    """At start: any config file missing from ~/.config (fresh live
    boot) comes back from the persistent store."""
    for d in _persist_targets():
        for name in PERSIST_FILES:
            try:
                src = d / name
                dst = CONFIG_DIR / name
                if src.is_file() and not dst.exists():
                    dst.write_bytes(src.read_bytes())
                    os.chmod(str(dst), 0o600)
            except Exception:
                continue


persist_restore()

# ---------------------------------------------------------------------------
# Rows: order is Drew's choice (1st, 2nd, 3rd...). Saved in rows.json.
# Default order (Drew, Nov 15): Your Apps, Live TV, News, TV Shows,
# Movies, Social Media, Games, Cloud Gaming. News sits right after
# Live TV; TV Shows sits right after News.
# ---------------------------------------------------------------------------
DEFAULT_ROWS = ["apps", "live", "news", "shows", "movies", "social",
                "games", "cloud"]
# The previous shipped default, kept only so a stale rows.json holding
# exactly this order can be recognised and replaced -- it was the old
# default, never Drew's choice, so it must not override the new one.
OLD_DEFAULT_ROWS = ["apps", "live", "movies", "social", "shows", "games",
                    "cloud"]
ROW_TITLES = {
    "apps": "Your Apps",
    "social": "Social Media",
    "live": "Live TV",
    "news": "News",
    "movies": "Movies",
    "shows": "TV Shows",
    "games": "Games",
    "cloud": "Cloud Gaming",
}


def load_row_order():
    """Read the saved row order, falling back to the default. A file
    holding exactly the OLD shipped default is stale -- it was never
    Drew's choice, just the previous default -- so the new default
    ships instead (and the file is rewritten, so it can't silently
    override the new order again). A file with a genuinely different
    order is Drew's own custom order and is respected as-is."""
    try:
        data = json.loads(ROWS_FILE.read_text())
        order = [r for r in data.get("order", []) if r in ROW_TITLES]
        if not order:
            return list(DEFAULT_ROWS)
        if order == OLD_DEFAULT_ROWS:
            save_row_order(list(DEFAULT_ROWS))
            return list(DEFAULT_ROWS)
        # Any rows missing from the file get slotted into their
        # default position (right after their predecessor in the
        # default order), so a new row lands where it belongs instead
        # of tacked on at the end. Drew's own custom order is
        # respected as-is otherwise.
        for r in DEFAULT_ROWS:
            if r in order:
                continue
            idx = DEFAULT_ROWS.index(r)
            placed = False
            for j in range(idx - 1, -1, -1):
                if DEFAULT_ROWS[j] in order:
                    order.insert(order.index(DEFAULT_ROWS[j]) + 1, r)
                    placed = True
                    break
            if not placed:
                order.append(r)
        return order
    except Exception:
        return list(DEFAULT_ROWS)


def save_row_order(order):
    ROWS_FILE.write_text(json.dumps({"order": order}, indent=2))
    persist_save("rows.json")


def load_playlists():
    """IPTV sources: list of {"name": ..., "url": ...,
    "type": "m3u"|"xtream", "username": ..., "password": ...}.
    Username/password are the Xtream login, optional -- the username
    is shown in the Flight Deck's IPTV section when set; the password
    is shown there only as xxxx, never in plain text."""
    try:
        data = json.loads(CONFIG_FILE.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_playlists(playlists):
    CONFIG_FILE.write_text(json.dumps(playlists, indent=2))
    try:
        os.chmod(str(CONFIG_FILE), 0o600)
    except Exception:
        pass
    _IPTV_STATE_CACHE.update(at=None, state=None)
    persist_save("playlists.json")


# ---------------------------------------------------------------------------
# EPG guide + dedicated Movies / Shows pages (data layer).
# The launcher KNOWS when the IPTV source is initiated: the guide and
# the title pages draw from the IPTV source once it is connected, and
# show a hint (with the built-in demo data) while it is not. Nothing
# here fakes IPTV data -- where the source has no program, quality or
# schedule info, the page says so instead of inventing one.
# ---------------------------------------------------------------------------

# Per-page colour themes (phone-style named variants). EACH page keeps
# its own theme, independent of the others: the EPG can be Blue while
# Movies is Pink and Shows is Red. The theme lives in that page's own
# options panel, persisted per page in settings (epg_color /
# movies_color / shows_color). Changing one page never changes another.
PAGE_THEMES = {
    "Navy": "#141a26",
    "Dark": "#0e0e12",
    "Blue": "#12233f",
    "Teal": "#0f2e2b",
    "Pink": "#3d1f2b",
    "Red": "#3d1414",
    "Purple": "#241a3d",
    "Green": "#142e1a",
}
PAGE_THEME_NAMES = list(PAGE_THEMES.keys())

# Each theme variant is presented by its BORDER HIGHLIGHT + BACKGROUND
# COLOR (phone-style theme picker): the swatch shows the theme's solid
# background with its bright border highlight around it.
PAGE_THEME_BORDER = {
    "Navy": "#2b6fe3",
    "Dark": "#6a6a7a",
    "Blue": "#2b6fe3",
    "Teal": "#2bb673",
    "Pink": "#e85d8a",
    "Red": "#e50914",
    "Purple": "#8b5cf6",
    "Green": "#34c759",
}


def page_theme_border(name):
    """Border highlight hex for a page theme name."""
    return PAGE_THEME_BORDER.get(name, PAGE_THEME_BORDER["Navy"])


def page_theme_hex(name):
    """Solid background hex for a page theme name (Navy if unknown)."""
    return PAGE_THEMES.get(name, PAGE_THEMES["Navy"])


EPG_FAVORITES_FILE = CONFIG_DIR / "epg_favorites.json"
EPG_CHANNELS_FILE = CONFIG_DIR / "epg_channels.json"
TITLE_FAVORITES_FILE = CONFIG_DIR / "title_favorites.json"
TITLE_HIDDEN_FILE = CONFIG_DIR / "title_hidden.json"
RESUME_FILE = CONFIG_DIR / "resume.json"


def _load_json_list(path):
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _load_json_dict(path):
    try:
        data = json.loads(path.read_text())
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_json(path, data):
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, indent=2))
    except Exception:
        pass


# -- EPG favourites (starred live channels) ----------------------------------
def load_epg_favorites():
    return _load_json_list(EPG_FAVORITES_FILE)


def save_epg_favorites(names):
    _save_json(EPG_FAVORITES_FILE, list(names))


def is_epg_favorite(name):
    return name in load_epg_favorites()


def toggle_epg_favorite(name):
    favs = load_epg_favorites()
    if name in favs:
        favs.remove(name)
        starred = False
    else:
        favs.append(name)
        starred = True
    save_epg_favorites(favs)
    return starred


# -- EPG channel checklist (which live channels stay in the guide) -----------
# Stored as the list of HIDDEN channel names; everything else is kept.
# Default: nothing hidden, every available channel is in the guide.
def load_epg_hidden_channels():
    return _load_json_list(EPG_CHANNELS_FILE)


def save_epg_hidden_channels(names):
    _save_json(EPG_CHANNELS_FILE, list(names))


def set_epg_channel_kept(name, kept):
    hidden = load_epg_hidden_channels()
    if kept and name in hidden:
        hidden.remove(name)
    elif not kept and name not in hidden:
        hidden.append(name)
    save_epg_hidden_channels(hidden)


def is_epg_channel_kept(name):
    return name not in load_epg_hidden_channels()


# -- Title favourites + hidden titles (Movies / Shows pages) ------------------
def load_title_favorites():
    data = _load_json_dict(TITLE_FAVORITES_FILE)
    return {"movies": list(data.get("movies", [])),
            "shows": list(data.get("shows", []))}


def save_title_favorites(favs):
    _save_json(TITLE_FAVORITES_FILE, {
        "movies": list(favs.get("movies", [])),
        "shows": list(favs.get("shows", []))})


def is_title_favorite(kind, title):
    return title in load_title_favorites().get(kind, [])


def toggle_title_favorite(kind, title):
    favs = load_title_favorites()
    lst = favs.setdefault(kind, [])
    if title in lst:
        lst.remove(title)
        starred = False
    else:
        lst.append(title)
        starred = True
    save_title_favorites(favs)
    return starred


def load_title_hidden():
    data = _load_json_dict(TITLE_HIDDEN_FILE)
    return {"movies": list(data.get("movies", [])),
            "shows": list(data.get("shows", []))}


def save_title_hidden(hidden):
    _save_json(TITLE_HIDDEN_FILE, {
        "movies": list(hidden.get("movies", [])),
        "shows": list(hidden.get("shows", []))})


def set_title_kept(kind, title, kept):
    hidden = load_title_hidden()
    lst = hidden.setdefault(kind, [])
    if kept and title in lst:
        lst.remove(title)
    elif not kept and title not in lst:
        lst.append(title)
    save_title_hidden(hidden)


def is_title_kept(kind, title):
    return title not in load_title_hidden().get(kind, [])


# -- Resume (continue watching) ----------------------------------------------
# Each entry: {"kind": "movie"|"show", "title": ..., "progress": 0-100,
# "updated": ISO timestamp}. Persisted so a stopped title can be picked
# up another time.
def load_resume():
    entries = _load_json_list(RESUME_FILE)
    out = []
    for e in entries:
        if isinstance(e, dict) and e.get("title"):
            try:
                prog = int(e.get("progress", 0))
            except (TypeError, ValueError):
                prog = 0
            out.append({"kind": e.get("kind", "movie"),
                        "title": e["title"],
                        "progress": max(0, min(100, prog)),
                        "updated": e.get("updated", "")})
    return out


def save_resume(entries):
    _save_json(RESUME_FILE, list(entries))


def get_resume(kind, title):
    for e in load_resume():
        if e["kind"] == kind and e["title"] == title:
            return e
    return None


def set_resume(kind, title, progress):
    entries = [e for e in load_resume()
               if not (e["kind"] == kind and e["title"] == title)]
    entries.insert(0, {
        "kind": kind, "title": title,
        "progress": max(0, min(100, int(progress))),
        "updated": datetime.datetime.now().isoformat(timespec="seconds")})
    save_resume(entries)


def clear_resume(kind, title):
    save_resume([e for e in load_resume()
                 if not (e["kind"] == kind and e["title"] == title)])


# -- Title quality (4K / 1080p badges) ----------------------------------------
# Quality is known ONLY when a source reports it -- the IPTV source,
# once initiated, fills TITLE_QUALITY from its stream info. The
# built-in demo titles carry NO quality here: their resolution is not
# in the source data, so no badge is shown rather than a faked one.
# Tests / the IPTV loader write into this dict.
TITLE_QUALITY = {}


def title_quality(kind, title):
    """'4K' or '1080p' when the source knows it, else None (no badge)."""
    return TITLE_QUALITY.get((kind, title))


# -- Title details (runtime / cast / plot / episodes) ------------------------
# Details are known ONLY when a source reports them -- the IPTV
# source, once initiated, fills TITLE_DETAILS from its stream info
# (VOD entries carry duration / cast / plot; series entries carry
# cast / plot / episode_run_time / series_id). The built-in demo
# titles carry NO details here: their runtime and cast are not in
# the source data, so the detail page shows only what is known
# rather than a faked runtime or cast list. Faces: a cast member
# shows a photo only when the source gives a photo URL for them.
TITLE_DETAILS = {}


def title_details(kind, title):
    """Detail dict for a title, or {} when the source knows nothing."""
    return TITLE_DETAILS.get((kind, title), {})


def _parse_duration(value):
    """A duration from source data into seconds, or None. Accepts
    seconds (int/float), "HH:MM:SS" / "MM:SS", and "1h 55m". Never
    raises, never guesses."""
    if value is None:
        return None
    try:
        if isinstance(value, (int, float)):
            secs = int(value)
            return secs if secs > 0 else None
        text = str(value).strip()
        if not text:
            return None
        if ":" in text:
            parts = [int(p) for p in text.split(":")]
            secs = 0
            for p in parts:
                secs = secs * 60 + p
            return secs if secs > 0 else None
        m = re.match(r"^(?:(\d+)\s*h\s*)?(?:(\d+)\s*m\s*)?$", text)
        if m and (m.group(1) or m.group(2)):
            return (int(m.group(1) or 0) * 3600
                    + int(m.group(2) or 0) * 60) or None
        secs = int(text)
        return secs if secs > 0 else None
    except Exception:
        return None


def _fmt_duration(seconds):
    """Seconds -> "2h 35m" / "45 min" / "1:23:45" for the runtime
    line. None in, None out."""
    if not seconds:
        return None
    seconds = int(seconds)
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return "%dh %02dm" % (h, m)
    if m:
        return "%d min" % m
    return "%d sec" % s


def _fmt_clock(seconds):
    """Seconds -> "1:23:45" / "12:34" for the runtime line."""
    seconds = max(0, int(seconds or 0))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


def _split_cast(value):
    """A cast field from source data into a list of names. Accepts a
    list, or a comma-separated string. Never raises."""
    if not value:
        return []
    if isinstance(value, (list, tuple)):
        return [str(v).strip() for v in value if str(v).strip()]
    return [p.strip() for p in str(value).split(",") if p.strip()]


def _record_title_details(kind, name, entry):
    """Store what one IPTV entry reports about a title (runtime,
    cast, plot, year, rating, series id). Only fields the entry
    actually carries are stored -- nothing is invented."""
    det = {}
    dur = _parse_duration(entry.get("duration")
                          or entry.get("episode_run_time"))
    if dur:
        det["runtime"] = dur
    cast = _split_cast(entry.get("cast"))
    if cast:
        det["cast"] = cast
    photos = entry.get("cast_photos") or entry.get("cast_images") or {}
    if isinstance(photos, dict) and photos:
        det["cast_photos"] = {str(k): str(v)
                              for k, v in photos.items()}
    plot = entry.get("plot") or entry.get("description") or ""
    if plot:
        det["plot"] = str(plot)
    year = (entry.get("release_date") or entry.get("releaseDate")
            or entry.get("year") or "")
    if year:
        det["year"] = str(year)[:4]
    rating = entry.get("rating") or entry.get("imdb_rating") or ""
    if rating:
        det["rating"] = str(rating)
    sid = entry.get("series_id")
    if sid is not None:
        det["series_id"] = sid
    cover = entry.get("stream_icon") or entry.get("cover") or ""
    if cover:
        det["cover"] = str(cover)
    backdrop = entry.get("backdrop_path") or ""
    if isinstance(backdrop, list):
        backdrop = backdrop[0] if backdrop else ""
    if backdrop:
        det["backdrop"] = str(backdrop)
    trailer = entry.get("youtube_trailer") or entry.get("trailer") or ""
    if trailer:
        det["trailer"] = str(trailer)
    vod_id = entry.get("stream_id") if kind == "movies" else \
        entry.get("series_id")
    if vod_id is not None:
        det["vod_id"] = vod_id
    if det:
        TITLE_DETAILS[(kind, name)] = det


# -- Episode lists for shows (from the IPTV source, lazily) ------------------
# A series' episodes come from the Xtream get_series_info call for
# that series -- the plain series list does not carry them. Fetched
# once per title (cached 60s) and only when the IPTV source is
# initiated. Returns {"seasons": n, "episodes": m, "list": [...]}
# or None when the source reports nothing -- the detail page then
# shows a hint, never a faked episode list.
_EPISODE_CACHE = {"at": {}, "data": {}}
EPISODE_CACHE_TTL_SECONDS = 60


def _xtream_source():
    """The configured Xtream source (base URL + credentials), or
    None when no Xtream source is configured."""
    for source in load_playlists():
        url = source.get("url") or ""
        stype = (source.get("type") or "").lower()
        if stype == "xtream" or "/player_api.php" in url:
            return source
    return None


def title_episodes(title):
    """Episodes for a show, from the IPTV source. Each entry:
    {"season": int, "episode": int, "name": str, "plot": str,
    "runtime": seconds|None}. None when the source reports no
    episode data -- never faked."""
    import time as _time
    now_ts = _time.time()
    cached = _EPISODE_CACHE["data"].get(title)
    if (cached is not None
            and now_ts - _EPISODE_CACHE["at"].get(title, 0)
            < EPISODE_CACHE_TTL_SECONDS):
        return cached
    result = None
    det = title_details("shows", title)
    sid = det.get("series_id")
    source = _xtream_source()
    if sid is not None and source:
        base = (source.get("url") or "").rstrip("/")
        user = source.get("username", "")
        password = source.get("password", "")
        api = ("%s/player_api.php?username=%s&password=%s&action="
               "get_series_info&series_id=%s" % (
                   base, urllib.parse.quote(user),
                   urllib.parse.quote(password), sid))
        try:
            data = json.loads(_fetch_url(api))
            eps = data.get("episodes") or {}
            out = []
            for season_key in sorted(eps, key=lambda k: int(k)):
                for e in eps[season_key] or []:
                    info = e.get("info") or {}
                    ep_url = ""
                    if e.get("id") is not None:
                        ext = e.get("container_extension") or "mp4"
                        ep_url = "%s/series/%s/%s/%s.%s" % (
                            base, user, password, e["id"], ext)
                    out.append({
                        "season": int(season_key),
                        "episode": int(e.get("episode_num") or 0),
                        "name": e.get("title") or "Episode %s" % (
                            e.get("episode_num") or "?"),
                        "plot": info.get("plot") or "",
                        "runtime": _parse_duration(
                            info.get("duration")),
                        "url": ep_url})
            if out:
                out.sort(key=lambda d: (d["season"], d["episode"]))
                result = {"seasons": len(eps),
                          "episodes": len(out), "list": out}
        except Exception:
            result = None
    _EPISODE_CACHE["data"][title] = result
    _EPISODE_CACHE["at"][title] = now_ts
    return result


# -- Genres for the built-in movies (the meta field is the year, not a
# genre, so the Movies page groups by this real genre map). Shows carry
# their genre in meta already.
MOVIE_GENRES = {
    "Oppenheimer": "Drama",
    "Barbie": "Comedy",
    "Top Gun: Maverick": "Action",
    "Avatar: The Way of Water": "Sci-Fi",
    "Spider-Man: Across the Spider-Verse": "Animation",
}


def movie_genre(title):
    return MOVIE_GENRES.get(title, "Other")


# -- EPG time header -----------------------------------------------------------
EPG_SLOT_MINUTES = 30
EPG_SLOT_COUNT = 5


def epg_time_slots(now=None):
    """Time header for the guide: the date string, 5 half-hour slots
    starting at the current half hour, the current-time label (for the
    highlighted pill) and the index of the slot 'now' sits in.
    Returns (date_str, slots, now_label, now_index) where slots is a
    list of (label, datetime)."""
    now = now or datetime.datetime.now()
    start = now.replace(minute=0 if now.minute < 30 else 30,
                        second=0, microsecond=0)
    slots = []
    for i in range(EPG_SLOT_COUNT):
        t = start + datetime.timedelta(minutes=EPG_SLOT_MINUTES * i)
        slots.append((t.strftime("%-I:%M %p"), t))
    date_str = now.strftime("%a %-d %b")
    now_label = now.strftime("%-I:%M %p")
    return date_str, slots, now_label, 0


# -- IPTV source: is it initiated? -------------------------------------------
# The launcher KNOWS when the IPTV source is initiated: a source is
# configured in playlists.json AND it loads (M3U parses to channels,
# or the Xtream API answers). The result is cached for 60s so opening
# the guide or a title page does not re-fetch every time; pass
# refresh=True to re-check (e.g. after the Flight Deck IPTV page
# saves). In this sandbox the fetch fails (no route) -- that is a
# real "not initiated", not a bug: the pages then show their demo data
# with a hint that the IPTV source is not connected.
_IPTV_STATE_CACHE = {"at": None, "state": None}
IPTV_STATE_TTL_SECONDS = 6 * 3600


def _parse_m3u(text):
    """Minimal M3U parser: (#EXTINF attributes, stream URL) pairs.
    Returns a list of {name, url, group, logo, epg_id, num, tvg_url}
    dicts. Never raises."""
    channels = []
    attrs = None
    name = None
    tvg_url = ""
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTM3U"):
            m = re.search(r'(?:url-tvg|x-tvg-url)="([^"]*)"', line)
            if m:
                tvg_url = m.group(1).split(",")[0].strip()
        elif line.startswith("#EXTINF"):
            head = line.rsplit(",", 1)[0] if "," in line else line
            attrs = dict(re.findall(r'([\w-]+)="([^"]*)"', head))
            name = line.rsplit(",", 1)[-1].strip() or \
                attrs.get("tvg-name") or "Unknown"
        elif not line.startswith("#") and name:
            channels.append({"name": name, "url": line,
                             "group": attrs.get("group-title", ""),
                             "logo": attrs.get("tvg-logo", ""),
                             "epg_id": attrs.get("tvg-id", ""),
                             "num": attrs.get("tvg-chno", ""),
                             "tvg_url": tvg_url})
            name = None
            attrs = None
    return channels


def _fetch_url(url, timeout=8):
    req = urllib.request.Request(url, headers={
        "User-Agent": "AeroDeck/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", "replace")


def _redact(text, *secrets):
    """Strip credentials out of any message before it is shown/logged."""
    text = str(text)
    for sec in secrets:
        if sec and len(str(sec)) >= 2:
            text = text.replace(str(sec), "****")
            text = text.replace(urllib.parse.quote(str(sec)), "****")
    return re.sub(r"(password=)[^&\s]+", r"\1****", text)


def normalize_iptv_source(name, url, username="", password="", stype=""):
    """Turn whatever was typed into a clean source dict.
    Understands: an M3U URL; an Xtream host ('host:port' or
    'http://host:port'); a full 'get.php?username=..&password=..'
    M3U link (becomes Xtream with the login filled in); a
    'player_api.php' URL. Returns (source_dict, error_or_None)."""
    url = (url or "").strip()
    username = (username or "").strip()
    password = password or ""
    stype = (stype or "").strip().lower()
    if not url:
        return None, "Type the server address or playlist URL."
    if not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", url):
        url = "http://" + url
    try:
        parts = urllib.parse.urlsplit(url)
    except Exception:
        return None, "That address doesn't look like a URL."
    if not parts.netloc:
        return None, "That address doesn't look like a URL."
    q = urllib.parse.parse_qs(parts.query)
    path = parts.path or ""
    base = "%s://%s" % (parts.scheme, parts.netloc)
    if path.endswith(("/get.php", "/player_api.php")) or (
            "username" in q and "password" in q):
        username = username or (q.get("username") or [""])[0]
        password = password or (q.get("password") or [""])[0]
        stype = "xtream"
        url = base + path.rsplit("/", 1)[0]
    elif stype == "xtream" or (username and password and
                               path in ("", "/")):
        stype = "xtream"
        url = (base + path).rstrip("/")
    else:
        stype = "m3u"
    if stype == "xtream" and not (username and password):
        return None, "Xtream needs the username and password too."
    src = {"name": (name or "").strip() or parts.hostname or "IPTV",
           "url": url.rstrip("/"), "type": stype,
           "username": username, "password": password}
    return src, None


def _fetch_bytes(url, timeout=30, limit=200 * 1024 * 1024):
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AeroDeck/1.2"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read(limit)


def _load_xtream(source, timeout=45, progress=None):
    """Xtream Codes player API: log in, then live streams (+ VOD
    movies + series when the server answers). Returns
    (channels, movies, shows, error). Credentials never appear in the
    error text."""
    base = (source.get("url") or "").rstrip("/")
    user = source.get("username", "")
    password = source.get("password", "")
    if not base or not user:
        return [], [], [], "Missing server address or username"
    api = "%s/player_api.php?username=%s&password=%s" % (
        base, urllib.parse.quote(user), urllib.parse.quote(password))
    red = lambda e: _redact(e, user, password)
    try:
        info = json.loads(_fetch_bytes(api, 20).decode("utf-8", "replace"))
        ui = info.get("user_info") if isinstance(info, dict) else None
        if isinstance(ui, dict) and str(ui.get("auth", "1")) == "0":
            return [], [], [], "Login refused (check username/password)"
        if isinstance(ui, dict) and ui.get("status") not in (
                None, "Active", "active"):
            return [], [], [], "Account status: %s" % ui.get("status")
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            return [], [], [], "Login refused (HTTP %d)" % exc.code
        return [], [], [], red("Server error (HTTP %d)" % exc.code)
    except Exception as exc:
        return [], [], [], red("Server not reachable: %s" % (
            getattr(exc, "reason", None) or exc.__class__.__name__))
    channels, movies, shows = [], [], []
    cats = {}
    try:
        for c in json.loads(_fetch_bytes(
                api + "&action=get_live_categories", timeout)):
            cats[str(c.get("category_id"))] = c.get("category_name", "")
    except Exception:
        pass
    if progress:
        progress("Loading channels…")
    try:
        live = json.loads(_fetch_bytes(api + "&action=get_live_streams",
                                       timeout).decode("utf-8", "replace"))
        for e in live if isinstance(live, list) else []:
            sid = e.get("stream_id")
            stream = e.get("direct_source") or ""
            if not stream and sid is not None:
                stream = "%s/live/%s/%s/%s.ts" % (
                    base, urllib.parse.quote(user),
                    urllib.parse.quote(password), sid)
            if not stream:
                continue
            channels.append({
                "name": e.get("name") or "Unknown", "url": stream,
                "logo": e.get("stream_icon") or "",
                "group": cats.get(str(e.get("category_id")), ""),
                "sid": sid, "epg_id": e.get("epg_channel_id") or "",
                "num": e.get("num") or ""})
    except Exception as exc:
        # Some panels time out on the JSON list; the M3U export of the
        # same account usually still works.
        try:
            text = _fetch_bytes(
                "%s/get.php?username=%s&password=%s&type=m3u_plus&output=ts"
                % (base, urllib.parse.quote(user),
                   urllib.parse.quote(password)), timeout * 2
            ).decode("utf-8", "replace")
            channels = _parse_m3u(text)
        except Exception:
            return [], [], [], red("Channel list failed: %s" % (
                getattr(exc, "reason", None) or exc.__class__.__name__))
    if progress:
        progress("%d channels · loading movies & series…" % len(channels))
    try:
        vod = json.loads(_fetch_bytes(api + "&action=get_vod_streams",
                                      timeout).decode("utf-8", "replace"))
        for e in vod if isinstance(vod, list) else []:
            name = e.get("name") or "Unknown"
            sid = e.get("stream_id")
            ext = e.get("container_extension") or "mp4"
            movies.append({"name": name, "group": e.get("category_name", ""),
                           "url": "%s/movie/%s/%s/%s.%s" % (
                               base, urllib.parse.quote(user),
                               urllib.parse.quote(password), sid, ext)
                           if sid is not None else ""})
            _record_title_details("movies", name, e)
    except Exception:
        pass
    try:
        series = json.loads(_fetch_bytes(api + "&action=get_series",
                                         timeout).decode("utf-8", "replace"))
        for e in series if isinstance(series, list) else []:
            name = e.get("name") or "Unknown"
            shows.append({"name": name, "url": "",
                          "group": e.get("category_name", "")})
            _record_title_details("shows", name, e)
    except Exception:
        pass
    return channels, movies, shows, None


IPTV_CACHE_FILE = CONFIG_DIR / "iptv_cache.json"
_IPTV_LOCK = threading.Lock()
_IPTV_LISTENERS = []


def _iptv_empty(error=None):
    return {"initiated": False, "source_name": "", "channels": [],
            "movies": [], "shows": [], "error": error, "sources": []}


def _iptv_disk_state():
    try:
        data = json.loads(IPTV_CACHE_FILE.read_text())
        if isinstance(data, dict) and "channels" in data:
            return data
    except Exception:
        pass
    return None


def iptv_load_now(progress=None):
    """Load every configured source (blocking -- call from a worker
    thread). Channels from all sources that load are merged. Each
    source gets a status line: loaded N / failed: reason."""
    playlists = load_playlists()
    state = _iptv_empty()
    if not playlists:
        state["error"] = "No IPTV source configured"
        return state
    for _src_i, source in enumerate(playlists):
        name = source.get("name") or "IPTV"
        stype = (source.get("type") or "").lower()
        url = source.get("url") or ""
        if progress:
            progress("%s: connecting…" % name)
        try:
            if stype == "xtream" or "/player_api.php" in url:
                chs, movs, shs, err = _load_xtream(
                    source, progress=(lambda m, n=name: progress(
                        "%s: %s" % (n, m))) if progress else None)
            else:
                text = _fetch_bytes(url, 60).decode("utf-8", "replace")
                chs, movs, shs = _parse_m3u(text), [], []
                err = None if chs else "Playlist has no channels"
        except Exception as exc:
            chs, movs, shs = [], [], []
            err = _redact("Could not load: %s" % (
                getattr(exc, "reason", None) or exc.__class__.__name__),
                source.get("username"), source.get("password"))
        state["sources"].append({"name": name, "ok": bool(chs),
                                 "channels": len(chs), "error": err})
        if chs:
            if not state["initiated"]:
                state["source_name"] = name
            state["initiated"] = True
            for _c in chs:
                _c["src"] = _src_i
            state["channels"].extend(chs)
            state["movies"].extend(movs)
            state["shows"].extend(shs)
        elif err and not state["initiated"]:
            state["error"] = "%s: %s" % (name, err)
    if state["initiated"]:
        state["error"] = None
    state["loaded_at"] = time.time()
    return state


def iptv_refresh_async(on_done=None, progress=None):
    """Reload all sources in the background; on_done(state) runs on the
    GTK main loop. Never blocks the UI."""
    def worker():
        if not _IPTV_LOCK.acquire(blocking=False):
            return
        try:
            prog = (lambda m: GLib.idle_add(progress, m)) if progress \
                else None
            state = iptv_load_now(prog)
            _IPTV_STATE_CACHE.update(at=time.time(), state=state)
            try:
                IPTV_CACHE_FILE.write_text(json.dumps(state))
                os.chmod(str(IPTV_CACHE_FILE), 0o600)
                persist_save("iptv_cache.json")
            except Exception:
                pass
        finally:
            _IPTV_LOCK.release()
        for cb in [on_done] + list(_IPTV_LISTENERS):
            if cb is not None:
                GLib.idle_add(lambda c=cb: (c(state), False)[1])
    threading.Thread(target=worker, daemon=True).start()


def iptv_source_state(refresh=False):
    """Current IPTV state, WITHOUT blocking: the last loaded result
    (memory, else the on-disk cache from the previous run). When it is
    older than IPTV_STATE_TTL_SECONDS a background reload starts and
    listeners are told when it lands. refresh=True loads synchronously
    (worker threads / tests only)."""
    if refresh:
        state = iptv_load_now()
        _IPTV_STATE_CACHE.update(at=time.time(), state=state)
        return state
    state = _IPTV_STATE_CACHE["state"]
    if state is None:
        state = _iptv_disk_state()
        if state is not None:
            _IPTV_STATE_CACHE.update(at=0, state=state)
    at = _IPTV_STATE_CACHE["at"]
    if load_playlists() and (at is None or time.time() - at
                             > IPTV_STATE_TTL_SECONDS):
        _IPTV_STATE_CACHE["at"] = time.time()   # one reload at a time
        iptv_refresh_async()
    if state is None:
        state = _iptv_empty("Loading IPTV…" if load_playlists()
                            else "No IPTV source configured")
    return state


def epg_available_channels():
    """Every live channel the guide COULD show (IPTV when initiated,
    else the demo list) -- without the checklist's hidden filter, so
    the options panel can offer unchecked channels back."""
    state = iptv_source_state()
    out = []
    if state["initiated"]:
        for ch in state["channels"]:
            out.append({"name": ch.get("name") or "Unknown",
                        "program": ch.get("program") or "Live TV",
                        "url": ch.get("url") or ""})
    else:
        for name, program, url in LIVE_CHANNELS:
            out.append({"name": name, "program": program, "url": url})
    return out


def epg_channel_list():
    """Channels for the guide, in guide order. IPTV channels when the
    source is initiated (their names as the source reports them);
    otherwise the built-in Live TV demo list -- each entry is
    {"number": int, "name": str, "program": str, "url": str}. The
    checklist hides channels Drew unchecked in the options panel;
    the number is the guide position, not a broadcaster number."""
    state = iptv_source_state()
    hidden = set(load_epg_hidden_channels())
    out = []
    if state["initiated"]:
        for ch in state["channels"]:
            name = ch.get("name") or "Unknown"
            if name in hidden:
                continue
            out.append({"number": len(out) + 1, "name": name,
                        "program": ch.get("program") or "Live TV",
                        "url": ch.get("url") or ""})
    else:
        for name, program, url in LIVE_CHANNELS:
            if name in hidden:
                continue
            out.append({"number": len(out) + 1, "name": name,
                        "program": program, "url": url})
    return out


def title_sections(kind):
    """Sections for a dedicated Movies / Shows page, as data:
    {"Popular": [(name, meta)], "New": [...],
     "Genre": {genre: [(name, meta)]}, "Favorites": [...],
     "Resume": [resume entries]}. IPTV titles when the source is
    initiated, otherwise the built-in lists. The options-panel
    checklist hides titles Drew unchecked; favourites and resume
    come from their persisted files. Quality rides on each title via
    title_quality()."""
    state = iptv_source_state()
    if kind == "movies":
        base = [(c["name"], c.get("group", "") or movie_genre(c["name"]))
                for c in state["movies"]] if state["initiated"] else \
            [(n, movie_genre(n)) for n, _y in MOVIES]
        genre_of = movie_genre
    else:
        base = [(c["name"], c.get("group", "") or "Other")
                for c in state["shows"]] if state["initiated"] else \
            list(SHOWS)
        genre_of = (lambda n: dict((nm, g) for nm, g in SHOWS).get(
            n, "Other"))
    kept = [(n, m) for n, m in base if is_title_kept(kind, n)]
    # Popular: the list as it stands. New: the most recent -- by year
    # for movies (2023 first), by reverse list order for shows (the
    # last added first, the list order is the order they were added).
    popular = list(kept)
    if kind == "movies":
        year = dict(MOVIES)
        new = [t for t in kept
               if year.get(t[0]) == max(year.values(), default="")]
        new = new or list(reversed(kept))[:3]
    else:
        new = list(reversed(kept))[:3]
    genres = {}
    for n, _m in kept:
        genres.setdefault(genre_of(n), []).append((n, genre_of(n)))
    favs = load_title_favorites().get(kind, [])
    favorites = [(n, m) for n, m in kept if n in favs]
    resume = [e for e in load_resume() if e["kind"] == kind]
    return {"Popular": popular, "New": new, "Genre": genres,
            "Favorites": favorites, "Resume": resume}


def title_section_names(kind):
    """Section names in page order."""
    return ["Popular", "New", "Genre", "Favorites", "Resume"]


# -- Sounds --------------------------------------------------------------------
# Two sound settings, both with an OFF option (Drew: "there CAN be
# sound, but with the OPTION to turn it off"):
#   (1) VIEWING SOUND -- the audio of the channel / movie / show you
#       are watching or previewing (EPG preview + player). Toggle in
#       the EPG options panel and on the player bar. Setting
#       "viewing_sound", default on.
#   (2) SYSTEM SOUNDS -- the UI navigation sounds (move / click /
#       panel open: a soft "boop", never the Steam Deck sound).
#       A toggle for the WHOLE launcher (Flight Deck -> Sound) and a
#       toggle PER PAGE (EPG / Movies / Shows options panels). The
#       effective sound for a page is global AND that page's toggle.
#       Settings "system_sounds" (global) and "<page>_system_sounds".
# Sounds are best-effort: a missing player or a missing tone file
# just means silence, never a crash. Tests set _UI_SOUNDS_MUTED so
# the suite stays quiet.
_UI_SOUNDS_MUTED = False
_UI_TONE_CACHE = {}


# UI sound SETS -- a few different navigation sounds to pick from
# (Drew: surprise him -- similar to what the Steam Deck has, or other
# phones / tablets, or Google TV / Fire Stick). Each set is a family
# of soft blips for move / click / open; the set is picked in the
# Flight Deck -> Sound page and persisted as "sound_set". The tones
# are synthesized (sine, faded) so nothing has to be downloaded.
#   Aero (default): soft round boop. Steam Deck: warm low bloop with
#     a pitch glide down. Google TV: clean bright short tick.
#     Fire Stick: soft woody click, fast decay. Phone: very short,
#     quiet tap.
SOUND_SETS = {
    "Aero": {"move": (660, 660, 0.05, 0.30), "click": (880, 880, 0.05, 0.30),
             "open": (523, 784, 0.12, 0.30)},
    "Steam Deck": {"move": (520, 430, 0.07, 0.32),
                   "click": (660, 590, 0.06, 0.32),
                   "open": (440, 660, 0.13, 0.32)},
    "Google TV": {"move": (1200, 1200, 0.03, 0.28),
                  "click": (1500, 1500, 0.03, 0.28),
                  "open": (1000, 1400, 0.08, 0.28)},
    "Fire Stick": {"move": (800, 760, 0.04, 0.30),
                   "click": (1000, 950, 0.04, 0.30),
                   "open": (700, 1000, 0.09, 0.30)},
    "Phone": {"move": (900, 900, 0.03, 0.20),
              "click": (1100, 1100, 0.03, 0.20),
              "open": (800, 1200, 0.07, 0.20)},
}
SOUND_SET_NAMES = list(SOUND_SETS.keys())


def _ui_tone_path(kind, sound_set=None):
    """A tiny synthesized tone WAV for a sound kind in a sound set,
    written once into the config dir and reused. The frequency glides
    from f0 to f1 over the note (a glide is what makes the Steam
    Deck set read as a 'bloop'); the envelope fades in and out so
    the blip is soft, not a click."""
    import wave as _wave
    import struct as _struct
    import math as _math
    sound_set = sound_set or "Aero"
    key = (sound_set, kind)
    if key in _UI_TONE_CACHE:
        return _UI_TONE_CACHE[key]
    spec = SOUND_SETS.get(sound_set, SOUND_SETS["Aero"])
    f0, f1, dur, amp = spec.get(kind, spec["move"])
    rate = 22050
    n = max(1, int(rate * dur))
    frames = bytearray()
    phase = 0.0
    for i in range(n):
        frac = i / n
        freq = f0 + (f1 - f0) * frac
        phase += 2 * _math.pi * freq / rate
        # Fade in/out (fast attack for the Fire Stick click, gentle
        # for the rest -- the fade length scales with the note).
        fade = max(1, int(rate * 0.008))
        env = min(1.0, i / fade, (n - i) / fade)
        val = int(amp * 32767 * env * _math.sin(phase))
        frames += _struct.pack("<h", val)
    sounds_dir = CONFIG_DIR / "sounds"
    try:
        sounds_dir.mkdir(parents=True, exist_ok=True)
        fname = "ui-%s-%s.wav" % (
            sound_set.lower().replace(" ", "-"), kind)
        path = sounds_dir / fname
        if not path.exists():
            with _wave.open(str(path), "wb") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(rate)
                wf.writeframes(bytes(frames))
        _UI_TONE_CACHE[key] = str(path)
        return str(path)
    except Exception:
        return None


def preview_sound_set(sound_set, page=None):
    """Play a set's click + open back to back so Drew can hear what
    a set sounds like before picking it (used by the Sound page and
    the per-page options panels). page scopes the preview to that
    page's on/off switch."""
    play_ui_sound("click", page=page, sound_set=sound_set)
    GLib.timeout_add(
        160, lambda: play_ui_sound("open", page=page,
                                   sound_set=sound_set) or False)


def play_ui_sound(kind, page=None, sound_set=None):
    """Play a UI navigation sound (move / click / open) -- silently
    skipped when sounds are off FOR THIS PAGE, muted for tests, or
    when no audio player is available. page is 'epg' / 'movies' /
    'shows' / None (the main Interface). Each page keeps its OWN
    sound on/off and its OWN sound set, independent of the others:
    sound on in the EPG does not mean sound on in Movies. sound_set
    overrides the saved set (used to preview a set before picking)."""
    if _UI_SOUNDS_MUTED:
        return
    try:
        settings = load_settings()
        if page:
            if not settings.get("%s_system_sounds" % page, True):
                return
            set_name = (sound_set or settings.get(
                "%s_sound_set" % page, "Aero"))
        else:
            if not settings.get("system_sounds", True):
                return
            set_name = sound_set or settings.get("sound_set", "Aero")
        path = _ui_tone_path(kind, set_name)
        if not path:
            return
        player = shutil.which("mpv") or shutil.which("ffplay")
        if not player:
            return
        if player.endswith("mpv"):
            args = [player, "--no-video", "--really-quiet", path]
        else:
            args = [player, "-nodisp", "-autoexit", "-loglevel",
                    "quiet", path]
        _spawn(args, stdout=subprocess.DEVNULL,
               stderr=subprocess.DEVNULL)
    except Exception:
        return


def viewing_sound_on():
    """Is the viewing (preview / player) audio enabled?"""
    try:
        return bool(load_settings().get("viewing_sound", True))
    except Exception:
        return True



# ---------------------------------------------------------------------------
# Launcher settings + tasks (saved in the Flight Deck).
# ---------------------------------------------------------------------------
SETTINGS_FILE = CONFIG_DIR / "settings.json"
TASKS_FILE = CONFIG_DIR / "tasks.json"

# AIs at the helm (Navigator -> the A triangle asks the active one).
# Each AI: name, web address, and an optional Android app package
# (opened via Waydroid when installed, otherwise the web address in
# the browser). Nova is built-in and can't be removed; Supreme is
# seeded as the example second AI -- add more on the AI page.
DEFAULT_AIS = [
    {"name": "Nova", "url": "https://muse.ai",
     "app": "com.facebook.aura"},
    {"name": "Supreme", "url": "https://grok.com", "app": "ai.x.grok"},
    {"name": "Grok", "url": "https://grok.com", "app": "ai.x.grok"},
    {"name": "ChatGPT", "url": "https://chatgpt.com",
     "app": "com.openai.chatgpt"},
    {"name": "Gemini", "url": "https://gemini.google.com",
     "app": "com.google.android.apps.bard"},
]

DEFAULT_SETTINGS = {
    "background": "blossom",
    "theme": "dark",
    "accent": "#e50914",
    "sound_output": "Soundbar (eARC)",
    "passthrough": True,
    "screensaver_timeout": "5 min",
    "language": "English",
    "region": "Canada",
    "cursor_visible": True,
    "power_commands_enabled": False,
    "email": "",
    "steam_input": True,
    "trackpad_mouse": True,
    # Keyboard appearance (Flight Deck -> Keyboard instrument panel): the reference
    # default is mostly white -- the background barely shows through
    # (opacity 0.95), the same slight translucency as the search and
    # results cards above it.
    "keyboard_color": "#ffffff",
    "keyboard_opacity": 1.0,
    # AIs at the helm: the list and which one the triangle asks.
    "ais": [dict(ai) for ai in DEFAULT_AIS],
    "active_ai": "Nova",
    # EPG guide: preview follows the focused channel as you scroll
    # ("change", the default) or stays put ("stay"). Each full-screen
    # page keeps its OWN theme (background + border highlight),
    # independent of the others -- the EPG can be Blue while Movies
    # is Pink and Shows is Red.
    "epg_preview_behavior": "change",
    "epg_color": "Navy",
    "movies_color": "Navy",
    "shows_color": "Navy",
    # Sounds: viewing sound (EPG preview / player audio) and system
    # sounds (UI navigation) -- global toggle + a toggle per page.
    "viewing_sound": True,
    "system_sounds": True,
    "sound_set": "Aero",
    "epg_system_sounds": True,
    "epg_sound_set": "Aero",
    "movies_system_sounds": True,
    "movies_sound_set": "Aero",
    "movies_categories": ["Popular", "New", "Genre", "Favorites",
                          "Resume"],
    "shows_system_sounds": True,
    "shows_sound_set": "Aero",
    "shows_categories": ["Popular", "New", "Genre", "Favorites",
                         "Resume"],
}


def helm_ai_entry(settings):
    """The AI at the helm for a settings dict: the entry in
    settings["ais"] whose name matches settings["active_ai"], or
    Nova (the first) if the name is gone. A missing/empty settings
    dict means the default helm, Nova."""
    settings = settings or {}
    ais = settings.get("ais") or DEFAULT_AIS
    active = settings.get("active_ai", "Nova")
    for ai in ais:
        if isinstance(ai, dict) and ai.get("name") == active:
            return ai
    return ais[0]


def load_settings():
    try:
        data = json.loads(SETTINGS_FILE.read_text())
        merged = dict(DEFAULT_SETTINGS)
        if isinstance(data, dict):
            merged.update(data)
        return merged
    except Exception:
        return dict(DEFAULT_SETTINGS)


def save_settings(settings):
    SETTINGS_FILE.write_text(json.dumps(settings, indent=2))
    persist_save("settings.json")


def load_tasks():
    """Tasks: list of {"text": ..., "done": bool}."""
    try:
        data = json.loads(TASKS_FILE.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_tasks(tasks):
    TASKS_FILE.write_text(json.dumps(tasks, indent=2))


EVENTS_FILE = CONFIG_DIR / "calendar_events.json"


def load_events():
    """Calendar events: list of {"date": "YYYY-MM-DD", "time": "HH:MM",
    "kind": "Event"|"Show", "title": ...}."""
    try:
        data = json.loads(EVENTS_FILE.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_events(events):
    EVENTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    EVENTS_FILE.write_text(json.dumps(events, indent=2))


# ---------------------------------------------------------------------------
# Demo lineup (from the Alt TV video). Replace with real data as it lands.
# ---------------------------------------------------------------------------
APPS = [
    # (name, tile letter, tile colour, kind, target, fallback url)
    # kind: "android" (target = Android package, launched via Waydroid),
    #       "linux"   (target = command, run natively),
    #       "web"     (target = URL, opened in the browser).
    # Android apps fall back to their website if Waydroid or the app
    # isn't there yet. No Google Play Store -- APKs install directly
    # and nothing is blocked.
    ("Netflix", "N", "#e50914", "linux", "aero-webapp netflix",
     "https://www.netflix.com"),
    ("Hulu", "h", "#1ce783", "android", "com.hulu.plus",
     "https://www.hulu.com"),
    ("Prime Video", "P", "#00a8e1", "linux", "aero-webapp prime",
     "https://www.primevideo.com"),
    ("Disney+", "D", "#113ccf", "android", "com.disney.disneyplus",
     "https://www.disneyplus.com"),
    ("HBO Max", "M", "#5822b4", "android", "com.hbo.hbonow",
     "https://www.max.com"),
    ("Peacock", "P", "#000000", "android", "com.peacocktv.peacockandroid",
     "https://www.peacocktv.com"),
    ("Apple TV", "A", "#000000", "android", "com.apple.atve.androidtv",
     "https://tv.apple.com"),
    # YouTube: the 8th tile in the Your Apps row, matching the
    # reference (white tile, red play button). Alexa is NOT here --
    # it stays reachable through the voice remote / Alexa
    # integration, not as a Your Apps tile.
    ("YouTube", "Y", "#ff0000", "linux", "aero-webapp youtube",
     "https://www.youtube.com/tv"),
    # Aero OS Monday Night additions.
    ("YouTube Music", "M", "#ff0000", "linux", "aero-webapp ytmusic",
     "https://music.youtube.com"),
    ("Amazon Music", "a", "#25d1da", "linux", "aero-webapp amazonmusic",
     "https://music.amazon.ca"),
    ("GeForce NOW", "G", "#76b900", "linux", "aero-gfn",
     "https://play.geforcenow.com"),
    ("Boosteroid", "B", "#ff6a00", "linux", "aero-boosteroid",
     "https://cloud.boosteroid.com"),
    ("Amazon Luna", "L", "#7b2ff7", "linux", "aero-webapp luna",
     "https://luna.amazon.ca"),
    ("Downloader", "D", "#f26522", "android", "com.esaba.downloader", ""),
]

# Social Media row: Rumble and any other social app Drew
# downloads. Only social apps go here -- that's the rule for this row.
# (YouTube lives in the Your Apps row now, matching the reference --
# it is NOT listed here, so the keyboard search index doesn't show
# it twice.)
SOCIAL_APPS = [
    # Andrew, Nov 16: the Social Media row is Rumble, YouTube, Facebook.
    ("Rumble", "R", "#85c742", "linux", "aero-webapp rumble",
     "https://rumble.com"),
    ("YouTube", "Y", "#ff0000", "web", "https://www.youtube.com",
     "https://www.youtube.com"),
    ("Facebook", "f", "#1877f2", "web", "https://www.facebook.com",
     "https://www.facebook.com"),
]

# Known social Android packages. When Drew downloads one of these (from
# Aurora Store, say), the launcher spots it in Waydroid and it shows up
# in the Social Media row on its own -- nothing to configure.
SOCIAL_PACKAGES = {
    "com.google.android.youtube": ("YouTube", "Y", "#ff0000",
                                   "https://www.youtube.com"),
    "com.google.android.youtube.tv": ("YouTube", "Y", "#ff0000",
                                      "https://www.youtube.com"),
    "com.rumble.app": ("Rumble", "R", "#85c742", "https://rumble.com"),
    "com.zhiliaoapp.musically": ("TikTok", "T", "#000000",
                                 "https://www.tiktok.com"),
    "com.facebook.katana": ("Facebook", "F", "#1877f2",
                           "https://www.facebook.com"),
    "com.instagram.android": ("Instagram", "I", "#e1306c",
                             "https://www.instagram.com"),
    "com.twitter.android": ("X", "X", "#000000", "https://x.com"),
    "tv.twitch.android.app": ("Twitch", "T", "#9146ff",
                             "https://www.twitch.tv"),
    "com.snapchat.android": ("Snapchat", "S", "#fffc00",
                            "https://www.snapchat.com"),
    "com.reddit.frontpage": ("Reddit", "R", "#ff4500",
                            "https://www.reddit.com"),
    "com.pinterest": ("Pinterest", "P", "#e60023",
                     "https://www.pinterest.com"),
}


def load_custom_apps():
    """Apps Drew adds from the panel: list of dicts with
    name/letter/colour/kind/target/fallback."""
    try:
        data = json.loads(CUSTOM_APPS_FILE.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_custom_apps(apps):
    CUSTOM_APPS_FILE.write_text(json.dumps(apps, indent=2))


# ---------------------------------------------------------------------------
# Your Apps row: order, discovery, and the Android (Waydroid) plumbing
# behind the app-management panel (Move / More Info / Uninstall /
# Force Stop / Clear Cache / Clear Data / Allow).
#
# One ordered list drives the row. An app dict is:
#   key (kind:target, unique), name, letter, colour, kind, target,
#   fallback, source (builtin/custom/waydroid/linux), icon (Linux icon
#   name, "" otherwise), installed (bool -- Android apps only).
# ---------------------------------------------------------------------------
def load_apps_order():
    """Your Apps row order: list of app keys, or None on first run
    (no file yet -- the row is seeded in reference order)."""
    try:
        data = json.loads(APPS_ORDER_FILE.read_text())
        if isinstance(data, list):
            return [str(k) for k in data]
        if isinstance(data, dict) and isinstance(data.get("order"), list):
            return [str(k) for k in data["order"]]
    except Exception:
        pass
    return None


def save_apps_order(order):
    APPS_ORDER_FILE.write_text(json.dumps(list(order), indent=2))


def load_apps_hidden():
    """App keys Drew removed/uninstalled from the row. A hidden key
    never comes back on its own -- a built-in would otherwise
    reappear as a web tile after he uninstalls it."""
    try:
        data = json.loads(APPS_HIDDEN_FILE.read_text())
        if isinstance(data, list):
            return [str(k) for k in data]
    except Exception:
        pass
    return []


def save_apps_hidden(hidden):
    APPS_HIDDEN_FILE.write_text(json.dumps(list(hidden), indent=2))


# Waydroid packages that are part of the Android system itself, not
# apps Drew installed -- these never show in the Your Apps row.
SYSTEM_PACKAGE_PREFIXES = (
    "com.android.", "android.", "com.google.android.ext.",
    "com.google.android.gms", "com.google.android.gsf",
    "com.google.android.webview", "com.google.android.packageinstaller",
    "com.google.android.permissioncontroller",
    "com.google.android.providers.", "com.google.android.inputmethod.",
    "com.google.android.tts", "com.google.android.marvin.",
    "org.lineageos.", "com.lineageos.", "com.cyanogenmod.",
    "com.qualcomm.", "com.qti.", "com.waydro.id.",
    "org.codeaurora.", "com.google.android.apps.work.",
)
SYSTEM_PACKAGES = {"android"}


def _is_system_package(pkg):
    if pkg in SYSTEM_PACKAGES:
        return True
    return any(pkg.startswith(p) for p in SYSTEM_PACKAGE_PREFIXES)


def _parse_waydroid_package_line(line):
    """waydroid app list prints 'Package: com.foo', not a bare package
    name per line. Also accept a bare package if one ever appears."""
    raw = (line or "").strip()
    if not raw:
        return None
    if raw.lower().startswith("package:"):
        return raw.split(":", 1)[1].strip() or None
    # Skip other metadata lines (Name:, Version:, ...).
    if ":" in raw:
        return None
    return raw


def _waydroid_packages():
    """Every package installed in Waydroid (best effort -- empty when
    Waydroid isn't up, so the row just shows the built-ins)."""
    try:
        out = subprocess.check_output(
            ["waydroid", "app", "list"], timeout=10,
            stderr=subprocess.DEVNULL).decode("utf-8", "replace")
    except Exception:
        return []
    pkgs = []
    for line in out.splitlines():
        pkg = _parse_waydroid_package_line(line)
        if pkg:
            pkgs.append(pkg)
    return pkgs


# Tile colours for discovered apps (no brand colour known): picked
# deterministically from the name, so the same app keeps its colour.
_DISCOVERED_COLOURS = ["#5a5a6a", "#2b6cb0", "#2f855a", "#b7791f",
                       "#9b2c2c", "#6b46c1", "#2c7a7b", "#975a16"]


def _colour_for(name):
    import hashlib
    digest = hashlib.md5(name.encode("utf-8")).hexdigest()
    return _DISCOVERED_COLOURS[int(digest[:2], 16)
                               % len(_DISCOVERED_COLOURS)]


def _name_from_package(pkg):
    """A display name for a Waydroid package: the known map first,
    otherwise the last package segment, split on camelCase and
    title-cased (com.spotify.music -> Music)."""
    if pkg in SOCIAL_PACKAGES:
        name, letter, colour, fallback = SOCIAL_PACKAGES[pkg]
        return name, letter, colour, fallback
    last = pkg.split(".")[-1]
    if last.lower() in ("app", "client", "android", "mobile"):
        parts = pkg.split(".")
        last = parts[-2] if len(parts) > 1 else last
    import re
    words = re.findall(r"[A-Z]+(?![a-z])|[A-Z][a-z0-9]*|[a-z0-9]+",
                       last.replace("_", " ").replace("-", " "))
    name = " ".join(w.title() for w in words) or pkg
    return name, name[0].upper(), _colour_for(name), ""


def discover_waydroid_apps():
    """Installed Waydroid apps: (name, letter, colour, kind, target,
    fallback) per app. System packages are filtered out; social apps
    are included -- they belong in the Your Apps row too."""
    found = []
    seen = set()
    for pkg in _waydroid_packages():
        if _is_system_package(pkg) or pkg in seen:
            continue
        seen.add(pkg)
        name, letter, colour, fallback = _name_from_package(pkg)
        found.append((name, letter, colour, "android", pkg, fallback))
    return found


def discover_linux_apps():
    """Linux native apps: every GUI .desktop file (system + user).
    Skips NoDisplay / Hidden / Terminal-only entries. Returns app
    dicts (key/target/icon included)."""
    found = []
    seen = set()
    import configparser
    import shlex
    dirs = [Path("/usr/share/applications"),
            Path.home() / ".local" / "share" / "applications"]
    for d in dirs:
        if not d.is_dir():
            continue
        for path in sorted(d.glob("*.desktop"),
                           key=lambda p: (p.stem != "nuvio", p.name)):
            desktop_id = path.stem
            key = "linux:%s" % desktop_id
            if key in seen:
                continue
            try:
                parser = configparser.ConfigParser(
                    strict=False, interpolation=None)
                parser.optionxform = str
                parser.read_string(
                    path.read_text(encoding="utf-8", errors="replace"),
                    source=str(path))
                entry = parser["Desktop Entry"]
            except Exception:
                continue
            if entry.get("Type", "Application") != "Application":
                continue
            if entry.get("NoDisplay", "false").lower() == "true":
                continue
            if entry.get("Hidden", "false").lower() == "true":
                continue
            if entry.get("Terminal", "false").lower() == "true":
                continue
            name = (entry.get("Name") or "").strip()
            exec_cmd = (entry.get("Exec") or "").strip()
            if not name or not exec_cmd:
                continue
            # Exec field codes (%U, %F, ...) are launch arguments,
            # not part of the command.
            try:
                argv = [t for t in shlex.split(exec_cmd)
                        if not t.startswith("%")]
            except Exception:
                argv = [t for t in exec_cmd.split()
                        if not t.startswith("%")]
            if not argv:
                continue
            seen.add(key)
            found.append({
                "key": key, "name": name, "letter": name[0].upper(),
                "colour": _colour_for(name), "kind": "linux",
                "target": " ".join(argv), "fallback": "",
                "source": "linux",
                "icon": (entry.get("Icon") or "").strip(),
                "installed": True,
            })
    found.sort(key=lambda a: a["key"] != "linux:nuvio")   # stable
    return found


def assemble_apps():
    """The Your Apps row, in display order: built-ins + custom apps +
    every installed Waydroid / Linux app, ordered by apps_order.json.
    First run (no order file): seeded in reference order -- built-ins,
    then custom, then discovered -- so the first 8 visible are the
    reference 8. Later, any app that appears and isn't in the saved
    order (a fresh install) goes to the FRONT. Hidden keys never
    reappear. Returns a list of app dicts."""
    installed_pkgs = set(_waydroid_packages())
    by_key = {}
    # Built-ins (reference order).
    for name, letter, colour, kind, target, fallback in APPS:
        key = "%s:%s" % (kind, target)
        by_key[key] = {
            "key": key, "name": name, "letter": letter,
            "colour": colour, "kind": kind, "target": target,
            "fallback": fallback, "source": "builtin", "icon": "",
            "installed": target in installed_pkgs,
        }
    # Custom apps Drew added.
    for custom in load_custom_apps():
        if custom.get("row", "apps") != "apps":
            continue
        kind = custom.get("kind", "web")
        target = custom.get("target", "")
        key = "%s:%s" % (kind, target)
        if key in by_key:
            continue
        name = custom.get("name", "")
        by_key[key] = {
            "key": key, "name": name,
            "letter": custom.get("letter", name[:1].upper() or "?"),
            "colour": custom.get("colour", "#5a5a6a"), "kind": kind,
            "target": target, "fallback": custom.get("fallback", ""),
            "source": "custom", "icon": "",
            "installed": kind == "android" and target in installed_pkgs,
        }
    # Discovered Waydroid apps (not already a tile).
    for name, letter, colour, kind, target, fallback in \
            discover_waydroid_apps():
        key = "%s:%s" % (kind, target)
        if key in by_key:
            by_key[key]["installed"] = True
            continue
        by_key[key] = {
            "key": key, "name": name, "letter": letter,
            "colour": colour, "kind": kind, "target": target,
            "fallback": fallback, "source": "waydroid", "icon": "",
            "installed": True,
        }
    # Discovered Linux apps.
    for app in discover_linux_apps():
        if app["key"] in by_key:
            continue
        by_key[app["key"]] = app
    # Hidden keys never come back.
    for key in load_apps_hidden():
        by_key.pop(key, None)
    # Order.
    order = load_apps_order()
    if order is None:
        order = list(by_key.keys())
        save_apps_order(order)
    else:
        new_keys = [k for k in by_key if k not in order]
        if new_keys:
            order = new_keys + order
        pruned = [k for k in order if k in by_key]
        if pruned != order or new_keys:
            order = pruned
            save_apps_order(order)
    return [by_key[k] for k in order if k in by_key]


# ---------------------------------------------------------------------------
# Android (Waydroid) command plumbing. Every app-management action that
# touches a real app goes through here: `waydroid shell` first, `adb
# shell` second (Waydroid exposes adb). Each returns (ok, message) so
# the panel can say what happened instead of failing silently.
# ---------------------------------------------------------------------------
def android_shell(*args):
    """Run a command inside the Android container. Returns
    (returncode, stdout, stderr); returncode None when neither
    Waydroid nor adb is available (not running on this box)."""
    for base in (["waydroid", "shell"], ["adb", "shell"]):
        try:
            result = subprocess.run(base + [str(a) for a in args],
                                    capture_output=True, timeout=20)
            return (result.returncode,
                    result.stdout.decode("utf-8", "replace"),
                    result.stderr.decode("utf-8", "replace"))
        except Exception:
            continue
    return None, "", "Waydroid / adb not available"


def force_stop_android(pkg):
    rc, _out, err = android_shell("am", "force-stop", pkg)
    if rc is None:
        return False, "Waydroid isn't running here."
    if rc == 0:
        return True, "Stopped."
    return False, (err or "Couldn't stop it.").strip()


def clear_cache_android(pkg):
    # There is no pm clear-cache; the cache lives in the app's cache
    # dirs (internal + external storage). Remove them.
    for cache_dir in ("/data/data/%s/cache" % pkg,
                      "/data/media/0/Android/data/%s/cache" % pkg):
        rc, _out, _err = android_shell("rm", "-rf", cache_dir)
        if rc is None:
            return False, "Waydroid isn't running here."
    return True, "Cache cleared."


def clear_data_android(pkg):
    rc, out, err = android_shell("pm", "clear", pkg)
    if rc is None:
        return False, "Waydroid isn't running here."
    if rc == 0 or "Success" in out:
        return True, "App data cleared."
    return False, (err or out or "Couldn't clear data.").strip()


def uninstall_android(pkg):
    """Remove an Android app: `waydroid app remove` first (the
    counterpart to `waydroid app install`), `pm uninstall` second."""
    try:
        result = subprocess.run(["waydroid", "app", "remove", pkg],
                                capture_output=True, timeout=60)
        if result.returncode == 0:
            return True, "Uninstalled."
    except Exception:
        pass
    rc, out, err = android_shell("pm", "uninstall", pkg)
    if rc is None:
        return False, "Waydroid isn't running here."
    if rc == 0 or "Success" in out:
        return True, "Uninstalled."
    return False, (err or out or "Couldn't uninstall it.").strip()


def android_app_permissions(pkg):
    """An installed Android app's permissions, from dumpsys: a list of
    (permission, granted) in requested order. Empty when Waydroid
    isn't up or the app isn't installed."""
    rc, out, _err = android_shell("dumpsys", "package", pkg)
    if rc is None or not out:
        return []
    import re
    requested = []
    granted = {}
    in_requested = False
    for line in out.splitlines():
        stripped = line.strip()
        low = stripped.lower()
        if low.startswith("requested permissions"):
            in_requested = True
            continue
        if in_requested:
            if stripped.startswith("android.permission."):
                requested.append(stripped.split()[0])
                continue
            # A new section header (ends with ':') ends the block.
            if stripped.endswith(":") or not stripped:
                in_requested = False
        match = re.match(r"(android\.permission\.\S+):\s*granted=(\w+)",
                         stripped)
        if match:
            granted[match.group(1)] = match.group(2) == "true"
    if not requested:
        requested = sorted(granted.keys())
    # Install-time (normal) permissions aren't in the granted map --
    # they're granted at install.
    return [(perm, granted.get(perm, True)) for perm in requested]


# Human-readable names for the permissions Drew will see. Files and
# Media is the storage set (READ_MEDIA_* / READ_EXTERNAL_STORAGE) --
# the UI groups those under one "Files and Media" row, first.
STORAGE_PERMISSIONS = {
    "android.permission.READ_MEDIA_IMAGES",
    "android.permission.READ_MEDIA_VIDEO",
    "android.permission.READ_MEDIA_AUDIO",
    "android.permission.READ_EXTERNAL_STORAGE",
    "android.permission.WRITE_EXTERNAL_STORAGE",
}
PERMISSION_LABELS = {
    "android.permission.CAMERA": "Camera",
    "android.permission.RECORD_AUDIO": "Microphone",
    "android.permission.ACCESS_FINE_LOCATION": "Location (precise)",
    "android.permission.ACCESS_COARSE_LOCATION": "Location (approximate)",
    "android.permission.READ_MEDIA_IMAGES": "Photos",
    "android.permission.READ_MEDIA_VIDEO": "Videos",
    "android.permission.READ_MEDIA_AUDIO": "Music and audio",
    "android.permission.READ_EXTERNAL_STORAGE": "Files and media",
    "android.permission.WRITE_EXTERNAL_STORAGE": "Files and media (write)",
    "android.permission.POST_NOTIFICATIONS": "Notifications",
    "android.permission.BLUETOOTH_CONNECT": "Bluetooth",
    "android.permission.BLUETOOTH_SCAN": "Bluetooth (scan)",
    "android.permission.NEARBY_WIFI_DEVICES": "Nearby Wi-Fi devices",
    "android.permission.REQUEST_INSTALL_PACKAGES": "Install unknown apps",
    "android.permission.SYSTEM_ALERT_WINDOW": "Display over other apps",
    "android.permission.READ_CONTACTS": "Contacts",
    "android.permission.WRITE_CONTACTS": "Contacts (write)",
    "android.permission.READ_CALENDAR": "Calendar",
    "android.permission.SEND_SMS": "Send text messages",
    "android.permission.CALL_PHONE": "Make phone calls",
    "android.permission.BODY_SENSORS": "Body sensors",
    "android.permission.ACTIVITY_RECOGNITION": "Physical activity",
}


def perm_label(perm):
    """A friendly name for a permission string."""
    if perm in PERMISSION_LABELS:
        return PERMISSION_LABELS[perm]
    short = perm.replace("android.permission.", "")
    return short.replace("_", " ").title()


def set_android_permission(pkg, perm, allow):
    """Allow / remove one permission: pm grant / pm revoke."""
    verb = "grant" if allow else "revoke"
    rc, out, err = android_shell("pm", verb, pkg, perm)
    if rc is None:
        return False, "Waydroid isn't running here."
    if rc == 0:
        return True, "Allowed." if allow else "Removed."
    return False, (err or out or "Couldn't change it.").strip()


def set_install_unknown(pkg, allow):
    """The 'Install unknown apps' toggle (the one that pops up when
    you install an APK from Downloader): the REQUEST_INSTALL_PACKAGES
    permission (pm grant/revoke) plus the appop that backs the
    Settings toggle."""
    ok, msg = set_android_permission(
        pkg, "android.permission.REQUEST_INSTALL_PACKAGES", allow)
    mode = "allow" if allow else "deny"
    android_shell("appops", "set", "--uid", pkg,
                  "REQUEST_INSTALL_PACKAGES", mode)
    return ok, msg


# ---------------------------------------------------------------------------
# Quick presets (the app-options menu's on/off toggles): Bluetooth,
# Wi-Fi, VPN, cursor. These are the SAME controls the Flight Deck
# uses -- the Flight Deck's toggle handlers call these helpers, and
# so does the app-options menu, so flipping a preset in either place
# does the same thing.
# Each setter returns True when the command was issued. Each reader
# returns True/False, or None when the state can't be read on this box.
# ---------------------------------------------------------------------------
def set_bluetooth_power(on):
    return bool(_spawn(
        ["bluetoothctl", "power", "on" if on else "off"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))


def bluetooth_powered():
    try:
        out = subprocess.check_output(
            ["bluetoothctl", "show"], timeout=5,
            stderr=subprocess.DEVNULL).decode("utf-8", "replace")
        for line in out.splitlines():
            if "Powered:" in line:
                return "yes" in line.lower()
    except Exception:
        pass
    return None


def set_wifi_radio(on):
    return bool(_spawn(
        ["nmcli", "radio", "wifi", "on" if on else "off"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))


def wifi_radio_enabled():
    try:
        out = subprocess.check_output(
            ["nmcli", "radio", "wifi"], timeout=5,
            stderr=subprocess.DEVNULL).decode("utf-8", "replace")
        state = out.strip().lower()
        if state == "enabled":
            return True
        if state == "disabled":
            return False
    except Exception:
        pass
    return None


def _vpn_connections():
    """Configured VPN connection names (NetworkManager), or []."""
    try:
        out = subprocess.check_output(
            ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show"],
            timeout=5, stderr=subprocess.DEVNULL).decode(
                "utf-8", "replace")
        return [l.split(":")[0] for l in out.strip().splitlines()
                if l.strip().endswith(":vpn")]
    except Exception:
        return []


def vpn_available():
    """True when a VPN can be toggled (a configured VPN connection,
    or the Proton VPN CLI)."""
    if _vpn_connections():
        return True
    try:
        subprocess.check_output(["protonvpn-cli", "status"], timeout=5,
                                stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def vpn_active():
    """True when a VPN connection is currently up."""
    try:
        out = subprocess.check_output(
            ["protonvpn-cli", "status"], timeout=5,
            stderr=subprocess.DEVNULL).decode("utf-8", "replace")
        if "Connected" in out:
            return True
    except Exception:
        pass
    try:
        out = subprocess.check_output(
            ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show",
             "--active"], timeout=5,
            stderr=subprocess.DEVNULL).decode("utf-8", "replace")
        return any(":vpn" in l.lower()
                   for l in out.strip().splitlines() if l.strip())
    except Exception:
        return False


def set_vpn_active(on):
    """VPN on/off: the Proton VPN CLI first, then NetworkManager."""
    if _spawn(
            ["protonvpn-cli", "connect", "--fastest"] if on
            else ["protonvpn-cli", "disconnect"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL):
        return True
    vpn_conns = _vpn_connections()
    if vpn_conns:
        cmd = (["nmcli", "connection", "up", vpn_conns[0]] if on
               else ["nmcli", "connection", "down", vpn_conns[0]])
        if _spawn(cmd, stdout=subprocess.DEVNULL,
                  stderr=subprocess.DEVNULL):
            return True
    return False


# ---------------------------------------------------------------------------
# Navigator search: universal scope, Interface-first ranking, typo tolerance.
# ---------------------------------------------------------------------------
# Instrument panels, searchable from the Navigator: (page, display name,
# keywords). "display" finds Appearance, "network" finds Wi-Fi, and so
# on -- the search matches the name or any keyword, and picking a
# setting opens the Flight Deck straight onto that page.
SETTINGS_SEARCH = [
    ("wifi", "Wi-Fi", "wifi wireless network internet connection"),
    ("bluetooth", "Bluetooth",
     "bluetooth remote headphones controller pairing"),
    ("appearance", "Appearance", "appearance display theme dark light"),
    ("keyboard", "Keyboard",
     "keyboard keys colour opacity appearance"),
    ("ai", "Wingman", "wingman ai assistant nova grok helm"),
    ("display", "Display", "display resolution scaling rotation brightness screen"),
    ("browser", "Browser", "browser brave firefox chrome default web"),
    ("updates", "Updates", "update launcher version"),
    ("install", "Install Aero Deck", "install disk drive permanent"),
    ("background", "Background", "background backdrop wallpaper blossom"),
    ("sound", "Sound", "sound audio volume output speaker"),
    ("music", "Music",
     "music radio genre rock pop country jazz classical hip-hop electronic"),
    ("iptv", "IPTV", "iptv live tv channels sources playlist"),
    ("apps", "Apps", "apps install apk android"),
    ("rows", "Row order", "row order rows reorder home screen layout"),
    ("vpn", "VPN", "vpn proton privacy"),
    ("power", "Power", "power sleep restart shutdown"),
    ("cursor", "Cursor", "cursor mouse pointer"),
    ("language", "Language", "language english"),
    ("region", "Region", "region canada country"),
    ("screensaver", "Screensaver", "screensaver timeout sleep display"),
    ("controller", "Controller", "controller gamepad game"),
    ("controls", "Controls", "controls help buttons deck map how"),
    ("storage", "Storage", "storage cache clear space disk app data"),
    ("printers", "Printers", "printer print printing queue"),
    ("reader", "Reading mode", "reader reading book ebook epub pdf"),
    ("calendar", "Calendar", "calendar date"),
    ("tasks", "Tasks", "tasks todo"),
    ("email", "Email", "email inbox mail"),
    ("about", "About", "about version"),
]

# Search ranking: Interface content first (the stuff on the home
# screen -- apps, live TV, movies, shows, games, cloud, videos),
# then settings, then the web.
SEARCH_KIND_RANK = {"App": 0, "Live TV": 0, "Movie": 0, "TV Show": 0,
                    "Game": 0, "Cloud gaming": 0, "Video": 0,
                    "Setting": 1, "Web": 2}


def fuzzy_ratio(query, text):
    """How close a (possibly misspelled) query is to a name/keyword:
    0.0-1.0 via difflib. Best of the whole string and each word, so a
    short query can match one word of a long title."""
    import difflib
    q = (query or "").lower()
    t = (text or "").lower()
    if not q or not t:
        return 0.0
    best = difflib.SequenceMatcher(None, q, t).ratio()
    for word in t.replace("-", " ").split():
        best = max(best, difflib.SequenceMatcher(None, q, word).ratio())
    return best


def search_match(items, query):
    """Rank and filter a search index for a query. Returns
    (shown, did_you_mean): up to 5 results and the "Did you mean"
    correction (or None). Pure function -- unit-testable without a window.

    Matching is deliberately tight so "netflix" shows Netflix and not
    unrelated apps: exact name > name prefix > word prefix in the name >
    substring of the name > keyword word-prefix > keyword substring.
    Fuzzy (misspelling) matching only kicks in when nothing matched
    directly, and only against whole words with a high threshold. No
    unrelated "same kind" padding is added."""
    q = (query or "").strip().lower()
    if not q:
        return [], None

    def words(text):
        return [w for w in re.split(r"[^0-9a-z+]+", text.lower()) if w]

    scored = []
    for it in items:
        name = it[0].lower()
        kw = it[4].lower() if len(it) > 4 else ""
        if name == q:
            tier = 0
        elif name.startswith(q):
            tier = 1
        elif any(w.startswith(q) for w in words(name)):
            tier = 2
        elif len(q) >= 3 and q in name:
            tier = 3
        elif any(w.startswith(q) for w in words(kw)):
            tier = 4
        elif len(q) >= 4 and q in kw:
            tier = 5
        else:
            continue
        scored.append((tier, SEARCH_KIND_RANK.get(it[1], 1), name, it))
    scored.sort(key=lambda s: s[:3])
    shown = [s[3] for s in scored[:5]]
    did_you_mean = None
    if not shown and len(q) >= 3:
        fuzzy = []
        for it in items:
            r = max([fuzzy_ratio(q, w) for w in words(it[0])] + [0.0])
            if r >= 0.75:
                fuzzy.append((-r, SEARCH_KIND_RANK.get(it[1], 1),
                              it[0].lower(), it))
        fuzzy.sort(key=lambda s: s[:3])
        shown = [s[3] for s in fuzzy[:5]]
        if shown:
            did_you_mean = shown[0][0]
    return shown, did_you_mean


def discover_social_apps():
    """Social apps Drew downloaded: scan the installed Waydroid apps and
    pick out the ones in SOCIAL_PACKAGES. Best effort -- if Waydroid
    isn't up, the row just shows the built-ins (YouTube, Rumble)."""
    found = []
    try:
        out = subprocess.check_output(
            ["waydroid", "app", "list"], timeout=10,
            stderr=subprocess.DEVNULL).decode("utf-8", "replace")
    except Exception:
        return found
    seen = set()
    for line in out.splitlines():
        pkg = _parse_waydroid_package_line(line)
        if pkg in SOCIAL_PACKAGES and pkg not in seen:
            seen.add(pkg)
            name, letter, colour, fallback = SOCIAL_PACKAGES[pkg]
            found.append((name, letter, colour, "android", pkg, fallback))
    return found


# ---------------------------------------------------------------------------
# Social row: real content from YouTube / Rumble, not app icons. The row
# shows the latest videos from the channels Drew watches -- thumbnail +
# title, tap to watch. Feeds are public RSS (no API key, no sign-in);
# thumbnails are cached on disk so the row shows instantly and refreshes
# in the background. Add/remove channels in the panel
# (Settings -> Apps -> Social feeds).
# ---------------------------------------------------------------------------
SOCIAL_FEEDS_FILE = CONFIG_DIR / "social_feeds.json"
SOCIAL_CACHE_FILE = CONFIG_DIR / "social_cache.json"
SOCIAL_THUMB_DIR = CONFIG_DIR / "thumbs"

DEFAULT_SOCIAL_FEEDS = [
    # Drew's own channel (verified @CHINOOKStories). Add the channels he
    # watches in the panel -- no subscriptions are read anywhere.
    {"service": "youtube", "channel": "@CHINOOKStories",
     "label": "CHINOOK Stories"},
]

SOCIAL_UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/120.0 Safari/537.36"}


def load_social_feeds():
    """Social feeds: [{"service": "youtube"|"rumble",
    "channel": "@handle" or "slug", "label": "..."}]."""
    try:
        data = json.loads(SOCIAL_FEEDS_FILE.read_text())
        if isinstance(data, list) and data:
            return data
    except Exception:
        pass
    return [dict(f) for f in DEFAULT_SOCIAL_FEEDS]


def save_social_feeds(feeds):
    SOCIAL_FEEDS_FILE.write_text(json.dumps(feeds, indent=2))


def load_social_cache():
    """Last good social videos, so the row shows instantly on launch."""
    try:
        data = json.loads(SOCIAL_CACHE_FILE.read_text())
        return data if isinstance(data, list) else []
    except Exception:
        return []


def save_social_cache(videos):
    SOCIAL_CACHE_FILE.write_text(json.dumps(videos, indent=2))


def _http_get(url, timeout=15):
    """GET with a browser user-agent; returns bytes or None."""
    try:
        req = urllib.request.Request(url, headers=SOCIAL_UA)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return None
            return resp.read()
    except Exception:
        return None


def _parse_feed_xml(raw):
    """Pull {title, url, thumb, published} items out of an Atom/RSS
    feed. Returns a list (possibly empty)."""
    import xml.etree.ElementTree as ET
    try:
        root = ET.fromstring(raw)
    except Exception:
        return []
    ns = {"atom": "http://www.w3.org/2005/Atom",
          "media": "http://search.yahoo.com/mrss/"}
    entries = root.findall(".//atom:entry", ns)
    if not entries:
        entries = root.findall(".//item")
    videos = []
    for entry in entries:
        title = None
        url = None
        thumb = None
        published = ""
        t = entry.find("atom:title", ns)
        if t is None:
            t = entry.find("title")
        if t is not None and t.text:
            title = t.text.strip()
        for link in entry.findall("atom:link", ns):
            if link.get("rel") in (None, "alternate"):
                url = link.get("href")
                break
        if url is None:
            l = entry.find("link")
            if l is not None and l.text:
                url = l.text.strip()
        th = entry.find("media:thumbnail", ns)
        if th is not None:
            thumb = th.get("url")
        if thumb is None:
            enc = entry.find("enclosure")
            if enc is not None and "image" in (enc.get("type") or ""):
                thumb = enc.get("url")
        p = entry.find("atom:published", ns)
        if p is None:
            p = entry.find("pubDate")
        if p is not None and p.text:
            published = p.text.strip()
        if title and url:
            videos.append({"title": title, "url": url, "thumb": thumb,
                           "published": published})
    return videos


def resolve_youtube_channel_id(handle_or_id):
    """Turn "@handle" into a UC channel id via the channel page's
    canonical link (verified for @CHINOOKStories). A raw UC id passes
    through unchanged."""
    text = (handle_or_id or "").strip()
    if text.startswith("UC"):
        return text
    handle = text.lstrip("@")
    raw = _http_get("https://www.youtube.com/@%s" % handle)
    if raw:
        import re
        m = re.search(
            rb'youtube\.com/channel/(UC[A-Za-z0-9_-]{10,})',
            raw)
        if m:
            return m.group(1).decode("ascii")
    return None


def fetch_youtube_feed(channel, limit=8):
    """Latest videos from a YouTube channel (public RSS, no key)."""
    channel_id = resolve_youtube_channel_id(channel)
    if not channel_id:
        return []
    raw = _http_get(
        "https://www.youtube.com/feeds/videos.xml?channel_id=%s"
        % channel_id)
    if not raw:
        return []
    return _parse_feed_xml(raw)[:limit]


def fetch_rumble_feed(slug, limit=8):
    """Latest videos from a Rumble channel (public RSS). Rumble sits
    behind Cloudflare, so this can fail on some networks -- the row
    just keeps showing its cached videos then."""
    raw = _http_get(
        "https://rumble.com/c/%s/videos/rss" % slug.strip().lstrip("@"))
    if not raw:
        return []
    return _parse_feed_xml(raw)[:limit]


def fetch_social_feed(feeds):
    """All configured feeds -> list of videos, newest first. Never
    raises; a dead feed just contributes nothing."""
    videos = []
    for feed in feeds or []:
        service = (feed.get("service") or "").lower()
        channel = feed.get("channel") or ""
        label = feed.get("label") or channel
        try:
            if service == "youtube":
                items = fetch_youtube_feed(channel)
            elif service == "rumble":
                items = fetch_rumble_feed(channel)
            else:
                continue
        except Exception:
            continue
        for item in items:
            item["service"] = ("YouTube" if service == "youtube"
                               else "Rumble")
            item["channel"] = label
            videos.append(item)
    videos.sort(key=lambda v: v.get("published") or "", reverse=True)
    return videos[:12]


def social_thumb_path(thumb_url):
    """Local cache path for a thumbnail URL (hash name)."""
    import hashlib
    name = hashlib.sha1(thumb_url.encode("utf-8")).hexdigest() + ".jpg"
    return SOCIAL_THUMB_DIR / name


def download_social_thumb(thumb_url):
    """Download a thumbnail into the cache; returns the path or None."""
    if not thumb_url:
        return None
    try:
        SOCIAL_THUMB_DIR.mkdir(parents=True, exist_ok=True)
        path = social_thumb_path(thumb_url)
        if path.exists() and path.stat().st_size > 0:
            return str(path)
        raw = _http_get(thumb_url, timeout=10)
        if raw:
            path.write_bytes(raw)
            return str(path)
    except Exception:
        pass
    return None


LIVE_CHANNELS = []   # no demo channels: Live TV = real IPTV channels only

# News row: INTERNET sources only -- the networks' official free live
# streams (their YouTube live feeds). Never the IPTV playlists and
# never Cozy Streamz. Baked in by default; Drew can add / change /
# remove them in the Flight Deck (persisted in news_sources.json).
NEWS_FILE = CONFIG_DIR / "news_sources.json"
DEFAULT_NEWS_SOURCES = [
    # (name, program, stream url)
    # Fox: the full Fox News Channel is NOT free (FOX One $19.99/mo
    # or a TV provider login). The free official live feed is
    # LiveNOW from FOX, Fox's own 24/7 stream on YouTube.
    ("FOX", "LiveNOW from FOX",
     "https://www.youtube.com/@LiveNOWfromFOX/live"),
    # CNN: no free 24/7 main-channel feed on YouTube; the official
    # channel runs live breaking segments / CNN Headlines instead.
    ("CNN", "CNN Live", "https://www.youtube.com/@CNN/live"),
    # BBC: official 24/7 live stream on YouTube since Oct 15, 2026.
    ("BBC", "BBC News Live", "https://www.youtube.com/@BBCNews/live"),
    # CTV: official live stream on the CTV News YouTube channel.
    ("CTV", "CTV News Live", "https://www.youtube.com/@CTVNews/live"),
    # CBC: official continuous live stream on the CBC News channel.
    ("CBC", "CBC News Live", "https://www.youtube.com/@CBCNews/live"),
]
# MS NOW (formerly MSNBC) is deliberately NOT baked in: it has no
# official free live stream -- the 24/7 feed is the $7.99/mo MS NOW
# Membership or a TV provider login, and its YouTube channel carries
# clips only (the old @msnbc handle 404s). Drew can add it himself
# in the News sources list if he has a stream URL for it.


def load_news_sources():
    """News sources: list of (name, program, url). The baked-in
    defaults ship when no file exists yet."""
    try:
        data = json.loads(NEWS_FILE.read_text())
        out = []
        for item in data:
            if isinstance(item, dict) and item.get("name") \
                    and item.get("url"):
                out.append((item["name"],
                            item.get("program", "Live"),
                            item["url"]))
            elif isinstance(item, (list, tuple)) and len(item) >= 3:
                out.append((item[0], item[1], item[2]))
        if out:
            return out
    except Exception:
        pass
    return list(DEFAULT_NEWS_SOURCES)


def save_news_sources(sources):
    NEWS_FILE.write_text(json.dumps(
        [{"name": n, "program": p, "url": u} for n, p, u in sources],
        indent=2))

MOVIES = [
    ("Oppenheimer", "2023"),
    ("Barbie", "2023"),
    ("Top Gun: Maverick", "2022"),
    ("Avatar: The Way of Water", "2022"),
    ("Spider-Man: Across the Spider-Verse", "2023"),
]

SHOWS = [
    ("The Bear", "Drama"),
    ("House of the Dragon", "Fantasy"),
    ("The Mandalorian", "Sci-Fi"),
    ("The Last of Us", "Drama"),
    ("Wednesday", "Comedy"),
    ("Succession", "Drama"),
]

# Hero synopsis: the short synopsis shows by default; the full
# description stays hidden until the synopsis is highlighted /
# selected, then it expands -- no spoilers up front.
HERO_SHORT_DESC = ""
HERO_FULL_DESC = ""

# -- Games: every tile opens ITS game ---------------------------------------
# Steam app IDs for the built-in suggestions (verified on
# store.steampowered.com). Installed Steam games are read from the
# Steam library on this machine and listed first. A tile runs
# steam://rungameid/<id> when the game is installed, otherwise it opens
# the game's Steam store page (steam://store/<id>) so it can be
# installed. Cloud links: GeForce NOW / Luna deep links are used when a
# title has one (gfn / luna keys); otherwise the cloud row opens the
# service home page.
GAMES = [
    # (name, meta) -- meta: dict with appid / gfn / luna, genre
    ("Elden Ring", {"appid": 1245620, "genre": "RPG"}),
    ("Cyberpunk 2077", {"appid": 1091500, "genre": "RPG"}),
    ("God of War Ragnarök", {"appid": 2322010, "genre": "Action"}),
    ("Hogwarts Legacy", {"appid": 990080, "genre": "Adventure"}),
    ("Starfield", {"appid": 1716740, "genre": "Sci-Fi"}),
    ("Hades II", {"appid": 1145350, "genre": "Action"}),
]

STEAM_ROOTS = [Path.home() / ".local/share/Steam",
               Path.home() / ".steam/steam",
               Path.home() / ".var/app/com.valvesoftware.Steam/data/Steam"]
_STEAM_TOOL_IDS = {228980, 1070560, 1391110, 1628350, 1493710, 2180100,
                   1826330, 1161040, 1580130, 1887720, 2348590, 961940,
                   858280, 3658110}


def _vdf_values(text, key):
    return re.findall(r'"%s"\s+"([^"]*)"' % re.escape(key), text)


def steam_library_dirs():
    """Every steamapps folder Steam knows about on this machine."""
    out = []
    for root in STEAM_ROOTS:
        sa = root / "steamapps"
        if sa.is_dir() and sa.resolve() not in [p.resolve() for p in out]:
            out.append(sa)
        try:
            text = (sa / "libraryfolders.vdf").read_text(errors="replace")
            for p in _vdf_values(text, "path"):
                d = Path(p.replace("\\\\", "/")) / "steamapps"
                if d.is_dir() and d.resolve() not in [
                        x.resolve() for x in out]:
                    out.append(d)
        except Exception:
            pass
    return out


def steam_installed_games():
    """[(appid, name)] of fully installed Steam games (tools such as
    Proton / Steam Linux Runtime are skipped)."""
    games = {}
    for sa in steam_library_dirs():
        for acf in sa.glob("appmanifest_*.acf"):
            try:
                text = acf.read_text(errors="replace")
                appid = int((_vdf_values(text, "appid") or ["0"])[0])
                name = (_vdf_values(text, "name") or [""])[0]
                flags = int((_vdf_values(text, "StateFlags") or ["0"])[0])
            except Exception:
                continue
            if not appid or appid in _STEAM_TOOL_IDS or not name:
                continue
            if re.search(r"proton|steam linux runtime|steamworks",
                         name, re.I):
                continue
            if flags & 4:          # StateFullyInstalled
                games[appid] = name
    return sorted(games.items(), key=lambda kv: kv[1].lower())


def steam_game_installed(appid):
    try:
        appid = int(appid)
    except (TypeError, ValueError):
        return False
    return any(a == appid for a, _n in steam_installed_games())


def game_launch_plan(name, meta, installed=None, have_steam=None):
    """What a game tile does, as data (unit-tested):
    ("steam", [argv]) | ("url", url) | ("none", reason)."""
    meta = meta if isinstance(meta, dict) else {}
    appid = meta.get("appid")
    if have_steam is None:
        have_steam = shutil.which("steam") is not None
    if appid:
        if installed is None:
            installed = steam_game_installed(appid)
        if have_steam:
            if installed:
                # -silent: no Steam main window on a cold start, the
                # game comes straight up over Aero.
                return ("steam", ["steam", "-silent",
                                  "steam://rungameid/%d" % int(appid)])
            return ("steam", ["steam", "steam://store/%d" % int(appid)])
        if meta.get("gfn"):
            return ("url", meta["gfn"])
        if meta.get("luna"):
            return ("url", meta["luna"])
        return ("url", "https://store.steampowered.com/app/%d/"
                % int(appid))
    if meta.get("gfn"):
        return ("url", meta["gfn"])
    if meta.get("luna"):
        return ("url", meta["luna"])
    return ("none", "No launch link for %s" % name)


def games_row_items():
    """Installed Steam games first (real library), then the built-in
    suggestions that aren't installed (open their store page)."""
    items = []
    seen = set()
    for appid, name in steam_installed_games():
        items.append((name, {"appid": appid, "installed": True}))
        seen.add(appid)
    for name, meta in GAMES:
        if meta.get("appid") not in seen:
            items.append((name, dict(meta)))
    return items


def steam_cover_path(appid):
    """Steam's own library art for an installed game, if cached."""
    for root in STEAM_ROOTS:
        base = root / "appcache" / "librarycache"
        for cand in (base / ("%d_library_600x900.jpg" % appid),
                     base / str(appid) / "library_600x900.jpg"):
            if cand.is_file():
                return cand
        d = base / str(appid)
        if d.is_dir():
            for cand in d.glob("*/library_600x900.jpg"):
                return cand
    return None

# Cloud gaming, baked in as one-tap tiles (they run in the browser, so
# there's nothing to install -- GeForce Now, Boosteroid and Xbox Cloud
# all carry Fortnite, which won't run natively on Linux).
CLOUD_GAMING = [
    ("GeForce Now", "https://play.geforcenow.com"),
    ("Boosteroid", "https://boosteroid.com"),
    ("Xbox Cloud Gaming", "https://www.xbox.com/play"),
    ("Amazon Luna", "https://luna.amazon.com"),
]

# Weather: Halifax, NS by default (metric). Change in the Flight Deck.
WEATHER_LAT = 44.6488
WEATHER_LON = -63.5752


# ---------------------------------------------------------------------------
# Styling: frosted glass, blossom backdrop, wide tiles.
# ---------------------------------------------------------------------------
CSS = b"""
window {
    /* Solid blue fallback; the real backdrop is the cherry-blossom
       photo (assets/backdrop.jpg) drawn as an image underlay. */
    background: #b4cfee;
}
button {
    border-radius: 18px;
    background: rgba(255, 255, 255, 0.55);
    border: 1px solid rgba(255, 255, 255, 0.5);
    box-shadow: 0 4px 12px rgba(90, 110, 140, 0.25);
    font-size: 15px;
    font-weight: 600;
    color: #3a2a3a;
}
button:hover {
    background: rgba(255, 255, 255, 0.8);
}
button.app-tile {
    border-radius: 16px;
    background: rgba(255, 255, 255, 0.20);
    border: 1px solid rgba(255, 255, 255, 0.6);
    box-shadow: 0 4px 14px rgba(90, 110, 140, 0.3);
    min-width: 164px;
    min-height: 116px;
}
button.app-tile:hover {
    background: rgba(255, 255, 255, 0.45);
}
/* App tile whose icon fills the whole tile edge-to-edge (the icon
   PNG itself is pre-rounded to the tile's corners): no frosted
   background, no border, no padding -- the tile IS the logo. */
button.app-tile-icon {
    padding: 0;
    border: none;
    background: transparent;
    box-shadow: none;
}
button.app-tile-icon:hover {
    background: transparent;
}
/* Live TV tile: the photo fills the whole tile; the button itself
   is transparent so the photo is the tile. */
button.live-tile {
    padding: 0;
    border: none;
    background: transparent;
    box-shadow: none;
    border-radius: 18px;
    min-width: 302px;
    min-height: 185px;
}
button.live-tile:hover {
    background: transparent;
}
/* Poster tile (Movies / TV Shows / Games rows): the poster art fills
   the whole tile edge-to-edge, corners rounded (28px, same as the
   hero poster). The plain button's default padding inflates each
   tile by 20px, so 5 tiles + 4 gaps would run wider than the row's
   1640px viewport (5x280 + 4x60) and the 5th poster would get
   clipped at the right edge. Padding 0 + no border keeps every tile
   at exactly 280x392, so all 5 fit. Same treatment as live-tile.
   The frosted button background stays, so the text fallback (no
   poster shipped) still reads. */
button.poster-tile {
    padding: 0;
    border: none;
    border-radius: 28px;
}
button.poster-tile:hover {
    background: rgba(255, 255, 255, 0.45);
}
label.live-overlay-chan {
    color: white;
    font-size: 26px;
    font-weight: bold;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.85),
                 0 0 8px rgba(0, 0, 0, 0.6);
}
label.live-overlay-prog {
    color: white;
    font-size: 17px;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.85),
                 0 0 8px rgba(0, 0, 0, 0.6);
}
/* Hero title: white, with a soft shadow so it reads on the
   frosted card. Condensed family stack: the card is only as wide
   as the rows below it now, so the huge title has to be narrower
   to fit -- Noto Sans Condensed keeps it 72pt but ~18% narrower.
   Falls back through other condensed faces to plain sans. */
label.hero-title {
    font-family: "Noto Sans Condensed", "Liberation Sans Narrow", "DejaVu Sans Condensed", sans-serif;
    text-shadow: 0 2px 10px rgba(0, 0, 0, 0.35);
}
/* App cell: the frosted rounded-rect card behind each app tile +
   its name (the reference: tile and name are one frosted unit).
   The tile image fills its button edge-to-edge inside the card. */
.app-cell {
    background: rgba(255, 255, 255, 0.22);
    border: 1px solid rgba(255, 255, 255, 0.45);
    border-radius: 16px;
    padding: 6px 8px 10px 8px;
    box-shadow: 0 4px 12px rgba(90, 110, 140, 0.2);
}
/* App-management side panel (hold OK on an app tile): Fire OS style.
   No panel box -- the options float over the dimmed home screen,
   right-aligned, close to the right edge, wide spacing. Only the
   focused item is bright white; the rest are dim grey-white. */
.dim-overlay {
    background: rgba(0, 0, 0, 0.45);
}
button.opt-item {
    background: transparent;
    border: none;
    box-shadow: none;
    border-radius: 0;
    padding: 6px 0;
    /* 40px min-height + 6px top/bottom padding = 52px total per
       button, so 4 buttons + 3 x 30px gaps = 298px, exactly the
       viewport height: 4 options visible at a time. (Was 52px
       min-height = 64px total, so only 3 fit and the 4th was a
       sliver at the bottom.) */
    min-height: 40px;
}
button.opt-item label {
    color: rgba(255, 255, 255, 0.55);
    font-size: 22px;
}
button.opt-item:focus label,
button.opt-item:hover label {
    color: #ffffff;
}
button.opt-item:focus {
    background: rgba(255, 255, 255, 0.10);
    outline: none;
}
/* App-options presets (Bluetooth / Wi-Fi / VPN / cursor): a label and
   a switch, same dim-until-focused treatment as the options. */
.preset-sep {
    background: rgba(255, 255, 255, 0.25);
    min-height: 1px;
    margin: 6px 0;
}
label.preset-label {
    color: rgba(255, 255, 255, 0.55);
    font-size: 20px;
}
.preset-focused label.preset-label {
    color: #ffffff;
}
/* The app tile being moved: a bright outline so Drew can see which
   app is in move mode. */
.app-cell.app-moving {
    border: 3px solid #ffffff;
    box-shadow: 0 0 0 3px rgba(229, 9, 20, 0.9), 0 4px 12px rgba(90, 110, 140, 0.2);
}
/* App info / Allow panel (More Info, Allow): dark, like the options
   panel -- white text, dim labels, switches for the permissions. */
.info-panel {
    background: rgba(18, 22, 38, 0.88);
    border-left: 1px solid rgba(255, 255, 255, 0.25);
    box-shadow: -8px 0 30px rgba(0, 0, 0, 0.4);
}
.info-panel label {
    color: #ffffff;
}
label.info-title {
    font-size: 26px;
    font-weight: bold;
    color: #ffffff;
}
label.info-heading {
    font-size: 16px;
    font-weight: bold;
    color: rgba(255, 255, 255, 0.9);
}
label.info-key {
    font-size: 15px;
    color: rgba(255, 255, 255, 0.6);
}
label.info-value {
    font-size: 15px;
    color: #ffffff;
}
label.info-status {
    font-size: 14px;
    color: rgba(255, 255, 255, 0.75);
}
button.icon-btn {
    border-radius: 50%;
    min-width: 44px;
    min-height: 44px;
    padding: 6px;
}
button.home-btn {
    border-radius: 12px;
    min-width: 44px;
    min-height: 44px;
    padding: 6px;
}
label {
    color: #2a2030;
}
label.app-name {
    font-size: 13px;
    font-weight: 600;
    color: #3a2a3a;
}
label.tile-letter {
    font-size: 48px;
    font-weight: bold;
}
label.live-badge {
    background: __ACCENT__;
    color: white;
    border-radius: 6px;
    padding: 2px 8px;
    font-size: 13px;
    font-weight: bold;
}
label.clock-weather {
    font-size: 15px;
    font-weight: 600;
    color: #3a2a3a;
}
.card {
    border-radius: 36px;
    background: rgba(255, 255, 255, 0.20);
    border: 1px solid rgba(255, 255, 255, 0.5);
    box-shadow: 0 6px 20px rgba(90, 110, 140, 0.25);
}
.hero-poster {
    border-radius: 28px;
    background: linear-gradient(135deg, #8e1a24 0%, #3a0d16 100%);
}
.splash-window {
    background: #0a0a12;
}
.retro-tv {
    border: 10px solid #2a2a3a;
    border-radius: 28px;
    background: #101018;
    box-shadow: 0 0 60px rgba(80, 120, 255, 0.25);
}
label.splash-a {
    font-size: 200px;
    font-weight: bold;
    color: __ACCENT__;
    text-shadow: 0 0 40px #2266ff, 0 0 80px #2266ff;
}
label.splash-name {
    font-size: 48px;
    font-weight: bold;
    color: #f0e8f8;
}
label.splash-antenna {
    font-size: 40px;
    color: #5a5a6a;
}
/* Flight Deck (settings panel, slides up from the bottom). LIGHT/WHITE
   frosted panel by default -- white, somewhat frosty but opaque
   enough to read as its own panel, clearly separate from the
   backdrop behind it; dark text inside stays crisp and easy to
   see. Dark navy only in Dark Mode (see the .dark-mode rules
   below). Rounded corners (rounded side wall). The focused tile is
   bright blue, like the reference panels. */
.settings-panel {
    background: rgba(255, 255, 255, 0.94);
    border: 1px solid rgba(43, 58, 85, 0.18);
    border-radius: 28px;
    box-shadow: -8px 0 30px rgba(10, 15, 30, 0.35);
}
.settings-panel label {
    color: #2b3a55;
}
label.panel-clock {
    font-size: 44px;
    font-weight: bold;
    color: #1a2436;
}
label.panel-date {
    font-size: 16px;
    color: rgba(43, 58, 85, 0.70);
}
label.panel-weather {
    font-size: 15px;
    font-weight: 600;
    color: #2b3a55;
}
/* Weather condition icon (sun / cloud / rain) and the calendar
   visual in the center of the clock/weather area -- big, HTC
   clock/weather widget style. */
label.panel-weather-icon {
    font-size: 32px;
}
label.panel-calendar-icon {
    font-size: 34px;
}
/* Other panel buttons (Back, Close, sub-page actions): same light
   tile treatment, dark text; focused = bright blue with white text.
   (Placed before the tile rules so button.settings-tile wins ties
   on tiles.) */
.settings-panel button {
    background: rgba(43, 58, 85, 0.08);
    border: 1px solid rgba(43, 58, 85, 0.16);
    border-radius: 12px;
    color: #2b3a55;
}
.settings-panel button label {
    color: #2b3a55;
}
.settings-panel button:hover {
    background: rgba(43, 58, 85, 0.14);
}
.settings-panel button:focus {
    background: #2b6fe3;
    border-color: #2b6fe3;
    outline: none;
}
.settings-panel button:focus label {
    color: #ffffff;
}
button.settings-tile {
    border-radius: 20px;
    background: rgba(43, 58, 85, 0.08);
    border: 1px solid rgba(43, 58, 85, 0.16);
    box-shadow: none;
    min-height: 96px;
    padding: 14px 18px;
}
button.settings-tile.iptv-compact { min-height: 0; padding: 6px 12px; }
button.settings-tile.deck-toggle { min-height: 0; padding: 4px 12px;
    border-radius: 16px; }
button.settings-tile:hover {
    background: rgba(43, 58, 85, 0.14);
}
/* Focused / highlighted tile: bright blue with white text, like the
   Wi-Fi and Appearance tiles in the reference panels. */
button.settings-tile:focus {
    background: #2b6fe3;
    border-color: #2b6fe3;
    outline: none;
}
button.settings-tile label {
    color: #2b3a55;
}
button.settings-tile:focus label {
    color: #ffffff;
}
label.tile-sub {
    font-size: 12px;
    color: rgba(43, 58, 85, 0.65);
}
button.settings-tile:focus label.tile-sub {
    color: rgba(255, 255, 255, 0.85);
}
/* IPTV section detail lines (full-width section at the top of the
   panel, under clock/weather): name, URL, username, password. */
label.iptv-detail {
    font-size: 13px;
    color: rgba(43, 58, 85, 0.85);
}
/* Toggles inside the panel: on = bright blue track, white knob;
   focused = blue outline. */
.settings-panel switch:checked {
    background: #2b6fe3;
}
.settings-panel switch:checked slider {
    background: #ffffff;
}
.settings-panel switch:focus {
    outline: 2px solid #2b6fe3;
}
/* Sliders (volume, keyboard opacity): value text in white so it
   reads on the dark panel. */
.settings-panel scale {
    color: #ffffff;
}
eventbox.panel-dim { background: rgba(0, 0, 0, 0.01); }
button.osk-cursor-key { background: #e6eefc; font-weight: bold; }
button.osk-mic-live { background: #d93025; }
button.osk-mic-live label { color: #ffffff; }
window.reader-window, .reader-library { background-color: #f6f3ee; }
.reader-toolbar { background: rgba(255,255,255,0.96); border-radius: 14px;
  padding: 8px; }
label.reader-pageno { color: #888888; }
button.reader-book { border-radius: 12px; }
label.osk-voice-status { color: #1f4fae; font-size: 15px; padding: 4px; }
button.osk-cursor-key label { color: #1f4fae; font-size: 16px; }
button.osk-delete-key { background: #fde8e8; }
button.osk-delete-key label { color: #b3261e; font-weight: bold; }
/* Navigator bar highlighted by the D-pad */
.searchbar.nav-focused {
    box-shadow: 0 0 0 3px #2b6fe3;
}
/* Drop-down keyboard under text fields (keys only) */
popover.entry-kb { background: rgba(255,255,255,0.98); border-radius: 18px; padding: 4px; }
popover.entry-kb button.osk-key:focus { background: #2b6fe3; }
popover.entry-kb button.osk-key:focus label { color: #ffffff; }
/* Wingman built-in chat window */
.wingman-card {
    background: #ffffff;
    border-radius: 22px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.40);
}
.wingman-head { padding: 10px 14px; border-bottom: 1px solid rgba(43,58,85,0.12); }
.wingman-head label { color: #1a2436; font-size: 16px; }
.wingman-head button { min-height: 36px; border-radius: 10px; }
/* Android start / install card */
.android-dim { background: rgba(10, 15, 30, 0.45); }
.android-card {
    background: rgba(255, 255, 255, 0.97);
    border-radius: 24px;
    padding: 28px 32px;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.35);
}
.android-card label { color: #1a2436; }
.android-card button {
    min-height: 44px; border-radius: 12px;
    background: rgba(43, 58, 85, 0.08); color: #2b3a55;
}
.android-card button:focus { background: #2b6fe3; }
.android-card button:focus label { color: #ffffff; }
/* Nov 16: Wingman label on the helmet button, Wi-Fi list rows, the
   connect box, entries and combos inside the Flight Deck. */
label.wingman-label {
    font-weight: bold;
    font-size: 14px;
    color: #2b3a55;
}
.settings-panel list, .settings-panel list row {
    background: transparent;
}
.settings-panel list.wifi-list {
    border: 1px solid rgba(43, 58, 85, 0.16);
    border-radius: 12px;
}
.settings-panel list.wifi-list row {
    border-bottom: 1px solid rgba(43, 58, 85, 0.10);
    min-height: 44px;
}
.settings-panel list.wifi-list row:selected,
.settings-panel list.wifi-list row:focus {
    background: #2b6fe3;
}
.settings-panel list.wifi-list row:selected label,
.settings-panel list.wifi-list row:focus label {
    color: #ffffff;
}
.settings-panel entry {
    min-height: 40px;
    color: #1a2436;
    background: #ffffff;
    border-radius: 10px;
}
.settings-panel entry:focus {
    border-color: #2b6fe3;
    box-shadow: 0 0 0 2px rgba(43, 111, 227, 0.35);
}
.settings-panel checkbutton:focus, .settings-panel radiobutton:focus {
    outline: 2px solid #2b6fe3;
}
.settings-panel combobox button {
    min-height: 38px;
}
/* Navigator: the top search bar (small, with the A triangle as its logo). */
.searchbar {
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.55);
    border: 1px solid rgba(255, 255, 255, 0.6);
    box-shadow: 0 4px 12px rgba(90, 110, 140, 0.25);
    padding: 4px 10px;
}
/* White name labels that must stay readable on LIGHT backgrounds:
   "Aero Deck" top-left (on the blossom photo) and "Navigator" in
   the search bar (on the frosted bar). White text with a soft dark
   shadow, so it reads instead of washing out. */
.brand-label {
    color: #ffffff;
    font-weight: bold;
    font-size: 32px;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.65);
}
.navigator-label {
    color: #ffffff;
    font-weight: bold;
    font-size: 15px;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.6);
}
/* Ask AI: the A triangle in the Navigator bar is its own button --
   a distinct frosted pill with a border and a separator, so it reads
   as pressable, not as a logo sitting in the bar. */
button.ask-nova-btn {
    background: rgba(255, 255, 255, 0.75);
    border: 1px solid rgba(255, 255, 255, 0.9);
    border-radius: 999px;
    padding: 2px 6px;
    min-width: 34px;
    min-height: 30px;
    box-shadow: 0 2px 6px rgba(90, 110, 140, 0.3);
}
button.ask-nova-btn:hover {
    background: rgba(255, 255, 255, 0.95);
}
.search-sep {
    background: rgba(90, 110, 140, 0.35);
    min-width: 1px;
}
/* On-screen keyboard (remote typing): query field on top, matching
   results under it, then the keys. THREE separate rounded cards with
   a small gap between them, like the reference photo -- the search
   bar, the results card and the keys card are each their own
   rounded rectangle. Mostly white: the background behind the view
   is BARELY visible, only a very faint hint of it shows through
   (0.95 white -- very slight translucency only). Number row on top
   (1-0), QWERTY with Q blue, Shift, wide Space, black Done
   bottom-right (photo-exact). */
.osk-card {
    border-radius: 20px;
    background: #ffffff;
    border: 1px solid rgba(43, 58, 85, 0.15);
    box-shadow: 0 8px 30px rgba(90, 110, 140, 0.35);
    padding: 12px 16px;
}
/* Top section of the Navigator view: its own rounded card now
   (separate from the results card below, with a small gap). */
.osk-card-top {
    border-radius: 20px;
}
/* Middle section: its own rounded card, with its own shadow (the
   shadow was dropped when the three sections touched with no gap). */
.osk-card-mid {
    border-radius: 20px;
}
/* Keys card: its own rounded card, background = the chosen keyboard
   colour at the chosen opacity (default 0.95 white, matching the
   query/results cards above). */
.osk-keys-card {
    border-radius: 20px;
    background: __KB_CARD__;
    border: 1px solid rgba(255, 255, 255, 0.9);
    box-shadow: 0 8px 30px rgba(90, 110, 140, 0.35);
    padding: 12px 16px;
}
/* Frost wash over the home screen while the Navigator is open: the
   background blurs/frosts behind the unified view (GTK has no
   backdrop blur, so a pale translucent wash is the frost). */
.nav-frost {
    background: rgba(238, 243, 252, 0.55);
}
.osk-query {
    background: transparent;
    border: none;
    box-shadow: none;
    font-size: 17px;
    color: #2b3a55;
}
button.osk-clear {
    min-width: 30px;
    min-height: 30px;
    border-radius: 50%;
    background: rgba(43, 58, 85, 0.12);
    border: none;
    box-shadow: none;
    font-size: 13px;
    color: #2b3a55;
}
/* "Back" pill at the top right of the Navigator search field, like
   the reference: small, light, dismisses the Navigator. */
button.osk-back {
    min-height: 30px;
    border-radius: 15px;
    background: rgba(43, 58, 85, 0.12);
    border: none;
    box-shadow: none;
    font-size: 13px;
    font-weight: 600;
    color: #2b3a55;
    padding: 4px 12px;
}
label.osk-label {
    font-size: 13px;
    font-weight: 600;
    color: #54627c;
}
/* "Search for..." label inside the keys card: follows the keyboard
   key text colour (white on a dark keyboard). */
label.osk-keys-label {
    color: __KB_KEY_TEXT__;
}
label.osk-hint {
    font-size: 14px;
    color: #54627c;
}
/* A key is one of ten equal columns in a homogeneous grid. The
   min-width is a floor, not the size: the grid expands the columns
   to fill the card (~72px each at the 830px card width). It must
   stay low (40px) or the grid's minimum width forces the whole
   Navigator view wider than the ~830px card. */
button.osk-key {
    min-width: 40px;
    min-height: 52px;
    padding: 4px 6px;
    border-radius: 12px;
    background: __KB_KEY__;
    border: 1px solid __KB_KEY_BORDER__;
    box-shadow: none;
    font-size: 20px;
    font-weight: 600;
    color: __KB_KEY_TEXT__;
}
button.osk-key:hover {
    background: __KB_KEY_HOVER__;
}
button.osk-key-armed {
    background: rgba(43, 111, 227, 0.30);
    border-color: #2b6fe3;
}
button.osk-done {
    background: #111111;
    border-color: #111111;
    color: white;
    font-weight: bold;
}
button.osk-done:hover {
    background: #333333;
}
button.osk-key-current {
    background: #2b6fe3;
    border-color: #2b6fe3;
    color: white;
}
button.osk-key-current:hover {
    background: #2b6fe3;
}
/* The label inside a button does not inherit the button's color
   here (it keeps the theme's dark text), so white-on-blue and
   white-on-black keys need the label color set explicitly. */
button.osk-key-current label,
button.osk-done label {
    color: white;
}
button.osk-result {
    background: transparent;
    border: none;
    box-shadow: none;
    border-radius: 12px;
    padding: 6px 10px;
}
button.osk-result:hover {
    background: rgba(255, 255, 255, 0.55);
}
button.osk-result-current {
    background: rgba(255, 255, 255, 0.85);
}
button.osk-result-current:hover {
    background: rgba(255, 255, 255, 0.85);
}
label.osk-result-name {
    font-size: 15px;
    font-weight: 600;
    color: #2b3a55;
}
label.osk-result-sub {
    font-size: 12px;
    color: #54627c;
}
label.osk-result-chev {
    font-size: 18px;
    color: #54627c;
}
label.osk-result-letter {
    font-size: 20px;
    font-weight: bold;
    color: #2b3a55;
    background: rgba(255, 255, 255, 0.45);
    border-radius: 10px;
}
/* Dark Mode (Flight Deck -> Appearance): the Navigator goes dark.
   The window carries the dark-mode class; these descendant rules
   recolour the query/results cards, their labels, the
   result rows and the frost wash. The keys card and keys go dark
   via the keyboard colour (forced to a dark colour while Dark Mode
   is on). Default is light/white. */
.dark-mode .osk-card {
    background: rgba(32, 38, 54, 0.95);
    border-color: rgba(255, 255, 255, 0.16);
}
.dark-mode .osk-query {
    color: #e8ecf4;
}
.dark-mode button.osk-clear,
.dark-mode button.osk-back {
    background: rgba(255, 255, 255, 0.14);
    color: #e8ecf4;
}
.dark-mode label.osk-label,
.dark-mode label.osk-hint {
    color: #aab4c8;
}
.dark-mode button.osk-result:hover {
    background: rgba(255, 255, 255, 0.10);
}
.dark-mode button.osk-result-current {
    background: rgba(255, 255, 255, 0.20);
}
.dark-mode label.osk-result-name {
    color: #eef1f7;
}
.dark-mode label.osk-result-sub,
.dark-mode label.osk-result-chev {
    color: #aab4c8;
}
.dark-mode label.osk-result-letter {
    color: #eef1f7;
    background: rgba(255, 255, 255, 0.14);
}
.dark-mode .nav-frost {
    background: rgba(16, 20, 32, 0.55);
}
.dark-mode .searchbar {
    background: rgba(32, 38, 54, 0.72);
    border-color: rgba(255, 255, 255, 0.16);
}
.dark-mode .search-entry {
    color: #e8ecf4;
}
.dark-mode .navigator-label {
    color: #e8ecf4;
}
/* Dark Mode: the Flight Deck goes dark navy (its light/white look
   is the default; Dark Mode flips it back to the dark panel with
   white text). Tile rules come after the generic button rules so
   they win ties on tiles, as in the light defaults above. */
.dark-mode .settings-panel {
    background: rgba(18, 22, 36, 0.82);
    border-color: rgba(255, 255, 255, 0.22);
}
.dark-mode .settings-panel label {
    color: #ffffff;
}
.dark-mode label.panel-clock {
    color: #ffffff;
}
.dark-mode label.panel-date {
    color: rgba(255, 255, 255, 0.75);
}
.dark-mode label.panel-weather {
    color: #ffffff;
}
.dark-mode .settings-panel button {
    background: rgba(255, 255, 255, 0.10);
    border-color: rgba(255, 255, 255, 0.16);
    color: #ffffff;
}
.dark-mode .settings-panel button label {
    color: #ffffff;
}
.dark-mode .settings-panel button:hover {
    background: rgba(255, 255, 255, 0.18);
}
.dark-mode button.settings-tile {
    background: rgba(255, 255, 255, 0.10);
    border-color: rgba(255, 255, 255, 0.16);
}
.dark-mode button.settings-tile:hover {
    background: rgba(255, 255, 255, 0.18);
}
.dark-mode button.settings-tile label {
    color: #ffffff;
}
.dark-mode label.tile-sub {
    color: rgba(255, 255, 255, 0.70);
}
.dark-mode label.iptv-detail {
    color: rgba(255, 255, 255, 0.85);
}
.search-entry {
    background: transparent;
    border: none;
    box-shadow: none;
    font-size: 15px;
    color: #2b3a55;
}
/* Bottom-right fixed dock: just the A button. Wi-Fi, Bluetooth and
   the gear live inside the Flight Deck -- nothing else sits on the
   home screen. */
button.a-btn {
    border-radius: 50%;
    min-width: 48px;
    min-height: 48px;
    padding: 6px;
    /* Blue circle -- the SAME blue as the helmet (#2b6fe3) -- with
       the white Aero "A" symbol on it (white on the old
       frosted-white button was invisible). Even 24px margins on
       the dock keep it fully on screen. */
    background: #2b6fe3;
    border: 1px solid rgba(255, 255, 255, 0.9);
    box-shadow: 0 4px 16px rgba(90, 110, 140, 0.45);
}
/* Backdrops (dark theme only; light theme uses its own pale background).
   "blossom" is the cherry-blossom photo (assets/backdrop.jpg) drawn as
   an image underlay; the solid blue here is only the fallback if the
   photo file is missing. */
window.bg-blossom {
    background: #b4cfee;
}
/* Keep the scrolled home content transparent so the photo backdrop
   shows through the gaps between rows. */
scrolledwindow, viewport {
    background-color: transparent;
}
window.bg-dark {
    background: #14141e;
}
window.bg-midnight {
    background: linear-gradient(160deg, #0a1628 0%, #0a0a14 60%, #141428 100%);
}
/* Light theme. */
window.light-theme {
    background: #ececf2;
}
.light-theme label {
    color: #1a1a2a;
}
.light-theme button {
    background: rgba(255, 255, 255, 0.85);
    color: #1a1a2a;
}
/* ------------------------------------------------------------------ */
/* EPG guide + dedicated Movies / Shows pages + channel player.        */
/* The guide and the title pages are SOLID (opaque) -- not frosted --  */
/* so the TV picture reads cleanly from them. Each page keeps its OWN */
/* theme (background + border highlight), applied by swapping one of  */
/* the .page-theme-* classes on the page box.                          */
/* ------------------------------------------------------------------ */
.page-theme-navy { background-color: #141a26; }
.page-theme-dark { background-color: #0e0e12; }
.page-theme-blue { background-color: #12233f; }
.page-theme-teal { background-color: #0f2e2b; }
.page-theme-pink { background-color: #3d1f2b; }
.page-theme-red { background-color: #3d1414; }
.page-theme-purple { background-color: #241a3d; }
.page-theme-green { background-color: #142e1a; }
/* Theme picker swatches: each variant shows its BACKGROUND colour
   with its BORDER HIGHLIGHT around it (phone-style theme picker).
   .selected gets the thick border + white ring. */
.theme-swatch {
    min-width: 64px;
    min-height: 44px;
    border-radius: 12px;
    padding: 0;
}
.theme-swatch-navy { background-color: #141a26; border: 3px solid #2b6fe3; }
.theme-swatch-dark { background-color: #0e0e12; border: 3px solid #6a6a7a; }
.theme-swatch-blue { background-color: #12233f; border: 3px solid #2b6fe3; }
.theme-swatch-teal { background-color: #0f2e2b; border: 3px solid #2bb673; }
.theme-swatch-pink { background-color: #3d1f2b; border: 3px solid #e85d8a; }
.theme-swatch-red { background-color: #3d1414; border: 3px solid #e50914; }
.theme-swatch-purple { background-color: #241a3d; border: 3px solid #8b5cf6; }
.theme-swatch-green { background-color: #142e1a; border: 3px solid #34c759; }
.theme-swatch.selected {
    border-width: 5px;
    box-shadow: 0 0 0 2px #ffffff;
}
label.theme-name {
    color: white;
    font-size: 13px;
}
/* EPG: the guide box itself is solid (the theme class sets the bg). */
.epg-view, .title-page, .player-view {
    color: white;
}
.epg-view {
    /* Inner breathing room; the view itself is edge-to-edge so
       the solid guide background covers the whole screen. */
    padding: 16px 24px;
}
.title-page {
    /* Same edge-to-edge treatment as the guide: the page covers
       the whole screen, so nothing underneath (EPG, home screen)
       shows through at the edges. */
    padding: 16px 24px;
}
/* The theme's label colour wins over `color` set on a button /
   checkbutton node, so labels on dark buttons and checkboxes
   render dark-on-dark unless the label child is styled itself.
   (Found by reading the EPG options / player / title-page
   captures: every dark button's label was unreadable.) */
button.playback-btn label,
button.epg-opt-btn label,
button.detail-play-btn label,
button.genre-chip label,
.epg-options-panel checkbutton label,
.title-page checkbutton label {
    color: white;
}
/* Poster names on the title pages: the home screen's app-name
   is dark plum on purpose (light frosted cells) -- the dark
   title pages need their own white name label. */
label.title-name {
    color: white;
    font-size: 15px;
    font-weight: 600;
}
/* Plain detail-page labels (runtime, cast, plot, episodes). */
label.detail-label {
    color: white;
}
label.epg-title {
    color: white;
    font-size: 30px;
    font-weight: bold;
}
label.epg-clock {
    color: rgba(255, 255, 255, 0.85);
    font-size: 18px;
}
button.epg-opt-btn {
    background: rgba(255, 255, 255, 0.14);
    border: 1px solid rgba(255, 255, 255, 0.35);
    border-radius: 12px;
    color: white;
    padding: 6px 14px;
    font-size: 16px;
}
button.epg-opt-btn:hover {
    background: rgba(255, 255, 255, 0.28);
}
.epg-search {
    background: rgba(255, 255, 255, 0.14);
    border: 1px solid rgba(255, 255, 255, 0.35);
    border-radius: 12px;
    color: white;
    padding: 8px 14px;
    font-size: 17px;
}
.epg-search entry {
    color: white;
}
/* Preview (hero) area: poster left, details right. */
label.epg-preview-title {
    color: white;
    font-size: 34px;
    font-weight: bold;
}
label.epg-preview-chan {
    color: #9ec1ff;
    font-size: 18px;
    font-weight: bold;
}
label.epg-preview-desc {
    color: rgba(255, 255, 255, 0.85);
    font-size: 17px;
}
label.epg-live-badge {
    color: white;
    font-size: 17px;
    font-weight: bold;
}
label.epg-preview-times {
    color: rgba(255, 255, 255, 0.75);
    font-size: 16px;
}
/* Time header + grid. */
label.epg-time-slot {
    color: rgba(255, 255, 255, 0.75);
    font-size: 16px;
    font-weight: bold;
}
label.epg-now-pill {
    background: #2b6fe3;
    color: white;
    font-size: 15px;
    font-weight: bold;
    border-radius: 12px;
    padding: 3px 10px;
}
label.epg-date {
    color: white;
    font-size: 17px;
    font-weight: bold;
}
label.epg-chan-count {
    color: rgba(255, 255, 255, 0.65);
    font-size: 15px;
}
.epg-now-line {
    background: #2bc8e3;
    min-width: 2px;
}
.epg-channel-cell {
    background: rgba(255, 255, 255, 0.06);
    border-radius: 10px;
    padding: 6px 10px;
}
.epg-channel-cell.selected {
    background: #2b6fe3;
}
label.epg-chan-num {
    color: rgba(255, 255, 255, 0.65);
    font-size: 15px;
    font-weight: bold;
}
.epg-channel-cell.selected label.epg-chan-num {
    color: rgba(255, 255, 255, 0.85);
}
label.epg-chan-name {
    color: white;
    font-size: 18px;
    font-weight: bold;
}
label.epg-chan-star {
    color: #ffd75e;
    font-size: 18px;
}
.epg-program-block {
    background: rgba(255, 255, 255, 0.10);
    border: 1px solid rgba(255, 255, 255, 0.18);
    border-radius: 10px;
    padding: 8px 12px;
}
.epg-program-block.now {
    background: rgba(43, 111, 227, 0.55);
    border: 1px solid #2b6fe3;
}
.epg-program-block.noguide {
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(255, 255, 255, 0.08);
}
label.epg-prog-name {
    color: white;
    font-size: 17px;
    font-weight: bold;
}
label.epg-prog-times {
    color: rgba(255, 255, 255, 0.70);
    font-size: 14px;
}
label.epg-prog-noguide {
    color: rgba(255, 255, 255, 0.40);
    font-size: 15px;
}
label.epg-hint {
    color: rgba(255, 255, 255, 0.65);
    font-size: 15px;
}
label.epg-iptv-hint {
    color: #ffd75e;
    font-size: 15px;
}
label.epg-bottom-hint {
    color: rgba(255, 255, 255, 0.60);
    font-size: 15px;
}
/* EPG / title-page options panel (slides down from the top). */
.epg-options-panel {
    background: rgba(20, 26, 38, 0.97);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 0 0 18px 18px;
    padding: 16px 20px;
}
label.epg-options-title {
    color: white;
    font-size: 20px;
    font-weight: bold;
}
label.epg-options-section {
    color: #9ec1ff;
    font-size: 15px;
    font-weight: bold;
}
label.epg-options-label {
    color: white;
    font-size: 16px;
}
.epg-options-panel checkbutton {
    color: white;
    font-size: 16px;
}
.epg-options-panel combobox {
    color: white;
}
/* Title pages: poster tile with quality badge + star. */
.quality-badge {
    background: rgba(0, 0, 0, 0.75);
    color: white;
    font-size: 14px;
    font-weight: bold;
    border-radius: 8px;
    padding: 2px 8px;
}
label.title-star {
    color: #ffd75e;
    font-size: 22px;
    text-shadow: 0 1px 3px rgba(0, 0, 0, 0.8);
}
label.title-page-heading {
    color: white;
    font-size: 30px;
    font-weight: bold;
}
label.title-section-heading {
    color: white;
    font-size: 21px;
    font-weight: bold;
}
button.genre-chip {
    background: rgba(255, 255, 255, 0.12);
    border: 1px solid rgba(255, 255, 255, 0.30);
    border-radius: 16px;
    color: white;
    padding: 6px 16px;
    font-size: 16px;
}
button.genre-chip.selected {
    background: #2b6fe3;
    border: 1px solid #2b6fe3;
}
label.resume-title {
    color: white;
    font-size: 18px;
    font-weight: bold;
}
label.resume-meta {
    color: rgba(255, 255, 255, 0.70);
    font-size: 15px;
}
.resume-row {
    background: rgba(255, 255, 255, 0.08);
    border-radius: 12px;
    padding: 10px 14px;
}
/* Channel player (full-screen) + bottom playback overlay. */
.player-view {
    background-color: #000000;
}
label.player-chan {
    color: white;
    font-size: 34px;
    font-weight: bold;
}
label.player-prog {
    color: rgba(255, 255, 255, 0.85);
    font-size: 20px;
}
label.player-live {
    color: white;
    font-size: 17px;
    font-weight: bold;
}
.playback-bar {
    /* Completely translucent, only near the bottom: the picture
       shows through behind the controls -- just the buttons and
       the runtime line float over what is playing. */
    background: transparent;
    border: none;
    padding: 14px 20px 18px 20px;
}
button.playback-btn {
    background: rgba(255, 255, 255, 0.14);
    border: 1px solid rgba(255, 255, 255, 0.35);
    border-radius: 12px;
    color: white;
    padding: 10px 18px;
    font-size: 17px;
    font-weight: bold;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.5);
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.7);
}
button.playback-btn:hover {
    background: #2b6fe3;
}
label.player-status {
    color: #ffd75e;
    font-size: 16px;
}
/* Runtime line in the playback overlay: elapsed / seek bar /
   duration, sitting below the buttons like any streaming service. */
.playback-runtime {
    background: transparent;
    padding: 6px 20px 0 20px;
}
label.player-time {
    color: white;
    font-size: 15px;
    font-weight: bold;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.8);
}
scale.playback-seek {
    min-height: 28px;
}
scale.playback-seek trough {
    background: rgba(255, 255, 255, 0.3);
    border-radius: 999px;
    min-height: 6px;
}
scale.playback-seek highlight {
    background: #2b6fe3;
    border-radius: 999px;
}
scale.playback-seek slider {
    background: white;
    border-radius: 50%;
    min-width: 18px;
    min-height: 18px;
}
/* Title detail page: Play / Resume button, cast chips, episode rows. */
button.detail-play-btn {
    background: #2b6fe3;
    border: none;
    border-radius: 12px;
    color: white;
    padding: 12px 28px;
    font-size: 19px;
    font-weight: bold;
}
button.detail-play-btn:hover {
    background: #3d7ef0;
}
.cast-chip {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.25);
    border-radius: 999px;
    color: white;
    padding: 6px 14px;
    font-size: 15px;
}
.episode-row {
    background: rgba(255, 255, 255, 0.08);
    border-radius: 12px;
    padding: 10px 14px;
}
.detail-status {
    color: #ffd75e;
    font-size: 16px;
}
"""


# Keyboard appearance (Flight Deck -> Keyboard instrument panel): colour presets
# plus an opacity slider. The keys card background is the chosen
# colour at the chosen opacity; the keys are a shade of the same
# colour at the same opacity, so the whole keyboard fades together.
# Dark colours get white key text. Defaults are the reference look:
# mostly white, background barely visible (opacity 0.95).
KB_COLOR_PRESETS = {
    "White": "#ffffff",
    "Frost": "#e8eaef",
    "Blossom": "#f6d9e0",
    "Sky": "#dbeafe",
    "Mint": "#d9f2e4",
    "Dark": "#2b3a55",
}
KB_OPACITY_MIN = 0.30
KB_OPACITY_MAX = 1.0


def _hex_to_rgb(hex_color):
    hex_color = str(hex_color).lstrip("#")
    if len(hex_color) != 6:
        return (255, 255, 255)
    try:
        return tuple(int(hex_color[i:i + 2], 16) for i in (0, 2, 4))
    except ValueError:
        return (255, 255, 255)


def _shade_hex(hex_color, factor):
    r, g, b = _hex_to_rgb(hex_color)
    r = max(0, min(255, round(r * factor)))
    g = max(0, min(255, round(g * factor)))
    b = max(0, min(255, round(b * factor)))
    return "#%02x%02x%02x" % (r, g, b)


def _is_dark_hex(hex_color):
    r, g, b = _hex_to_rgb(hex_color)
    lum = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0
    return lum < 0.40


def _rgba(hex_color, opacity):
    r, g, b = _hex_to_rgb(hex_color)
    return "rgba(%d, %d, %d, %.2f)" % (r, g, b, opacity)


def keyboard_css_values(color_hex, opacity):
    """CSS values for the keys card + keys from the chosen colour and
    opacity (clamped 0.30-1.00). Returns (card, key, key_border,
    key_text, key_hover) as CSS strings."""
    try:
        opacity = float(opacity)
    except (TypeError, ValueError):
        opacity = 1.0
    opacity = max(KB_OPACITY_MIN, min(KB_OPACITY_MAX, opacity))
    card = _rgba(color_hex, opacity)
    if _is_dark_hex(color_hex):
        key = _rgba(_shade_hex(color_hex, 1.45), opacity)
        key_border = _rgba(_shade_hex(color_hex, 1.80), opacity)
        key_text = "#ffffff"
        key_hover = _rgba(_shade_hex(color_hex, 1.70), opacity)
    else:
        key = _rgba(_shade_hex(color_hex, 0.92), opacity)
        key_border = _rgba(_shade_hex(color_hex, 0.82), opacity)
        key_text = "#2b3a55"
        key_hover = _rgba(color_hex, opacity)
    return card, key, key_border, key_text, key_hover


def apply_css(accent="#e50914", kb_color="#ffffff", kb_opacity=1.0):
    init_ui_scale()
    """Load the Alt TV stylesheet for the whole app (splash + launcher).
    The accent colour and the keyboard colour/opacity are substituted
    into the CSS wherever they appear."""
    card, key, key_border, key_text, key_hover = keyboard_css_values(
        kb_color, kb_opacity)
    css = CSS.replace(b"__ACCENT__", accent.encode())
    css = css.replace(b"__KB_CARD__", card.encode())
    css = css.replace(b"__KB_KEY__", key.encode())
    css = css.replace(b"__KB_KEY_BORDER__", key_border.encode())
    css = css.replace(b"__KB_KEY_TEXT__", key_text.encode())
    css = css.replace(b"__KB_KEY_HOVER__", key_hover.encode())
    global _APP_CSS_PROVIDER
    provider = Gtk.CssProvider()
    provider.load_from_data(css)
    screen = Gdk.Screen.get_default()
    if _APP_CSS_PROVIDER is not None:
        Gtk.StyleContext.remove_provider_for_screen(screen,
                                                    _APP_CSS_PROVIDER)
    _APP_CSS_PROVIDER = provider
    Gtk.StyleContext.add_provider_for_screen(
        screen,
        provider,
        Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
    )


_APP_CSS_PROVIDER = None


def _rounded_poly_path(cr, points, radius):
    """Append a rounded-corner polygon path (quadratic corners)."""
    import math

    def _toward(a, b, dist):
        dx, dy = b[0] - a[0], b[1] - a[1]
        d = math.hypot(dx, dy) or 1.0
        return (a[0] + dx / d * dist, a[1] + dy / d * dist)

    n = len(points)
    for i, p in enumerate(points):
        prev_p = points[i - 1]
        next_p = points[(i + 1) % n]
        start = _toward(p, prev_p, radius)
        end = _toward(p, next_p, radius)
        if i == 0:
            cr.move_to(*start)
        else:
            cr.line_to(*start)
        # Both control points on the vertex: a quadratic-style round.
        cr.curve_to(p[0], p[1], p[0], p[1], *end)
    cr.close_path()


class ATriangle(Gtk.DrawingArea):
    """The Alt TV mark: a frosty triangle pointing up (reads as an A,
    not a play button), soft very round corners, thick soft outline,
    hollow middle. Colour is an (r, g, b) tuple, 0-1."""

    def __init__(self, color=(1.0, 1.0, 1.0), size=48):
        super().__init__()
        if isinstance(color, str):   # '#rrggbb' -> (r, g, b) for cairo
            hx = color.lstrip("#")
            try:
                color = tuple(int(hx[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
            except Exception:
                color = (1.0, 1.0, 1.0)
        self._color = color
        self.set_size_request(size, size)
        self.connect("draw", self.on_draw)

    def on_draw(self, widget, cr):
        w = widget.get_allocated_width()
        h = widget.get_allocated_height()
        pad = 4
        outer = [(w / 2, pad), (w - pad, h - pad), (pad, h - pad)]
        cx = sum(p[0] for p in outer) / 3
        cy = sum(p[1] for p in outer) / 3
        # Soft halo first: two faint, slightly enlarged copies of the
        # outer shape, so the edge reads soft like the reference (white
        # rounded triangle on pink) instead of hard.
        for scale, alpha in ((1.08, 0.10), (1.04, 0.18)):
            halo = [(cx + (x - cx) * scale, cy + (y - cy) * scale)
                    for x, y in outer]
            cr.set_source_rgba(*self._color, alpha)
            _rounded_poly_path(cr, halo, max(4, w * 0.30))
            cr.fill()
        # Inner triangle, scaled toward the centroid: the ring between
        # the two is the mark -- thick like the reference, not slim.
        k = 0.45
        inner = [(cx + (x - cx) * k, cy + (y - cy) * k)
                 for x, y in outer]
        cr.set_source_rgba(*self._color, 0.92)
        _rounded_poly_path(cr, outer, max(4, w * 0.30))
        _rounded_poly_path(cr, inner, max(2, w * 0.13))
        cr.set_fill_rule(1)  # cairo FILL_RULE_EVEN_ODD
        cr.fill()
        return False


class CoverImage(Gtk.Image):
    """A photo that always fills its allocation edge-to-edge, scaled
    to COVER and centre-cropped. Works by re-scaling the source
    pixbuf whenever the widget is allocated a new size (plain
    GdkPixbuf scaling -- no cairo, so it works without pycairo).
    Used for the hero poster: the poster box is taller than the
    photo's fixed size, so a plain Gtk.Image leaves the red card
    showing above and below. This repaints on every size change, so
    the photo always fills the box exactly."""

    def __init__(self, pixbuf, init_w=520, init_h=300):
        super().__init__()
        self._src = pixbuf
        self._last = (0, 0)
        # Start at the nominal cover crop, so the natural size is
        # right before the first allocation.
        self._apply(init_w, init_h)
        self.connect("size-allocate", self._on_alloc)

    def _apply(self, w, h):
        src = self._src
        if src is None or w <= 0 or h <= 0:
            return
        self._last = (w, h)
        sw, sh = src.get_width(), src.get_height()
        scale = max(w / sw, h / sh)
        dw, dh = int(sw * scale + 0.5), int(sh * scale + 0.5)
        scaled = src.scale_simple(dw, dh, GdkPixbuf.InterpType.BILINEAR)
        ox, oy = (dw - w) // 2, (dh - h) // 2
        self.set_from_pixbuf(scaled.new_subpixbuf(ox, oy, w, h))

    def _on_alloc(self, widget, allocation):
        w, h = allocation.width, allocation.height
        if (w, h) != self._last:
            self._apply(w, h)


# ONE key layout shared by BOTH keyboards (the Navigator's stationary
# keyboard and the drop-down keyboard for every other text field), so
# the keys are always in the same place. Ten columns per row.
#   ◀ Back / Forward ▶  move the cursor WITHOUT deleting
#   |◀  ▶|              jump to the start / end
#   ⌫ Delete            deletes ONE character (hold to repeat)
#   Clear all           its own clearly labelled key
#   Mic                 offline voice typing at the cursor (Vosk)
OSK_ROWS = [list("1234567890"), list("qwertyuiop"),
            list("asdfghjkl") + ["⌫"],
            ["⇧"] + list("zxcvbnm") + [",", "."]]
OSK_SYMBOLS = [list("1234567890"), list("!@#$%^&*()"),
               list("-_=+/\\:;'") + ["⌫"],
               ["⇧", "?", "<", ">", "[", "]", "{", "}", "\"", "|"]]
OSK_CURSOR_ROW = [("|◀", "home", 1), ("◀  Back", "left", 3),
                  ("Forward  ▶", "right", 3), ("▶|", "end", 1),
                  ("⌫ Delete", "back", 2)]
OSK_BOTTOM_ROW = [("#+=", "symbols", 1), ("🎤 Mic", "mic", 1),
                  ("Space", "space", 3), ("Clear all", "clear", 2),
                  ("Hide", "hide", 1), ("Enter ⏎", "done", 2)]

# The Navigator keyboard's own action names for the shared keys.
_OSK_NAV_ACTIONS = {"back": "backspace", "left": "cur_left",
                    "right": "cur_right", "home": "cur_home",
                    "end": "cur_end", "symbols": "symbols_top",
                    "mic": "dictate", "clear": "clear_all", "hide": "done",
                    "done": "submit"}


def _osk_nav_row(row):
    return [(l, _OSK_NAV_ACTIONS.get(a, a), w) for l, a, w in row]


class Dictation:
    """Offline voice typing: runs aero-deck-dictate (Vosk, bundled
    small English model -- no internet, nothing leaves the machine)
    and reports partial / final text on the GTK main loop."""

    def __init__(self):
        self.proc = None

    def running(self):
        return self.proc is not None and self.proc.poll() is None

    def start(self, on_partial, on_final, on_error):
        self.stop()
        exe = shutil.which("aero-deck-dictate") or \
            "/usr/local/bin/aero-deck-dictate"
        try:
            self.proc = subprocess.Popen([exe], stdout=subprocess.PIPE,
                                         stderr=subprocess.DEVNULL,
                                         bufsize=0)
        except Exception as e:
            on_error("Voice typing isn't available: %s" % e)
            return
        proc = self.proc
        buf = {"b": b""}

        def on_out(fd, cond):
            chunk = b""
            if cond & GLib.IO_IN:
                try:
                    chunk = os.read(fd, 4096)
                except OSError:
                    chunk = b""
            buf["b"] += chunk
            while b"\n" in buf["b"]:
                line, buf["b"] = buf["b"].split(b"\n", 1)
                try:
                    msg = json.loads(line.decode("utf-8", "replace"))
                except Exception:
                    continue
                if "partial" in msg:
                    on_partial(msg["partial"])
                elif "text" in msg:
                    on_final(msg["text"])
                elif "error" in msg:
                    on_error(msg["error"])
            if not chunk:
                if self.proc is proc:
                    self.proc = None
                return False
            return True

        GLib.io_add_watch(proc.stdout.fileno(),
                          GLib.IO_IN | GLib.IO_HUP | GLib.IO_ERR, on_out)

    def stop(self):
        """Stop listening; the helper still prints what it heard."""
        if self.running():
            try:
                self.proc.terminate()
            except Exception:
                pass


def _dictation_join(before, text):
    """Space the dictated words sensibly against the text before the
    cursor."""
    text = (text or "").strip()
    if not text:
        return ""
    if before and not before.endswith((" ", "\n")):
        text = " " + text
    return text


class EntryKeyboard(Gtk.Popover):
    """Drop-down keyboard for ordinary text fields (Flight Deck Wi-Fi
    password, IPTV URL, AI name ...). It drops down right UNDER the
    field being typed in, and it is ONLY the keys -- the same key
    layout and style as the Navigator keyboard, without its search
    field, results or presets. (The Navigator keeps its own stationary
    keyboard.) Keys are normal focusable buttons, so the D-pad / stick
    moves between them, A presses, B closes, Done = Enter."""

    ROWS = OSK_ROWS
    SYMBOLS = OSK_SYMBOLS

    def __init__(self, launcher):
        super().__init__()
        self.launcher = launcher
        self.entry = None
        self.shift = False
        self.symbols = False
        self.set_position(Gtk.PositionType.BOTTOM)
        self.set_modal(True)
        self.get_style_context().add_class("entry-kb")
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        card.get_style_context().add_class("osk-keys-card")
        card.set_margin_start(6)
        card.set_margin_end(6)
        card.set_margin_top(6)
        card.set_margin_bottom(6)
        self.grid = Gtk.Grid()
        self.grid.set_column_homogeneous(True)
        self.grid.set_row_spacing(6)
        self.grid.set_column_spacing(6)
        card.pack_start(self.grid, False, False, 0)
        # Voice typing status ("Listening…" + the words so far).
        self.voice_label = Gtk.Label(label="")
        self.voice_label.get_style_context().add_class("osk-voice-status")
        self.voice_label.set_line_wrap(True)
        self.voice_label.set_no_show_all(True)
        card.pack_start(self.voice_label, False, False, 0)
        self.dictation = Dictation()
        self.mic_btn = None
        self.add(card)
        self.connect("closed", self._on_closed)
        self.connect("key-press-event", self._on_key)
        self._build()

    def _on_key(self, widget, event):
        """Fire OS-style: the D-pad moves between keys, A presses,
        BackSpace / the on-screen delete key delete without closing,
        Back (B / Esc) closes the keyboard only (a second Back then
        leaves the page), Done = Enter submits and closes."""
        if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_Back):
            self.popdown()
            return True
        if event.keyval == Gdk.KEY_BackSpace:
            self._press(None, "back")
            return True
        # Bumpers (L1 / R1 = Shift+Tab / Tab) move the text cursor.
        if event.keyval == Gdk.KEY_ISO_Left_Tab:
            self._press(None, "left")
            return True
        if event.keyval == Gdk.KEY_Tab:
            self._press(None, "right")
            return True
        if event.keyval in (Gdk.KEY_Home, Gdk.KEY_End):
            self._press(None, "home" if event.keyval == Gdk.KEY_Home
                        else "end")
            return True
        ch = Gdk.keyval_to_unicode(event.keyval)
        if ch and ch > 0x20 and ch != 0x7f and not (
                event.state & Gdk.ModifierType.CONTROL_MASK):
            self._press(None, chr(ch))
            return True
        return False

    def _key(self, label, action):
        b = Gtk.Button(label=label)
        b.get_style_context().add_class("osk-key")
        b.set_size_request(40, 40)
        if action in ("left", "right", "home", "end"):
            b.get_style_context().add_class("osk-cursor-key")
        if action == "back":
            # Delete ONE character per press; hold (touch / click) to
            # repeat. Looks different from the ◀ cursor key.
            b.get_style_context().add_class("osk-delete-key")
            b.set_tooltip_text("Delete one character (hold to repeat)")
            b.connect("pressed", self._back_hold_start)
            b.connect("released", self._back_hold_stop)
            b.connect("clicked", self._back_clicked)
        else:
            b.connect("clicked", self._press, action)
        return b

    def _back_clicked(self, button):
        # Keyboard / controller activation (no pressed/released pair).
        if not getattr(self, "_back_by_pointer", False):
            self._press(button, "back")
        self._back_by_pointer = False

    def _back_hold_start(self, button):
        ev = Gtk.get_current_event()
        self._back_by_pointer = ev is not None and ev.type in (
            Gdk.EventType.BUTTON_PRESS, Gdk.EventType.TOUCH_BEGIN)
        if not self._back_by_pointer:
            return
        self._press(button, "back")
        self._back_hold_stop(None)
        self._back_timer = GLib.timeout_add(450, self._back_repeat_begin)

    def _back_repeat_begin(self):
        self._back_timer = GLib.timeout_add(
            80, lambda: (self._press(None, "back"), True)[1])
        return False

    def _back_hold_stop(self, button):
        t = getattr(self, "_back_timer", None)
        if t:
            GLib.source_remove(t)
        self._back_timer = None

    def _build(self):
        for c in self.grid.get_children():
            self.grid.remove(c)
        rows = self.SYMBOLS if self.symbols else self.ROWS
        self.first_key = None
        for r, row in enumerate(rows):
            for c, ch in enumerate(row):
                action = {"⌫": "back", "⇧": "shift"}.get(ch, ch)
                label = ch.upper() if (self.shift and len(ch) == 1
                                       and ch.isalpha()) else ch
                b = self._key(label, action)
                if action == "shift" and self.shift:
                    b.get_style_context().add_class("osk-key-armed")
                self.grid.attach(b, c, r, 1, 1)
                if r == 1 and c == 0:
                    self.first_key = b
        # Shared cursor + bottom rows (see OSK_CURSOR_ROW). L1 / R1
        # move the cursor too.
        for extra, row in ((0, OSK_CURSOR_ROW), (1, OSK_BOTTOM_ROW)):
            col = 0
            for label, action, width in row:
                b = self._key(label, action)
                if action == "done":
                    b.get_style_context().add_class("osk-done")
                if action == "mic":
                    self.mic_btn = b
                    b.set_tooltip_text("Voice typing (offline)")
                    b.get_style_context().add_class("osk-mic")
                    if self.dictation.running():
                        b.get_style_context().add_class("osk-mic-live")
                self.grid.attach(b, col, len(rows) + extra, width, 1)
                col += width
        self.grid.show_all()

    def popup_for(self, entry):
        if entry is None:
            return
        self.entry = entry
        self.set_relative_to(entry)
        self.show_all()
        self.popup()
        if self.first_key is not None:
            self.first_key.grab_focus()

    def is_open(self):
        return self.get_visible()

    def _press(self, button, action):
        e = self.entry
        if e is None:
            return
        if action == "hide":
            self.popdown()
            return
        if action == "clear":
            e.set_text("")
            return
        if action == "space":
            action = " "
        if action == "mic":
            self._toggle_dictation()
            return
        if action in ("left", "right", "home", "end"):
            pos, n = e.get_position(), len(e.get_text())
            e.set_position({"left": max(0, pos - 1),
                            "right": min(n, pos + 1),
                            "home": 0, "end": n}[action])
            return
        if action == "done":
            self.popdown()
            e.activate()
            return
        if action == "shift":
            self.shift = not self.shift
            self._build()
            return
        if action == "symbols":
            self.symbols = not self.symbols
            self._build()
            return
        pos = e.get_position()
        if action == "back":
            if pos > 0:
                e.delete_text(pos - 1, pos)
                e.set_position(pos - 1)
            return
        ch = action.upper() if self.shift else action
        new_pos = e.insert_text(ch, pos)
        e.set_position(new_pos if isinstance(new_pos, int)
                       else pos + len(ch))
        if self.shift:
            self.shift = False
            self._build()
            # keep the D-pad on the same row after the rebuild
            if self.first_key is not None:
                self.first_key.grab_focus()

    # -- voice typing ---------------------------------------------------
    def _set_mic_live(self, live):
        if self.mic_btn is not None:
            ctx = self.mic_btn.get_style_context()
            (ctx.add_class if live else ctx.remove_class)("osk-mic-live")

    def _voice_status(self, text):
        self.voice_label.set_text(text)
        self.voice_label.set_visible(bool(text))

    def _toggle_dictation(self):
        if self.dictation.running():
            self.dictation.stop()      # final text still arrives
            return
        self._set_mic_live(True)
        self._voice_status("🎤 Listening… speak now (Mic again to stop)")
        self.dictation.start(self._on_voice_partial, self._on_voice_final,
                             self._on_voice_error)

    def _on_voice_partial(self, text):
        self._voice_status("🎤 " + text + " …")

    def _on_voice_final(self, text):
        self._set_mic_live(False)
        e = self.entry
        if e is None or not text:
            self._voice_status("Didn't catch that -- press Mic to try again."
                               if not text else "")
            return
        pos = e.get_position()
        ins = _dictation_join(e.get_text()[:pos], text)
        new_pos = e.insert_text(ins, pos)
        e.set_position(new_pos if isinstance(new_pos, int)
                       else pos + len(ins))
        self._voice_status("")

    def _on_voice_error(self, msg):
        self._set_mic_live(False)
        self._voice_status(msg)

    def _on_closed(self, popover):
        self.dictation.stop()
        self._voice_status("")
        if self.entry is not None:
            try:
                self.entry.grab_focus_without_selecting()
            except Exception:
                pass


class OnScreenKeyboard(Gtk.Box):
    """On-screen keyboard for remote typing -- the reference: a
    Navigator view that opens from the top (search field on top
    with a Back button, matching results under it, then the keys),
    three separate rounded cards with a small gap between them.
    All three are mostly white -- the background barely shows
    through (very slight translucency only). Photo-exact keys:
    number row on top (1-0), QWERTY with Q blue, Shift, wide Space,
    black Done bottom-right. No 123 key -- digits are always on the
    top row.
    The bottom row's small keys: "#+=" toggles the top row
    digits<->symbols, Mic is push-to-talk voice, Go opens the top
    result (or web-searches the query). Results show the real brand
    logo for apps (assets/icons/, the same logos the Your Apps row
    uses); a letter tile is only the last resort when an app has no
    logo at all.

    It types into its own query field. The launcher shows it when a
    search entry gets focus (remote: D-pad to the search bar, OK) and
    hides it on Done / Back / Escape. Live results come from the
    launcher's apps, live channels, movies, shows, games, cloud
    services and cached social videos; tapping one launches it, and
    the last row searches the web for the typed query.

    Remote navigation is highlight-driven: the launcher's key handler
    moves the highlight (arrows), activates the highlighted key or
    result (Enter/OK), and inserts physical-keyboard characters.
    Keys are not GTK-focusable, so the D-pad never fights GTK focus."""

    # (label, action, grid columns) per cell. Action is the character
    # to type, or "backspace" / "shift" / "space" / "done" /
    # "symbols_top" / "voice" / "submit". Letters always show
    # uppercase, like the reference; shift is one-shot (the next
    # letter comes out capital, then shift releases). All rows are
    # exactly 10 columns, so the grid is uniform.
    KEY_ROWS = [
        [("1", "1", 1), ("2", "2", 1), ("3", "3", 1), ("4", "4", 1),
         ("5", "5", 1), ("6", "6", 1), ("7", "7", 1), ("8", "8", 1),
         ("9", "9", 1), ("0", "0", 1)],
        [("Q", "q", 1), ("W", "w", 1), ("E", "e", 1), ("R", "r", 1),
         ("T", "t", 1), ("Y", "y", 1), ("U", "u", 1), ("I", "i", 1),
         ("O", "o", 1), ("P", "p", 1)],
        [("A", "a", 1), ("S", "s", 1), ("D", "d", 1), ("F", "f", 1),
         ("G", "g", 1), ("H", "h", 1), ("J", "j", 1), ("K", "k", 1),
         ("L", "l", 1), ("⌫", "backspace", 1)],
        [("⇧", "shift", 1), ("Z", "z", 1), ("X", "x", 1),
         ("C", "c", 1), ("V", "v", 1), ("B", "b", 1), ("N", "n", 1),
         ("M", "m", 1), (",", ",", 1), ("–", "-", 1)],
    ]
    # Top row when "#+=" is on: symbols in place of the digits.
    SYMBOL_TOP_ROW = [
        [("!", "!", 1), ("@", "@", 1), ("#", "#", 1), ("$", "$", 1),
         ("%", "%", 1), ("^", "^", 1), ("&", "&", 1), ("*", "*", 1),
         ("(", "(", 1), (")", ")", 1)],
    ]
    # Bottom row: (label, action, grid columns). Done is the black
    # pill at the bottom right, like the photo.
    # Cursor row (Nov 16): ◀ Back / Forward ▶ move the cursor without
    # deleting, |◀ ▶| jump to start / end, ⌫ deletes one character.
    CURSOR_ROW = _osk_nav_row(OSK_CURSOR_ROW)
    BOTTOM_ROW = _osk_nav_row(OSK_BOTTOM_ROW)

    def __init__(self, launcher):
        # Three separate rounded cards with a small gap between
        # them, like the reference photo: the search bar, the
        # results card and the keys card are each their own rounded
        # rectangle (spacing 10), not one continuous block.
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.launcher = launcher
        self.shift = False
        self.items = []            # (name, kind, icon, launch, keywords)
        self.result_buttons = []   # [(button, launch)]
        self._keep_keyboard = False  # a "Did you mean" pick keeps it up
        self.key_rows = []         # [[(button, action, center_x), ...]]
        self.hl_section = "keys"   # "results" | "keys"
        self.hl_row = 1            # Q row first, like the reference (Q blue)
        self.hl_col = 0
        self.shift_btn = None
        self.done_btn = None
        self.top_symbols = False   # "#+=" swaps the number row for symbols

        # -- query field (mostly-white rounded card, like the reference) --
        query_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                            spacing=8)
        query_bar.get_style_context().add_class("osk-card")
        query_bar.get_style_context().add_class("osk-card-top")
        icon = Gtk.Image.new_from_icon_name(
            "system-search", Gtk.IconSize.MENU)
        query_bar.pack_start(icon, False, False, 0)
        self.entry = Gtk.Entry()
        self.entry.set_placeholder_text("Apps, channels, videos or a website")
        self.entry.get_style_context().add_class("osk-query")
        self.entry.set_hexpand(True)
        self.entry.connect("changed", self.on_query_changed)
        self.entry.connect("key-press-event", self.launcher.on_kb_entry_key)
        self.entry._navigator_field = True
        # The Navigator has its own keys: don't also summon the system
        # on-screen keyboard (squeekboard) for this field -- the two
        # keyboards fought each other on the Deck.
        try:
            self.entry.set_property("im-module", "gtk-im-context-simple")
        except Exception:
            pass
        query_bar.pack_start(self.entry, True, True, 0)
        clear_btn = Gtk.Button(label="Clear all")
        clear_btn.get_style_context().add_class("osk-clear")
        clear_btn.set_can_focus(False)
        clear_btn.set_tooltip_text("Clear the whole search")
        clear_btn.connect("clicked", self.on_clear_query)
        query_bar.pack_start(clear_btn, False, False, 0)
        # Back (top right of the search field, like the reference):
        # dismisses the Navigator.
        back_btn = Gtk.Button(label="✕  Close")
        back_btn.get_style_context().add_class("osk-back")
        back_btn.set_can_focus(False)
        back_btn.set_tooltip_text("Close the Navigator (B / Esc)")
        back_btn.connect("clicked",
                         lambda w: self.launcher.hide_keyboard())
        query_bar.pack_start(back_btn, False, False, 0)
        self.pack_start(query_bar, False, False, 0)

        # -- results (mostly-white rounded card; hint until the user types) --
        results_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                               spacing=4)
        results_card.get_style_context().add_class("osk-card")
        results_card.get_style_context().add_class("osk-card-mid")
        results_label = Gtk.Label(label="Results")
        results_label.get_style_context().add_class("osk-label")
        results_label.set_halign(Gtk.Align.START)
        results_card.pack_start(results_label, False, False, 0)
        self.results_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                   spacing=2)
        results_card.pack_start(self.results_box, False, False, 0)
        self.pack_start(results_card, False, False, 0)

        # -- keys (mostly-white rounded card, like the reference; its
        # own card with a small gap above it). No header: Done is
        # a grid button in the bottom row, bottom-right, like the
        # photo.
        keys_card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        keys_card.get_style_context().add_class("osk-keys-card")
        self.grid = Gtk.Grid()
        self.grid.set_column_homogeneous(True)
        self.grid.set_column_spacing(8)
        self.grid.set_row_spacing(8)
        keys_card.pack_start(self.grid, True, True, 0)
        self.voice_label = Gtk.Label(label="")
        self.voice_label.get_style_context().add_class("osk-voice-status")
        self.voice_label.set_line_wrap(True)
        self.voice_label.set_no_show_all(True)
        keys_card.pack_start(self.voice_label, False, False, 0)
        self.pack_start(keys_card, False, False, 0)
        self.build_keys()
        self.refresh_results()
        self.update_highlight()

    # -- keys ---------------------------------------------------------------
    def _make_key(self, label, action):
        btn = Gtk.Button(label=label)
        btn.get_style_context().add_class("osk-key")
        btn.set_can_focus(False)
        btn.set_hexpand(True)
        btn.connect("clicked", self.on_key_clicked, action)
        return btn

    def build_keys(self):
        """Lay out the key grid, photo-exact: number row, QWERTY,
        ASDF, Shift row, bottom row ("#+=" / Mic / Go / wide Space /
        "." / black Done bottom-right). The Done key is a grid button
        in the bottom row (the last row); Q is row 1, so the remote
        still lands on blue Q first. "#+=" swaps the number row for
        symbols; Mic is push-to-talk voice; Go opens the top result
        (or web-searches the query)."""
        for child in self.grid.get_children():
            self.grid.remove(child)
        self.shift_btn = None
        self.done_btn = None
        self.key_rows = []
        # Same layout as the drop-down keyboard (OSK_* above); letters
        # are shown in capitals here, like the Fire TV reference.
        nav_action = {"⌫": "backspace", "⇧": "shift"}
        rows = [[(ch.upper() if ch.isalpha() else ch,
                  nav_action.get(ch, ch), 1) for ch in row]
                for row in (OSK_SYMBOLS if self.top_symbols else OSK_ROWS)]
        for r, cells in enumerate(rows):
            row_cells = []
            col = 0
            for label, action, width in cells:
                btn = self._make_key(label, action)
                if action == "shift":
                    self.shift_btn = btn
                self.grid.attach(btn, col, r, width, 1)
                row_cells.append((btn, action, (col + width / 2) / 10))
                col += width
            self.key_rows.append(row_cells)
        # Cursor row (above the bottom row).
        row_cells = []
        col = 0
        for label, action, width in self.CURSOR_ROW:
            btn = self._make_key(label, action)
            if action.startswith("cur_"):
                btn.get_style_context().add_class("osk-cursor-key")
            else:
                btn.get_style_context().add_class("osk-delete-key")
                self._hold_repeat(btn)
            self.grid.attach(btn, col, len(rows), width, 1)
            row_cells.append((btn, action, (col + width / 2) / 10))
            col += width
        self.key_rows.append(row_cells)
        rows = rows + [None]   # the bottom row goes one line lower
        # Bottom row: "#+=" / Mic / Go / wide Space / "." / Done.
        row_cells = []
        col = 0
        for label, action, width in self.BOTTOM_ROW:
            btn = self._make_key(label, action)
            if action == "submit":
                btn.get_style_context().add_class("osk-done")
            if action == "done":
                self.done_btn = btn
            if action == "dictate":
                self.mic_btn = btn
                btn.get_style_context().add_class("osk-mic")
                btn.set_tooltip_text("Voice typing (offline)")
            self.grid.attach(btn, col, len(rows), width, 1)
            row_cells.append((btn, action, (col + width / 2) / 10))
            col += width
        self.key_rows.append(row_cells)
        self.update_highlight()

    def on_key_clicked(self, button, action):
        # Clicking a key also moves the highlight there, so the remote
        # and the pointer never disagree about which key is current.
        for r, row_cells in enumerate(self.key_rows):
            for c, (btn, _a, _cx) in enumerate(row_cells):
                if btn is button:
                    self.hl_section = "keys"
                    self.hl_row, self.hl_col = r, c
                    self.update_highlight()
                    break
        self.press_key(action)

    def press_key(self, action):
        if action == "done":
            self.launcher.hide_keyboard()
            return
        if action == "symbols_top":
            # "#+=" swaps the number row for symbols (and back).
            self.top_symbols = not self.top_symbols
            self.shift = False
            self.build_keys()
            self.hl_section = "keys"
            self.hl_row, self.hl_col = 1, 0
            self.update_highlight()
            return
        if action == "voice":
            # Mic: push-to-talk voice (Alexa), like the remote mic.
            self.launcher.hide_keyboard()
            self.launcher.on_voice_button()
            return
        if action == "submit":
            # Go: open the top result (or web-search the query).
            self.submit_query()
            return
        if action == "shift":
            self.shift = not self.shift
            self.update_shift_style()
            return
        if action == "backspace":
            if getattr(self, "_skip_click_delete", False):
                self._skip_click_delete = False   # hold already deleted
                return
            self.delete_char()
            return
        if action == "clear_all":
            self.on_clear_query(None)
            return
        if action == "dictate":
            self.toggle_dictation()
            return
        if action.startswith("cur_"):
            self.move_cursor(action[4:])
            return
        if action == "space":
            self.insert_text(" ")
            return
        if len(action) == 1 and action.isalpha() and self.shift:
            self.insert_text(action.upper())
            self.shift = False
            self.update_shift_style()
            return
        self.insert_text(action)

    def submit_query(self):
        """Go: open the top result (if any), else web-search the
        typed query."""
        if self.result_buttons:
            _btn, launch = self.result_buttons[0]
            self.activate_result(launch)
            return
        query = self.entry.get_text().strip()
        if query:
            self.launcher.do_search(query)
        self.launcher.hide_keyboard()

    def update_shift_style(self):
        if self.shift_btn is None:
            return
        ctx = self.shift_btn.get_style_context()
        if self.shift:
            ctx.add_class("osk-key-armed")
        else:
            ctx.remove_class("osk-key-armed")

    def insert_text(self, text):
        pos = self.entry.get_position()
        new_pos = self.entry.insert_text(text, pos)
        self.entry.set_position(new_pos)

    # -- hold-to-repeat delete + voice typing --------------------------
    def _hold_repeat(self, btn):
        def start(_b):
            ev = Gtk.get_current_event()
            if ev is None or ev.type not in (Gdk.EventType.BUTTON_PRESS,
                                             Gdk.EventType.TOUCH_BEGIN):
                return
            self.delete_char()
            self._skip_click_delete = True
            stop(None)
            self._del_timer = GLib.timeout_add(450, begin)

        def begin():
            self._del_timer = GLib.timeout_add(
                80, lambda: (self.delete_char(), True)[1])
            return False

        def stop(_b):
            t = getattr(self, "_del_timer", None)
            if t:
                GLib.source_remove(t)
            self._del_timer = None
        btn.connect("pressed", start)
        btn.connect("released", stop)

    def _voice_status(self, text):
        lbl = getattr(self, "voice_label", None)
        if lbl is None:
            return
        lbl.set_text(text)
        lbl.set_visible(bool(text))

    def _set_mic_live(self, live):
        b = getattr(self, "mic_btn", None)
        if b is not None:
            ctx = b.get_style_context()
            (ctx.add_class if live else ctx.remove_class)("osk-mic-live")

    def toggle_dictation(self):
        if not hasattr(self, "dictation"):
            self.dictation = Dictation()
        if self.dictation.running():
            self.dictation.stop()
            return
        self._set_mic_live(True)
        self._voice_status("🎤 Listening… speak now (Mic again to stop)")

        def partial(t):
            self._voice_status("🎤 " + t + " …")

        def final(t):
            self._set_mic_live(False)
            if not t:
                self._voice_status("Didn't catch that -- press Mic to "
                                   "try again.")
                return
            pos = self.entry.get_position()
            self.insert_text(_dictation_join(
                self.entry.get_text()[:pos], t))
            self._voice_status("")

        def error(m):
            self._set_mic_live(False)
            self._voice_status(m)
        self.dictation.start(partial, final, error)

    def move_cursor(self, where):
        pos, n = self.entry.get_position(), len(self.entry.get_text())
        self.entry.set_position({"left": max(0, pos - 1),
                                 "right": min(n, pos + 1),
                                 "home": 0, "end": n}[where])

    def delete_char(self):
        if not self.entry.get_text():
            return
        pos = self.entry.get_position()
        if pos > 0:
            self.entry.delete_text(pos - 1, pos)
            self.entry.set_position(pos - 1)

    def on_clear_query(self, button):
        self.entry.set_text("")
        self.entry.grab_focus()

    def on_query_changed(self, entry):
        self.refresh_results()

    # -- results --------------------------------------------------------------
    def build_index(self):
        """Fresh searchable items for this showing (apps, live, movies,
        shows, games, cloud, cached social videos)."""
        self.items = self.launcher.search_items()

    def refresh_results(self):
        for child in self.results_box.get_children():
            self.results_box.remove(child)
        self.result_buttons = []
        query = self.entry.get_text().strip()
        if not query:
            hint = Gtk.Label(
                label="Type to search apps, movies, shows, channels, "
                      "videos, settings and more.")
            hint.get_style_context().add_class("osk-hint")
            hint.set_halign(Gtk.Align.START)
            hint.set_line_wrap(True)
            self.results_box.pack_start(hint, False, False, 0)
        else:
            # Direct matches (name or keyword contains the query) and
            # fuzzy matches (a misspelling still finds it), Interface
            # content first, then related items of the top hit's kind.
            shown, did_you_mean = search_match(self.items, query)
            # "Did you mean": no direct hit, but a close fuzzy one --
            # offer the correction first (picking it re-runs the
            # search with the corrected term).
            if did_you_mean:
                self.add_result("Did you mean: %s?" % did_you_mean,
                                "Suggestion",
                                lambda b=did_you_mean:
                                self.correct_query(b))
            for name, kind, icon, launch, _kw in shown:
                self.add_result(name, kind, launch, icon)
            # Ask the AI at the helm: always here when there's a
            # query, and the lifeline when results are thin or empty.
            # Named for whoever is at the helm right now. It carries
            # the A-triangle mark (a real graphic, not a letter).
            helm = self.launcher.active_ai_entry().get("name", "Nova")
            self.add_result("Ask %s about “%s”" % (helm, query), helm,
                            lambda q=query: self.launcher.ask_ai(q),
                            icon=self._ask_icon())
            # Always offer the web search for the typed query (with
            # a magnifier icon, not a letter tile).
            self.add_result("Search the web for “%s”" % query, "Web",
                            lambda q=query: self.launcher.do_search(q),
                            icon=self._web_icon())
        self.results_box.show_all()
        # Keep the highlight valid after the list changes.
        if self.hl_section == "results":
            if self.result_buttons:
                self.hl_col = min(self.hl_col,
                                  len(self.result_buttons) - 1)
            else:
                self.hl_section = "keys"
                self.hl_row, self.hl_col = 1, 0
        self.update_highlight()

    def correct_query(self, correction):
        """A "Did you mean" pick: put the corrected term in the query
        and show its results (the keyboard stays up so he sees them)."""
        self._keep_keyboard = True
        self.entry.set_text(correction)
        self.refresh_results()

    def _ask_icon(self):
        """The A-triangle mark for the Ask-AI result row -- a real
        graphic, not a letter tile. None when the file is missing
        (the row falls back to its letter)."""
        try:
            path = (ASSETS_DIR
                    / "a-triangle-dark.png")
            if path.exists():
                return GdkPixbuf.Pixbuf.new_from_file_at_scale(
                    str(path), 48, 48, True)
        except Exception:
            pass
        return None

    def _web_icon(self):
        """A magnifier for the web-search result row -- a real
        graphic, not a letter tile."""
        try:
            theme = Gtk.IconTheme.get_default()
            info = theme.lookup_icon("system-search", 48, 0)
            if info is not None:
                return info.load_icon()
        except Exception:
            pass
        return None

    def add_result(self, name, kind, launch, icon=None):
        btn = Gtk.Button()
        btn.get_style_context().add_class("osk-result")
        btn.set_can_focus(False)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        # Small icon when the launcher has one for this item (the
        # reference shows the app icon per row); the first letter
        # otherwise -- only a last resort, when an app has no logo
        # at all.
        if icon is not None:
            row.pack_start(Gtk.Image.new_from_pixbuf(icon),
                           False, False, 0)
        else:
            letter = Gtk.Label(label=name[:1].upper() if name else "?")
            letter.get_style_context().add_class("osk-result-letter")
            letter.set_size_request(48, 48)
            row.pack_start(letter, False, False, 0)
        texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        name_label = Gtk.Label(label=name)
        name_label.get_style_context().add_class("osk-result-name")
        name_label.set_halign(Gtk.Align.START)
        name_label.set_max_width_chars(48)
        texts.pack_start(name_label, False, False, 0)
        sub = Gtk.Label(label=kind)
        sub.get_style_context().add_class("osk-result-sub")
        sub.set_halign(Gtk.Align.START)
        texts.pack_start(sub, False, False, 0)
        row.pack_start(texts, True, True, 0)
        chev = Gtk.Label(label="›")
        chev.get_style_context().add_class("osk-result-chev")
        row.pack_start(chev, False, False, 0)
        btn.add(row)
        btn.connect("clicked", lambda w: self.activate_result(launch))
        self.results_box.pack_start(btn, False, False, 0)
        self.result_buttons.append((btn, launch))

    def activate_result(self, launch):
        self._keep_keyboard = False
        launch()
        # A "Did you mean" correction keeps the keyboard up so he sees
        # the corrected results; everything else hides it.
        if not self._keep_keyboard:
            self.launcher.hide_keyboard()
        self._keep_keyboard = False

    # -- highlight (remote navigation) ----------------------------------------
    def set_highlight(self, section, row=0, col=0):
        self.hl_section = section
        self.hl_row = row
        self.hl_col = col
        self.update_highlight()

    def update_highlight(self):
        for btn, _launch in self.result_buttons:
            btn.get_style_context().remove_class("osk-result-current")
        for row_cells in self.key_rows:
            for btn, _action, _cx in row_cells:
                btn.get_style_context().remove_class("osk-key-current")
        if self.hl_section == "results" and self.result_buttons:
            btn = self.result_buttons[self.hl_col][0]
            btn.get_style_context().add_class("osk-result-current")
        elif self.hl_section == "keys" and self.key_rows:
            row_cells = self.key_rows[self.hl_row]
            if row_cells:
                col = max(0, min(self.hl_col, len(row_cells) - 1))
                row_cells[col][0].get_style_context().add_class(
                    "osk-key-current")

    def _nearest_col(self, row, center_x):
        cells = self.key_rows[row]
        best, best_d = 0, None
        for i, (_btn, _action, cx) in enumerate(cells):
            d = abs(cx - center_x)
            if best_d is None or d < best_d:
                best_d, best = d, i
        return best

    def move_highlight(self, direction):
        if self.hl_section == "results":
            if direction == "down":
                if self.hl_col < len(self.result_buttons) - 1:
                    self.hl_col += 1
                else:
                    # Past the last result: land on the Q row (row 1;
                    # row 0 is the number row).
                    self.set_highlight("keys", 1, 0)
                    return
            elif direction == "up":
                if self.hl_col > 0:
                    self.hl_col -= 1
            self.update_highlight()
            return
        row, col = self.hl_row, self.hl_col
        cells = self.key_rows[row]
        if direction == "left":
            col = max(0, col - 1)
        elif direction == "right":
            col = min(len(cells) - 1, col + 1)
        elif direction == "down":
            if row < len(self.key_rows) - 1:
                row += 1
                col = self._nearest_col(row, cells[col][2])
        elif direction == "up":
            if row > 0:
                row -= 1
                col = self._nearest_col(row, cells[col][2])
            elif self.result_buttons:
                self.set_highlight("results", 0,
                                   len(self.result_buttons) - 1)
                return
        self.hl_row, self.hl_col = row, col
        self.update_highlight()

    def activate_highlight(self):
        if self.hl_section == "results" and self.result_buttons:
            _btn, launch = self.result_buttons[self.hl_col]
            self.activate_result(launch)
            return
        row_cells = self.key_rows[self.hl_row]
        _btn, action, _cx = row_cells[self.hl_col]
        self.press_key(action)


# ---------------------------------------------------------------------------
# Web browser (Andrew, Nov 16): Brave is the default for every web tile,
# and the Flight Deck -> Browser page lets him pick another one. The
# choice is settings["browser"]; open_url() is the ONE place web pages
# are opened from, so every tile follows the picker.
# ---------------------------------------------------------------------------
BROWSERS = [
    # (key, label, binaries to try, .desktop id)
    ("brave", "Brave", ["brave", "brave-browser", "brave-browser-stable"],
     "brave-browser.desktop"),
    ("firefox", "Firefox", ["firefox"], "firefox.desktop"),
    ("chrome", "Google Chrome", ["google-chrome-stable", "google-chrome"],
     "google-chrome.desktop"),
    ("chromium", "Chromium", ["chromium", "chromium-browser"],
     "chromium.desktop"),
    ("vivaldi", "Vivaldi", ["vivaldi-stable", "vivaldi"],
     "vivaldi-stable.desktop"),
    ("librewolf", "LibreWolf", ["librewolf"], "librewolf.desktop"),
    ("edge", "Microsoft Edge", ["microsoft-edge-stable"],
     "microsoft-edge.desktop"),
]
DEFAULT_BROWSER = "brave"
# Chromium-family browsers: native Wayland + the system on-screen
# keyboard (text-input-v3), so squeekboard pops up in web text fields.
_CHROMIUM_FLAGS = ["--ozone-platform-hint=auto", "--enable-wayland-ime",
                   "--wayland-text-input-version=3"]


def browser_binary(key):
    for k, _label, bins, _desk in BROWSERS:
        if k == key:
            for b in bins:
                if shutil.which(b):
                    return b
    return None


def installed_browsers():
    return [(k, label) for k, label, _b, _d in BROWSERS
            if browser_binary(k)]


def current_browser():
    try:
        key = load_settings().get("browser") or DEFAULT_BROWSER
    except Exception:
        key = DEFAULT_BROWSER
    return key


def set_default_browser(key):
    """Remember the pick and make it the system default too (xdg), so
    links opened by other apps follow it."""
    settings = load_settings()
    settings["browser"] = key
    save_settings(settings)
    for k, _label, _bins, desk in BROWSERS:
        if k == key:
            _spawn(["xdg-settings", "set", "default-web-browser", desk],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            _spawn(["xdg-mime", "default", desk, "x-scheme-handler/http",
                    "x-scheme-handler/https", "text/html"],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def open_url(url):
    """Open a web page in the picked browser (Brave by default). Falls
    back to any installed browser, then xdg-open. Non-web links
    (mailto:, file:) go to xdg-open."""
    if not url:
        return None
    url = str(url)
    if not re.match(r"^https?://", url, re.I):
        return _spawn(["xdg-open", url])
    order = [current_browser()] + [k for k, *_ in BROWSERS]
    seen = set()
    for key in order:
        if key in seen:
            continue
        seen.add(key)
        binary = browser_binary(key)
        if not binary:
            continue
        cmd = [binary]
        if key in ("brave", "chrome", "chromium", "vivaldi", "edge"):
            cmd += _CHROMIUM_FLAGS
        proc = _spawn(cmd + [url], stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)
        if proc is not None:
            return proc
    return _spawn(["xdg-open", url])


# ---------------------------------------------------------------------------
# Wi-Fi (NetworkManager / nmcli). Everything here is best effort and runs
# off the GTK thread (the panel calls these from worker threads).
# Passwords are handed to nmcli only; they are never logged or stored by
# the launcher (NetworkManager keeps saved networks itself).
# ---------------------------------------------------------------------------
def _nmcli_split(line):
    """Split one `nmcli -t` line on unescaped ':' (nmcli escapes ':' and
    '\\' inside values with a backslash)."""
    fields, cur, esc = [], [], False
    for ch in line:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == ":":
            fields.append("".join(cur))
            cur = []
        else:
            cur.append(ch)
    fields.append("".join(cur))
    return fields


def _nmcli(args, timeout=30, input_text=None):
    """Run nmcli; returns (ok, stdout, short error). Never raises."""
    if not shutil.which("nmcli"):
        return False, "", "NetworkManager (nmcli) isn't installed."
    try:
        res = subprocess.run(["nmcli"] + list(args), capture_output=True,
                             text=True, timeout=timeout, input=input_text)
    except subprocess.TimeoutExpired:
        return False, "", "Timed out."
    except Exception as exc:
        return False, "", str(exc)
    err = (res.stderr or res.stdout or "").strip().splitlines()
    return res.returncode == 0, res.stdout, (err[-1] if err else "")


def wifi_device():
    ok, out, _ = _nmcli(["-t", "-f", "DEVICE,TYPE,STATE", "device"], 10)
    if not ok:
        return None
    for line in out.splitlines():
        f = _nmcli_split(line)
        if len(f) >= 2 and f[1] == "wifi":
            return f[0]
    return None


def wifi_scan(rescan=True):
    """Visible networks, strongest first, one entry per SSID:
    [{"ssid", "signal", "security", "in_use"}]."""
    ok, out, err = _nmcli(["-t", "-f", "IN-USE,SSID,SIGNAL,SECURITY",
                           "device", "wifi", "list", "--rescan",
                           "yes" if rescan else "no"], 40)
    if not ok:
        return None, err
    best = {}
    for line in out.splitlines():
        f = _nmcli_split(line)
        if len(f) < 4:
            continue
        in_use, ssid, signal, security = f[0], f[1], f[2], f[3]
        if not ssid:
            continue
        try:
            sig = int(signal)
        except ValueError:
            sig = 0
        entry = {"ssid": ssid, "signal": sig,
                 "security": "" if security in ("", "--") else security,
                 "in_use": in_use.strip() == "*"}
        prev = best.get(ssid)
        if (prev is None or entry["in_use"]
                or (sig > prev["signal"] and not prev["in_use"])):
            best[ssid] = entry
    nets = sorted(best.values(),
                  key=lambda e: (not e["in_use"], -e["signal"]))
    return nets, ""


def wifi_saved():
    """Saved Wi-Fi profiles: [{"name", "uuid", "ssid", "active"}]."""
    ok, out, _ = _nmcli(["-t", "-f", "NAME,UUID,TYPE,ACTIVE",
                         "connection", "show"], 10)
    if not ok:
        return []
    saved = []
    for line in out.splitlines():
        f = _nmcli_split(line)
        if len(f) >= 4 and f[2] in ("802-11-wireless", "wifi"):
            ssid = f[0]
            ok2, out2, _ = _nmcli(["-t", "-g", "802-11-wireless.ssid",
                                   "connection", "show", "uuid", f[1]], 10)
            if ok2 and out2.strip():
                ssid = out2.strip()
            saved.append({"name": f[0], "uuid": f[1], "ssid": ssid,
                          "active": f[3] == "yes"})
    return saved


def wifi_connect(ssid, password="", hidden=False):
    """Connect to a network. A saved profile is brought up as is; a new
    one is created by nmcli. Returns (ok, message)."""
    for prof in wifi_saved():
        if prof["ssid"] == ssid and not password:
            ok, _out, err = _nmcli(["connection", "up", "uuid",
                                    prof["uuid"]], 60)
            return ok, ("Connected to %s." % ssid) if ok else err
    args = ["device", "wifi", "connect", ssid]
    if password:
        args += ["password", password]
    if hidden:
        args += ["hidden", "yes"]
    dev = wifi_device()
    if dev:
        args += ["ifname", dev]
    ok, _out, err = _nmcli(args, 60)
    if not ok:
        # A failed first try leaves a half-made profile behind (wrong
        # password): drop it so the next try asks again cleanly.
        for prof in wifi_saved():
            if prof["ssid"] == ssid and not prof["active"]:
                _nmcli(["connection", "delete", "uuid", prof["uuid"]], 15)
        if password:
            err = err.replace(password, "****")
        if "Secrets were required" in err or "802-1x" in err:
            err = "Wrong password, or this network needs one."
        return False, err or "Couldn't connect."
    return True, "Connected to %s." % ssid


def wifi_forget(uuid):
    ok, _out, err = _nmcli(["connection", "delete", "uuid", uuid], 15)
    return ok, "Forgotten." if ok else err


def wifi_disconnect():
    dev = wifi_device()
    if not dev:
        return False, "No Wi-Fi adapter found."
    ok, _out, err = _nmcli(["device", "disconnect", dev], 15)
    return ok, "Disconnected." if ok else err


def ethernet_status():
    """Wired network state for the Flight Deck (built-in or USB / USB-C
    Ethernet adapters -- r8152, ax88179, cdc_ether ... are in the kernel).
    Returns a short line like 'Ethernet: Connected (enp4s0u1)'."""
    ok, out, _ = _nmcli(["-t", "-f", "DEVICE,TYPE,STATE,CONNECTION",
                         "device"], 10)
    if not ok:
        return "Ethernet: status unavailable"
    wired = []
    for line in out.splitlines():
        f = _nmcli_split(line)
        if len(f) >= 3 and f[1] == "ethernet":
            wired.append(f)
    if not wired:
        return "Ethernet: no wired adapter found"
    for f in wired:
        if f[2].startswith("connected"):
            return "Ethernet: Connected (%s)" % f[0]
    for f in wired:
        if "connecting" in f[2]:
            return "Ethernet: Connecting… (%s)" % f[0]
    if any(f[2] == "unavailable" for f in wired):
        return "Ethernet: cable not plugged in (%s)" % wired[0][0]
    return "Ethernet: not connected (%s)" % wired[0][0]


def wifi_signal_bars(signal):
    if signal >= 75:
        return "▂▄▆█"
    if signal >= 50:
        return "▂▄▆_"
    if signal >= 25:
        return "▂▄__"
    return "▂___"


# ---------------------------------------------------------------------------
# Display (wlr-randr) and brightness (brightnessctl) for the Flight Deck
# Display page. wlroots compositors only (labwc); elsewhere the page says
# the controls aren't available.
# ---------------------------------------------------------------------------
DISPLAY_TRANSFORMS = [("normal", "Normal (0°)"), ("90", "90°"),
                      ("180", "180°"), ("270", "270°"),
                      ("flipped", "Flipped"), ("flipped-90", "Flipped 90°"),
                      ("flipped-180", "Flipped 180°"),
                      ("flipped-270", "Flipped 270°")]
DISPLAY_SCALES = ["1", "1.25", "1.5", "1.75", "2", "2.5", "3"]


def is_steam_deck():
    """Steam Deck LCD (Jupiter) or OLED (Galileo), from DMI."""
    try:
        with open("/sys/class/dmi/id/product_name") as f:
            return f.read().strip() in ("Jupiter", "Galileo")
    except Exception:
        return False


def display_outputs():
    """[{"name", "description", "enabled", "modes": [(w, h, hz, current,
    preferred)], "scale", "transform"}] from `wlr-randr --json`, or
    None when wlr-randr can't talk to the compositor."""
    if not shutil.which("wlr-randr"):
        return None
    try:
        out = subprocess.check_output(["wlr-randr", "--json"], timeout=5,
                                      stderr=subprocess.DEVNULL)
        data = json.loads(out.decode("utf-8", "replace"))
    except Exception:
        return None
    result = []
    for o in data if isinstance(data, list) else []:
        modes = []
        for m in o.get("modes", []):
            try:
                modes.append((int(m["width"]), int(m["height"]),
                              float(m.get("refresh", 0)),
                              bool(m.get("current")),
                              bool(m.get("preferred"))))
            except Exception:
                continue
        result.append({
            "name": o.get("name", "?"),
            "description": o.get("description") or o.get("model") or "",
            "enabled": bool(o.get("enabled", True)),
            "modes": modes,
            "scale": float(o.get("scale") or 1.0),
            "transform": str(o.get("transform") or "normal"),
        })
    return result


def display_apply(name, mode=None, scale=None, transform=None):
    """Apply one output's settings; returns (ok, message)."""
    cmd = ["wlr-randr", "--output", name]
    if mode:
        w, h, hz = mode
        cmd += ["--mode", "%dx%d@%.3fHz" % (w, h, hz) if hz else
                "%dx%d" % (w, h)]
    if scale:
        cmd += ["--scale", str(scale)]
    if transform:
        cmd += ["--transform", str(transform)]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
    except Exception as exc:
        return False, str(exc)
    if res.returncode != 0:
        return False, (res.stderr or "wlr-randr failed").strip()[:200]
    return True, "Applied."


def brightness_get():
    """Backlight percent (0-100) or None when there's no backlight (a TV
    over HDMI has none)."""
    if not shutil.which("brightnessctl"):
        return None
    try:
        out = subprocess.check_output(
            ["brightnessctl", "-m", "-c", "backlight", "info"], timeout=5,
            stderr=subprocess.DEVNULL).decode().strip()
        pct = out.split(",")[3].rstrip("%")
        return int(pct)
    except Exception:
        return None


def brightness_set(pct):
    pct = max(5, min(100, int(pct)))  # never fully black
    return _spawn(["brightnessctl", "-q", "-c", "backlight", "set",
                   "%d%%" % pct], stdout=subprocess.DEVNULL,
                  stderr=subprocess.DEVNULL)


def show_system_keyboard(visible=True):
    """Ask the system on-screen keyboard (squeekboard, sm.puri.OSK0) to
    show or hide. Falls back to toggling wvkbd with SIGRTMIN when that
    is what's running. Best effort."""
    if shutil.which("busctl"):
        _spawn(["busctl", "call", "--user", "sm.puri.OSK0", "/sm/puri/OSK0",
                "sm.puri.OSK0", "SetVisible", "b",
                "true" if visible else "false"],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if shutil.which("pkill"):
        _spawn(["pkill", "-SIGUSR2" if visible else "-SIGUSR1",
                "-x", "wvkbd-mobintl"],
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ---------------------------------------------------------------------------
# Self-updating launcher settings (used by the Flight Deck -> Updates page;
# the actual check/download is /usr/local/bin/aero-deck-update, run by
# aero-deck-loop at every start).
# ---------------------------------------------------------------------------
UPDATE_SYSTEM_CONF = Path("/etc/aero-deck/update.json")
UPDATE_USER_CONF = Path.home() / ".config" / "aero-deck" / "update.json"


def read_update_config():
    conf = {"enabled": True, "url": ""}
    for path in (UPDATE_SYSTEM_CONF, UPDATE_USER_CONF):
        try:
            data = json.loads(path.read_text())
            if isinstance(data, dict):
                conf.update({k: v for k, v in data.items()
                             if k in ("enabled", "url")})
        except Exception:
            pass
    return conf


def write_update_config(**changes):
    conf = {}
    try:
        conf = json.loads(UPDATE_USER_CONF.read_text())
    except Exception:
        conf = {}
    conf.update(changes)
    try:
        UPDATE_USER_CONF.parent.mkdir(parents=True, exist_ok=True)
        UPDATE_USER_CONF.write_text(json.dumps(conf, indent=2))
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Installer helpers (Flight Deck -> Install Aero Deck).
# ---------------------------------------------------------------------------
def _boot_disk():
    """The disk the live system booted from (never offered as a target)."""
    try:
        src = subprocess.check_output(
            ["findmnt", "-no", "SOURCE", "/run/archiso/bootmnt"],
            timeout=5, stderr=subprocess.DEVNULL).decode().strip()
        if src:
            pk = subprocess.check_output(
                ["lsblk", "-no", "PKNAME", src], timeout=5,
                stderr=subprocess.DEVNULL).decode().strip().splitlines()
            return "/dev/" + pk[0] if pk and pk[0] else src
    except Exception:
        pass
    return None


def list_install_disks():
    try:
        out = subprocess.check_output(
            ["lsblk", "-J", "-b", "-d", "-o",
             "PATH,SIZE,MODEL,TYPE,TRAN,RO"], timeout=5,
            stderr=subprocess.DEVNULL)
        devs = json.loads(out.decode()).get("blockdevices", [])
    except Exception:
        return []
    boot = _boot_disk()
    disks = []
    for d in devs:
        if d.get("type") != "disk" or str(d.get("ro")) in ("1", "True",
                                                            "true"):
            continue
        path = d.get("path") or ""
        if not path or path == boot or path.startswith(("/dev/zram",
                                                        "/dev/loop")):
            continue
        size = int(d.get("size") or 0)
        if size < 16 * 1024 ** 3:
            continue
        label = "%s  %.0f GB  %s%s" % (
            path, size / 1e9, (d.get("model") or "").strip(),
            ("  [%s]" % d["tran"]) if d.get("tran") else "")
        disks.append({"path": path, "size": size, "label": label})
    return disks


def _event_is_pointer():
    """True when the event being handled is a click / tap."""
    ev = Gtk.get_current_event()
    if ev is None:
        return False
    return ev.type in (Gdk.EventType.BUTTON_PRESS,
                       Gdk.EventType.BUTTON_RELEASE,
                       Gdk.EventType.TOUCH_BEGIN, Gdk.EventType.TOUCH_END)


def _scroll_focus_into_view(scrolled, widget, smooth=None):
    """Scroll a ScrolledWindow so the focused widget is fully visible."""
    if widget is None or scrolled is None:
        return
    child = scrolled.get_child()
    if isinstance(child, Gtk.Viewport) and child.get_child() is not None:
        child = child.get_child()
    if child is None or not widget.is_ancestor(child):
        return
    try:
        _x, y = widget.translate_coordinates(child, 0, 0)
    except Exception:
        return
    h = widget.get_allocated_height()
    adj = scrolled.get_vadjustment()
    top, page = adj.get_value(), adj.get_page_size()
    target = None
    if y < top + 20:
        target = max(adj.get_lower(), y - 40)
    elif y + h > top + page - 20:
        target = min(adj.get_upper() - page, y + h - page + 40)
    if target is None:
        return
    if smooth is not None:
        smooth(target)
    else:
        adj.set_value(target)


def _monitor_size(default=(1920, 1080)):
    """Size of the monitor the launcher opens on (1280x800 on the
    Steam Deck, 1920x1080 on a TV), so the first layout already fits
    before the compositor's fullscreen configure arrives."""
    try:
        display = Gdk.Display.get_default()
        mon = display.get_primary_monitor() or display.get_monitor(0)
        geo = mon.get_geometry()
        if geo.width > 0 and geo.height > 0:
            return geo.width, geo.height
    except Exception:
        pass
    return default


class AltTVLauncher(Gtk.Window):
    def __init__(self):
        super().__init__(title="Aero Deck")
        self.set_default_size(*_monitor_size())
        self.fullscreen()
        self.connect("destroy", Gtk.main_quit)
        self.connect("key-press-event", self.on_key)
        # Key release: the hold-OK trigger needs it (a short OK tap
        # launches the app; a hold opens the app-options panel).
        self.connect("key-release-event", self.on_key_release)

        self.settings = load_settings()
        # The AI list is mutable: take our own copy so adding or
        # removing an AI never mutates the module defaults, and make
        # sure the helm names an AI that is actually listed.
        ais = [dict(ai) for ai in (self.settings.get("ais") or [])
               if isinstance(ai, dict) and ai.get("name")]
        self.settings["ais"] = ais or [dict(ai) for ai in DEFAULT_AIS]
        if self.settings.get("active_ai") not in [
                ai["name"] for ai in self.settings["ais"]]:
            self.settings["active_ai"] = "Nova"
        apply_css(self.settings.get("accent", "#e50914"),
                  self.kb_effective_color(),
                  self.settings.get("keyboard_opacity", 1.0))
        # Dark Mode (off by default): the Navigator is light/white
        # unless it is on. The window carries the dark-mode class;
        # the stylesheet's .dark-mode rules do the rest.
        if self.settings.get("dark_mode", False):
            self.get_style_context().add_class("dark-mode")

        # Overlay: home content underneath, Flight Deck slides in on top.
        self.overlay = Gtk.Overlay()
        self.add(self.overlay)

        # Backdrop photo: the real cherry-blossom picture
        # (assets/backdrop.jpg) as a full-screen underlay behind all
        # content. It is the overlay's base child; everything else is
        # layered on top of it via add_overlay, so the frosted rows and
        # hero let the blossoms show through faintly between rows.
        self.backdrop_pixbuf = self._load_backdrop_pixbuf()
        self.backdrop_image = Gtk.Image()
        self.backdrop_image.connect("size-allocate", self._on_backdrop_allocate)
        self._backdrop_alloc = (0, 0)
        self.overlay.add(self.backdrop_image)

        # Main column: fixed top bar, scrolled hero+rows, fixed bottom bar.
        self.main = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        self.main.set_margin_start(40)
        self.main.set_margin_end(40)
        self.main.set_margin_top(10)
        self.main.set_margin_bottom(0)
        self.overlay.add_overlay(self.main)

        self.build_top_bar()

        self.scrolled = Gtk.ScrolledWindow()
        self.scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scrolled.set_kinetic_scrolling(True)
        self.scrolled.set_vexpand(True)
        self.main.pack_start(self.scrolled, True, True, 0)

        # Content inside the scroller: hero up a tad (small top margin),
        # even gaps between sections so apps sit evenly between hero and
        # Live TV.
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        # Bottom clearance so the last row scrolls clear of the fixed dock.
        self.content.set_margin_bottom(100)
        self.scrolled.add(self.content)

        self.build_hero()
        self.rows_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        self.content.pack_start(self.rows_box, False, False, 0)
        self.build_rows()
        # Social row: pull the latest videos in the background; the row
        # first shows the cached batch, then rebuilds when fresh videos land.
        self.refresh_social_feed()

        self.build_dock()

        # Frost wash over the home screen while the Navigator is
        # open: the background blurs/frosts behind the unified view.
        # It sits below the keyboard in the overlay stack (added
        # before the keyboard revealer) so the view stays crisp on
        # top of it; clicking it dismisses the Navigator.
        self.kb_frost = Gtk.EventBox()
        self.kb_frost.get_style_context().add_class("nav-frost")
        self.kb_frost.set_halign(Gtk.Align.FILL)
        self.kb_frost.set_valign(Gtk.Align.FILL)
        self.kb_frost.connect("button-press-event",
                              lambda w, e: self.hide_keyboard())
        self.kb_frost.hide()
        self.overlay.add_overlay(self.kb_frost)

        # On-screen keyboard for remote typing: the Navigator open
        # view -- three separate rounded cards (search field,
        # results, keyboard) with a small gap between them, that
        # slide DOWN from the top, flush with the top edge, over the
        # frosted home screen. A centred card of moderate size (~43%
        # of the screen width, like the TV reference). Hidden until
        # a search entry gets focus.
        self.kb = OnScreenKeyboard(self)
        self.kb_revealer = Gtk.Revealer()
        self.kb_revealer.set_transition_type(
            Gtk.RevealerTransitionType.SLIDE_DOWN)
        self.kb_revealer.set_transition_duration(250)
        self.kb_revealer.set_halign(Gtk.Align.CENTER)
        self.kb_revealer.set_valign(Gtk.Align.START)
        self.kb.set_size_request(830, -1)
        self.kb_revealer.add(self.kb)
        self.kb_revealer.set_reveal_child(False)
        self.overlay.add_overlay(self.kb_revealer)
        self.kb_visible = False
        self.kb_target = None

        # Flight Deck (settings panel, hidden until the A triangle opens it).
        self.settings_panel = SettingsPanel(self)
        self.panel_revealer = Gtk.Revealer()
        self.panel_revealer.set_transition_type(
            Gtk.RevealerTransitionType.SLIDE_UP)
        self.panel_revealer.set_transition_duration(250)
        self.panel_revealer.set_halign(Gtk.Align.END)
        # Tall panel, bottom-to-top (most of the height): it slides
        # UP from the bottom and its top edge sits near the top of
        # the screen, like the reference panel. It still floats --
        # rounded corners, a small gap at the bottom edge -- and the
        # content inside scrolls.
        self.panel_revealer.set_valign(Gtk.Align.END)
        self.panel_revealer.set_margin_bottom(16)
        # Nov 16 (Andrew): the open Flight Deck must not cover the A
        # button that opens it -- the panel sits just LEFT of the dock
        # (24px margin + ~60px button + gap), so the A stays visible and
        # pressing it again closes the panel.
        self.panel_revealer.set_margin_end(100)
        self.panel_revealer.add(self.settings_panel)
        self.panel_revealer.set_reveal_child(False)
        self.overlay.add_overlay(self.panel_revealer)
        self.panel_open = False
        self.connect("size-allocate", self._on_win_size)
        # Any input keeps the open Flight Deck awake (auto-hide timer).
        self.add_events(Gdk.EventMask.POINTER_MOTION_MASK)
        for sig in ("key-press-event", "button-press-event",
                    "motion-notify-event", "scroll-event", "touch-event"):
            self.connect(sig, self._panel_activity)
        self.connect("set-focus", self._on_set_focus)
        self._stage1_install()
        self.entry_kb = EntryKeyboard(self)
        self._hook_entry_keyboards(self.settings_panel)
        # The launcher's own keyboards handle its fields; don't also
        # summon the system keyboard (squeekboard) for them.
        try:
            Gtk.Settings.get_default().set_property(
                "gtk-im-module", "gtk-im-context-simple")
        except Exception:
            pass

        # App management (hold OK on an app tile): a right-side
        # OPTIONS panel over a dimmed home screen, plus the app-info /
        # Allow panel. Both are independent overlays -- opening or
        # closing them never moves, shifts or resizes the home screen
        # underneath, and scrolling inside them never scrolls it.
        # The Flight Deck above is a SEPARATE panel (A triangle) --
        # clock, weather, IPTV and every tile stay exactly as they
        # were; this panel does not replace or change it.
        self.options_open = False
        self.options_app = None
        self.options_return_btn = None
        self.info_open = False
        self.info_app = None
        self.info_return_btn = None
        self.move_app = None
        self.move_orig_order = None
        self._hold_timer = None
        self._hold_fired = False
        self._hold_btn = None
        self.build_options_panel()
        self.build_info_panel()

        # Full-screen pages: the EPG guide (Live TV), the dedicated
        # Movies / Shows pages, and the channel player. Each is a
        # full-screen overlay child, built lazily on first open and
        # hidden until then. Games and Social do NOT get pages -- they
        # open their individual apps, so they are deliberately left
        # out of all of this.
        self.epg_open = False
        self.epg_view = None
        self.epg_channels = []
        self.epg_focus = 0
        self.epg_preview_name = None
        self.epg_search_query = ""
        self.epg_time_offset = 0
        self.epg_options_open = False
        self.epg_options_revealer = None
        self.epg_preview_proc = None
        self.player_open = False
        self.player_view = None
        self.player_channel = None
        self.player_overlay_open = False
        self.player_overlay_revealer = None
        self.player_fullscreen = False
        self.player_aspect = "16:9"
        self.player_size = "Large"
        self.player_record_proc = None
        # Playback state: pause, position and the runtime line.
        # The player is the full-screen "on the program" state --
        # live TV, or a movie / show opened from its detail page.
        # The EPG guide itself keeps its own navigation; these
        # controls only live here, in the player.
        self.player_paused = False
        self.player_position = 0.0
        self.player_duration = None
        self.player_is_live = True
        self.player_return_to = "epg"
        self.player_detail_return = None
        self.player_tick_id = None
        self.player_seek_guard = False
        self.player_pause_btn = None
        self.player_seek_scale = None
        self.player_elapsed_label = None
        self.player_duration_label = None
        self.player_live_label = None
        self.title_pages = {}
        self.title_page_open = None
        self.title_options_revealers = {}
        self.title_options_open = None
        self.title_focus = {}
        # Per-page search (Movies / Shows): each page searches only
        # its own titles. The EPG has its own search already.
        self.title_search = {}
        self.title_search_entry = {}
        # Individual title detail pages (opened from a poster).
        self.title_detail_view = None
        self.title_detail_open = None
        self.title_detail_content = None
        self.title_detail_heading = None
        self.title_detail_quality = None
        self.title_detail_status = None
        self.title_detail_play_btn = None
        self.title_detail_scale = None
        self.title_detail_scroll = None
        # Hold OK on a poster: quick tap opens the detail page, a
        # hold past HOLD_OK_MS stars the title instead.
        self._poster_hold_timer = None
        self._poster_hold_fired = False
        self._poster_hold_btn = None

        self.show_all()
        # show_all() re-shows the options-menu dim overlay that
        # build_options_panel() hid; it must stay hidden until the
        # options menu actually opens, or it greys out the whole
        # home screen (and the keyboard) with its 45% black. The
        # Navigator frost wash likewise stays hidden until the
        # Navigator actually opens.
        self.dim_overlay.hide()
        self.kb_frost.hide()
        # Position "Aero Deck" once the layout has settled: the
        # allocate-time runs can measure the label before its CSS
        # lands (a 115px fallback height), leaving it at the wrong
        # top margin. The style-updated hook above fixes it when
        # the CSS lands; this 500ms backstop covers the case where
        # that signal already fired before the hero was placed.
        # (The 2.5s splash covers the delay -- nothing visible
        # moves on screen.)
        GLib.timeout_add(500, self._position_brand_label_once)
        self.start_clock()
        self.apply_background(self.settings.get("background", "blossom"))
        self.apply_theme(self.settings.get("theme", "dark"))

    # -- top bar ------------------------------------------------------------
    def build_top_bar(self):
        # The Navigator (search bar) centred at the top. Top middle
        # and top right stay empty -- no Home button, no search pill,
        # no Settings button, no clock/weather, no avatar.
        # "Aero Deck" (the launcher's name) does NOT live in this bar:
        # it sits in the overlay, top-left, ABOVE the hero card (its
        # bottom just above the hero's top edge, its left edge lined
        # up with the hero's left edge -- see _on_hero_allocate) --
        # same height as the NETFLIX wording in the hero, white with
        # a shadow so it reads on the blossom backdrop.
        self.brand_label = Gtk.Label(label="Aero Deck")
        self.brand_label.get_style_context().add_class("brand-label")
        self.brand_label.set_halign(Gtk.Align.START)
        self.brand_label.set_valign(Gtk.Align.START)
        # Never wraps: one line, so its preferred height is always
        # the single-line height (the label position math depends on
        # it -- a wrapped two-line height would push it off target).
        self.brand_label.set_line_wrap(False)
        # Re-position when the label's style lands: right after
        # construction it still measures with the fallback font
        # (115px), and only once the 32px CSS applies does it
        # measure its true single-line height (45px). Without this
        # the label is placed from the fallback height and stays
        # at the wrong top margin.
        self.brand_label.connect(
            "style-updated", lambda w: self._position_brand_label())
        # ... and when the label itself is re-allocated with its
        # real size (its size request changes as the CSS lands).
        # This is the deterministic trigger: a timed run alone can
        # miss the moment the style lands.
        self.brand_label.connect(
            "size-allocate", lambda w, a: self._position_brand_label())
        self.brand_label.set_margin_start(40)
        # Placeholder until the hero's size-allocate handler lines
        # it up exactly (above the hero's top edge, at its left edge).
        self.brand_label.set_margin_top(70)
        self.overlay.add_overlay(self.brand_label)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        top.set_margin_bottom(6)

        # Slim and narrow on purpose: one unified bar -- the helmet
        # (Co-pilot) mark on the left, the word "Navigator" centred,
        # nothing else. No "Search" text, no divider line: the ENTIRE
        # bar says "Navigator". The bar stays clear of the hero card.
        # Widened from 230px so the Navigator label fits; centred in
        # the space beside the brand label.
        searchbar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        searchbar.get_style_context().add_class("searchbar")
        searchbar.set_size_request(440, -1)
        searchbar.set_halign(Gtk.Align.CENTER)
        self.searchbar = searchbar
        # The helmet (Co-pilot) IS the Ask-AI button in the Navigator
        # bar: the flight helmet logo (assets/aero-deck-logo.png) at
        # the left of the bar, where the A triangle used to be.
        # Pressing it asks the AI at the helm -- the co-pilot that
        # takes over when he needs it. It is a real button (its own
        # frosted pill background, border and spacing), so it reads
        # at a glance as a pressable button, not a logo. It is a
        # separate widget with its own handler: pressing it ONLY asks
        # the AI at the helm. Clicking anywhere else on the bar opens
        # the Navigator keyboard (see _on_nav_bar_click, which skips
        # presses that land on the helmet). The bottom-right dock
        # (which opens the Flight Deck) is unchanged. Missing logo
        # file: fall back to the A-triangle mark so the Ask button
        # still exists.
        helm_btn = Gtk.Button()
        helm_btn.get_style_context().add_class("ask-nova-btn")
        self.helm_image = None
        try:
            helm_path = (ASSETS_DIR
                         / "aero-deck-logo.png")
            if helm_path.exists():
                self.helm_image = Gtk.Image.new_from_pixbuf(
                    GdkPixbuf.Pixbuf.new_from_file_at_size(
                        str(helm_path), 32, 32))
        except Exception:
            self.helm_image = None
        # Andrew, Nov 16: the helmet button is called "Wingman" --
        # the mark plus the word, so it reads as its own button.
        helm_inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                             spacing=6)
        if self.helm_image is not None:
            self.helm_image.set_valign(Gtk.Align.CENTER)
            helm_inner.pack_start(self.helm_image, False, False, 0)
        else:
            helm_inner.pack_start(self.mark_image(
                "a-triangle-dark.png", (0.17, 0.23, 0.33)), False, False, 0)
        wingman_label = Gtk.Label(label="Wingman")
        wingman_label.get_style_context().add_class("wingman-label")
        wingman_label.set_valign(Gtk.Align.CENTER)
        helm_inner.pack_start(wingman_label, False, False, 0)
        helm_btn.add(helm_inner)
        self.ask_btn = helm_btn
        self.refresh_ai_button()
        helm_btn.connect("clicked", self.on_ask_ai_button)
        searchbar.pack_start(helm_btn, False, False, 0)
        # "Navigator" centred on the bar: the label expands to fill
        # the space between the helmet and a same-width spacer on
        # the right, so its centre is the bar's true centre. White
        # with a shadow so it reads on the frosted bar.
        nav_label = Gtk.Label(label="Navigator")
        nav_label.get_style_context().add_class("navigator-label")
        nav_label.set_valign(Gtk.Align.CENTER)
        nav_label.set_hexpand(True)
        searchbar.pack_start(nav_label, True, True, 0)
        # Same-width spacer as the helmet button (48px), so the
        # centred label sits on the bar's true centre.
        nav_spacer = self._mon_start_button()
        searchbar.pack_start(nav_spacer, False, False, 0)
        # The search field itself is no longer IN the bar -- the bar
        # is just helmet + "Navigator". The entry is kept as a backing
        # widget: the keyboard seeds from it and hands the query back
        # to it, and Ask-AI reads it. Clicking anywhere on the bar
        # (except the helmet, which asks the AI) opens the Navigator
        # keyboard.
        self.search_entry = Gtk.Entry()
        self.search_entry.get_style_context().add_class("search-entry")
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("activate", self.on_search_entry)
        self.search_entry.connect("focus-in-event", self.on_search_focus_in)
        self.search_entry.connect("key-press-event", self.on_kb_entry_key)
        bar_click = Gtk.EventBox()
        bar_click.add(searchbar)
        # Opens on a completed click / tap (press AND release on the
        # bar) -- never on hover, pointer motion or focus.
        bar_click.connect("button-press-event", self._on_nav_bar_press)
        bar_click.connect("button-release-event", self._on_nav_bar_click)
        self.nav_bar_eventbox = bar_click
        # Focusable, so the D-pad can highlight it; A / OK opens the
        # Navigator keyboard, Down leaves it again.
        bar_click.set_can_focus(True)
        bar_click.connect("focus-in-event", lambda w, e: (
            self.searchbar.get_style_context().add_class("nav-focused"),
            False)[1])
        bar_click.connect("focus-out-event", lambda w, e: (
            self.searchbar.get_style_context().remove_class("nav-focused"),
            False)[1])
        bar_click.connect("key-press-event", self._on_nav_bar_key)
        self.search_entry._navigator_field = True
        top.pack_start(bar_click, True, True, 0)

        self.main.pack_start(top, False, False, 0)

    def _on_nav_bar_key(self, widget, event):
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space):
            self.show_keyboard(self.search_entry)
            return True
        if event.keyval == Gdk.KEY_Down:
            self.content.child_focus(Gtk.DirectionType.TAB_FORWARD)
            return True
        if event.keyval in (Gdk.KEY_Left, Gdk.KEY_Right):
            self.ask_btn.grab_focus()
            return True
        return False

    def _on_nav_bar_press(self, widget, event):
        self._nav_pressed = (event.button == 1)
        return False

    def _on_nav_bar_click(self, widget, event):
        if not getattr(self, "_nav_pressed", False) or event.button != 1:
            return False
        self._nav_pressed = False
        alloc = widget.get_allocation()
        if not (0 <= event.x < alloc.width and 0 <= event.y < alloc.height):
            return False   # released outside the bar: not a click
        return self._nav_bar_open(widget, event)

    def _nav_bar_open(self, widget, event):
        """Clicking the Navigator bar opens the keyboard -- except on
        the helmet button, which asks the AI at the helm (the button
        handles that press itself). The press bubbles from the button
        up to this EventBox, so presses landing on the helmet are
        skipped here."""
        try:
            pos = self.ask_btn.translate_coordinates(widget, 0, 0)
            alloc = self.ask_btn.get_allocation()
            if (pos is not None
                    and pos[0] <= event.x < pos[0] + alloc.width
                    and pos[1] <= event.y < pos[1] + alloc.height):
                return False
        except Exception:
            pass
        self.show_keyboard(self.search_entry)
        return True

    def on_search_entry(self, entry):
        self.do_search(entry.get_text())

    def do_search(self, query):
        query = (query or "").strip()
        if query:
            open_url("https://duckduckgo.com/?q=" + query)

    def on_ask_ai_button(self, widget):
        """The helmet (Co-pilot) in the Navigator bar: ask the AI at
        the helm, with whatever is typed in the bar. Clicking the bar
        is normal search (opens the keyboard, type and search
        yourself); pressing the helmet asks the helm AI -- two
        distinct actions on the same bar, never mixed up."""
        if self.kb_visible:
            # Hand the keyboard's live query back to the bar first.
            self.hide_keyboard()
        query = ""
        try:
            query = self.search_entry.get_text()
        except Exception:
            pass
        self.ask_ai(query)

    # -- on-screen keyboard (remote typing) ----------------------------------
    def on_search_focus_in(self, entry, event):
        # Nov 16 (Andrew): the Navigator keyboard never opens by itself
        # -- only a click / tap on the bar, or A / OK on the highlighted
        # bar opens it.
        return False

    def on_kb_entry_key(self, entry, event):
        # Entry-level key handler: runs before the entry's own handler
        # (key-press is RUN_LAST), so the keyboard owns arrows / Enter
        # / BackSpace / Escape while it is up.
        if self.kb_visible and self.handle_kb_key(event):
            return True
        return False

    def show_keyboard(self, target_entry):
        """Show the on-screen keyboard, typing into its query field
        (seeded from the entry that summoned it)."""
        if self.kb_visible:
            return
        self.kb_target = target_entry
        self.kb.build_index()
        self.kb.entry.set_text(target_entry.get_text())
        self.kb.refresh_results()
        self.kb.set_highlight("keys", 1, 0)
        # The Navigator must sit on top of any full-screen page (the
        # EPG guide / a title page are overlay children added after
        # the keyboard, so they would cover it). Raise the frost wash
        # and the keyboard revealer to the top of the overlay stack
        # before revealing -- removing + re-adding is what moves a
        # child to the top. A hidden revealer is transparent, so
        # leaving it on top afterwards is harmless.
        for child in (self.kb_frost, self.kb_revealer):
            if child.get_parent() is not None:
                self.overlay.remove(child)
                self.overlay.add_overlay(child)
        self.kb_revealer.set_reveal_child(True)
        # Force the overlay to re-allocate the revealer now that it
        # has a size: without this the overlay can leave it at the
        # x=0 allocation it got while hidden, instead of centred.
        self.kb_revealer.queue_resize()
        self.kb_frost.show()
        # The home screen's own search bar sits directly behind the
        # Navigator's query field (same spot, same size) and would
        # show through the frost as a confusing second search bar
        # (helmet + "Navigator" + "Search" ghosting inside the query
        # field). Fade it out while the Navigator is open -- opacity
        # 0 keeps its allocation, so nothing shifts; it comes back
        # when the Navigator closes.
        self.searchbar.set_opacity(0)
        self.kb_visible = True
        self.kb.entry.grab_focus()

    def hide_keyboard(self):
        if not self.kb_visible:
            return
        # Hand the query back to the search bar that summoned it.
        if self.kb_target is not None:
            try:
                self.kb_target.set_text(self.kb.entry.get_text())
            except Exception:
                pass
        if getattr(self.kb, "dictation", None) is not None:
            self.kb.dictation.stop()
            self.kb._voice_status("")
        self.kb_revealer.set_reveal_child(False)
        self.kb_frost.hide()
        # Bring the home screen's search bar back (see show_keyboard).
        self.searchbar.set_opacity(1)
        self.kb_visible = False
        self.kb_target = None
        self.set_focus(None)

    def handle_kb_key(self, event):
        """Remote/physical keys while the on-screen keyboard is up.
        Returns True when the key was consumed."""
        keyval = event.keyval
        # B (controller) / Esc / remote Back: close the Navigator.
        if keyval in (Gdk.KEY_Escape, Gdk.KEY_Back):
            self.hide_keyboard()
            return True
        # Start / Menu: search now (same as the Go key).
        if keyval == Gdk.KEY_Menu:
            self.kb.submit_query()
            return True
        if keyval in (Gdk.KEY_Up, Gdk.KEY_Down,
                      Gdk.KEY_Left, Gdk.KEY_Right):
            self._kb_physical_typing = False
            self.kb.move_highlight(
                {Gdk.KEY_Up: "up", Gdk.KEY_Down: "down",
                 Gdk.KEY_Left: "left", Gdk.KEY_Right: "right"}[keyval])
            return True
        if keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            # Typed on a real keyboard: Enter searches. Moving the
            # highlight with the D-pad / stick: Enter (A) presses the
            # highlighted key.
            if getattr(self, "_kb_physical_typing", False):
                self._kb_physical_typing = False
                self.kb.submit_query()
            else:
                self.kb.activate_highlight()
            return True
        if keyval == Gdk.KEY_BackSpace:
            self.kb.delete_char()
            return True
        # Bumpers (R1 / L1 = Tab / Shift+Tab) and Home / End move the
        # text cursor -- edit in the middle without deleting the rest.
        if keyval == Gdk.KEY_Tab:
            self.kb.move_cursor("right")
            return True
        if keyval == Gdk.KEY_ISO_Left_Tab:
            self.kb.move_cursor("left")
            return True
        if keyval in (Gdk.KEY_Home, Gdk.KEY_End) and \
                getattr(self, "_kb_physical_typing", False):
            self.kb.move_cursor("home" if keyval == Gdk.KEY_Home else "end")
            return True
        # Physical keyboard: printable characters type straight into
        # the keyboard's query field.
        ch = Gdk.keyval_to_unicode(keyval)
        if ch and ch >= 0x20 and ch != 0x7f:
            self.kb.insert_text(chr(ch))
            self._kb_physical_typing = True
            return True
        return False

    def search_items(self):
        """Everything the Navigator can match: (name, kind, icon, launch,
        keywords). The whole box, not just media -- every app
        (built-in, custom, installed Waydroid / Linux), live channels,
        movies, shows, games, cloud services, cached social videos
        (music apps and music videos included), and every settings
        page (Bluetooth, Wi-Fi, display, sound, network...). Websites
        are covered by the web-search result. Built fresh each time
        the keyboard opens."""
        items = []
        seen_names = set()
        for app in assemble_apps():
            name = app["name"]
            seen_names.add(name.lower())
            items.append((name, "App", self.load_app_icon(
                name, app["target"], app["kind"], size=48,
                icon_name=app.get("icon", "")),
                lambda a=app: self.on_open_app(
                    None, a["kind"], a["target"], a["fallback"],
                    a["name"]),
                "app"))
        for name, _letter, _colour, kind, target, fallback in SOCIAL_APPS:
            if name.lower() in seen_names:
                continue
            seen_names.add(name.lower())
            items.append((name, "App", self.load_app_icon(
                name, target, kind, size=48),
                lambda k=kind, t=target, f=fallback, n=name:
                self.on_open_app(None, k, t, f, n),
                "app social"))
        for name, program, url in LIVE_CHANNELS:
            items.append((name, "Live TV", self.load_channel_logo(
                name, width=48, height=48),
                lambda u=url, n=name: self.on_open_live(None, u, n),
                "live tv channel"))
        for name, meta in MOVIES:
            items.append((name, "Movie", None,
                          lambda n=name, m=meta: self.on_open_title(
                              None, n, m),
                          "movie film"))
        for name, meta in SHOWS:
            items.append((name, "TV Show", None,
                          lambda n=name, m=meta: self.on_open_title(
                              None, n, m),
                          "tv show series"))
        for name, meta in games_row_items():
            items.append((name, "Game", None,
                          lambda n=name, m=meta: self.on_open_game(
                              None, n, m),
                          "game"))
        for name, url in CLOUD_GAMING:
            items.append((name, "Cloud gaming", None,
                          lambda n=name, u=url: self.on_open_cloud(
                              None, n, u),
                          "cloud gaming"))
        for video in load_social_cache():
            title = video.get("title", "")
            url = video.get("url", "")
            thumb = None
            thumb_path = video.get("thumb_path")
            if thumb_path:
                try:
                    thumb = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        thumb_path, 40, 40, True)
                except Exception:
                    thumb = None
            items.append((title, "Video", thumb,
                          lambda u=url: self.on_open_video(None, u),
                          "video"))
        # Settings pages: searching "bluetooth", "wifi", "display",
        # "sound" or "network" surfaces the setting, and picking it
        # opens the Flight Deck straight onto that page.
        for page, display, keywords in SETTINGS_SEARCH:
            items.append((display, "Setting", None,
                          lambda p=page: self.open_panel_page(p),
                          "setting " + keywords))
        return items

    def active_ai_entry(self):
        """The AI at the helm: the entry in settings["ais"] whose
        name matches settings["active_ai"], or Nova (the first) if
        the name is gone."""
        return helm_ai_entry(getattr(self, "settings", None))

    def refresh_ai_button(self):
        """The helmet asks the AI at the helm: its tooltip names
        whoever is at the helm right now."""
        name = self.active_ai_entry().get("name", "Nova")
        try:
            self.ask_btn.set_tooltip_text("Wingman: ask %s" % name)
        except Exception:
            pass

    def ask_ai(self, query):
        """Ask the AI at the helm: open the active AI with the query
        he typed. Nova (Muse) is the default helm -- the Muse
        Android app (com.facebook.aura) via Waydroid when it's
        installed, otherwise muse.ai in the browser. Any other AI
        works the same way: its app when one is listed and
        installed, otherwise its web address in the browser. The
        query travels in the URL (?q=) so the AI sees what he was
        looking for -- best effort for AIs other than Nova, whose
        page may or may not read it."""
        query = (query or "").strip()
        import urllib.parse
        # Any object with a settings dict works here (the model
        # tests call this unbound, with None or a bare namespace):
        # the helm comes from the settings, defaulting to Nova.
        settings = (getattr(self, "settings", None)
                    if self is not None else None)
        ai = helm_ai_entry(settings)
        base = (ai.get("url") or "https://muse.ai").rstrip("/")
        if query:
            if "?" in base:
                url = base + "&q=" + urllib.parse.quote(query)
            elif "/" not in (base.split("://", 1)[1] if "://" in base
                            else base):
                # Bare host (muse.ai): keep the root slash so the
                # query reads muse.ai/?q=... like before.
                url = base + "/?q=" + urllib.parse.quote(query)
            else:
                url = base + "?q=" + urllib.parse.quote(query)
        else:
            url = base + "/"
        app = (ai.get("app") or "").strip()
        mode = (settings or {}).get("wingman_mode", "window") \
            if isinstance(settings, dict) else "window"
        if self is not None and hasattr(self, "open_wingman"):
            name = ai.get("name", "Wingman")
            if mode == "android" and app:
                if app in _waydroid_packages():
                    rc, _o, _e = android_shell(
                        "am", "start", "-a", "android.intent.action.VIEW",
                        "-d", url)
                    if rc == 0:
                        return
                # Starts Android if needed, launches the app, or
                # offers to install it ("Open website instead" opens
                # the built-in chat window, not a browser tab).
                self.android_open(app, url, name,
                                  web_cb=lambda: self.open_wingman(url, name))
                return
            self.open_wingman(url, name)
            return
        if app and app in _waydroid_packages():
            # Open the AI's app on the query link (Android routes a
            # web link to the app when it handles it); if that
            # doesn't take, launch the app directly.
            rc, _out, _err = android_shell(
                "am", "start", "-a", "android.intent.action.VIEW",
                "-d", url)
            if rc == 0:
                return
            proc = _spawn(["waydroid", "app", "launch", app],
                          stdout=subprocess.DEVNULL,
                          stderr=subprocess.DEVNULL)
            if proc is not None:
                return
        open_url(url)

    # -- Wingman: the AI in its own built-in chat window ----------------------
    # Nov 16 (Andrew): Wingman never opens a browser tab. Mode
    # "window" (default): a built-in chat panel inside the launcher
    # (WebKitGTK, its own logins kept in ~/.local/share/aero-deck/
    # wingman). Mode "android": the AI's Android app through Waydroid
    # (Grok, ChatGPT, Gemini ...), offering to install it when missing.
    # Fallbacks: Brave/Chromium --app= window (frameless), then the
    # default browser.
    def _wingman_webkit(self):
        if getattr(self, "_wk_mod", None) is not None:
            return self._wk_mod or None
        try:
            try:
                gi.require_version("WebKit2", "4.1")
            except ValueError:
                gi.require_version("WebKit2", "4.0")
            from gi.repository import WebKit2
            self._wk_mod = WebKit2
        except Exception:
            self._wk_mod = False
        return self._wk_mod or None

    def _wingman_build(self, WebKit2):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        box.get_style_context().add_class("wingman-card")
        box.set_halign(Gtk.Align.CENTER)
        box.set_valign(Gtk.Align.FILL)
        box.set_margin_top(70)
        box.set_margin_bottom(20)
        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        head.get_style_context().add_class("wingman-head")
        self._wm_title = Gtk.Label()
        self._wm_title.set_halign(Gtk.Align.START)
        head.pack_start(self._wm_title, True, True, 0)
        back = Gtk.Button(label="◀")
        back.set_tooltip_text("Back")
        back.connect("clicked", lambda w: self._wm_view.go_back())
        head.pack_start(back, False, False, 0)
        close = Gtk.Button(label="✕  Close")
        close.set_tooltip_text("Close Wingman (B / Esc)")
        close.connect("clicked", lambda w: self.close_wingman())
        head.pack_start(close, False, False, 0)
        box.pack_start(head, False, False, 0)
        data = str(Path.home() / ".local" / "share" / "aero-deck" / "wingman")
        cache = str(Path.home() / ".cache" / "aero-deck" / "wingman")
        try:
            mgr = WebKit2.WebsiteDataManager(base_data_directory=data,
                                             base_cache_directory=cache)
            ctx = WebKit2.WebContext.new_with_website_data_manager(mgr)
            try:
                mgr.get_cookie_manager().set_persistent_storage(
                    data + "/cookies.sqlite",
                    WebKit2.CookiePersistentStorage.SQLITE)
            except Exception:
                pass
            view = WebKit2.WebView.new_with_context(ctx)
        except Exception:
            view = WebKit2.WebView()
        try:
            s = view.get_settings()
            s.set_enable_media_stream(True)   # voice chat
            s.set_javascript_can_access_clipboard(True)
            s.set_user_agent_with_application_details("AeroDeck", "1.1")
        except Exception:
            pass
        # Links that want a new window open inside Wingman too.
        view.connect("create", lambda v, nav: (
            v.load_uri(nav.get_request().get_uri()), None)[1])
        view.set_vexpand(True)
        box.pack_start(view, True, True, 0)
        self._wm_view = view
        self._wm_box = box
        self.overlay.add_overlay(box)

    def wingman_open(self):
        return (getattr(self, "_wm_box", None) is not None
                and self._wm_box.get_visible())

    def open_wingman(self, url, name):
        WebKit2 = self._wingman_webkit()
        if WebKit2 is not None:
            try:
                if getattr(self, "_wm_box", None) is None:
                    self._wingman_build(WebKit2)
                alloc = self.get_allocation()
                self._wm_box.set_size_request(
                    min(1100, max(640, _dz(alloc.width) - 160)), -1)
                self._wm_title.set_markup(
                    "<b>Wingman</b>  ·  %s" % _esc(name))
                if self._wm_box.get_parent() is self.overlay:
                    self.overlay.remove(self._wm_box)
                    self.overlay.add_overlay(self._wm_box)
                self._wm_box.show_all()
                self._wm_view.load_uri(url)
                self._wm_view.grab_focus()
                return
            except Exception:
                pass
        # No WebKitGTK: a frameless app-mode window of a Chromium
        # browser, then the default browser.
        for key in ("brave", "chromium", "chrome", "vivaldi", "edge"):
            binary = browser_binary(key)
            if binary and _spawn([binary] + _CHROMIUM_FLAGS
                                 + ["--app=" + url],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL):
                return
        open_url(url)

    def close_wingman(self):
        if getattr(self, "_wm_box", None) is not None:
            self._wm_box.hide()
            try:
                self.ask_btn.grab_focus()
            except Exception:
                pass

    # -- hero ----------------------------------------------------------------
    def build_hero(self):
        # ONE unified card: the text sits on the left inside the same
        # card, and the kids photo fills the right half of that same
        # card edge-to-edge -- no separate boxes, no gap.
        hero = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        hero.get_style_context().add_class("card")
        hero.set_margin_top(4)
        # The hero card aligns with the rows below it (all ~1640 wide,
        # ~140-1780 at 1920px) -- it does NOT span the full content
        # width. Centred, fixed width.
        hero.set_halign(Gtk.Align.CENTER)
        hero.set_size_request(min(1640, getattr(self, "_content_w", 1640)),
                              -1)
        self.hero_card = hero

        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left.set_margin_start(30)
        left.set_margin_top(30)
        left.set_margin_bottom(30)

        # The reference hero has NO "FEATURED Continue Watching" line
        # and NO "More Info" pill -- just NETFLIX, the huge title, the
        # description, and the one Watch Now pill.
        global HERO_SHORT_DESC, HERO_FULL_DESC
        info = self._hero_info()
        HERO_SHORT_DESC, HERO_FULL_DESC = info["short"], info["full"]
        title = Gtk.Label()
        title.get_style_context().add_class("hero-title")
        title.set_line_wrap(True)
        title.set_max_width_chars(24)
        title.set_markup(
            "<span size='24576' weight='bold' color='#4da3ff'>%s</span>\n"
            "<span size='%d' weight='bold' color='white'>%s</span>" % (
                _esc(info["service"]),
                73728 if len(info["title"]) <= 16 else 49152,
                _esc(info["title"].upper())))
        title.set_halign(Gtk.Align.START)
        left.pack_start(title, False, False, 0)

        desc = Gtk.Label()
        desc.get_style_context().add_class("hero-desc")
        # Bigger lettering, filling the hero's wasted space: the
        # short synopsis by default, at 20pt across the left column.
        desc.set_markup("<span size='20480'>%s</span>" % _esc(HERO_SHORT_DESC))
        desc.set_line_wrap(True)
        desc.set_max_width_chars(72)
        desc.set_halign(Gtk.Align.START)
        # Short synopsis by default; the full description stays
        # hidden until the synopsis is highlighted (focus) or
        # selected (click) -- then it expands to the full text,
        # without spoiling the show up front.
        desc_box = Gtk.EventBox()
        desc_box.set_can_focus(True)
        desc_box.add(desc)
        desc_box.connect("button-press-event",
                         lambda w, e: self._toggle_hero_desc())
        # Synopsis opens only on a click / A press, never on focus.
        desc_box.connect("key-press-event", lambda w, e: (
            self._toggle_hero_desc(), True)[1]
            if e.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter) else False)
        left.pack_start(desc_box, False, False, 10)
        self.hero_desc_label = desc
        self.hero_desc_expanded = False
        self.hero_desc_hint = Gtk.Label()
        self.hero_desc_hint.get_style_context().add_class(
            "hero-desc-hint")
        # Just "Synopsis" in big legible text, with a small black
        # upside-down triangle beside it -- small but visible, and
        # clickable to scroll down / expand the rest of the info.
        self.hero_desc_hint.set_markup(
            "<span size='16384' weight='bold' color='black'>Synopsis "
            "</span><span size='12288' color='black'>▼</span>")
        self.hero_desc_hint.set_halign(Gtk.Align.START)
        hint_box = Gtk.EventBox()
        hint_box.set_can_focus(True)
        hint_box.add(self.hero_desc_hint)
        hint_box.connect("button-press-event",
                         lambda w, e: self._toggle_hero_desc())
        # Synopsis opens only on a click / A press, never on focus.
        hint_box.connect("key-press-event", lambda w, e: (
            self._toggle_hero_desc(), True)[1]
            if e.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter) else False)
        left.pack_start(hint_box, False, False, 0)

        watch_btn = Gtk.Button(label=info["action"])
        watch_btn.set_size_request(160, 44)
        watch_btn.set_halign(Gtk.Align.START)
        watch_btn.connect("clicked", self.on_watch_hero)
        left.pack_start(watch_btn, False, False, 25)

        hero.pack_start(left, True, True, 0)

        # Hero photo: four kids on bikes under the red sky, filling
        # the right ~45% of this same card edge-to-edge, full height,
        # flush with the card's right edge -- no frosted strip between
        # the photo and the card edge. The photo's right corners are
        # pre-rounded to the card, so it reads as one card, not a box
        # inside a box. Falls back to the stand-in label if the image
        # isn't there.
        # NOTE: the CoverImage must NOT have hexpand set -- hexpand on
        # the cover propagates up to the poster box, making the poster
        # an expand child of the hero box, which breaks the left
        # box's expansion and leaves the poster floating with equal
        # frosted gaps on both sides instead of flush right.
        # The poster is 738px: ~45% of the 1640px card, so the left
        # text box has room for the 72pt title in its condensed face.
        poster = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        poster.set_size_request(738, -1)
        hero_pb = None
        if info.get("cover"):
            try:
                hero_pb = GdkPixbuf.Pixbuf.new_from_file(str(info["cover"]))
            except Exception:
                hero_pb = None
        if hero_pb is not None:
            cover = CoverImage(hero_pb, 738, 445)
            cover.set_vexpand(True)
            poster.pack_start(cover, True, True, 0)
        else:
            # No art: no fake poster -- the Aero mark, small and quiet.
            poster.set_size_request(320, -1)
            mark = self.mark_image("aero-a-white.png", "#ffffff", size=140)
            mark.set_opacity(0.55)
            poster.pack_start(mark, True, True, 0)
        poster.set_vexpand(True)
        hero.pack_start(poster, False, False, 0)

        self.content.pack_start(hero, False, False, 0)
        # Kept so the brand label ("Aero Deck") can align itself
        # above the hero card (it sits in the overlay, above the
        # hero's top edge at its left edge, not in the top bar).
        self.hero_card = hero
        hero.connect("size-allocate", self._on_hero_allocate)
        # NOTE: do NOT also connect the window's size-allocate here.
        # A handler on the window runs mid-allocation and any
        # measurement / margin set inside it disturbs the overlay --
        # it leaves the Navigator revealer stuck at 1x1 when it
        # opens. The hero handler above plus the idle re-position
        # after show_all() are what place the label.

    def _on_hero_allocate(self, hero, _alloc):
        """Keep "Aero Deck" ABOVE the hero card: its bottom sits just
        above the hero card's top edge, and its left edge lines up
        with the hero card's left edge (plus a 6px nudge right, so
        the start of the "A" is fully visible, never clipped) -- same
        32px size as the NETFLIX wording in the hero, white. It is
        NOT on NETFLIX's baseline: NETFLIX is inside the hero,
        "Aero Deck" sits above it. Only while the rows are at scroll
        position 0 -- the label is a fixed overlay child and must NOT
        chase the hero when the rows scroll."""
        self._position_brand_label()

    def _position_brand_label_once(self):
        """One-shot backstop for _position_brand_label (see the
        timeout_add in __init__): returns False so it runs once."""
        self._position_brand_label()
        return False

    def _position_brand_label(self):
        try:
            if self.scrolled.get_vadjustment().get_value() != 0:
                return
            pos = self.hero_card.translate_coordinates(self, 0, 0)
            if pos is None:
                return
            # The label's height comes from its ACTUAL allocation,
            # not a preferred-size query: in this VM the Pango font
            # metrics resolve nondeterministically after startup
            # (the same 32px label measures 45px one run, 80px the
            # next), so a preferred height measured early can be
            # wrong. The allocated height is what the label really
            # occupies; whenever the font settles and the allocation
            # changes, the size-allocate hook re-runs this and the
            # label lands correctly.
            label_h = self.brand_label.get_allocation().height
            if label_h <= 1:
                label_h = self.brand_label.get_preferred_height_for_width(
                    400)[0]
            # Nudged ever so slightly right (+6px): the start of the
            # "A" sits straight with the hero card's left edge, with
            # just enough clearance that the "A" is fully visible
            # and never reads as clipped on the edge.
            new_start = max(0, int(pos[0])) + 6
            new_top = max(0, int(pos[1]) - label_h - 8)
            # Only set margins when they change: setting them queues
            # another resize, and doing it unconditionally on every
            # window size-allocate starves the overlay (the Navigator
            # revealer never finishes opening).
            if self.brand_label.get_margin_start() != new_start:
                self.brand_label.set_margin_start(new_start)
            if self.brand_label.get_margin_top() != new_top:
                self.brand_label.set_margin_top(new_top)
        except Exception:
            pass

    def _set_hero_desc(self, expanded):
        """Hero synopsis: collapsed shows the short synopsis;
        expanded shows the short synopsis plus the full description.
        The full text is only revealed when the synopsis is
        highlighted / selected."""
        self.hero_desc_expanded = bool(expanded)
        if getattr(self, "hero_desc_label", None) is None:
            return
        if expanded:
            self.hero_desc_label.set_markup(
                "<span size='20480'>%s %s</span>"
                % (_esc(HERO_SHORT_DESC), _esc(HERO_FULL_DESC)))
            if getattr(self, "hero_desc_hint", None) is not None:
                self.hero_desc_hint.set_markup(
                    "<span size='16384' weight='bold' color='black'>"
                    "Synopsis </span><span size='12288' "
                    "color='black'>▲</span>")
        else:
            self.hero_desc_label.set_markup(
                "<span size='20480'>%s</span>" % _esc(HERO_SHORT_DESC))
            if getattr(self, "hero_desc_hint", None) is not None:
                self.hero_desc_hint.set_markup(
                    "<span size='16384' weight='bold' color='black'>"
                    "Synopsis </span><span size='12288' "
                    "color='black'>▼</span>")

    def _toggle_hero_desc(self):
        self._set_hero_desc(not getattr(
            self, "hero_desc_expanded", False))
        return True

    def mark_image(self, filename, fallback_color, size=None):
        """The Alt TV "A" mark as a plain Gtk.Image, from a pre-rendered
        PNG in assets/ (a-triangle-white.png / a-triangle-dark.png /
        aero-a-white.png). The old ATriangle DrawingArea needs
        pycairo's cairo.Context converter, which is missing on systems
        where pycairo isn't registered with PyGObject -- then the mark
        silently never paints (search bar logo and dock button both
        blank). A PNG needs no cairo at runtime, so the mark always
        shows. Falls back to ATriangle if the PNG is missing. Pass
        size to load the mark scaled to that many pixels (the dock
        mark is 32px; the raw asset is 256px)."""
        path = ASSETS_DIR / filename
        try:
            if path.exists():
                if size:
                    return Gtk.Image.new_from_pixbuf(
                        GdkPixbuf.Pixbuf.new_from_file_at_scale(
                            str(path), size, size, True))
                return Gtk.Image.new_from_pixbuf(
                    GdkPixbuf.Pixbuf.new_from_file(str(path)))
        except Exception:
            pass
        return ATriangle(color=fallback_color, size=22)

    def load_hero_image(self):
        """Kids-on-bikes hero photo (assets/hero-kids.jpg, shipped next
        to this file), at full resolution -- CoverImage scales it to
        cover the poster card. Returns None if it isn't there, so the
        hero falls back to the stand-in label."""
        try:
            base = ASSETS_DIR
            # The rounded PNG (right corners rounded to the card) is
            # preferred; the plain JPG is the fallback.
            for name in ("hero-kids.png", "hero-kids.jpg"):
                path = base / name
                if path.exists():
                    return GdkPixbuf.Pixbuf.new_from_file(str(path))
            return None
        except Exception:
            return None

    def _asset_pixbuf(self, subdir, name, width, height):
        """An image shipped in assets/<subdir>/<slug>.(png|jpg), scaled
        to fit. Returns a pixbuf or None -- the caller falls back to
        the text tile, never a fake icon."""
        import re
        slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
        base = ASSETS_DIR / subdir
        for ext in (".png", ".jpg", ".jpeg"):
            path = base / (slug + ext)
            if path.exists():
                try:
                    return GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        str(path), width, height, True)
                except Exception:
                    return None
        return None

    def load_app_icon(self, name, target, kind, size=96, width=None,
                      height=None, icon_name=None):
        """A real icon for an app tile, best available source first:
        1) assets/icons/<slug>.png (drop a brand icon in), 2) the
        system icon theme by app/package name (or by icon_name, the
        Icon field from a Linux .desktop file). Returns a pixbuf or
        None -- the caller falls back to the letter tile. Pass size
        for a square icon, or width/height for a wide tile (the Your
        Apps tiles are 164x116 in the reference)."""
        if width is None:
            width = size
        if height is None:
            height = size
        pixbuf = self._asset_pixbuf("icons", name, width, height)
        if pixbuf is not None:
            return pixbuf
        candidates = []
        if icon_name:
            candidates.append(icon_name)
        candidates += [name.lower().replace(" ", "-"), name.lower()]
        if kind == "android" and target:
            candidates.append(target.split(".")[-1])
            candidates.append(target)
        theme = Gtk.IconTheme.get_default()
        for cand in candidates:
            try:
                info = theme.lookup_icon(cand, max(width, height), 0)
                if info is not None:
                    return info.load_icon()
            except Exception:
                continue
        return None

    def load_poster_image(self, name, width=200, height=280):
        """Poster art for a movie/show/game (assets/posters/<slug>).
        None if there isn't one -- the title text tile is the fallback."""
        return self._asset_pixbuf("posters", name, width, height)

    def _rounded_pixbuf(self, pixbuf, radius):
        """Round the corners of a pixbuf (cairo rounded-rect clip).
        Returns the original pixbuf when pycairo is unavailable --
        the row never fails over rounded corners."""
        if pixbuf is None or cairo is None:
            return pixbuf
        import math
        w, h = pixbuf.get_width(), pixbuf.get_height()
        r = max(0, min(radius, w // 2, h // 2))
        surface = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
        ctx = cairo.Context(surface)
        ctx.new_sub_path()
        ctx.arc(w - r, r, r, -math.pi / 2, 0)
        ctx.arc(w - r, h - r, r, 0, math.pi / 2)
        ctx.arc(r, h - r, r, math.pi / 2, math.pi)
        ctx.arc(r, r, r, math.pi, 3 * math.pi / 2)
        ctx.close_path()
        ctx.clip()
        Gdk.cairo_set_source_pixbuf(ctx, pixbuf, 0, 0)
        ctx.paint()
        return Gdk.pixbuf_get_from_surface(surface, 0, 0, w, h)

    def load_channel_logo(self, name, width=200, height=60):
        """Channel logo art (assets/logos/<slug>). None if there isn't
        one -- the channel name text is the fallback."""
        return self._asset_pixbuf("logos", name, width, height)

    def open_panel_page(self, page):
        """Open the Flight Deck straight onto one of its instrument panels."""
        self.open_settings_panel()
        self.settings_panel.show_page(page)

    # -- bottom-right fixed dock -------------------------------------------
    def build_dock(self):
        """Fixed bottom-right dock: just the A button (opens the Flight
        Deck). It lives on the overlay, so it stays put no matter what
        the rows/menus scroll. Wi-Fi, Bluetooth and the gear live inside
        the Flight Deck -- nothing else sits on the home screen."""
        dock = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        dock.get_style_context().add_class("dock")
        dock.set_halign(Gtk.Align.END)
        dock.set_valign(Gtk.Align.END)
        # EVEN margins: the same distance from the right edge as from
        # the bottom edge, so the button sits proportionate and equal
        # on the corner -- fully on screen, never clipped.
        dock.set_margin_end(24)
        dock.set_margin_bottom(24)

        a_btn = Gtk.Button()
        a_btn.get_style_context().add_class("a-btn")
        # The Aero "A" symbol (white sharp triangle/arrow "A" with
        # the orbit swoosh -- assets/aero-a-white.png), NOT a plain
        # triangle. White on a dark circle: the white mark was
        # invisible on the old frosted-white button, so the button
        # is dark now and the white Aero "A" reads on it.
        a_btn.add(self.mark_image("aero-a-white.png", (1.0, 1.0, 1.0),
                                  size=32))
        a_btn.set_tooltip_text("Flight Deck")
        a_btn.connect("clicked", self.toggle_settings_panel)
        dock.pack_start(a_btn, False, False, 0)

        self.overlay.add_overlay(dock)
        self.dock = dock
        self.dock = dock


    # -- rows -----------------------------------------------------------------
    # Row visible-count rule (Drew): the Apps row shows exactly 8
    # tiles at once; every other row shows exactly 5. These are
    # VISIBLE counts, not totals -- each row scrolls horizontally to
    # reveal more items beyond the visible ones.
    APPS_VISIBLE_COUNT = 8
    ROW_VISIBLE_COUNT = 5

    def scrollable_row(self, row, visible_width):
        """Wrap a row's tile box in a horizontal scroller whose
        viewport is exactly `visible_width` wide, so only that many
        tiles show at once. Extra tiles slide in from the right as
        you move right (and back as you move left) -- the row never
        shrinks or wraps. The scrollbar is overlaid (no layout space,
        no bar sitting on the screen) and the scroll is animated, so
        moving through a long row glides instead of jumping.
        Vertical spacing is untouched: the scroller takes no extra
        height, so the row-to-row gaps stay exactly as they are."""
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        # Stage 1: kinetic = touch drag-to-scroll with momentum (GTK's
        # touch-only pan gesture). It was off, so swipes did nothing.
        scroll.set_kinetic_scrolling(True)
        scroll.set_capture_button_press(False)
        scroll.set_overlay_scrolling(True)
        scroll.set_shadow_type(Gtk.ShadowType.NONE)
        # Never wider than the screen (Steam Deck 1280px): the row
        # shrinks to the content width and scrolls instead.
        scroll._full_width = visible_width
        fit = min(visible_width, getattr(self, "_content_w", visible_width))
        scroll.set_min_content_width(fit)
        scroll.set_max_content_width(visible_width)
        if not hasattr(self, "_row_scrollers"):
            self._row_scrollers = []
        self._row_scrollers.append(scroll)
        scroll.add(row)
        self._hook_smooth_hscroll(scroll)
        return scroll

    def _hook_smooth_hscroll(self, scrolled):
        """Smooth animated horizontal scrolling for one row's scrolled
        window. GTK jumps the adjustment instantly when focus moves
        to an off-screen tile; instead we reset to the last drawn
        value (before the jump is painted) and ease to the target.
        One step takes 180ms on a 16ms tick (~11 frames, ease-out),
        and a new keypress mid-glide re-targets from the current
        position instead of queuing up, so holding Right through 20
        items stays fluid and never drags. Jumps under 20px (a drag
        or fine nudge) pass through un-animated."""
        adj = scrolled.get_hadjustment()
        state = {"last": adj.get_value(), "animating": False,
                 "resetting": False, "timer": None, "t": 0.0}

        def on_value_changed(a):
            if state["resetting"]:
                return
            target = a.get_value()
            start = state["last"]
            now = time.monotonic()
            burst = now - state["t"] < 0.06
            state["t"] = now
            # Small steps and continuous streams (finger drag, fling
            # momentum, trackpad/wheel) pass straight through.
            if abs(target - start) < 20.0 or (burst and
                                              not state["animating"]):
                state["last"] = target
                return
            if state["animating"] and state["timer"] is not None:
                GLib.source_remove(state["timer"])
                state["timer"] = None
            state["animating"] = True
            # Reset to the last drawn value before the jump is
            # painted, then ease to the target.
            state["resetting"] = True
            a.set_value(start)
            state["resetting"] = False
            duration_ms = 180
            steps = max(1, duration_ms // 16)
            step = [0]

            def tick():
                step[0] += 1
                frac = min(1.0, step[0] / steps)
                eased = 1 - (1 - frac) ** 2
                state["resetting"] = True
                a.set_value(start + (target - start) * eased)
                state["resetting"] = False
                state["last"] = a.get_value()
                if step[0] >= steps:
                    state["animating"] = False
                    state["timer"] = None
                    return False
                return True

            state["timer"] = GLib.timeout_add(16, tick)

        adj.connect("value-changed", on_value_changed)

    def build_rows(self):
        """Build the content rows in Drew's chosen order. Every row
        section is centred in the window (equal space left and right)
        -- the title sits above its tiles, aligned with the tiles'
        left edge, and the whole block is centred as one unit. Keep
        his place: remember which app tile had focus (if any) and put
        focus back on it after the rebuild, so a background refresh
        (social feeds landing) doesn't drop him."""
        focused_key = None
        focused = self._focused_app_tile()
        if focused is not None:
            focused_key = getattr(focused, "_app_key", None)
        for child in self.rows_box.get_children():
            self.rows_box.remove(child)
        for row_key in load_row_order():
            builder = getattr(self, "build_row_" + row_key, None)
            if builder is not None:
                section = builder()
                section.set_halign(Gtk.Align.CENTER)
                self.rows_box.pack_start(section, False, False, 0)
        self.rows_box.show_all()
        if focused_key is not None:
            self._focus_app_tile(focused_key)

    def row_title(self, text):
        label = Gtk.Label()
        label.set_markup(
            "<span size='large' weight='bold'>%s</span>" % _esc(text))
        label.set_halign(Gtk.Align.START)
        return label

    def build_row_apps(self):
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        section.pack_start(self.row_title("Your Apps"), False, False, 0)
        # Spacing 28: each cell is 180 wide (164 tile + 8px card
        # padding each side), so 8 cells + 7 gaps = 1636px -- aligned
        # with the hero card (1640) and the Live TV row (1634).
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=28)
        # Every app, in Drew's order: built-ins, custom apps, and
        # every installed Waydroid / Linux app (assemble_apps). New
        # installs land at the front; the row scrolls (8 visible).
        self.app_tile_buttons = []
        all_apps = assemble_apps()
        for app in all_apps:
            name = app["name"]
            letter = app["letter"]
            colour = app["colour"]
            kind = app["kind"]
            target = app["target"]
            fallback = app["fallback"]
            # Wide tile (164x116, like the reference), name written
            # underneath. A real icon fills the whole tile edge-to-edge
            # (the icon PNG is pre-rounded to the tile's corners); the
            # letter is only a last-resort fallback, never a stand-in
            # for real art. The tile + name sit on one frosted card
            # (app-cell), like the reference -- the name is inside the
            # card, not bare on the blossom.
            tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            tile_box.get_style_context().add_class("app-cell")
            btn = Gtk.Button()
            btn.get_style_context().add_class("app-tile")
            # The app this tile is, for the hold-OK toggle menu and
            # for move mode (focus is restored to this exact tile).
            btn._app = app
            btn._app_key = app["key"]
            btn._cell = tile_box
            icon = self.load_app_icon(name, target, kind,
                                      width=164, height=116,
                                      icon_name=app.get("icon", ""))
            if icon is not None:
                btn.get_style_context().add_class("app-tile-icon")
                btn.set_size_request(164, 116)
                btn.add(CoverImage(icon, 164, 116))
            else:
                letter_label = Gtk.Label()
                letter_label.get_style_context().add_class("tile-letter")
                letter_label.set_markup(
                    "<span color='%s'>%s</span>" % (_esc(colour), _esc(letter)))
                btn.add(letter_label)
            btn.connect("clicked", self.on_open_app, kind, target,
                        fallback, name)
            self.app_tile_buttons.append(btn)
            tile_box.pack_start(btn, False, False, 0)
            name_label = Gtk.Label(label=name)
            name_label.get_style_context().add_class("app-name")
            tile_box.pack_start(name_label, False, False, 0)
            row.pack_start(tile_box, False, False, 0)
        # Visible count: 8 app cells at once (180px cell + 28px gap);
        # extra apps scroll in from the right.
        visible = (self.APPS_VISIBLE_COUNT * 180
                   + (self.APPS_VISIBLE_COUNT - 1) * 28)
        section.pack_start(self.scrollable_row(row, visible),
                           False, False, 0)
        return section

    def build_row_live(self):
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        section.pack_start(self.row_title("Live TV"), False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=31)
        for name, program, url in LIVE_CHANNELS:
            btn = Gtk.Button()
            btn.set_size_request(302, 185)
            btn.get_style_context().add_class("live-tile")
            # Full-bleed photo: the channel art fills the whole tile.
            # The shipped art is a full-tile crop from the reference,
            # so the LIVE badge + channel + program are already in the
            # image -- no GTK overlay is drawn on top (it would double
            # the text). Falls back to the frosted text tile when no
            # art is shipped.
            logo = self.load_channel_logo(name, width=302, height=185)
            if logo is not None:
                btn.add(CoverImage(logo, 302, 185))
            else:
                box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
                live = Gtk.Label()
                live.get_style_context().add_class("live-badge")
                live.set_markup("<span color='white'>● LIVE</span>")
                live.set_halign(Gtk.Align.START)
                box.pack_start(live, False, False, 0)
                chan = Gtk.Label()
                chan.set_markup("<span weight='bold' size='large'>%s</span>" % _esc(name))
                box.pack_start(chan, False, False, 0)
                prog = Gtk.Label(label=program)
                prog.set_line_wrap(True)
                box.pack_start(prog, False, False, 0)
                btn.add(box)
            btn.connect("clicked", self.on_open_live, url, name)
            row.pack_start(btn, False, False, 0)
        # Visible count: 5 Live TV tiles at once (302px tile + 31px
        # gap); extra channels scroll in from the right.
        visible = (self.ROW_VISIBLE_COUNT * 302
                   + (self.ROW_VISIBLE_COUNT - 1) * 31)
        section.pack_start(self.scrollable_row(row, visible),
                           False, False, 0)
        return section

    def build_row_news(self):
        """News row: same look as Live TV -- 302x185 landscape panels
        with the LIVE badge + channel + program baked into the tile.
        INTERNET sources only: the networks' official free live
        streams (YouTube live). Never the IPTV playlists, never Cozy
        Streamz. A tile opens that network's live news video in the
        browser. Sources are baked in by default and editable in the
        app-options menu's News sources list (add / change / remove,
        persisted)."""
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        section.pack_start(self.row_title("News"), False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=31)
        for name, program, url in load_news_sources():
            btn = Gtk.Button()
            btn.set_size_request(302, 185)
            btn.get_style_context().add_class("live-tile")
            # Real tile art if one is shipped (assets/logos/news-<slug>);
            # the frosted text tile is the fallback, never a fake tile.
            logo = self._asset_pixbuf("logos", "news-" + name, 302, 185)
            if logo is not None:
                btn.add(CoverImage(logo, 302, 185))
            else:
                box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
                live = Gtk.Label()
                live.get_style_context().add_class("live-badge")
                live.set_markup("<span color='white'>● LIVE</span>")
                live.set_halign(Gtk.Align.START)
                box.pack_start(live, False, False, 0)
                chan = Gtk.Label()
                chan.set_markup("<span weight='bold' size='large'>%s</span>" % _esc(name))
                box.pack_start(chan, False, False, 0)
                prog = Gtk.Label(label=program)
                prog.set_line_wrap(True)
                box.pack_start(prog, False, False, 0)
                btn.add(box)
            btn.connect("clicked", self.on_open_news, url, name)
            row.pack_start(btn, False, False, 0)
        # Visible count: 5 News tiles at once (302px tile + 31px
        # gap, same as Live TV); more sources scroll in from the right.
        visible = (self.ROW_VISIBLE_COUNT * 302
                   + (self.ROW_VISIBLE_COUNT - 1) * 31)
        section.pack_start(self.scrollable_row(row, visible),
                           False, False, 0)
        return section

    def on_open_news(self, widget, url, name):
        """News tile: open that network's live stream in the browser.
        Internet source only -- never IPTV, never a playlist."""
        if url:
            open_url(url)

    def build_row_social(self):
        """Social Media row: real content, not app icons. The latest
        videos from the YouTube / Rumble channels Drew watches --
        thumbnail + title, tap to watch. The feed refreshes in the
        background; what you see first is the last cached batch, so
        the row is never blank while it loads. Add channels in
        Settings -> Apps -> Social feeds."""
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        section.pack_start(self.row_title("Social Media"), False, False, 0)
        # Social tiles are the SAME visual size as the Live TV panels
        # (302x185 landscape, 31px gaps) -- same width as every other
        # row, 5 at a time.
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=31)
        videos = load_social_cache()
        # Andrew, Nov 16: the row starts with Rumble, YouTube and
        # Facebook (logo tiles, open in the picked browser), then the
        # latest videos from the followed channels.
        for (sname, sletter, scolour, skind, starget,
             sfallback) in SOCIAL_APPS:
            tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                               spacing=6)
            btn = Gtk.Button()
            btn.get_style_context().add_class("app-tile")
            btn.set_size_request(302, 185)
            icon = self.load_app_icon(sname, starget, skind,
                                      width=150, height=150)
            if icon is not None:
                btn.add(Gtk.Image.new_from_pixbuf(icon))
            else:
                letter_label = Gtk.Label()
                letter_label.get_style_context().add_class("tile-letter")
                letter_label.set_markup("<span color='%s'>%s</span>" % (
                    _esc(scolour), _esc(sletter)))
                btn.add(letter_label)
            btn.connect("clicked", self.on_open_app, skind, starget,
                        sfallback, sname)
            tile_box.pack_start(btn, False, False, 0)
            name_label = Gtk.Label(label=sname)
            name_label.get_style_context().add_class("app-name")
            tile_box.pack_start(name_label, False, False, 0)
            row.pack_start(tile_box, False, False, 0)
        if not videos:
            hint = Gtk.Label(
                label="Add the channels you watch in Settings → Apps → "
                      "Social feeds and the latest videos will show here.")
            hint.set_line_wrap(True)
            hint.set_halign(Gtk.Align.START)
            row.pack_start(hint, False, False, 0)
        for video in videos:
            # Video tile: thumbnail art if cached, title text if the
            # thumbnail never landed. No brand icons, no letter tiles.
            # Full-bleed thumbnail (CoverImage, like Live TV).
            tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            btn = Gtk.Button()
            btn.get_style_context().add_class("app-tile")
            btn.set_size_request(302, 185)
            thumb_img = None
            thumb = video.get("thumb_path")
            if thumb:
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file(thumb)
                    thumb_img = CoverImage(pixbuf, 302, 185)
                except Exception:
                    thumb_img = None
            if thumb_img is not None:
                btn.add(thumb_img)
            else:
                title_label = Gtk.Label(label=video.get("title", ""))
                title_label.set_line_wrap(True)
                title_label.set_max_width_chars(20)
                title_label.set_justify(Gtk.Justification.CENTER)
                btn.add(title_label)
            btn.connect("clicked", self.on_open_video,
                        video.get("url", ""))
            tile_box.pack_start(btn, False, False, 0)
            name_label = Gtk.Label(label=video.get("title", ""))
            name_label.get_style_context().add_class("app-name")
            name_label.set_line_wrap(True)
            name_label.set_max_width_chars(30)
            tile_box.pack_start(name_label, False, False, 0)
            row.pack_start(tile_box, False, False, 0)
        # Custom apps Drew marked "Social Media" still land here, after
        # the videos, with a real icon when one is available. Same
        # 302x185 tile as the videos and the Live TV panels.
        for custom in load_custom_apps():
            if custom.get("row", "apps") != "social":
                continue
            name = custom.get("name", "")
            tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            btn = Gtk.Button()
            btn.get_style_context().add_class("app-tile")
            btn.set_size_request(302, 185)
            icon = self.load_app_icon(
                name, custom.get("target", ""), custom.get("kind", "web"),
                width=302, height=185)
            if icon is not None:
                btn.add(Gtk.Image.new_from_pixbuf(icon))
            else:
                letter_label = Gtk.Label()
                letter_label.get_style_context().add_class("tile-letter")
                letter_label.set_markup(
                    "<span color='%s'>%s</span>" % (
                        _esc(custom.get("colour", "#5a5a6a")),
                        _esc(custom.get("letter", "?"))))
                btn.add(letter_label)
            btn.connect("clicked", self.on_open_app,
                        custom.get("kind", "web"), custom.get("target", ""),
                        custom.get("fallback", ""), name)
            tile_box.pack_start(btn, False, False, 0)
            name_label = Gtk.Label(label=name)
            name_label.get_style_context().add_class("app-name")
            tile_box.pack_start(name_label, False, False, 0)
            row.pack_start(tile_box, False, False, 0)
        # Visible count: 5 video tiles at once (302px tile + 31px
        # gap, same as Live TV); more videos scroll in from the right.
        visible = (self.ROW_VISIBLE_COUNT * 302
                   + (self.ROW_VISIBLE_COUNT - 1) * 31)
        section.pack_start(self.scrollable_row(row, visible),
                           False, False, 0)
        return section

    def on_open_video(self, widget, url):
        """Watch a social video: open it in the browser."""
        if url:
            open_url(url)

    def refresh_social_feed(self):
        """Fetch the configured YouTube / Rumble feeds in the background
        and rebuild the rows when fresh videos land. Cache-first: the
        Social row shows the last good batch immediately."""
        def work():
            try:
                videos = fetch_social_feed(load_social_feeds())
                for video in videos:
                    path = download_social_thumb(video.get("thumb") or "")
                    if path:
                        video["thumb_path"] = path
                save_social_cache(videos)
            except Exception:
                pass
            GLib.idle_add(self.build_rows)
        threading.Thread(target=work, daemon=True).start()

    def build_row_movies(self):
        return self.build_poster_row(
            "Movies", MOVIES, self.on_open_movies_page,
            on_title_click=self.on_open_movies_page)

    def build_row_shows(self):
        return self.build_poster_row(
            "TV Shows", SHOWS, self.on_open_shows_page,
            on_title_click=self.on_open_shows_page)

    def build_row_games(self):
        return self.build_poster_row("Games", GAMES, self.on_open_game)

    def build_row_cloud(self):
        """Cloud Gaming row: GeForce Now, Boosteroid, Xbox Cloud Gaming.
        One tap opens the service in the browser -- nothing to install."""
        return self.build_poster_row(
            "Cloud Gaming", CLOUD_GAMING, self.on_open_cloud)

    def build_poster_row(self, title, items, on_click,
                         on_title_click=None):
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        # The row title is clickable when a title-click handler is
        # given (Movies / Shows open their dedicated page from the
        # title as well as from a tile). Games / Cloud keep the plain
        # label -- they launch their own apps, no page.
        title_label = self.row_title(title)
        if on_title_click is not None:
            title_box = Gtk.EventBox()
            title_box.add(title_label)
            title_box.connect("button-press-event",
                              lambda w, e: on_title_click(w))
            section.pack_start(title_box, False, False, 0)
        else:
            section.pack_start(title_label, False, False, 0)
        # Poster rows span the SAME full width as the Your Apps row
        # (1636) and the Live TV row (1634): 5 posters at 280px wide
        # (5:7, 280x392 -- the shipped 200x280 art scales up cleanly)
        # + 4 gaps of 60px = 1640px. Same left/right edges as every
        # other row, so nothing looks indented or uneven. Posters stay
        # big for the visual, just a touch smaller than the 300px used
        # to first fill the width, with more rounded corners (28px).
        # 5 posters at a time; more titles scroll in from the right.
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=60)
        for name, meta in items:
            tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            btn = Gtk.Button()
            btn.set_size_request(280, 392)
            # poster-tile: no button padding/border, so the tile stays
            # exactly 280x392 and all 5 fit the 1640px viewport.
            btn.get_style_context().add_class("poster-tile")
            # Real poster art if one is shipped (assets/posters),
            # corners rounded to match the tile; the title text is
            # only the fallback, never a fake poster.
            poster = self.load_poster_image(name, 280, 392)
            poster = self._rounded_pixbuf(poster, 28)
            if poster is not None:
                btn.add(Gtk.Image.new_from_pixbuf(poster))
            else:
                box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
                poster_label = Gtk.Label()
                poster_label.set_markup(
                    "<span weight='bold' size='large'>%s</span>" % _esc(name))
                poster_label.set_line_wrap(True)
                poster_label.set_max_width_chars(16)
                poster_label.set_justify(Gtk.Justification.CENTER)
                box.pack_start(poster_label, True, True, 0)
                btn.add(box)
            btn.connect("clicked", on_click, name, meta)
            tile_box.pack_start(btn, False, False, 0)
            name_label = Gtk.Label(label=name)
            name_label.get_style_context().add_class("app-name")
            name_label.set_line_wrap(True)
            name_label.set_max_width_chars(28)
            tile_box.pack_start(name_label, False, False, 0)
            row.pack_start(tile_box, False, False, 0)
        # Visible count: 5 poster tiles at once (280px tile + 60px
        # gap); more titles scroll in from the right.
        visible = (self.ROW_VISIBLE_COUNT * 280
                   + (self.ROW_VISIBLE_COUNT - 1) * 60)
        section.pack_start(self.scrollable_row(row, visible),
                           False, False, 0)
        return section

    # -- smooth scrolling ------------------------------------------------------
    def smooth_scroll_to(self, target, duration_ms=250):
        """Animate the vertical scroll to a target value (smooth scrolling)."""
        adj = self.scrolled.get_vadjustment()
        start = adj.get_value()
        steps = max(1, duration_ms // 16)
        step = [0]

        def tick():
            step[0] += 1
            frac = min(1.0, step[0] / steps)
            # Ease out: fast start, gentle stop.
            eased = 1 - (1 - frac) ** 2
            adj.set_value(start + (target - start) * eased)
            return step[0] < steps

        GLib.timeout_add(16, tick)

    def go_home(self):
        """Back / Home always lands on the home screen, top of the page."""
        self.smooth_scroll_to(0)

    def on_key(self, widget, event):
        # On-screen keyboard up: it owns the keys (arrows move the
        # highlight, Enter activates a key/result, Escape dismisses).
        if self.kb_visible and self.handle_kb_key(event):
            return True
        if getattr(self, "entry_kb", None) is not None and \
                self.entry_kb.is_open():
            # The drop-down keyboard owns the keys: arrows move between
            # keys, A presses, B (Esc) closes it.
            return False
        if self.wingman_open() and event.keyval in (Gdk.KEY_Escape,
                                                    Gdk.KEY_Back):
            self.close_wingman()
            return True
        if self.wingman_open():
            return False   # the chat page gets every other key
        if self.android_card_open() and event.keyval in (
                Gdk.KEY_Escape, Gdk.KEY_BackSpace, Gdk.KEY_Back):
            self.android_close()
            return True
        if self.android_card_open() and event.keyval in (Gdk.KEY_Up,
                                                         Gdk.KEY_Down):
            self._adroid_box.child_focus(
                Gtk.DirectionType.DOWN if event.keyval == Gdk.KEY_Down
                else Gtk.DirectionType.UP)
            return True
        # Channel player open -- full-screen, ON the program: Back /
        # Esc returns to the guide (live) or the detail page (a
        # title). OK = play / pause. D-pad Down opens the translucent
        # bottom overlay, Down again moves onto the runtime line.
        # Left / Right = fast-forward / rewind. While focus sits on
        # one of the overlay's buttons or the seek bar, the keys
        # belong to that control (Left/Right move between buttons or
        # along the bar, Return activates), so Down/Up do not yank
        # the overlay away. The EPG guide itself is untouched by
        # these controls -- it keeps its own navigation.
        if self.player_open:
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                self.close_player()
                return True
            if event.keyval == Gdk.KEY_Down:
                if self._focus_on_player_seek():
                    return True
                if self._focus_in_player_bar():
                    self.player_seek_scale.grab_focus()
                    return True
                if not self.player_overlay_open:
                    self.player_toggle_overlay()
                else:
                    self.player_full_btn.grab_focus()
                return True
            if event.keyval == Gdk.KEY_Up:
                if self._focus_on_player_seek():
                    self.player_full_btn.grab_focus()
                    return True
                if self._focus_in_player_bar():
                    self.player_toggle_overlay()
                    return True
                return False
            if event.keyval in (Gdk.KEY_Left, Gdk.KEY_Right):
                # Fast-forward / rewind 10s wherever the focus is
                # in the bar. (When the runtime line itself has
                # focus, its own key handler below does the same
                # seek first -- the scale's bindings would otherwise
                # eat the arrows as 1s nudges before this runs.)
                self.player_seek(
                    10 if event.keyval == Gdk.KEY_Right else -10)
                return True
            if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter,
                                Gdk.KEY_space):
                # OK = play/pause -- unless the focus is on one of
                # the bar's own buttons, where OK must activate
                # that button (FULL SCREEN, Pause, ...). Focus on
                # the runtime line is not a button, so OK pauses.
                focused = self.get_focus()
                if (isinstance(focused, Gtk.Button)
                        and self._focus_in_player_bar()):
                    return False
                self.player_toggle_pause()
                return True
            return False
        # EPG guide open: it owns the keys. Up/Down move channels,
        # Left/Right shift the time window, OK plays the channel,
        # F stars it, Back/Esc closes to the home screen. The options
        # panel owns its keys while open; the search entry owns its
        # keys while focused (Return there jumps to the first match,
        # Escape just leaves the entry).
        if self.epg_open:
            if self.epg_options_open:
                if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                    self.epg_close_options()
                    return True
                return False
            search_focused = (
                self.epg_search_entry is not None
                and self.epg_search_entry.has_focus())
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                if search_focused:
                    self.set_focus(None)
                    return True
                self.close_epg()
                return True
            if search_focused and event.keyval in (
                    Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space):
                return False
            if event.keyval == Gdk.KEY_Down:
                self.epg_move_focus(1)
                return True
            if event.keyval == Gdk.KEY_Up:
                self.epg_move_focus(-1)
                return True
            if event.keyval == Gdk.KEY_Right:
                self.epg_shift_time(30)
                return True
            if event.keyval == Gdk.KEY_Left:
                self.epg_shift_time(-30)
                return True
            if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter,
                                Gdk.KEY_space):
                self.epg_play_focused()
                return True
            if event.keyval in (Gdk.KEY_f, Gdk.KEY_F, Gdk.KEY_F13):
                self.epg_toggle_favorite()
                return True
            return False
        # Title detail page open (on top of its Movies / Shows page):
        # Back/Esc closes back to the page; Up/Down scroll the
        # detail; F stars the title. Its own buttons own Return.
        if self.title_detail_open is not None:
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                self.close_title_detail()
                return True
            if event.keyval == Gdk.KEY_Down:
                self.title_detail_scroll_page(400)
                return True
            if event.keyval == Gdk.KEY_Up:
                self.title_detail_scroll_page(-400)
                return True
            if event.keyval in (Gdk.KEY_f, Gdk.KEY_F):
                kind, name, meta = self.title_detail_open
                toggle_title_favorite(kind, name)
                play_ui_sound("click", page=kind)
                self.render_title_detail(kind, name, meta)
                return True
            return False
        # Dedicated Movies / Shows page open: Back/Esc closes to the
        # home screen; Up/Down scroll the page; F stars the focused
        # title. The options panel owns its keys while open.
        if self.title_page_open is not None:
            if self.title_options_open is not None:
                if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                    self.title_page_close_options(self.title_options_open)
                    return True
                return False
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                self.close_title_page()
                return True
            if event.keyval == Gdk.KEY_Down:
                self.title_page_scroll(400)
                return True
            if event.keyval == Gdk.KEY_Up:
                self.title_page_scroll(-400)
                return True
            if event.keyval in (Gdk.KEY_f, Gdk.KEY_F):
                self.title_toggle_focused_favorite()
                return True
            if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter,
                                Gdk.KEY_space):
                # OK on a poster: hold-OK -- a quick tap opens the
                # detail page, a hold stars it into Favorites. Other
                # focused controls (Back, Options, the search entry)
                # keep their own activation.
                focused = self.get_focus()
                if focused is not None and hasattr(
                        focused, "_title_kind"):
                    play_ui_sound("click", page=self.title_page_open)
                    self._start_poster_hold(focused)
                    return True
            return False
        # App info / Allow panel open: Back/Esc dismisses it and
        # focus returns to the app tile. Everything else belongs to
        # the panel's own controls (switches, Back button) -- the Alt
        # Interface behind it never scrolls.
        if self.info_open:
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace):
                self.close_info_panel()
                return True
            if event.keyval == Gdk.KEY_Menu:
                self.close_info_panel()
                return True
            return False
        # App-options menu open: Back/Esc/Menu dismisses it and focus
        # returns to the app tile. Up/Down move through the options
        # and scroll ONLY the menu's list -- the Alt Interface behind
        # it never moves. Enter activates the focused option.
        if self.options_open:
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace,
                                Gdk.KEY_Menu):
                self.close_options_panel()
                return True
            if event.keyval == Gdk.KEY_Home:
                self.close_options_panel(restore=False)
                self.go_home()
                return True
            return False
        # Move mode: Left/Right slides the picked-up app along the
        # row, OK drops it, Back cancels (it goes back where it was).
        if self.move_app is not None:
            if event.keyval == Gdk.KEY_Left:
                self.move_app_step(-1)
                return True
            if event.keyval == Gdk.KEY_Right:
                self.move_app_step(1)
                return True
            if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter,
                                Gdk.KEY_space):
                self.drop_move()
                return True
            if event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace,
                                Gdk.KEY_Menu):
                self.cancel_move()
                return True
            if event.keyval == Gdk.KEY_Home:
                self.cancel_move()
                self.go_home()
                return True
            return True
        if event.keyval == Gdk.KEY_Escape:
            # Escape / controller B never quits the launcher on the TV
            # (it used to -- the session then restarted it); on a
            # Flight Deck sub-page it goes back, otherwise home.
            if self.panel_open:
                if self.settings_panel.current_page() != "main":
                    self.settings_panel.show_page("main")
                else:
                    self.close_settings_panel()
            else:
                self.go_home()
            return True
        focused = self.get_focus()
        if (isinstance(focused, Gtk.Entry)
                and getattr(focused, "_navigator_field", False)
                and focused is not getattr(self.kb, "entry", None)
                and event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter)
                and not self.kb_visible):
            self.show_keyboard(focused)
            return True
        if isinstance(focused, Gtk.Entry) and not getattr(
                focused, "_navigator_field", False):
            if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter) and \
                    not getattr(focused, "_typed", False):
                # A / OK on a highlighted text field: drop the keyboard
                # down under it (it never opens by itself).
                self.entry_kb.popup_for(focused)
                return True
            ch = Gdk.keyval_to_unicode(event.keyval)
            if ch and ch >= 0x20:
                focused._typed = True   # real keyboard: Enter submits
        if (isinstance(focused, Gtk.Editable)
                and event.keyval not in (Gdk.KEY_Escape, Gdk.KEY_Up,
                                         Gdk.KEY_Down)):
            # Typing in a text field (Wi-Fi password, IPTV URL, ...):
            # the field gets BackSpace / Left / Right / Home / Enter.
            return False
        if event.keyval in (Gdk.KEY_BackSpace, Gdk.KEY_Back):
            if self.panel_open:
                # On a sub-page, Back goes to the tiles page; on the tiles
                # page it closes the panel.
                if self.settings_panel.current_page() != "main":
                    self.settings_panel.show_page("main")
                else:
                    self.close_settings_panel()
            else:
                self.go_home()
            return True
        # Voice button (remote mic / voice key): push-to-talk Alexa, just
        # like the Fire TV remote. Opens the Alexa app to listen.
        voice_keys = {Gdk.KEY_Search, Gdk.KEY_v}
        voice_keyval = getattr(Gdk, "KEY_Voice", None)
        if voice_keyval is not None:
            voice_keys.add(voice_keyval)
        if event.keyval in voice_keys:
            self.on_voice_button()
            return True
        # Steam Deck extra buttons (aero-deck-padd): L3 = Navigator
        # search, R3 = Wingman, View = Controls page, Menu (≡) = options
        # for the focused item.
        if event.keyval == Gdk.KEY_F14:
            if self.panel_open:
                self.close_settings_panel()
            self.show_keyboard(self.search_entry)
            return True
        if event.keyval == Gdk.KEY_F15:
            # R3: tap = Wingman, HOLD = talk (voice typing via the
            # Deck's built-in mics into the field / search / Wingman).
            if getattr(self, "_ptt_t0", None) is None:
                self._ptt_t0 = time.time()
                self._ptt_id = GLib.timeout_add(350, self._ptt_begin)
            return True
        if event.keyval == Gdk.KEY_F16:
            if not self.panel_open:
                self.open_settings_panel()
            self.settings_panel.show_page("controls")
            return True
        if event.keyval == Gdk.KEY_F17:
            tile = self._focused_app_tile()
            if tile is not None:
                self.open_options_panel(tile._app, tile)
            elif not self.panel_open:
                self.open_settings_panel()
            return True
        # Alexa Voice Remote: Home goes home, Menu opens the Flight Deck.
        if event.keyval == Gdk.KEY_Home:
            if self.panel_open:
                self.close_settings_panel()
            else:
                self.go_home()
            return True
        if event.keyval == Gdk.KEY_Menu:
            self.toggle_settings_panel(None)
            return True
        # Hold OK on an app tile: a quick tap launches the app (the
        # release does that), holding past HOLD_OK_MS opens the Alt
        # Navigator instead. The press is consumed here so the tile
        # doesn't fire on the press itself.
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_space):
            btn = self._focused_app_tile()
            if btn is not None and not self.panel_open:
                play_ui_sound("click")
                self._start_hold_ok(btn)
                return True
            return False
        adj = self.scrolled.get_vadjustment()
        # Nov 16: Up/Down (remote D-pad, Steam Deck D-pad / stick) MOVE
        # THE FOCUS to the control above / below -- in the Flight Deck
        # and on the home rows -- and the view follows the focus. Only
        # when there is nothing further that way does it just scroll.
        if event.keyval in (Gdk.KEY_Down, Gdk.KEY_Up):
            direction = (Gtk.DirectionType.DOWN
                         if event.keyval == Gdk.KEY_Down
                         else Gtk.DirectionType.UP)
            if self.panel_open:
                if not self.settings_panel.move_focus(direction):
                    self.settings_panel.smooth_scroll_by(
                        300 if direction == Gtk.DirectionType.DOWN
                        else -300)
                play_ui_sound("move")
                return True
            if self._home_move_focus(direction):
                play_ui_sound("move")
                return True
        if event.keyval == Gdk.KEY_Down:
            if self.panel_open:
                # Panel open: glide the panel, not the home screen.
                self.settings_panel.smooth_scroll_by(300)
            else:
                self.smooth_scroll_to(min(
                    adj.get_upper() - adj.get_page_size(),
                    adj.get_value() + 400))
            play_ui_sound("move")
            return True
        if event.keyval == Gdk.KEY_Up:
            if self.panel_open:
                self.settings_panel.smooth_scroll_by(-300)
            elif adj.get_value() <= 0 and not self.kb_visible:
                # Already at the top: Up HIGHLIGHTS the Navigator bar
                # (A / OK then opens its keyboard -- it never opens by
                # itself).
                self.nav_bar_eventbox.grab_focus()
            else:
                self.smooth_scroll_to(max(0, adj.get_value() - 400))
            play_ui_sound("move")
            return True
        return False

    def on_key_release(self, widget, event):
        """Key release: the short-OK-tap half of hold-OK. If the hold
        timer is still pending, the OK was a quick tap -- cancel the
        timer and launch the focused app tile. If the hold already
        fired (the app-options menu is open), this release is the release
        of that same hold -- swallow it so it doesn't activate the
        focused option."""
        if event.keyval not in (Gdk.KEY_Return, Gdk.KEY_KP_Enter,
                                Gdk.KEY_space):
            return False
        if self._hold_timer is not None:
            btn = self._hold_btn
            self._cancel_hold_ok()
            if btn is not None and hasattr(btn, "_app"):
                app = btn._app
                self.on_open_app(btn, app["kind"], app["target"],
                                 app["fallback"], app["name"])
                return True
            return False
        # Hold OK on a poster: the timer still pending means the OK
        # was a quick tap -- open the detail page. If the hold
        # already fired (the title was starred), this release is the
        # release of that same hold -- swallow it.
        if self._poster_hold_timer is not None:
            btn = self._poster_hold_btn
            self._cancel_poster_hold()
            if btn is not None and hasattr(btn, "_title_kind"):
                self.open_title_detail(
                    btn._title_kind, btn._title_name,
                    getattr(btn, "_title_meta", ""))
                return True
            return False
        if self._poster_hold_fired:
            self._poster_hold_fired = False
            return True
        if self._hold_fired:
            self._hold_fired = False
            return True
        return False

    # -- Flight Deck (slide-in) -------------------------------------------
    def toggle_settings_panel(self, widget):
        if self.panel_open:
            self.close_settings_panel()
        else:
            self.open_settings_panel()

    def open_settings_panel(self):
        # The app-options menu / info panel can't stay up under the
        # Flight Deck (its dim would cover it).
        self.close_options_panel(restore=False)
        self.close_info_panel(restore=False)
        self.settings_panel.refresh_clock()
        # Click / tap outside the panel closes it: a clear catcher sits
        # under the panel (and under the A button).
        if getattr(self, "panel_dim", None) is None:
            self.panel_dim = Gtk.EventBox()
            self.panel_dim.set_visible_window(True)
            self.panel_dim.get_style_context().add_class("panel-dim")
            self.panel_dim.connect("button-press-event", lambda w, e: (
                self.close_settings_panel(), True)[1])
            self.overlay.add_overlay(self.panel_dim)
        for child in (self.panel_dim, self.panel_revealer):
            if child.get_parent() is self.overlay:
                self.overlay.remove(child)
                self.overlay.add_overlay(child)
        self.panel_dim.show()
        self.panel_revealer.show()
        # Keep the A button on top of everything (and clickable).
        dock = getattr(self, "dock", None)
        if dock is not None and dock.get_parent() is self.overlay:
            self.overlay.remove(dock)
            self.overlay.add_overlay(dock)
            dock.show_all()
        self.panel_revealer.set_reveal_child(True)
        self.panel_open = True
        self._panel_activity()

    def _home_move_focus(self, direction):
        """D-pad Up/Down on the home screen: focus the tile in the row
        above / below and scroll it into view. False when there is no
        row that way (the caller then scrolls / opens the Navigator)."""
        focus = self.get_focus()
        content = self.content
        if focus is None or not focus.is_ancestor(content):
            if direction == Gtk.DirectionType.DOWN:
                moved = content.child_focus(Gtk.DirectionType.TAB_FORWARD)
            else:
                return False
        else:
            moved = content.child_focus(direction)
        if moved:
            _scroll_focus_into_view(self.scrolled, self.get_focus(),
                                    self.smooth_scroll_to)
        return bool(moved)

    def _hook_entry_keyboards(self, root):
        """Tap / click on any ordinary text field drops the keyboard
        down under it (Navigator-type search fields are left alone)."""
        def walk(w):
            if isinstance(w, Gtk.Entry):
                if not getattr(w, "_ekb_hooked", False) and not getattr(
                        w, "_navigator_field", False):
                    w._ekb_hooked = True
                    w.connect("button-release-event",
                              self._on_entry_tapped)
                return
            if isinstance(w, Gtk.Container):
                for c in w.get_children():
                    walk(c)
        walk(root)

    def _on_entry_tapped(self, entry, event):
        if entry.get_sensitive():
            GLib.idle_add(lambda: (self.entry_kb.popup_for(entry), False)[1])
        return False

    def _on_set_focus(self, window, widget):
        """System on-screen keyboard: pops up for any text field in the
        launcher (Flight Deck entries, dialogs). The Navigator search
        field keeps its own built-in keyboard."""
        # Inside the launcher the drop-down EntryKeyboard is used (it
        # opens on tap / A, never by itself); squeekboard serves the
        # other apps (browsers, Android, terminal).
        return

    def _on_win_size(self, widget, alloc):
        try:
            self.settings_panel.fit_to_screen(_dz(alloc.width),
                                              _dz(alloc.height))
        except Exception:
            pass
        content_w = max(600, _dz(alloc.width) - 80)
        if content_w != getattr(self, "_content_w", None):
            self._content_w = content_w
            GLib.idle_add(self._fit_content)

    def _fit_content(self):
        """Hero and rows fit the screen width (1280 on the Deck, 1920 on
        a TV) instead of a fixed 1640px that ran off a small screen."""
        cw = self._content_w
        hero = getattr(self, "hero_card", None)
        if hero is not None:
            hero.set_size_request(min(1640, cw), -1)
        alive = []
        for sc in getattr(self, "_row_scrollers", []):
            if sc.get_parent() is None:
                continue
            sc.set_min_content_width(min(sc._full_width, cw))
            alive.append(sc)
        self._row_scrollers = alive
        return False

    # -- Flight Deck auto-hide + click outside -------------------------------
    def _panel_activity(self, *args):
        if not self.panel_open:
            return False
        if getattr(self, "_panel_idle_id", None):
            GLib.source_remove(self._panel_idle_id)
            self._panel_idle_id = None
        secs = int(self.settings.get("panel_autohide_s", 15) or 0)
        if secs > 0:
            self._panel_idle_id = GLib.timeout_add_seconds(
                secs, self._panel_idle_fire)
        return False

    def _panel_idle_fire(self):
        self._panel_idle_id = None
        if not self.panel_open:
            return False
        busy = (self.entry_kb.is_open()
                or isinstance(self.get_focus(), Gtk.Editable)
                or self.settings_panel.current_page() in ("install",
                                                          "display"))
        if busy:
            self._panel_activity()   # don't yank it away mid-typing
            return False
        self.close_settings_panel()
        return False

    def close_settings_panel(self):
        self.panel_revealer.set_reveal_child(False)
        self.panel_open = False
        if getattr(self, "panel_dim", None) is not None:
            self.panel_dim.hide()
        if getattr(self, "_panel_idle_id", None):
            GLib.source_remove(self._panel_idle_id)
            self._panel_idle_id = None
        self.settings_panel.show_page("main")
        self.go_home()

    def set_cursor_visible(self, visible):
        """Show / hide the mouse pointer (the Cursor setting). The
        Flight Deck's toggle and the app-options preset both use
        this, so they stay in sync."""
        self.settings["cursor_visible"] = bool(visible)
        save_settings(self.settings)
        window = self.get_window()
        if window is not None:
            if visible:
                window.set_cursor(None)
            else:
                blank = Gdk.Cursor.new_from_name(
                    Gdk.Display.get_default(), "none")
                window.set_cursor(blank)

    # -- app-management toggle menu (hold OK on an app tile) ---------------
    # The toggle menu is the Fire OS-style right-side options list. It
    # is an independent overlay (dim + list, added to the Gtk.Overlay):
    # it floats over the Alt Interface, which does not move, shift,
    # resize or scroll when the menu opens, closes, or scrolls. Back
    # dismisses it and focus returns to the exact app tile he was on.
    # The Flight Deck (A triangle) is a SEPARATE panel -- this menu
    # does not replace or change it.
    HOLD_OK_MS = 700
    OPT_VISIBLE_COUNT = 4

    def build_options_panel(self):
        """The dim overlay + the toggle menu list. No heading, no box
        -- the options float over the dimmed Alt Interface,
        right-aligned, close to the right edge. Hidden until hold-OK
        opens it."""
        self.dim_overlay = Gtk.EventBox()
        self.dim_overlay.get_style_context().add_class("dim-overlay")
        self.dim_overlay.set_halign(Gtk.Align.FILL)
        self.dim_overlay.set_valign(Gtk.Align.FILL)
        self.dim_overlay.connect(
            "button-press-event",
            lambda w, e: self.close_options_panel())
        self.dim_overlay.hide()
        self.overlay.add_overlay(self.dim_overlay)

        self.options_revealer = Gtk.Revealer()
        self.options_revealer.set_transition_type(
            Gtk.RevealerTransitionType.SLIDE_LEFT)
        self.options_revealer.set_transition_duration(250)
        self.options_revealer.set_halign(Gtk.Align.END)
        self.options_revealer.set_valign(Gtk.Align.CENTER)
        self.options_revealer.set_margin_end(24)
        self.options_revealer.set_reveal_child(False)
        # The list: wide spacing, 4 visible at a time, smooth vertical
        # scroll for the rest.
        self.options_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                   spacing=30)
        self.options_scroll = Gtk.ScrolledWindow()
        self.options_scroll.set_policy(Gtk.PolicyType.NEVER,
                                       Gtk.PolicyType.AUTOMATIC)
        self.options_scroll.set_kinetic_scrolling(False)
        self.options_scroll.set_overlay_scrolling(True)
        self.options_scroll.set_shadow_type(Gtk.ShadowType.NONE)
        # 4 items at once: 4 x 52px button + 3 x 30px gaps = 298px.
        self.options_scroll.set_min_content_height(298)
        self.options_scroll.set_max_content_height(298)
        self.options_scroll.add(self.options_box)
        self._hook_smooth_vscroll(self.options_scroll)
        self.options_revealer.add(self.options_scroll)
        self.overlay.add_overlay(self.options_revealer)
        self.option_buttons = []

    def _hook_smooth_vscroll(self, scrolled):
        """Smooth animated vertical scrolling for one scrolled window
        (the toggle menu's option list). Same 180ms ease-out as the
        rows: D-pad Up/Down glides the list instead of jumping, and
        the Alt Interface behind it never moves -- only this list
        scrolls."""
        adj = scrolled.get_vadjustment()
        state = {"last": adj.get_value(), "animating": False,
                 "resetting": False, "timer": None, "t": 0.0}

        def on_value_changed(a):
            if state["resetting"]:
                return
            target = a.get_value()
            start = state["last"]
            now = time.monotonic()
            burst = now - state["t"] < 0.06
            state["t"] = now
            # Small steps and continuous streams (finger drag, fling
            # momentum, trackpad/wheel) pass straight through.
            if abs(target - start) < 20.0 or (burst and
                                              not state["animating"]):
                state["last"] = target
                return
            if state["animating"] and state["timer"] is not None:
                GLib.source_remove(state["timer"])
                state["timer"] = None
            state["animating"] = True
            state["resetting"] = True
            a.set_value(start)
            state["resetting"] = False
            duration_ms = 180
            steps = max(1, duration_ms // 16)
            step = [0]

            def tick():
                step[0] += 1
                frac = min(1.0, step[0] / steps)
                eased = 1 - (1 - frac) ** 2
                state["resetting"] = True
                a.set_value(start + (target - start) * eased)
                state["resetting"] = False
                state["last"] = a.get_value()
                if step[0] >= steps:
                    state["animating"] = False
                    state["timer"] = None
                    return False
                return True

            state["timer"] = GLib.timeout_add(16, tick)

        adj.connect("value-changed", on_value_changed)

    def options_for_app(self, app):
        """The toggle-menu options for this app, in order. An option
        is only listed when it applies to this app -- Force Stop /
        Clear Cache / Clear Data / Allow need a real installed Android
        app (Force Stop also works for a native Linux app, via pkill).
        Final list: Move, More Info, Uninstall, Force Stop, Clear
        Cache, Clear Data, Allow. No Offload, no Remove, no Add, and
        no heading on the panel."""
        options = [("Move", "move"), ("More Info", "info"),
                   ("Uninstall", "uninstall")]
        kind = app.get("kind")
        installed = bool(app.get("installed"))
        if kind == "android" and installed:
            options += [("Force Stop", "force-stop"),
                        ("Clear Cache", "clear-cache"),
                        ("Clear Data", "clear-data"),
                        ("Allow", "allow")]
        elif kind == "linux":
            options += [("Force Stop", "force-stop")]
        return options

    def open_options_panel(self, app, return_btn):
        """Open the toggle menu for one app. The Alt Interface behind
        it does not move -- the menu is an overlay (dim + list)."""
        if self.panel_open:
            self.close_settings_panel()
        self.close_info_panel(restore=False)
        self.options_app = app
        self.options_return_btn = return_btn
        for child in self.options_box.get_children():
            self.options_box.remove(child)
        self.option_buttons = []
        for label, action in self.options_for_app(app):
            btn = Gtk.Button(label=label)
            btn.get_style_context().add_class("opt-item")
            child = btn.get_child()
            if child is not None:
                child.set_halign(Gtk.Align.END)
            btn.connect("clicked", self.on_option_chosen, action)
            self.options_box.pack_start(btn, False, False, 0)
            self.option_buttons.append(btn)
        # Quick presets, below the app options: Bluetooth, Wi-Fi, VPN
        # (when one is configured), Show cursor. Same controls as the
        # Flight Deck -- flipping one here does the same thing.
        # They scroll with the list (4 visible at a time).
        self._build_preset_rows()
        # Background + News sources, below the presets. Same
        # dim-until-focused option buttons; they scroll with the list.
        self._build_navigator_extras()
        self.options_box.show_all()
        # Start at the top, first option focused (bright white).
        self.options_scroll.get_vadjustment().set_value(0)
        self.dim_overlay.show()
        self.options_revealer.set_reveal_child(True)
        self.options_open = True
        if self.option_buttons:
            self.option_buttons[0].grab_focus()

    def _build_preset_rows(self):
        """Preset toggles at the end of the Navigator list. Each one
        reads the real current state and flips the real setting."""
        presets = []
        bt = bluetooth_powered()
        presets.append(("Bluetooth", bt if bt is not None else True,
                        self._on_preset_bluetooth))
        wifi = wifi_radio_enabled()
        presets.append(("Wi-Fi", wifi if wifi is not None else True,
                        self._on_preset_wifi))
        if vpn_available():
            presets.append(("VPN", vpn_active(), self._on_preset_vpn))
        presets.append(("Show cursor",
                        bool(self.settings.get("cursor_visible", True)),
                        self._on_preset_cursor))
        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        sep.get_style_context().add_class("preset-sep")
        self.options_box.pack_start(sep, False, False, 0)
        self.preset_switches = []
        for label, active, handler in presets:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            name = Gtk.Label(label=label)
            name.get_style_context().add_class("preset-label")
            name.set_halign(Gtk.Align.END)
            name.set_hexpand(True)
            row.pack_start(name, True, True, 0)
            switch = Gtk.Switch()
            switch.set_active(bool(active))
            switch.connect("notify::active", handler)
            switch.connect("focus-in-event",
                           lambda w, e, r=row: self._preset_focus(r, True))
            switch.connect("focus-out-event",
                           lambda w, e, r=row: self._preset_focus(r, False))
            row.pack_start(switch, False, False, 0)
            self.options_box.pack_start(row, False, False, 0)
            self.preset_switches.append(switch)

    def _build_navigator_extras(self):
        """Background + News sources at the end of the Navigator list.
        Same dim-until-focused option buttons as the app options;
        they scroll with the list."""
        sep = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        sep.get_style_context().add_class("preset-sep")
        self.options_box.pack_start(sep, False, False, 0)
        # Background: cycles blossom -> dark -> midnight -> custom
        # (custom appears only once an image has been picked).
        self.bg_cycle_btn = Gtk.Button(
            label="Background: " + self.settings.get("background",
                                                     "blossom"))
        self.bg_cycle_btn.get_style_context().add_class("opt-item")
        child = self.bg_cycle_btn.get_child()
        if child is not None:
            child.set_halign(Gtk.Align.END)
        self.bg_cycle_btn.connect("clicked",
                                  self._on_nav_background_cycle)
        self.options_box.pack_start(self.bg_cycle_btn, False, False, 0)
        # Choose background image...
        choose_btn = Gtk.Button(label="Choose background image…")
        choose_btn.get_style_context().add_class("opt-item")
        child = choose_btn.get_child()
        if child is not None:
            child.set_halign(Gtk.Align.END)
        choose_btn.connect("clicked", self._on_nav_background_choose)
        self.options_box.pack_start(choose_btn, False, False, 0)
        # News sources...
        news_btn = Gtk.Button(label="News sources…")
        news_btn.get_style_context().add_class("opt-item")
        child = news_btn.get_child()
        if child is not None:
            child.set_halign(Gtk.Align.END)
        news_btn.connect("clicked", self._on_nav_news_sources)
        self.options_box.pack_start(news_btn, False, False, 0)

    def _on_nav_background_cycle(self, widget):
        """Cycle the backdrop: blossom -> dark -> midnight -> custom
        (only when a custom image has been picked)."""
        order = ["blossom", "dark", "midnight"]
        if self.settings.get("background_image", ""):
            order.append("custom")
        current = self.settings.get("background", "blossom")
        nxt = order[(order.index(current) + 1) % len(order)] \
            if current in order else "blossom"
        self.apply_background(nxt)
        self.bg_cycle_btn.set_label("Background: " + nxt)

    def _on_nav_background_choose(self, widget):
        """Pick any image on the box as the backdrop."""
        if self.choose_background_image():
            self.bg_cycle_btn.set_label("Background: custom")

    def _on_nav_news_sources(self, widget):
        """Edit the News sources: add, change, remove. The six
        networks are baked in by default; changes persist and the
        News row rebuilds when the dialog closes."""
        dialog = Gtk.Dialog(title="News sources", parent=self,
                            flags=Gtk.DialogFlags.MODAL)
        dialog.add_buttons("Done", Gtk.ResponseType.CLOSE)
        dialog.set_default_size(780, 460)
        content = dialog.get_content_area()
        content.set_spacing(10)
        sources = load_news_sources()
        selected = [None]  # index of the selected row, if any

        listbox = Gtk.ListBox()
        listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)

        def rebuild_list():
            for child in listbox.get_children():
                listbox.remove(child)
            for i, (name, program, url) in enumerate(sources):
                row = Gtk.ListBoxRow()
                box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=10)
                name_label = Gtk.Label(label=name)
                name_label.set_halign(Gtk.Align.START)
                name_label.set_size_request(70, -1)
                box.pack_start(name_label, False, False, 0)
                url_label = Gtk.Label(label=url)
                url_label.set_halign(Gtk.Align.START)
                url_label.set_hexpand(True)
                url_label.set_max_width_chars(48)
                box.pack_start(url_label, True, True, 0)
                remove_btn = Gtk.Button(label="Remove")
                remove_btn.connect("clicked", on_remove, i)
                box.pack_start(remove_btn, False, False, 0)
                row.add(box)
                listbox.add(row)
            listbox.show_all()

        def on_remove(btn, index):
            del sources[index]
            save_news_sources(sources)
            selected[0] = None
            rebuild_list()

        def on_row_selected(box, row):
            if row is not None:
                selected[0] = row.get_index()
                name, program, url = sources[selected[0]]
                name_entry.set_text(name)
                prog_entry.set_text(program)
                url_entry.set_text(url)

        listbox.connect("row-selected", on_row_selected)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER,
                          Gtk.PolicyType.AUTOMATIC)
        scroll.set_min_content_height(200)
        scroll.add(listbox)
        content.pack_start(scroll, True, True, 0)

        form = Gtk.Grid()
        form.set_column_spacing(10)
        form.set_row_spacing(8)
        name_entry = Gtk.Entry()
        name_entry.set_placeholder_text("Name (e.g. FOX)")
        prog_entry = Gtk.Entry()
        prog_entry.set_placeholder_text("Program (e.g. LiveNOW from FOX)")
        url_entry = Gtk.Entry()
        url_entry.set_placeholder_text("Stream URL (https://…)")
        form.attach(Gtk.Label(label="Name"), 0, 0, 1, 1)
        form.attach(name_entry, 1, 0, 1, 1)
        form.attach(Gtk.Label(label="Program"), 0, 1, 1, 1)
        form.attach(prog_entry, 1, 1, 1, 1)
        form.attach(Gtk.Label(label="Stream URL"), 0, 2, 1, 1)
        form.attach(url_entry, 1, 2, 1, 1)
        content.pack_start(form, False, False, 0)

        def on_add(btn):
            name = name_entry.get_text().strip()
            url = url_entry.get_text().strip()
            if not name or not url:
                return
            sources.append((name,
                            prog_entry.get_text().strip() or "Live",
                            url))
            save_news_sources(sources)
            rebuild_list()

        def on_change(btn):
            if selected[0] is None:
                return
            name = name_entry.get_text().strip()
            url = url_entry.get_text().strip()
            if not name or not url:
                return
            sources[selected[0]] = (
                name, prog_entry.get_text().strip() or "Live", url)
            save_news_sources(sources)
            rebuild_list()

        btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=10)
        add_btn = Gtk.Button(label="Add")
        add_btn.connect("clicked", on_add)
        btn_box.pack_start(add_btn, False, False, 0)
        change_btn = Gtk.Button(label="Change")
        change_btn.connect("clicked", on_change)
        btn_box.pack_start(change_btn, False, False, 0)
        content.pack_start(btn_box, False, False, 0)

        rebuild_list()
        dialog.show_all()
        dialog.run()
        dialog.destroy()
        # Rebuild the rows so the News row shows the edited sources.
        self.build_rows()

    def _preset_focus(self, row, focused):
        ctx = row.get_style_context()
        if focused:
            ctx.add_class("preset-focused")
        else:
            ctx.remove_class("preset-focused")
        return False

    def _sync_settings_switch(self, switch, handler, active):
        """Keep the Flight Deck's switch in step with an app-options
        preset (without re-running its command)."""
        if switch is None:
            return
        try:
            switch.handler_block_by_func(handler)
            switch.set_active(active)
            switch.handler_unblock_by_func(handler)
        except Exception:
            pass

    def _on_preset_bluetooth(self, switch, _param=None):
        on = switch.get_active()
        set_bluetooth_power(on)
        panel = getattr(self, "settings_panel", None)
        if panel is not None:
            self._sync_settings_switch(getattr(panel, "bt_switch", None),
                                       panel.on_bluetooth_toggled, on)
            panel.refresh_bluetooth_status()

    def _on_preset_wifi(self, switch, _param=None):
        on = switch.get_active()
        set_wifi_radio(on)
        panel = getattr(self, "settings_panel", None)
        if panel is not None:
            self._sync_settings_switch(getattr(panel, "wifi_switch", None),
                                       panel.on_wifi_toggled, on)
            panel.refresh_wifi_status()

    def _on_preset_vpn(self, switch, _param=None):
        on = switch.get_active()
        set_vpn_active(on)
        panel = getattr(self, "settings_panel", None)
        if panel is not None:
            self._sync_settings_switch(getattr(panel, "vpn_switch", None),
                                       panel.on_vpn_toggled, on)
            panel.refresh_vpn_status()

    def _on_preset_cursor(self, switch, _param=None):
        on = switch.get_active()
        self.set_cursor_visible(on)
        panel = getattr(self, "settings_panel", None)
        if panel is not None:
            self._sync_settings_switch(
                getattr(panel, "cursor_switch", None),
                panel.on_cursor_toggled, on)

    def close_options_panel(self, restore=True):
        """Dismiss the toggle menu. Back resumes exactly what he was
        doing: focus goes back to the app tile he was on, the Alt
        Interface untouched (no row jumped, no scroll moved)."""
        if not self.options_open:
            return
        self.options_revealer.set_reveal_child(False)
        self.dim_overlay.hide()
        self.options_open = False
        self.options_app = None
        btn = self.options_return_btn
        self.options_return_btn = None
        if restore and btn is not None:
            target = getattr(btn, "_app_key", None)
            self._focus_app_tile(target, fallback=btn)

    def on_option_chosen(self, widget, action):
        app = self.options_app
        if app is None:
            self.close_options_panel()
            return
        if action == "move":
            self.close_options_panel(restore=False)
            self.enter_move_mode(app)
        elif action == "info":
            return_btn = self.options_return_btn
            self.close_options_panel(restore=False)
            self.open_info_panel(app, focus_permissions=False,
                                 return_btn=return_btn)
        elif action == "uninstall":
            self.do_uninstall(app)
        elif action == "force-stop":
            self.do_force_stop(app)
        elif action == "clear-cache":
            self.do_clear_cache(app)
        elif action == "clear-data":
            self.do_clear_data(app)
        elif action == "allow":
            return_btn = self.options_return_btn
            self.close_options_panel(restore=False)
            self.open_info_panel(app, focus_permissions=True,
                                 return_btn=return_btn)

    # -- app info / Allow panel (More Info, Allow) --------------------------
    def build_info_panel(self):
        """The app-info / Allow panel: a dark right-side panel with
        the app's details and, for an installed Android app, its
        Permissions section -- Files and Media first, then the rest,
        each with an allow/remove switch, plus the Install unknown
        apps switch. An independent overlay, like the toggle menu."""
        self._perm_updating = False
        self.info_revealer = Gtk.Revealer()
        self.info_revealer.set_transition_type(
            Gtk.RevealerTransitionType.SLIDE_LEFT)
        self.info_revealer.set_transition_duration(250)
        self.info_revealer.set_halign(Gtk.Align.END)
        self.info_revealer.set_valign(Gtk.Align.FILL)
        self.info_revealer.set_reveal_child(False)
        panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        panel.get_style_context().add_class("info-panel")
        panel.set_size_request(560, -1)
        panel.set_margin_start(24)
        panel.set_margin_end(24)
        panel.set_margin_top(24)
        panel.set_margin_bottom(24)
        self.info_title = Gtk.Label()
        self.info_title.get_style_context().add_class("info-title")
        self.info_title.set_halign(Gtk.Align.START)
        panel.pack_start(self.info_title, False, False, 0)
        self.info_details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                    spacing=6)
        panel.pack_start(self.info_details, False, False, 0)
        perm_heading = Gtk.Label(label="Permissions")
        perm_heading.get_style_context().add_class("info-heading")
        perm_heading.set_halign(Gtk.Align.START)
        panel.pack_start(perm_heading, False, False, 0)
        self.info_perm_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                     spacing=10)
        self.info_perm_scroll = Gtk.ScrolledWindow()
        self.info_perm_scroll.set_policy(Gtk.PolicyType.NEVER,
                                         Gtk.PolicyType.AUTOMATIC)
        self.info_perm_scroll.set_overlay_scrolling(True)
        self.info_perm_scroll.set_shadow_type(Gtk.ShadowType.NONE)
        self.info_perm_scroll.set_vexpand(True)
        self.info_perm_scroll.add(self.info_perm_box)
        panel.pack_start(self.info_perm_scroll, True, True, 0)
        self.info_status = Gtk.Label()
        self.info_status.get_style_context().add_class("info-status")
        self.info_status.set_halign(Gtk.Align.START)
        self.info_status.set_line_wrap(True)
        panel.pack_start(self.info_status, False, False, 0)
        self.info_back_btn = Gtk.Button(label="Back")
        self.info_back_btn.connect(
            "clicked", lambda w: self.close_info_panel())
        panel.pack_start(self.info_back_btn, False, False, 0)
        self.info_revealer.add(panel)
        self.overlay.add_overlay(self.info_revealer)

    def open_info_panel(self, app, focus_permissions=False,
                        return_btn=None):
        """More Info / Allow: the app's details, and for an installed
        Android app its Permissions -- Files and Media first, then the
        rest, each with an allow/remove switch, plus Install unknown
        apps. Allow jumps straight to the permissions."""
        self.info_app = app
        self.info_return_btn = return_btn
        if self.info_return_btn is None:
            self.info_return_btn = self._find_app_tile(app["key"])
        self.info_title.set_text(app["name"])
        for child in self.info_details.get_children():
            self.info_details.remove(child)
        source_label = {"builtin": "Built-in", "custom": "Added",
                        "waydroid": "Installed (Android)",
                        "linux": "Installed (Linux)"}.get(app["source"], "")
        details = [("Type", {"android": "Android app",
                             "linux": "Linux app",
                             "web": "Web app"}.get(app["kind"], app["kind"])),
                   ("Source", source_label),
                   ("Target", app["target"])]
        if app.get("fallback"):
            details.append(("Website", app["fallback"]))
        if app.get("installed"):
            details.append(("Installed", "Yes"))
        for key, value in details:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            k = Gtk.Label(label=key)
            k.get_style_context().add_class("info-key")
            k.set_halign(Gtk.Align.START)
            v = Gtk.Label(label=value)
            v.get_style_context().add_class("info-value")
            v.set_halign(Gtk.Align.START)
            v.set_line_wrap(True)
            v.set_selectable(True)
            row.pack_start(k, False, False, 0)
            row.pack_start(v, True, True, 0)
            self.info_details.pack_start(row, False, False, 0)
        self.info_details.show_all()
        # Permissions (installed Android apps only -- nothing to
        # allow/remove for a web tile or a native Linux app).
        for child in self.info_perm_box.get_children():
            self.info_perm_box.remove(child)
        self.info_status.set_text("")
        self._perm_switches = []
        if app.get("kind") == "android" and app.get("installed"):
            self._build_perm_rows(app)
        else:
            note = Gtk.Label(
                label="No permissions to manage for this app.")
            note.get_style_context().add_class("info-status")
            note.set_halign(Gtk.Align.START)
            note.set_line_wrap(True)
            self.info_perm_box.pack_start(note, False, False, 0)
        self.info_perm_box.show_all()
        self.dim_overlay.show()
        self.info_revealer.set_reveal_child(True)
        self.info_open = True
        if focus_permissions and self._perm_switches:
            self._perm_switches[0].grab_focus()
        else:
            self.info_back_btn.grab_focus()

    def close_info_panel(self, restore=True):
        """Dismiss the app-info / Allow panel. Back resumes what he
        was doing: focus back on the app tile he was on."""
        if not self.info_open:
            return
        self.info_revealer.set_reveal_child(False)
        self.dim_overlay.hide()
        self.info_open = False
        self.info_app = None
        btn = self.info_return_btn
        self.info_return_btn = None
        if restore and btn is not None:
            target = getattr(btn, "_app_key", None)
            self._focus_app_tile(target, fallback=btn)

    def _build_perm_rows(self, app):
        """Permission switches for an installed Android app: Files and
        Media first (the storage permissions grouped under one row),
        then the rest, then Install unknown apps (when the app asks
        for it). Each switch allows / removes that permission via
        pm grant / revoke (appops for install-unknown-apps)."""
        pkg = app["target"]
        perms = android_app_permissions(pkg)
        if not perms:
            note = Gtk.Label(
                label="Permissions unavailable (Waydroid isn't running).")
            note.get_style_context().add_class("info-status")
            note.set_halign(Gtk.Align.START)
            note.set_line_wrap(True)
            self.info_perm_box.pack_start(note, False, False, 0)
            return
        storage = [(p, g) for p, g in perms if p in STORAGE_PERMISSIONS]
        others = [(p, g) for p, g in perms
                  if p not in STORAGE_PERMISSIONS
                  and p != "android.permission.REQUEST_INSTALL_PACKAGES"]
        install_unknown = [(p, g) for p, g in perms
                           if p == "android.permission.REQUEST_INSTALL_PACKAGES"]
        if storage:
            # One "Files and Media" row toggling the storage set.
            granted = all(g for _p, g in storage)
            self._perm_row("Files and Media", granted,
                           lambda sw, _pspec, s=storage:
                           self._on_storage_toggled(sw, app, s))
        for perm, granted in others:
            self._perm_row(perm_label(perm), granted,
                           lambda sw, _pspec, p=perm:
                           self._on_perm_toggled(sw, app, p))
        if install_unknown:
            _p, granted = install_unknown[0]
            self._perm_row("Install unknown apps", granted,
                           lambda sw, _pspec:
                           self._on_install_unknown_toggled(sw, app))

    def _perm_row(self, label, granted, callback):
        """One permission row: the name + an allow/remove switch."""
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        name = Gtk.Label(label=label)
        name.get_style_context().add_class("info-value")
        name.set_halign(Gtk.Align.START)
        name.set_hexpand(True)
        row.pack_start(name, True, True, 0)
        switch = Gtk.Switch()
        switch.set_active(bool(granted))
        switch.connect("notify::active", callback)
        row.pack_start(switch, False, False, 0)
        self.info_perm_box.pack_start(row, False, False, 0)
        self._perm_switches.append(switch)
        return switch

    def _on_perm_toggled(self, switch, app, perm):
        if self._perm_updating:
            return
        ok, msg = set_android_permission(app["target"], perm,
                                         switch.get_active())
        self.info_status.set_text("%s: %s" % (perm_label(perm), msg))
        if not ok:
            self._perm_updating = True
            switch.set_active(not switch.get_active())
            self._perm_updating = False

    def _on_storage_toggled(self, switch, app, storage):
        if self._perm_updating:
            return
        allow = switch.get_active()
        for perm, _g in storage:
            set_android_permission(app["target"], perm, allow)
        self.info_status.set_text("Files and Media: %s"
                                  % ("Allowed." if allow else "Removed."))

    def _on_install_unknown_toggled(self, switch, app):
        if self._perm_updating:
            return
        ok, msg = set_install_unknown(app["target"], switch.get_active())
        self.info_status.set_text("Install unknown apps: %s" % msg)
        if not ok:
            self._perm_updating = True
            switch.set_active(not switch.get_active())
            self._perm_updating = False

    # -- move mode ------------------------------------------------------------
    def enter_move_mode(self, app):
        """Move: the app is picked up (bright outline). D-pad Left /
        Right slides it along the row, OK drops it, Back cancels and
        puts it back where it was."""
        self.move_app = app
        self.move_orig_order = load_apps_order() or []
        self._apply_move_highlight()
        btn = self._find_app_tile(app["key"])
        if btn is not None:
            btn.grab_focus()

    def _apply_move_highlight(self):
        if self.move_app is None:
            return
        btn = self._find_app_tile(self.move_app["key"])
        if btn is not None and hasattr(btn, "_cell"):
            btn._cell.get_style_context().add_class("app-moving")

    def _clear_move_highlight(self):
        for btn in getattr(self, "app_tile_buttons", []):
            if hasattr(btn, "_cell"):
                btn._cell.get_style_context().remove_class("app-moving")

    def move_app_step(self, direction):
        """Slide the picked-up app one spot left (-1) or right (+1) in
        the row. The order is saved and the row rebuilds, so the move
        is real immediately; focus stays on the moving tile."""
        if self.move_app is None:
            return
        order = load_apps_order() or []
        key = self.move_app["key"]
        if key not in order:
            return
        idx = order.index(key)
        new_idx = idx + direction
        if new_idx < 0 or new_idx >= len(order):
            return
        order[idx], order[new_idx] = order[new_idx], order[idx]
        save_apps_order(order)
        self.build_rows()
        self._apply_move_highlight()
        btn = self._find_app_tile(key)
        if btn is not None:
            btn.grab_focus()

    def drop_move(self):
        """OK drops the app where it is -- the new order stands."""
        self._clear_move_highlight()
        self.move_app = None
        self.move_orig_order = None

    def cancel_move(self):
        """Back cancels the move: the app goes back to where it was."""
        key = self.move_app["key"] if self.move_app else None
        if self.move_orig_order is not None:
            save_apps_order(self.move_orig_order)
            self.build_rows()
        self._clear_move_highlight()
        self.move_app = None
        self.move_orig_order = None
        if key is not None:
            btn = self._find_app_tile(key)
            if btn is not None:
                btn.grab_focus()

    # -- toggle-menu actions --------------------------------------------------
    def do_force_stop(self, app):
        """Force Stop: stop the app if it's running. Android: am
        force-stop. Linux: kill the app's process (pkill)."""
        if app.get("kind") == "linux":
            import shlex
            try:
                binary = shlex.split(app["target"])[0]
            except Exception:
                binary = app["target"].split()[0]
            try:
                result = subprocess.run(["pkill", "-f", binary],
                                        capture_output=True, timeout=10)
                # pkill exits 1 when nothing matched (not running).
                ok = result.returncode in (0, 1)
                msg = "Stopped." if result.returncode == 0 else \
                    "Not running."
            except Exception:
                ok, msg = False, "Couldn't stop it."
        else:
            ok, msg = force_stop_android(app["target"])
        self._finish_app_action(ok, msg)

    def do_clear_cache(self, app):
        ok, msg = clear_cache_android(app["target"])
        self._finish_app_action(ok, msg)

    def do_clear_data(self, app):
        if not self._confirm("Clear data for %s?" % app["name"],
                             "This wipes the app's saved data -- accounts, "
                             "settings, downloads inside the app."):
            return
        ok, msg = clear_data_android(app["target"])
        self._finish_app_action(ok, msg)

    def do_uninstall(self, app):
        if not self._confirm("Uninstall %s?" % app["name"],
                             "This removes the app entirely."):
            # Cancelled: back on the tile he was on.
            self._restore_after_action()
            return
        key = app["key"]
        kind = app.get("kind")
        source = app.get("source")
        if kind == "android" and app.get("installed"):
            ok, msg = uninstall_android(app["target"])
        else:
            # Nothing installed to remove (a web tile, a Linux app, a
            # custom entry): take it out of the row and keep it out.
            ok, msg = True, "Removed from the row."
        if not ok:
            self._show_message("Couldn't uninstall %s" % app["name"], msg)
            self._restore_after_action()
            return
        # Take it out of the row, and keep it out.
        if source == "custom":
            apps = [a for a in load_custom_apps()
                    if "%s:%s" % (a.get("kind", "web"),
                                  a.get("target", "")) != key]
            save_custom_apps(apps)
        order = [k for k in (load_apps_order() or []) if k != key]
        save_apps_order(order)
        hidden = load_apps_hidden()
        if key not in hidden:
            hidden.append(key)
            save_apps_hidden(hidden)
        self.build_rows()
        # The tile is gone -- focus the first app tile.
        btn = self._first_app_tile()
        if btn is not None:
            btn.grab_focus()

    def _finish_app_action(self, ok, msg):
        """After a Force Stop / Clear Cache / Clear Data: success just
        closes the menu and lands back on the tile; failure says so."""
        if ok:
            self.close_options_panel()
        else:
            self._show_message("That didn't work", msg)

    def _restore_after_action(self):
        """Back on the tile he was on (used when an action is
        cancelled)."""
        self.close_options_panel()

    def _confirm(self, title, text):
        """A yes/no confirm dialog. True when he confirms."""
        dialog = Gtk.MessageDialog(
            parent=self, flags=0, message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.OK_CANCEL, text=title)
        dialog.format_secondary_text(text)
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.OK

    def _show_message(self, title, text):
        dialog = Gtk.MessageDialog(
            parent=self, flags=0, message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text=title)
        dialog.format_secondary_text(text)
        dialog.run()
        dialog.destroy()

    # -- hold OK + app-tile focus helpers -------------------------------------
    def _focused_app_tile(self):
        """The app tile that has focus right now, or None."""
        focused = self.get_focus()
        if focused is not None and hasattr(focused, "_app"):
            return focused
        return None

    def _start_hold_ok(self, btn):
        """OK pressed on an app tile: start the hold timer. A quick
        release launches the app; holding past HOLD_OK_MS opens the
        toggle menu instead."""
        self._cancel_hold_ok()
        self._hold_fired = False
        self._hold_btn = btn

        def on_timeout():
            self._hold_timer = None
            if self._hold_btn is None:
                return False
            self._hold_fired = True
            app = getattr(self._hold_btn, "_app", None)
            if app is not None:
                self.open_options_panel(app, self._hold_btn)
            return False

        self._hold_timer = GLib.timeout_add(self.HOLD_OK_MS, on_timeout)

    def _cancel_hold_ok(self):
        if self._hold_timer is not None:
            GLib.source_remove(self._hold_timer)
            self._hold_timer = None
        self._hold_btn = None
        self._hold_fired = False

    # -- hold OK on a poster (Movies / Shows) --------------------------------
    # A quick OK tap on a poster opens the title's detail page; a
    # HOLD on OK (past HOLD_OK_MS) stars it into Favorites instead.
    def _start_poster_hold(self, btn):
        """OK pressed on a poster tile: start the hold timer. A quick
        release opens the detail page; holding past HOLD_OK_MS
        stars the title instead."""
        self._cancel_poster_hold()
        self._poster_hold_fired = False
        self._poster_hold_btn = btn
        self._poster_hold_timer = GLib.timeout_add(
            self.HOLD_OK_MS, self._fire_poster_hold)

    def _fire_poster_hold(self):
        """The hold fired: star the poster (into Favorites)."""
        self._poster_hold_timer = None
        btn = self._poster_hold_btn
        if btn is None:
            return False
        self._poster_hold_fired = True
        kind = getattr(btn, "_title_kind", None)
        name = getattr(btn, "_title_name", None)
        if kind is not None and name is not None:
            toggle_title_favorite(kind, name)
            play_ui_sound("click", page=kind)
            if self.title_page_open == kind:
                self.title_page_render(kind)
        return False

    def _cancel_poster_hold(self):
        if self._poster_hold_timer is not None:
            GLib.source_remove(self._poster_hold_timer)
            self._poster_hold_timer = None
        self._poster_hold_btn = None
        self._poster_hold_fired = False

    def _find_app_tile(self, key):
        """The current Your Apps tile button for one app key, or None."""
        for btn in getattr(self, "app_tile_buttons", []):
            if getattr(btn, "_app_key", None) == key:
                return btn
        return None

    def _first_app_tile(self):
        buttons = getattr(self, "app_tile_buttons", [])
        return buttons[0] if buttons else None

    def _focus_app_tile(self, key, fallback=None):
        """Focus the tile for one app key (after a rebuild, or after
        the toggle menu / info panel closes). Falls back to the given
        button when the tile is gone."""
        btn = self._find_app_tile(key) if key else None
        if btn is None:
            btn = fallback
        if btn is not None:
            btn.grab_focus()
        return btn

    # -- appearance / backdrop --------------------------------------------------
    def apply_background(self, name):
        """Backdrop: blossom (photo) / dark / midnight (dark theme
        only) / custom (any image Drew picks). The frost is CSS
        rgba white, independent of the image -- changing the
        background never breaks or removes the frost."""
        ctx = self.get_style_context()
        for cls in ("bg-blossom", "bg-dark", "bg-midnight"):
            ctx.remove_class(cls)
        if self.settings.get("theme", "dark") == "dark" and name in (
                "blossom", "dark", "midnight"):
            ctx.add_class("bg-" + name)
        self.settings["background"] = name
        if name == "custom":
            # (Re)load the custom image as the backdrop photo.
            self.backdrop_pixbuf = self._load_backdrop_pixbuf()
            self._backdrop_alloc = (0, 0)
            alloc = self.backdrop_image.get_allocation()
            if alloc.width > 0:
                self._scale_backdrop(alloc.width, alloc.height)
        self._update_backdrop_visibility()
        save_settings(self.settings)
        self._sync_background_combo()

    def _sync_background_combo(self):
        """Keep the Flight Deck's Background combo showing the
        current background (it can change from the app-options menu too)."""
        panel = getattr(self, "settings_panel", None)
        combo = getattr(panel, "bg_combo", None) if panel else None
        if combo is None:
            return
        try:
            combo.handler_block_by_func(panel.on_background_changed)
            choices = ("blossom", "dark", "midnight", "custom")
            current = self.settings.get("background", "blossom")
            if current in choices:
                combo.set_active(choices.index(current))
            combo.handler_unblock_by_func(panel.on_background_changed)
        except Exception:
            pass

    def _load_backdrop_pixbuf(self):
        """The backdrop photo. A custom image Drew picked himself wins
        when the background is "custom" and the file still exists;
        otherwise the shipped blossom photo is the default. Returns
        None if neither is there, so the window falls back to the
        solid blue background."""
        custom = self.settings.get("background_image", "")
        if self.settings.get("background") == "custom" and custom:
            path = Path(custom)
            if path.exists():
                try:
                    return GdkPixbuf.Pixbuf.new_from_file(str(path))
                except Exception:
                    pass
        try:
            path = ASSETS_DIR / "backdrop.jpg"
            if not path.exists():
                return None
            return GdkPixbuf.Pixbuf.new_from_file(str(path))
        except Exception:
            return None

    def choose_background_image(self):
        """Pick any image on the box as the backdrop. Returns the
        chosen path, or None if Drew cancelled. The choice is saved
        and applied right away (background becomes "custom")."""
        dialog = Gtk.FileChooserDialog(
            title="Choose background image", parent=self,
            action=Gtk.FileChooserAction.OPEN)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                           Gtk.STOCK_OPEN, Gtk.ResponseType.OK)
        image_filter = Gtk.FileFilter()
        image_filter.set_name("Images")
        image_filter.add_mime_type("image/*")
        dialog.add_filter(image_filter)
        chosen = None
        if dialog.run() == Gtk.ResponseType.OK:
            chosen = dialog.get_filename()
        dialog.destroy()
        if chosen:
            self.settings["background_image"] = chosen
            self.apply_background("custom")
        return chosen

    def _on_backdrop_allocate(self, widget, allocation):
        """Re-scale the backdrop photo to cover the window whenever its
        size changes (fullscreen / resize)."""
        if self.backdrop_pixbuf is None:
            return
        width, height = allocation.width, allocation.height
        if width <= 0 or height <= 0:
            return
        if (width, height) == self._backdrop_alloc:
            return
        self._backdrop_alloc = (width, height)
        self._scale_backdrop(width, height)

    def _scale_backdrop(self, width, height):
        """Scale the backdrop photo to cover (width, height), cropping
        the centre, so it fills the screen with no distortion and no
        letterboxing."""
        src = self.backdrop_pixbuf
        iw, ih = src.get_width(), src.get_height()
        scale = max(width / iw, height / ih)
        sw, sh = max(1, int(iw * scale + 0.5)), max(1, int(ih * scale + 0.5))
        scaled = src.scale_simple(sw, sh, GdkPixbuf.InterpType.BILINEAR)
        if scaled is None:
            return
        x = max(0, (sw - width) // 2)
        y = max(0, (sh - height) // 2)
        cropped = scaled.new_subpixbuf(
            x, y, min(width, sw), min(height, sh))
        self.backdrop_image.set_from_pixbuf(cropped)

    def _update_backdrop_visibility(self):
        """Show the photo for the blossom backdrop or a custom image
        in the dark theme; dark / midnight (and the light theme) use
        their CSS backgrounds instead."""
        show = (
            self.backdrop_pixbuf is not None
            and self.settings.get("theme", "dark") == "dark"
            and self.settings.get("background", "blossom") in ("blossom",
                                                              "custom")
        )
        self.backdrop_image.set_visible(show)

    def apply_theme(self, theme):
        """Dark / light theme. Light uses its own pale background."""
        ctx = self.get_style_context()
        if theme == "light":
            for cls in ("bg-blossom", "bg-dark", "bg-midnight"):
                ctx.remove_class(cls)
            ctx.add_class("light-theme")
        else:
            ctx.remove_class("light-theme")
            if self.settings.get("background", "blossom") in (
                    "blossom", "dark", "midnight"):
                ctx.add_class(
                    "bg-" + self.settings.get("background", "blossom"))
        self.settings["theme"] = theme
        self._update_backdrop_visibility()
        save_settings(self.settings)

    def apply_accent(self, colour):
        """Accent colour (hero FEATURED text, LIVE badges)."""
        self.settings["accent"] = colour
        save_settings(self.settings)
        apply_css(colour,
                  self.kb_effective_color(),
                  self.settings.get("keyboard_opacity", 1.0))

    def kb_effective_color(self):
        """The keyboard colour actually used: Dark Mode forces a dark
        keys card, otherwise the user's chosen colour."""
        if self.settings.get("dark_mode", False):
            return "#232838"
        return self.settings.get("keyboard_color", "#ffffff")

    def apply_dark_mode(self, on):
        """Dark Mode (Flight Deck -> Appearance): the launcher --
        including the Navigator -- goes dark. Default is light/white.
        Persisted to settings.json."""
        self.settings["dark_mode"] = bool(on)
        save_settings(self.settings)
        ctx = self.get_style_context()
        if on:
            ctx.add_class("dark-mode")
        else:
            ctx.remove_class("dark-mode")
        apply_css(self.settings.get("accent", "#e50914"),
                  self.kb_effective_color(),
                  self.settings.get("keyboard_opacity", 1.0))

    def apply_keyboard_appearance(self):
        """Keyboard colour + opacity (Flight Deck -> Keyboard instrument
        panel). Saves the settings and reloads the stylesheet, so an open
        keyboard changes live and a closed one picks it up next time
        it opens (and on the next launch)."""
        save_settings(self.settings)
        apply_css(self.settings.get("accent", "#e50914"),
                  self.kb_effective_color(),
                  self.settings.get("keyboard_opacity", 1.0))


    # -- clock + weather --------------------------------------------------------
    def start_clock(self):
        self.update_clock_weather()
        GLib.timeout_add_seconds(30, self.update_clock_weather)
        # Refresh the weather every 30 minutes in the background.
        threading.Thread(target=self.fetch_weather_loop, daemon=True).start()

    def update_clock_weather(self):
        # The clock lives ONLY in the Flight Deck (never on the
        # desktop, tray or top bar). Refresh it -- and the weather
        # pill -- whenever the clock ticks or a weather fetch lands.
        # The EPG guide has its own small clock (top-right, by the
        # option button); refresh that too while the guide is open.
        panel = getattr(self, "settings_panel", None)
        if panel is not None:
            panel.refresh_clock()
        if getattr(self, "epg_open", False):
            self.epg_update_clock()
        return True

    def fetch_weather_loop(self):
        while True:
            self.fetch_weather_once()
            # 30 minutes between refreshes.
            threading.Event().wait(1800)

    def fetch_weather_once(self):
        """Weather, metric/Celsius only. On failure show unavailable --
        never a clock/date fallback (the clock is its own thing)."""
        try:
            url = ("https://api.open-meteo.com/v1/forecast?latitude=%s"
                   "&longitude=%s&current=temperature_2m,weather_code"
                   "&temperature_unit=celsius" % (WEATHER_LAT, WEATHER_LON))
            with urllib.request.urlopen(url, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            temp = data["current"]["temperature_2m"]
            code = data["current"]["weather_code"]
            cond = {
                0: "Clear", 1: "Mainly clear", 2: "Partly cloudy",
                3: "Overcast", 45: "Foggy", 48: "Foggy",
                51: "Drizzle", 53: "Drizzle", 55: "Drizzle",
                61: "Rain", 63: "Rain", 65: "Rain",
                71: "Snow", 73: "Snow", 75: "Snow",
                95: "Thunderstorm",
            }.get(code, "Cloudy")
            self.weather_text = "%s, %d°C" % (cond, round(temp))
        except Exception:
            self.weather_text = "Weather unavailable"
        GLib.idle_add(self._refresh_clock_once)

    def _refresh_clock_once(self):
        self.update_clock_weather()
        return False

    # -- actions -----------------------------------------------------------------
    # -- Android apps (Waydroid): start Android, install, launch --------------
    # Nov 16 (Andrew): an Android tile never silently drops into the
    # browser any more. It shows what is happening ("Starting
    # Android…"), waits for Waydroid, and when the app isn't installed
    # offers to install it (Aurora Store, bundled; Play Store if the
    # image has it). The website only opens when he picks "Open website
    # instead".
    AURORA_PKG = "com.aurora.store"
    PLAY_PKG = "com.android.vending"
    AURORA_APK = "/usr/local/share/aero-deck/apks/AuroraStore.apk"

    def _android_card(self):
        if getattr(self, "_adroid_box", None) is not None:
            return
        dim = Gtk.EventBox()
        dim.get_style_context().add_class("android-dim")
        dim.set_halign(Gtk.Align.FILL)
        dim.set_valign(Gtk.Align.FILL)
        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        card.get_style_context().add_class("android-card")
        card.set_halign(Gtk.Align.CENTER)
        card.set_valign(Gtk.Align.CENTER)
        card.set_size_request(560, -1)
        self._adroid_title = Gtk.Label()
        self._adroid_title.get_style_context().add_class("android-title")
        card.pack_start(self._adroid_title, False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self._adroid_spinner = Gtk.Spinner()
        row.pack_start(self._adroid_spinner, False, False, 0)
        self._adroid_msg = Gtk.Label()
        self._adroid_msg.set_line_wrap(True)
        self._adroid_msg.set_max_width_chars(48)
        self._adroid_msg.set_halign(Gtk.Align.START)
        row.pack_start(self._adroid_msg, True, True, 0)
        card.pack_start(row, False, False, 0)
        self._adroid_btns = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                    spacing=8)
        card.pack_start(self._adroid_btns, False, False, 0)
        dim.add(card)
        self._adroid_box = dim
        self._adroid_job = 0
        self.overlay.add_overlay(dim)

    def android_card_open(self):
        return (getattr(self, "_adroid_box", None) is not None
                and self._adroid_box.get_visible())

    def _android_show(self, title, msg, busy, buttons):
        """buttons: [(label, callback)]; Cancel is always added."""
        self._android_card()
        self._adroid_title.set_markup(
            "<span size='x-large' weight='bold'>%s</span>" % _esc(title))
        self._adroid_msg.set_text(msg)
        if busy:
            self._adroid_spinner.start()
            self._adroid_spinner.show()
        else:
            self._adroid_spinner.stop()
            self._adroid_spinner.hide()
        for c in self._adroid_btns.get_children():
            self._adroid_btns.remove(c)
        first = None
        for label, cb in list(buttons) + [("Cancel", None)]:
            b = Gtk.Button(label=label)
            b.connect("clicked", self._android_btn, cb)
            self._adroid_btns.pack_start(b, False, False, 0)
            first = first or b
        # Keep it on top of everything (rows, Flight Deck).
        if self._adroid_box.get_parent() is self.overlay:
            self.overlay.remove(self._adroid_box)
            self.overlay.add_overlay(self._adroid_box)
        self._adroid_box.show_all()
        if not busy:
            self._adroid_spinner.hide()
        first.grab_focus()

    def _android_btn(self, button, cb):
        if cb is None:
            self.android_close()
        else:
            cb()

    def android_close(self):
        self._adroid_job = getattr(self, "_adroid_job", 0) + 1  # cancel
        if getattr(self, "_adroid_box", None) is not None:
            self._adroid_spinner.stop()
            self._adroid_box.hide()

    @staticmethod
    def _waydroid_state():
        """(initialised, container_running, session_running)."""
        inited = Path("/var/lib/waydroid/waydroid.cfg").exists()
        try:
            out = subprocess.check_output(
                ["waydroid", "status"], timeout=10,
                stderr=subprocess.STDOUT).decode("utf-8", "replace")
        except Exception:
            return inited, False, False
        sess = re.search(r"Session:\s*RUNNING", out) is not None
        cont = re.search(r"Container:\s*(RUNNING|FROZEN)", out) is not None
        return inited, cont, sess

    def _android_bg(self, job, work):
        def worker():
            try:
                work(job)
            except Exception as exc:
                self._android_ui(job, "Android", "Something went wrong: %s"
                                 % exc, False, [])
        threading.Thread(target=worker, daemon=True).start()

    def _android_ui(self, job, title, msg, busy, buttons):
        def run():
            if job == self._adroid_job:
                self._android_show(title, msg, busy, buttons)
            return False
        GLib.idle_add(run)

    def _android_wait_ready(self, job, title, timeout=240):
        """Make sure Waydroid is set up and its session is running.
        Returns True when ready; updates the card while waiting."""
        start = time.time()
        started_session = False
        while job == self._adroid_job and time.time() - start < timeout:
            inited, cont, sess = self._waydroid_state()
            if sess:
                return True
            if not inited:
                self._android_ui(job, title, "Setting up Android for the "
                                 "first time… (this takes a minute or two)",
                                 True, [])
            elif not cont:
                self._android_ui(job, title, "Starting Android… (waiting "
                                 "for the Android container)", True, [])
                _spawn(["systemctl", "start", "--no-block",
                        "waydroid-container.service"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            else:
                self._android_ui(job, title, "Starting Android…", True, [])
                if not started_session:
                    _spawn(["waydroid", "session", "start"],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
                    started_session = True
            time.sleep(3)
        return False

    def android_open(self, target, fallback, name, web_cb=None):
        self._android_card()
        self.android_close()
        self._adroid_job += 1
        job = self._adroid_job
        opener = web_cb or (lambda: open_url(fallback))
        web = [("Open website instead",
                lambda: (self.android_close(), opener()))] \
            if fallback else []
        if not shutil.which("waydroid"):
            self._android_show(name, "Android apps need Waydroid, which "
                               "isn't installed on this system.", False, web)
            return
        if not (os.path.exists("/dev/binderfs")
                or "binder" in Path("/proc/filesystems").read_text()):
            self._android_show(name, "This kernel has no Android (binder) "
                               "support, so Android apps can't run here.",
                               False, web)
            return
        self._android_show(name, "Starting Android…", True, [])

        def work(job):
            if not self._android_wait_ready(job, name):
                if job == self._adroid_job:
                    self._android_ui(
                        job, name, "Android didn't start (check "
                        "Flight Deck → Apps, or try again in a moment).",
                        False, [("Try again", lambda: self.android_open(
                            target, fallback, name))] + web)
                return
            pkgs = set(_waydroid_packages())
            if target in pkgs:
                self._android_ui(job, name, "Opening %s…" % name, True, [])
                _spawn(["waydroid", "app", "launch", target],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                time.sleep(2.5)
                GLib.idle_add(lambda: (job == self._adroid_job
                                       and self.android_close(), False)[1])
                return
            buttons = []
            if self.PLAY_PKG in pkgs:
                buttons.append(("Install from Play Store",
                                lambda: self.android_store_install(
                                    target, fallback, name, self.PLAY_PKG)))
            buttons.append(("Install with Aurora Store",
                            lambda: self.android_store_install(
                                target, fallback, name, self.AURORA_PKG)))
            self._android_ui(job, name, "%s isn't installed in Android yet."
                             % name, False, buttons + web)
        self._android_bg(job, work)

    def android_store_install(self, target, fallback, name, store):
        self._adroid_job += 1
        job = self._adroid_job
        self._android_show(name, "Opening the app store…", True, [])

        def work(job):
            pkgs = set(_waydroid_packages())
            if store == self.AURORA_PKG and store not in pkgs:
                if not os.path.exists(self.AURORA_APK):
                    self._android_ui(job, name, "Aurora Store isn't bundled "
                                     "on this build.", False, [])
                    return
                self._android_ui(job, name, "Installing Aurora Store "
                                 "(first time only)…", True, [])
                subprocess.run(["waydroid", "app", "install",
                                self.AURORA_APK], timeout=180,
                               stdout=subprocess.DEVNULL,
                               stderr=subprocess.DEVNULL)
                for _ in range(20):
                    if store in set(_waydroid_packages()):
                        break
                    time.sleep(2)
            _spawn(["waydroid", "app", "intent", "android.intent.action.VIEW",
                    "market://details?id=%s" % target],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if store == self.AURORA_PKG:
                # Aurora handles market:// links; launch it too in case
                # the intent was ignored (first start shows its setup).
                time.sleep(1.5)
                _spawn(["waydroid", "app", "launch", store],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self._android_ui(
                job, name, "The store is open on %s. Install it there, then "
                "press its tile again. (Aurora: choose 'Anonymous' to sign "
                "in without a Google account.)" % name, False, [])
        self._android_bg(job, work)

    def on_open_app(self, widget, kind, target, fallback, name):
        """Open an app from either side: Android (Waydroid), Linux
        (native command) or web. Android apps fall back to their website
        if Waydroid or the app isn't there yet."""
        if kind == "android":
            self.android_open(target, fallback, name)
        elif kind == "linux":
            try:
                import shlex
                cmd = shlex.split(target)
            except Exception:
                cmd = None
            if not _spawn(cmd):
                if fallback:
                    open_url(fallback)
        else:
            open_url(target or fallback)

    def on_voice_button(self):
        """Remote mic / voice button: push-to-talk Alexa, Fire TV style.
        Opens the Alexa app to listen (falls back to the Alexa web page)."""
        proc = _spawn(["waydroid", "app", "launch",
                       "com.amazon.dee.app"],
                      stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)
        if proc is not None:
            return
        open_url("https://alexa.amazon.com")

    def on_open_live(self, widget, url, name):
        """Live TV tile: open the full-screen EPG guide, focused on
        this channel. The channel itself plays from the guide (OK, or
        click the preview) -- the row no longer launches mpv directly."""
        self.open_epg(focus_name=name)

    def on_open_movies_page(self, widget, name=None, meta=None):
        """Movies row / tile: open the dedicated Movies page."""
        self.open_title_page("movies", focus_title=name)

    def on_open_shows_page(self, widget, name=None, meta=None):
        """TV Shows row / tile: open the dedicated Shows page."""
        self.open_title_page("shows", focus_title=name)

    # -- EPG guide (full-screen, Live TV) -------------------------------------
    # Opens from a Live TV tile. Solid opaque background (its own theme,
    # per page -- not the frosted Navigator, not the Flight Deck).
    # NO top nav bar. Preview ~top 40% (poster left, details right),
    # time header, 5 channel rows at a time (scroll for more), program
    # grid, bottom hints. Back: player -> EPG -> home screen.
    EPG_ROW_HEIGHT = 88
    EPG_VISIBLE_ROWS = 5
    EPG_CHAN_COL_WIDTH = 340
    EPG_SLOT_WIDTH = 290

    def _apply_page_theme(self, widget, theme_name):
        """Swap a page box onto one of the named themes (background +
        border highlight). Each page keeps its own theme."""
        ctx = widget.get_style_context()
        for name in PAGE_THEME_NAMES:
            ctx.remove_class("page-theme-" + name.lower())
        ctx.add_class("page-theme-" + theme_name.lower())

    def _page_theme_slug(self, theme_name):
        return str(theme_name or "Navy").lower()

    def open_epg(self, focus_name=None):
        """Open the full-screen EPG guide, focused on a channel."""
        if self.epg_view is None:
            # Exactly 5 channel rows on screen at any size (1280x800
            # Deck included); scroll for the rest.
            win_h = _dz(self.get_allocated_height() or _monitor_size()[1])
            self.EPG_ROW_HEIGHT = int(max(56, min(88, (win_h - 430) / 5
                                                  - 8)))
            self.build_epg_view()
        self.epg_search_query = ""
        if self.epg_search_entry is not None:
            self.epg_search_entry.set_text("")
        self.epg_time_offset = 0
        self.epg_all_channels = epg_channel_list()
        self.epg_channels = list(self.epg_all_channels)
        self.epg_focus = 0
        if focus_name:
            for i, ch in enumerate(self.epg_channels):
                if ch["name"] == focus_name:
                    self.epg_focus = i
                    break
        self.epg_preview_name = (
            self.epg_channels[self.epg_focus]["name"]
            if self.epg_channels else None)
        self.epg_apply_theme()
        self.epg_view.show_all()
        self.epg_open = True
        self.epg_render()
        self.epg_update_preview()
        self.epg_update_clock()
        play_ui_sound("open", page="epg")

    def close_epg(self):
        """Back from the EPG goes to the main page (home screen)."""
        if not self.epg_open:
            return
        self.epg_close_options()
        self.epg_stop_audio()
        if self.epg_view is not None:
            self.epg_view.hide()
        self.epg_open = False
        play_ui_sound("click", page="epg")
        self.go_home()

    def epg_apply_theme(self):
        if self.epg_view is not None:
            self._apply_page_theme(
                self.epg_view, self.settings.get("epg_color", "Navy"))

    def build_epg_view(self):
        """Build the full-screen guide (hidden until opened)."""
        view = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        view.get_style_context().add_class("epg-view")
        view.set_halign(Gtk.Align.FILL)
        view.set_valign(Gtk.Align.FILL)
        # Edge-to-edge: the guide COVERS the whole screen (solid
        # background, no blossom peeking through at the edges).
        # Breathing room for the content comes from the .epg-view
        # CSS padding, not from margins on the view.
        view.set_margin_start(0)
        view.set_margin_end(0)
        view.set_margin_top(0)
        view.set_margin_bottom(0)

        # Header: title left, search centred at the middle top,
        # clock + option button top-right. No nav bar.
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                         spacing=16)
        title = Gtk.Label(label="Live TV")
        title.get_style_context().add_class("epg-title")
        title.set_halign(Gtk.Align.START)
        header.pack_start(title, False, False, 0)
        self.epg_search_entry = Gtk.Entry()
        self.epg_search_entry._navigator_field = True
        self.epg_search_entry.set_placeholder_text(
            "Search channels...")
        self.epg_search_entry.get_style_context().add_class(
            "epg-search")
        self.epg_search_entry.set_halign(Gtk.Align.CENTER)
        self.epg_search_entry.set_size_request(420, -1)
        self.epg_search_entry.connect("changed", self.on_epg_search)
        self.epg_search_entry.connect("activate",
                                      self.on_epg_search_activate)
        self.epg_search_entry.connect("focus-in-event",
                                      self.on_epg_search_focus_in)
        header.pack_start(self.epg_search_entry, True, True, 0)
        self.epg_clock_label = Gtk.Label(label="")
        self.epg_clock_label.get_style_context().add_class("epg-clock")
        header.pack_start(self.epg_clock_label, False, False, 0)
        opt_btn = Gtk.Button(label="Options")
        opt_btn.get_style_context().add_class("epg-opt-btn")
        opt_btn.connect("clicked", lambda w: self.epg_open_options())
        header.pack_start(opt_btn, False, False, 0)
        view.pack_start(header, False, False, 0)

        # IPTV state: the guide says plainly whether the IPTV source
        # is initiated, and that the demo channels show until it is.
        self.epg_iptv_hint = Gtk.Label(label="")
        self.epg_iptv_hint.get_style_context().add_class(
            "epg-iptv-hint")
        self.epg_iptv_hint.set_halign(Gtk.Align.START)
        self.epg_iptv_hint.set_margin_top(6)
        view.pack_start(self.epg_iptv_hint, False, False, 0)

        # Preview (~top 40%): poster left, details right. Clicking
        # the poster plays the channel it shows.
        preview = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=24)
        preview.set_margin_top(12)
        # ~30% of the screen (360 px on a 1080p TV, 240 on the Deck) so
        # the 5 channel rows below always fit.
        preview.set_size_request(
            -1, int(min(360, _dz(self.get_allocated_height()
                                  or _monitor_size()[1]) * 0.3)))
        self.epg_poster_box = Gtk.EventBox()
        self.epg_poster_box.connect(
            "button-press-event", lambda w, e: self.epg_play_preview())
        self.epg_poster_image = Gtk.Image()
        self.epg_poster_box.add(self.epg_poster_image)
        preview.pack_start(self.epg_poster_box, False, False, 0)
        details = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=8)
        self.epg_prev_title = Gtk.Label(label="")
        self.epg_prev_title.get_style_context().add_class(
            "epg-preview-title")
        self.epg_prev_title.set_halign(Gtk.Align.START)
        self.epg_prev_title.set_line_wrap(True)
        details.pack_start(self.epg_prev_title, False, False, 0)
        live_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                           spacing=10)
        self.epg_prev_live = Gtk.Label(label="")
        self.epg_prev_live.get_style_context().add_class(
            "epg-live-badge")
        live_row.pack_start(self.epg_prev_live, False, False, 0)
        self.epg_prev_times = Gtk.Label(label="")
        self.epg_prev_times.get_style_context().add_class(
            "epg-preview-times")
        live_row.pack_start(self.epg_prev_times, False, False, 0)
        details.pack_start(live_row, False, False, 0)
        self.epg_prev_chan = Gtk.Label(label="")
        self.epg_prev_chan.get_style_context().add_class(
            "epg-preview-chan")
        self.epg_prev_chan.set_halign(Gtk.Align.START)
        details.pack_start(self.epg_prev_chan, False, False, 0)
        self.epg_prev_desc = Gtk.Label(label="")
        self.epg_prev_desc.get_style_context().add_class(
            "epg-preview-desc")
        self.epg_prev_desc.set_halign(Gtk.Align.START)
        self.epg_prev_desc.set_line_wrap(True)
        self.epg_prev_desc.set_max_width_chars(80)
        details.pack_start(self.epg_prev_desc, False, False, 0)
        preview.pack_start(details, True, True, 0)
        view.pack_start(preview, False, False, 0)

        # Time header: "All channels" + count and date at the left,
        # time slots across the top, current time highlighted.
        self.epg_time_header = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
        self.epg_time_header.set_margin_top(14)
        view.pack_start(self.epg_time_header, False, False, 0)

        # Grid: 5 channel rows at a time, scroll down for more. The
        # now-line overlays the grid at the current time.
        self.epg_grid_overlay = Gtk.Overlay()
        self.epg_grid_overlay.set_margin_top(8)
        self.epg_grid_scroll = Gtk.ScrolledWindow()
        self.epg_grid_scroll.set_policy(
            Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.epg_grid_scroll.set_size_request(
            -1, self.EPG_ROW_HEIGHT * self.EPG_VISIBLE_ROWS + 8)
        self.epg_grid_scroll.set_min_content_height(
            self.EPG_ROW_HEIGHT * self.EPG_VISIBLE_ROWS)
        self.epg_rows_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.epg_grid_scroll.add(self.epg_rows_box)
        self.epg_grid_overlay.add(self.epg_grid_scroll)
        self.epg_now_line = Gtk.Box()
        self.epg_now_line.get_style_context().add_class("epg-now-line")
        self.epg_now_line.set_halign(Gtk.Align.START)
        self.epg_now_line.set_valign(Gtk.Align.FILL)
        self.epg_grid_overlay.add_overlay(self.epg_now_line)
        view.pack_start(self.epg_grid_overlay, False, False, 0)

        # Bottom action hints (like the reference).
        hints = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                        spacing=36)
        hints.set_margin_top(12)
        for text in ("Select   Full screen", "Hold Select   Options",
                     "F   Star channel", "Back   Top menu"):
            lab = Gtk.Label(label=text)
            lab.get_style_context().add_class("epg-bottom-hint")
            hints.pack_start(lab, False, False, 0)
        view.pack_start(hints, False, False, 0)

        self.epg_view = view
        self.overlay.add_overlay(view)
        view.hide()
        # The options panel (top-down) lives above the guide.
        self.build_options_revealer("epg")

    def epg_update_clock(self):
        """The EPG clock: small, subtle, top-right by the option
        button -- readable, not distracting."""
        if getattr(self, "epg_clock_label", None) is not None:
            self.epg_clock_label.set_text(
                datetime.datetime.now().strftime("%-I:%M %p"))

    def on_epg_search(self, entry):
        self.epg_apply_search(entry.get_text())

    def on_epg_search_activate(self, entry):
        """Return in the guide search: jump to the first match."""
        if self.epg_channels:
            self.epg_focus = 0
            self.epg_render()
            self.epg_update_preview()
        self.set_focus(None)

    def on_epg_search_focus_in(self, entry, event):
        """The guide search uses the launcher's on-screen keyboard,
        like every other search entry: type there, the text comes
        back here when the keyboard closes. Only a click / tap opens it
        here; A / OK on the highlighted field opens it from on_key."""
        if _event_is_pointer():
            self.show_keyboard(entry)
        return False

    def epg_apply_search(self, query):
        """Filter the guide to channels whose name matches the query
        (type a channel name, it filters / jumps to matches)."""
        self.epg_search_query = (query or "").strip().lower()
        if not self.epg_search_query:
            self.epg_channels = list(self.epg_all_channels)
        else:
            self.epg_channels = [
                ch for ch in self.epg_all_channels
                if self.epg_search_query in ch["name"].lower()]
        self.epg_focus = 0
        if self.epg_channels:
            self.epg_preview_name = self.epg_channels[0]["name"]
        self.epg_render()
        self.epg_update_preview()

    def epg_render(self):
        """Rebuild the time header + channel rows from the current
        state (channels, focus, time offset, search filter)."""
        if self.epg_view is None:
            return
        state = iptv_source_state()
        if state["initiated"]:
            self.epg_iptv_hint.set_text(
                "IPTV connected: %s" % state["source_name"])
        else:
            self.epg_iptv_hint.set_text(
                (state.get("error") or "No IPTV source yet") +
                " -- add or check it in Flight Deck -> IPTV.")
        # Time header.
        for child in self.epg_time_header.get_children():
            self.epg_time_header.remove(child)
        now = datetime.datetime.now() + datetime.timedelta(
            minutes=self.epg_time_offset)
        date_str, slots, now_label, _idx = epg_time_slots(now)
        left = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                       spacing=10)
        left.set_size_request(self.EPG_CHAN_COL_WIDTH, -1)
        count = Gtk.Label(label="All channels  %d"
                          % len(self.epg_channels))
        count.get_style_context().add_class("epg-chan-count")
        left.pack_start(count, False, False, 0)
        date_lab = Gtk.Label(label=date_str)
        date_lab.get_style_context().add_class("epg-date")
        left.pack_start(date_lab, False, False, 0)
        self.epg_time_header.pack_start(left, False, False, 0)
        for i, (label, _t) in enumerate(slots):
            slot_lab = Gtk.Label(label=label)
            slot_lab.set_size_request(self.EPG_SLOT_WIDTH, -1)
            slot_lab.set_halign(Gtk.Align.CENTER)
            # The slot "now" sits in is the highlighted pill, showing
            # the exact current time.
            if self.epg_time_offset == 0 and i == 0:
                slot_lab.set_text(now_label)
                slot_lab.get_style_context().add_class("epg-now-pill")
            else:
                slot_lab.get_style_context().add_class(
                    "epg-time-slot")
            self.epg_time_header.pack_start(slot_lab, False, False, 0)
        self.epg_time_header.show_all()
        # Now-line: only when the window actually contains "now".
        if self.epg_time_offset == 0:
            mins = datetime.datetime.now().minute % 30
            # The channel cell allocates EPG_CHAN_COL_WIDTH - 20
            # wide (its inner box), so the first slot starts there
            # plus the row spacing -- NOT at EPG_CHAN_COL_WIDTH.
            # (Measured: blocks start 20px left of the old value,
            # which put the line across the program name.)
            now_x = (self.EPG_CHAN_COL_WIDTH - 20 + 16
                     + int(mins / 30.0 * self.EPG_SLOT_WIDTH))
            self.epg_now_line.set_margin_start(now_x)
            self.epg_now_line.show()
        else:
            self.epg_now_line.hide()
        # Rows.
        for child in self.epg_rows_box.get_children():
            self.epg_rows_box.remove(child)
        for i, ch in enumerate(self.epg_channels):
            row = self._epg_row(i, ch, now)
            self.epg_rows_box.pack_start(row, False, False, 0)
        self.epg_rows_box.show_all()
        self.epg_scroll_to_focus()

    def _epg_row(self, index, ch, now):
        """One guide row: channel cell (number + name + star) and the
        program blocks across the time slots. The current program
        sits in the 'now' slot; later slots say 'No guide data' --
        the guide never fakes a schedule it does not have."""
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                      spacing=16)
        row.set_size_request(-1, self.EPG_ROW_HEIGHT)
        cell = Gtk.EventBox()
        cell.get_style_context().add_class("epg-channel-cell")
        if index == self.epg_focus:
            cell.get_style_context().add_class("selected")
        cell_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                           spacing=10)
        cell_box.set_size_request(self.EPG_CHAN_COL_WIDTH - 20, -1)
        num = Gtk.Label(label=str(ch["number"]))
        num.get_style_context().add_class("epg-chan-num")
        cell_box.pack_start(num, False, False, 0)
        name = Gtk.Label(label=ch["name"])
        name.get_style_context().add_class("epg-chan-name")
        name.set_halign(Gtk.Align.START)
        name.set_line_wrap(True)
        name.set_max_width_chars(28)
        cell_box.pack_start(name, True, True, 0)
        if is_epg_favorite(ch["name"]):
            star = Gtk.Label(label="★")
            star.get_style_context().add_class("epg-chan-star")
            cell_box.pack_start(star, False, False, 0)
        cell.add(cell_box)
        # Clicking a channel plays it (the preview is the other way
        # to play it). Up/Down moves focus without playing.
        cell.connect("button-press-event",
                     lambda w, e, c=ch: self.open_player(c))
        row.pack_start(cell, False, False, 0)
        # Program blocks: slot 0 is the current program (when the
        # window is on "now"); every other slot is honest about
        # having no guide data.
        _date, slots, _now_label, _idx = epg_time_slots(now)
        for i, (label, _t) in enumerate(slots):
            block = Gtk.EventBox()
            block.get_style_context().add_class("epg-program-block")
            block.set_size_request(self.EPG_SLOT_WIDTH, -1)
            if self.epg_time_offset == 0 and i == 0:
                block.get_style_context().add_class("now")
                inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                spacing=2)
                prog = Gtk.Label(label=ch["program"])
                prog.get_style_context().add_class("epg-prog-name")
                prog.set_halign(Gtk.Align.START)
                prog.set_line_wrap(True)
                prog.set_max_width_chars(30)
                inner.pack_start(prog, False, False, 0)
                times = Gtk.Label(
                    label="%s - %s" % (slots[0][0], slots[1][0]))
                times.get_style_context().add_class("epg-prog-times")
                inner.pack_start(times, False, False, 0)
                block.add(inner)
            else:
                block.get_style_context().add_class("noguide")
                inner = Gtk.Label(label="No guide data")
                inner.get_style_context().add_class(
                    "epg-prog-noguide")
                block.add(inner)
            block.connect("button-press-event",
                          lambda w, e, c=ch: self.open_player(c))
            row.pack_start(block, False, False, 0)
        return row

    def epg_scroll_to_focus(self):
        """Keep the focused channel row visible in the 5-row window."""
        if not self.epg_channels:
            return
        adj = self.epg_grid_scroll.get_vadjustment()
        row_h = self.EPG_ROW_HEIGHT + 8
        target = max(0, self.epg_focus * row_h - 2 * row_h)
        upper = max(0, adj.get_upper() - adj.get_page_size())
        adj.set_value(min(target, upper))

    def epg_move_focus(self, delta):
        """Up/Down through the channels. The preview follows the
        focused channel (and its sound) when the preview behavior is
        'change'; it stays put when the behavior is 'stay'."""
        if not self.epg_channels:
            return
        self.epg_focus = max(
            0, min(len(self.epg_channels) - 1, self.epg_focus + delta))
        play_ui_sound("move", page="epg")
        self.epg_render()
        if self.settings.get("epg_preview_behavior", "change") \
                == "change":
            self.epg_preview_name = \
                self.epg_channels[self.epg_focus]["name"]
            self.epg_update_preview()
        else:
            # Stay: the highlight moves, the preview does not.
            self.epg_update_preview()

    def epg_shift_time(self, delta_min):
        """Left/Right shifts the guide's time window by 30 minutes."""
        self.epg_time_offset = max(
            -120, min(240, self.epg_time_offset + delta_min))
        play_ui_sound("move", page="epg")
        self.epg_render()

    def epg_focused_channel(self):
        if self.epg_channels and 0 <= self.epg_focus \
                < len(self.epg_channels):
            return self.epg_channels[self.epg_focus]
        return None

    def epg_update_preview(self):
        """The preview shows the preview channel: poster left, title /
        LIVE badge / times / description / channel on the right. The
        preview plays that channel's audio (best-effort) when viewing
        sound is on."""
        if self.epg_view is None or not self.epg_channels:
            return
        name = self.epg_preview_name or self.epg_channels[0]["name"]
        ch = next((c for c in self.epg_channels if c["name"] == name),
                  self.epg_channels[0])
        pix = self.load_channel_logo(ch["name"], 640, 360)
        if pix is not None:
            self.epg_poster_image.set_from_pixbuf(pix)
        else:
            self.epg_poster_image.clear()
        self.epg_prev_title.set_text(ch["program"])
        self.epg_prev_live.set_markup(
            "<span color='#ff5a5a'>●</span> LIVE")
        _date, slots, _now_label, _idx = epg_time_slots(
            datetime.datetime.now())
        self.epg_prev_times.set_text(
            "%s - %s" % (slots[0][0], slots[1][0]))
        star = "  ★" if is_epg_favorite(ch["name"]) else ""
        self.epg_prev_chan.set_text("%s%s" % (ch["name"], star))
        self.epg_prev_desc.set_text(
            "%s -- live on %s." % (ch["program"], ch["name"]))
        self.epg_start_audio(ch)

    def epg_play_preview(self):
        """Click the preview: play the channel it is showing."""
        if not self.epg_channels:
            return
        name = self.epg_preview_name or self.epg_channels[0]["name"]
        ch = next((c for c in self.epg_channels if c["name"] == name),
                  self.epg_channels[0])
        self.open_player(ch)

    def epg_play_focused(self):
        """OK on a channel: go to that channel (play it full-screen)."""
        ch = self.epg_focused_channel()
        if ch is not None:
            self.epg_preview_name = ch["name"]
            self.open_player(ch)

    def epg_toggle_favorite(self):
        """F: star / un-star the focused channel into Favorites."""
        ch = self.epg_focused_channel()
        if ch is None:
            return
        starred = toggle_epg_favorite(ch["name"])
        play_ui_sound("click", page="epg")
        self.epg_render()
        self.epg_update_preview()
        return starred

    def epg_start_audio(self, ch, start_offset=0):
        """Preview audio: the channel's stream, audio-only, in the
        background -- only when viewing sound is on and the channel
        actually has a stream URL. No URL means silence (the demo
        channels have none); nothing is faked, and a missing player
        just means no audio. start_offset (seconds) is where a
        movie / show resumes or seeks to."""
        self.epg_stop_audio()
        if not viewing_sound_on():
            return
        url = (ch or {}).get("url") or ""
        if not url:
            return
        player = shutil.which("mpv") or shutil.which("ffplay")
        if not player:
            return
        try:
            if player.endswith("mpv"):
                args = [player, "--no-video", "--really-quiet"]
                if start_offset:
                    args.append("--start=%d" % int(start_offset))
                args.append(url)
            else:
                args = [player, "-nodisp", "-autoexit", "-loglevel",
                        "quiet"]
                if start_offset:
                    args += ["-ss", str(int(start_offset))]
                args.append(url)
            self.epg_preview_proc = _spawn(
                args, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL)
        except Exception:
            self.epg_preview_proc = None

    def epg_stop_audio(self):
        proc = getattr(self, "epg_preview_proc", None)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass
            self.epg_preview_proc = None

    def epg_open_options(self):
        if self.epg_options_revealer is None:
            self.build_options_revealer("epg")
        self.build_options_content("epg")
        self.epg_options_revealer.set_reveal_child(True)
        self.epg_options_open = True
        play_ui_sound("open", page="epg")

    def epg_close_options(self):
        if self.epg_options_revealer is not None:
            self.epg_options_revealer.set_reveal_child(False)
        self.epg_options_open = False

    def epg_set_theme(self, name):
        self.settings["epg_color"] = name
        save_settings(self.settings)
        self.epg_apply_theme()

    def epg_set_preview_behavior(self, mode):
        self.settings["epg_preview_behavior"] = mode
        save_settings(self.settings)

    def epg_set_viewing_sound(self, on):
        self.settings["viewing_sound"] = bool(on)
        save_settings(self.settings)
        if not on:
            self.epg_stop_audio()
        else:
            ch = self.epg_focused_channel()
            if ch is not None:
                self.epg_start_audio(ch)

    def epg_set_system_sounds(self, on):
        self.settings["epg_system_sounds"] = bool(on)
        save_settings(self.settings)

    def epg_set_sound_set(self, name):
        self.settings["epg_sound_set"] = name
        save_settings(self.settings)
        preview_sound_set(name, page="epg")

    # -- Channel player (full-screen, from the EPG) ---------------------------
    # OK on a channel (or a click on the preview / a channel) opens
    # the channel full-screen here. D-pad Down brings up the bottom
    # overlay: FULL SCREEN, 16:9, STOP, REWIND, RECORD, SCREEN SIZE.
    # Back from the player returns to the EPG guide (not the home
    # screen -- that is one more Back from the guide).
    PLAYER_SIZES = ["Small", "Medium", "Large", "Full"]
    # Display modes on the ASPECT button: 16:9 and 4:3 are aspect
    # ratios; 1080p and 4K are display-resolution modes for the
    # picture (the stream's own resolution comes from the source).
    PLAYER_ASPECTS = ["16:9", "4:3", "1080p", "4K"]

    def build_player_view(self):
        """Full-screen player: the channel art as the picture, the
        channel/program info on top, and the bottom playback bar
        (hidden until D-pad Down)."""
        view = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        view.get_style_context().add_class("player-view")
        view.set_halign(Gtk.Align.FILL)
        view.set_valign(Gtk.Align.FILL)
        # Top info bar (hidden in full-screen mode).
        self.player_info_bar = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        self.player_info_bar.set_margin_start(40)
        self.player_info_bar.set_margin_end(40)
        self.player_info_bar.set_margin_top(24)
        self.player_chan_label = Gtk.Label(label="")
        self.player_chan_label.get_style_context().add_class(
            "player-chan")
        self.player_chan_label.set_halign(Gtk.Align.START)
        self.player_info_bar.pack_start(
            self.player_chan_label, False, False, 0)
        self.player_prog_label = Gtk.Label(label="")
        self.player_prog_label.get_style_context().add_class(
            "player-prog")
        self.player_prog_label.set_halign(Gtk.Align.START)
        self.player_info_bar.pack_start(
            self.player_prog_label, False, False, 0)
        live = Gtk.Label(label="")
        live.set_markup("<span color='#ff5a5a'>●</span> LIVE")
        live.get_style_context().add_class("player-live")
        # show_all() must not force this visible for a movie / show
        # -- the badge is live TV only.
        live.set_no_show_all(True)
        self.player_live_label = live
        self.player_info_bar.pack_start(live, False, False, 0)
        view.pack_start(self.player_info_bar, False, False, 0)
        # The picture: the channel's art, centred, sized by the
        # aspect + screen-size settings.
        self.player_pic_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL)
        self.player_pic_box.set_halign(Gtk.Align.CENTER)
        self.player_pic_box.set_valign(Gtk.Align.CENTER)
        self.player_pic_box.set_vexpand(True)
        self.player_pic = Gtk.Image()
        self.player_pic_box.pack_start(
            self.player_pic, True, True, 0)
        view.pack_start(self.player_pic_box, True, True, 0)
        # Bottom playback overlay (Revealer, slides up). Completely
        # translucent, only near the bottom: the buttons row, then
        # the runtime line (elapsed / seek bar / duration) below it.
        self.player_overlay_revealer = Gtk.Revealer()
        self.player_overlay_revealer.set_transition_type(
            Gtk.RevealerTransitionType.SLIDE_UP)
        self.player_overlay_revealer.set_transition_duration(200)
        overlay_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                              spacing=0)
        overlay_box.get_style_context().add_class("playback-bar")
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                      spacing=12)
        bar.set_halign(Gtk.Align.FILL)
        self.player_full_btn = Gtk.Button(label="FULL SCREEN")
        self.player_full_btn.get_style_context().add_class(
            "playback-btn")
        self.player_full_btn.connect(
            "clicked", lambda w: self.player_toggle_fullscreen())
        bar.pack_start(self.player_full_btn, False, False, 0)
        self.player_pause_btn = Gtk.Button(label="⏸ Pause")
        self.player_pause_btn.get_style_context().add_class(
            "playback-btn")
        self.player_pause_btn.connect(
            "clicked", lambda w: self.player_toggle_pause())
        bar.pack_start(self.player_pause_btn, False, False, 0)
        self.player_aspect_btn = Gtk.Button(label="16:9")
        self.player_aspect_btn.get_style_context().add_class(
            "playback-btn")
        self.player_aspect_btn.connect(
            "clicked", lambda w: self.player_cycle_aspect())
        bar.pack_start(self.player_aspect_btn, False, False, 0)
        stop_btn = Gtk.Button(label="STOP")
        stop_btn.get_style_context().add_class("playback-btn")
        stop_btn.connect("clicked", lambda w: self.player_stop())
        bar.pack_start(stop_btn, False, False, 0)
        rew_btn = Gtk.Button(label="REWIND")
        rew_btn.get_style_context().add_class("playback-btn")
        rew_btn.connect("clicked", lambda w: self.player_rewind())
        bar.pack_start(rew_btn, False, False, 0)
        self.player_rec_btn = Gtk.Button(label="RECORD")
        self.player_rec_btn.get_style_context().add_class(
            "playback-btn")
        self.player_rec_btn.connect(
            "clicked", lambda w: self.player_record())
        bar.pack_start(self.player_rec_btn, False, False, 0)
        size_btn = Gtk.Button(label="SCREEN SIZE")
        size_btn.get_style_context().add_class("playback-btn")
        size_btn.connect(
            "clicked", lambda w: self.player_screen_size())
        bar.pack_start(size_btn, False, False, 0)
        self.player_sound_btn = Gtk.Button(label="Sound: ON")
        self.player_sound_btn.get_style_context().add_class(
            "playback-btn")
        self.player_sound_btn.connect(
            "clicked", lambda w: self.player_toggle_sound())
        bar.pack_start(self.player_sound_btn, False, False, 0)
        self.player_status = Gtk.Label(label="")
        self.player_status.get_style_context().add_class(
            "player-status")
        self.player_status.set_halign(Gtk.Align.START)
        bar.pack_start(self.player_status, True, True, 0)
        overlay_box.pack_start(bar, False, False, 0)
        # Runtime line below the buttons: elapsed time, the seek
        # bar, duration -- like any streaming service. Down from
        # the buttons moves focus onto it; Left / Right there
        # fast-forwards and rewinds.
        runtime = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=12)
        runtime.get_style_context().add_class("playback-runtime")
        self.player_elapsed_label = Gtk.Label(label="0:00")
        self.player_elapsed_label.get_style_context().add_class(
            "player-time")
        runtime.pack_start(self.player_elapsed_label, False, False, 0)
        self.player_seek_scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.player_seek_scale.set_draw_value(False)
        self.player_seek_scale.get_style_context().add_class(
            "playback-seek")
        self.player_seek_scale.set_hexpand(True)
        self.player_seek_scale.connect(
            "value-changed", lambda w: self.on_player_seek_changed())
        # Arrow keys while the runtime line has focus: the scale's
        # own bindings would eat them as 1s nudges before the
        # window's on_key ever runs, so intercept them here --
        # Left/Right fast-forward/rewind 10s, Up goes back to the
        # playback buttons, Down stays put.
        self.player_seek_scale.connect(
            "key-press-event", self._on_player_seek_key)
        runtime.pack_start(self.player_seek_scale, True, True, 0)
        self.player_duration_label = Gtk.Label(label="—:—")
        self.player_duration_label.get_style_context().add_class(
            "player-time")
        runtime.pack_start(self.player_duration_label, False, False, 0)
        overlay_box.pack_start(runtime, False, False, 0)
        self.player_overlay_revealer.add(overlay_box)
        self.player_overlay_revealer.set_reveal_child(False)
        view.pack_start(self.player_overlay_revealer, False, False, 0)
        self.player_view = view
        self.overlay.add_overlay(view)
        view.hide()

    def open_player(self, channel, live=True):
        """Play a channel / title full-screen (from the EPG, or from
        a title's detail page). The picture is the channel's art (or
        the title's poster); the audio is the stream when one is
        available and viewing sound is on. There is no real stream
        for the demo channels, so they play silent with their art --
        the wiring (audio starts for a real stream) is what is
        verified here, not a faked picture. This is the full-screen
        "on the program" state: the playback controls (OK
        play/pause, D-pad-down overlay, runtime line) live here,
        not in the EPG guide."""
        if self.player_view is None:
            self.build_player_view()
        self.player_channel = channel
        self.player_is_live = bool(live)
        self.player_return_to = "epg" if live else "detail"
        self.player_fullscreen = False
        self.player_overlay_open = False
        self.player_overlay_revealer.set_reveal_child(False)
        self.player_info_bar.show()
        self.player_chan_label.set_text(channel["name"])
        self.player_prog_label.set_text("  " + channel["program"])
        self.player_status.set_text("")
        if self.player_live_label is not None:
            self.player_live_label.set_visible(bool(live))
        # Playback state: fresh position, playing, duration only
        # when the source knows the runtime (VOD titles).
        self.player_paused = False
        self.player_position = 0.0
        self.player_duration = channel.get("duration") or None
        if self.player_pause_btn is not None:
            self.player_pause_btn.set_label("⏸ Pause")
        self._update_player_runtime()
        self._start_player_tick()
        self._player_apply_picture()
        self._player_apply_sound_btn()
        self.player_view.show_all()
        # show_all re-shows the hidden playback bar; hide it again
        # until D-pad Down brings it up.
        self.player_overlay_revealer.set_reveal_child(False)
        self.player_open = True
        if channel.get("url") and shutil.which("mpv"):
            # Real stream: full-screen video in mpv (controller keys in
            # /etc/mpv/input.conf: A pause, B back, D-pad seek / volume).
            # Back in mpv returns here (EPG / detail page).
            self._play_video(channel)
            play_ui_sound("open", page=channel.get(
                "page", "epg" if live else "movies"))
            return
        if not channel.get("url"):
            self.player_status.set_text(
                "Demo channel -- no stream. Connect your IPTV source in "
                "the Flight Deck (IPTV) to watch.")
        self.epg_start_audio(channel)
        play_ui_sound("open",
                      page=channel.get("page", "epg" if live else "movies"))

    def _play_video(self, channel):
        self.epg_stop_audio()
        args = ["mpv", "--fs", "--force-window=immediate",
                "--title=Aero Deck -- %s" % channel.get("name", ""),
                "--really-quiet", "--hwdec=auto-safe",
                "--input-default-bindings=yes"]
        if channel.get("start"):
            args.append("--start=%d" % int(channel["start"]))
        args.append(channel["url"])
        proc = _spawn(args, stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)
        if proc is None:
            self.player_status.set_text("Couldn't start the video player.")
            return
        self._video_proc = proc
        self._video_t0 = time.time()

        def watch():
            if proc.poll() is None:
                return True
            self._video_proc = None
            # Rough resume point for movies / shows.
            pg = channel.get("page")
            if pg in ("movies", "shows") and channel.get("duration"):
                try:
                    dur = float(channel["duration"]) * 60
                    done = time.time() - self._video_t0 + \
                        float(channel.get("start") or 0)
                    set_resume(pg, channel["name"],
                               int(min(100, 100 * done / dur)))
                except Exception:
                    pass
            self.close_player()
            self.present()
            return False
        GLib.timeout_add(500, watch)

    def close_player(self):
        """Back from a channel returns to where it came from: the
        EPG guide for live TV, the title detail page for a movie /
        show."""
        if not self.player_open:
            return
        self._stop_player_tick()
        self.player_stop_record()
        self.epg_stop_audio()
        vp = getattr(self, "_video_proc", None)
        if vp is not None and vp.poll() is None:
            vp.terminate()
        self._video_proc = None
        if self.player_view is not None:
            self.player_view.hide()
        self.player_open = False
        self.player_overlay_open = False
        play_ui_sound("click", page="epg")
        if self.player_return_to == "detail" \
                and self.player_detail_return is not None:
            # The detail page is still underneath; just mark it open
            # again (its view was never hidden, only covered).
            self.title_detail_open = self.player_detail_return
            self.player_return_to = "epg"
        elif self.epg_open:
            # The EPG is still open underneath; refresh its preview.
            self.epg_update_preview()

    def player_stop(self):
        """STOP: stop playback and return to the EPG guide."""
        self.close_player()

    def player_toggle_overlay(self):
        """D-pad Down (and Up to hide it again): the bottom overlay
        with FULL SCREEN, 16:9, STOP, REWIND, RECORD, SCREEN SIZE."""
        self.player_overlay_open = not self.player_overlay_open
        self.player_overlay_revealer.set_reveal_child(
            self.player_overlay_open)
        play_ui_sound("click", page="epg")
        if self.player_overlay_open:
            self.player_full_btn.grab_focus()
        else:
            # Focus must leave the bar when it hides, or the next
            # OK would re-trigger the hidden button instead of
            # pausing playback.
            self.set_focus(None)

    # -- Playback controls (full-screen watching only) -----------------------
    # OK = play / pause. D-pad Down opens the translucent bottom
    # overlay; Down again (from the buttons) moves onto the runtime
    # line. Left / Right = fast-forward / rewind. These controls
    # live ONLY here, while actually watching a program full
    # screen -- the EPG guide keeps its own navigation.
    def player_toggle_pause(self):
        """OK while watching: pause / resume playback. The audio
        process is frozen (SIGSTOP) and thawed (SIGCONT) -- a real
        pause, not a muted pretence."""
        self.player_paused = not self.player_paused
        proc = getattr(self, "epg_preview_proc", None)
        if proc is not None:
            try:
                import signal as _signal
                proc.send_signal(
                    _signal.SIGSTOP if self.player_paused
                    else _signal.SIGCONT)
            except Exception:
                pass
        if self.player_pause_btn is not None:
            self.player_pause_btn.set_label(
                "▶ Play" if self.player_paused else "⏸ Pause")
        self.player_status.set_text(
            "Paused" if self.player_paused else "Playing")
        play_ui_sound("click", page="epg")

    def player_seek(self, delta):
        """D-pad Forward / Back: fast-forward / rewind by `delta`
        seconds. Live TV has no DVR buffer, so there is nothing to
        seek -- the bar says so. A movie / show seeks for real: the
        audio restarts at the new position."""
        if self.player_is_live:
            self.player_status.set_text(
                "Rewind is not available for live TV.")
            play_ui_sound("click", page="epg")
            return
        self.player_seek_to(self.player_position + delta)

    def player_seek_to(self, pos):
        """Seek to an absolute position (seconds). Clamped to the
        runtime when it is known."""
        if self.player_duration:
            pos = max(0.0, min(float(self.player_duration), float(pos)))
        else:
            pos = max(0.0, float(pos))
        self.player_position = pos
        ch = self.player_channel
        if ch is not None and (ch.get("url") or ""):
            self.epg_start_audio(ch, start_offset=int(pos))
        self._update_player_runtime()
        self.player_status.set_text(
            "⏩ %s" % _fmt_clock(pos) if pos > 0 else "")
        play_ui_sound("click", page="epg")

    def _on_player_seek_key(self, widget, event):
        """Arrow keys while the runtime line (seek scale) has focus.
        Runs before the scale's own key bindings, which would
        otherwise eat Left/Right as 1s nudges and Up/Down as
        value changes instead of moving focus."""
        keyval = event.keyval
        if keyval in (Gdk.KEY_Left, Gdk.KEY_KP_Left):
            self.player_seek(-10)
            return True
        if keyval in (Gdk.KEY_Right, Gdk.KEY_KP_Right):
            self.player_seek(10)
            return True
        if keyval in (Gdk.KEY_Up, Gdk.KEY_KP_Up):
            if self.player_full_btn is not None:
                self.player_full_btn.grab_focus()
            return True
        if keyval in (Gdk.KEY_Down, Gdk.KEY_KP_Down):
            return True
        return False

    def on_player_seek_changed(self):
        """The runtime line's seek bar was moved: seek there (VOD
        only -- live TV cannot seek, so the bar snaps back)."""
        if getattr(self, "player_seek_guard", False):
            return
        scale = getattr(self, "player_seek_scale", None)
        if scale is None or not self.player_open:
            return
        if self.player_is_live:
            self.player_status.set_text(
                "Rewind is not available for live TV.")
            self._update_player_runtime()
            return
        self.player_seek_to(scale.get_value())

    def _start_player_tick(self):
        """One-second tick: advances the runtime line while playing."""
        self._stop_player_tick()

        def tick():
            if not self.player_open:
                return False
            if not self.player_paused:
                self.player_position += 1
                if self.player_duration and \
                        self.player_position >= self.player_duration:
                    self.player_position = float(self.player_duration)
                    self.player_paused = True
                    if self.player_pause_btn is not None:
                        self.player_pause_btn.set_label("▶ Play")
                    self.player_status.set_text("Finished")
                self._update_player_runtime()
            return True

        self.player_tick_id = GLib.timeout_add(1000, tick)

    def _stop_player_tick(self):
        if getattr(self, "player_tick_id", None) is not None:
            try:
                GLib.source_remove(self.player_tick_id)
            except Exception:
                pass
            self.player_tick_id = None

    def _update_player_runtime(self):
        """Refresh the runtime line: elapsed / seek bar / duration."""
        elapsed = getattr(self, "player_elapsed_label", None)
        if elapsed is not None:
            elapsed.set_text(_fmt_clock(self.player_position))
        duration = getattr(self, "player_duration_label", None)
        if duration is not None:
            duration.set_text(
                _fmt_clock(self.player_duration)
                if self.player_duration else "LIVE")
        scale = getattr(self, "player_seek_scale", None)
        if scale is not None:
            upper = float(self.player_duration) if self.player_duration \
                else max(60.0, self.player_position + 60.0)
            self.player_seek_guard = True
            try:
                adj = scale.get_adjustment()
                adj.set_upper(upper)
                scale.set_value(min(self.player_position, upper))
            finally:
                self.player_seek_guard = False

    def _focus_on_player_seek(self):
        """Is keyboard focus on the runtime line's seek bar?"""
        focus = self.get_focus()
        scale = getattr(self, "player_seek_scale", None)
        return focus is not None and scale is not None \
            and focus is scale

    def player_toggle_fullscreen(self):
        """FULL SCREEN: hide the info bar so the picture fills the
        screen; press again to bring the info back."""
        self.player_fullscreen = not self.player_fullscreen
        if self.player_fullscreen:
            self.player_info_bar.hide()
        else:
            self.player_info_bar.show()
        play_ui_sound("click", page="epg")

    def player_cycle_aspect(self):
        """ASPECT: cycle the display mode -- 16:9, 4:3, 1080p, 4K.
        16:9 / 4:3 change the picture's shape; 1080p / 4K are the
        display-resolution modes (the stream's own resolution still
        comes from the source)."""
        idx = self.PLAYER_ASPECTS.index(self.player_aspect)
        self.player_aspect = self.PLAYER_ASPECTS[
            (idx + 1) % len(self.PLAYER_ASPECTS)]
        self.player_aspect_btn.set_label(self.player_aspect)
        self._player_apply_picture()
        if self.player_aspect in ("1080p", "4K"):
            self.player_status.set_text(
                "Display mode: %s" % self.player_aspect)
        play_ui_sound("click", page="epg")

    def player_screen_size(self):
        """SCREEN SIZE: cycle the picture size Small / Medium / Large
        / Full."""
        idx = self.PLAYER_SIZES.index(self.player_size)
        self.player_size = self.PLAYER_SIZES[
            (idx + 1) % len(self.PLAYER_SIZES)]
        self._player_apply_picture()
        self.player_status.set_text("Size: %s" % self.player_size)
        play_ui_sound("click", page="epg")

    def _player_apply_picture(self):
        """Size the picture to the current aspect + screen size. A
        movie / show shows its poster; a live channel its art."""
        if self.player_channel is None:
            return
        sizes = {"Small": (640, 360), "Medium": (960, 540),
                 "Large": (1280, 720), "Full": (1820, 1020)}
        w, h = sizes[self.player_size]
        if self.player_aspect == "4:3":
            w = int(h * 4 / 3)
        pix = None
        if not self.player_is_live:
            pix = self.load_poster_image(
                self.player_channel["name"], w, h)
        if pix is None:
            pix = self.load_channel_logo(
                self.player_channel["name"], w, h)
        if pix is not None:
            self.player_pic.set_from_pixbuf(pix)
        else:
            self.player_pic.clear()
        self.player_pic.set_size_request(w, h)

    def _player_apply_sound_btn(self):
        self.player_sound_btn.set_label(
            "Sound: ON" if viewing_sound_on() else "Sound: OFF")

    def player_toggle_sound(self):
        """Viewing sound on/off, right on the playback bar."""
        self.epg_set_viewing_sound(not viewing_sound_on())
        self._player_apply_sound_btn()
        if viewing_sound_on() and self.player_channel is not None:
            self.epg_start_audio(self.player_channel)

    def player_rewind(self):
        """REWIND button: live TV has no DVR buffer, so there is
        nothing to rewind -- the bar says so instead of pretending.
        A movie / show rewinds 10 seconds."""
        if not self.player_is_live:
            self.player_seek(-10)
            return
        self.player_status.set_text(
            "Rewind is not available for live TV.")
        play_ui_sound("click", page="epg")

    def player_record(self):
        """RECORD: with a real stream URL, mpv records the stream to
        ~/Videos/Aero Deck Recordings; without one (the demo
        channels) it says so. Press again to stop recording."""
        if self.player_record_proc is not None:
            self.player_stop_record()
            return
        ch = self.player_channel
        url = (ch or {}).get("url") or ""
        if not url:
            self.player_status.set_text(
                "Recording needs a live stream -- not available "
                "for this channel.")
            play_ui_sound("click", page="epg")
            return
        try:
            rec_dir = Path.home() / "Videos" / "Aero Deck Recordings"
            rec_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
            out = rec_dir / ("%s-%s.ts" % (
                re.sub(r"[^A-Za-z0-9]+", "-", ch["name"]).strip("-"),
                stamp))
            player = shutil.which("mpv")
            if not player:
                self.player_status.set_text(
                    "Recording needs mpv -- not installed.")
                return
            self.player_record_proc = _spawn(
                [player, "--no-video", "--really-quiet",
                 "--stream-record=%s" % out, url],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if self.player_record_proc is None:
                self.player_status.set_text("Recording failed to start.")
                play_ui_sound("click", page="epg")
                return
            self.player_rec_btn.set_label("● REC")
            self.player_status.set_text("Recording to %s" % out.name)
        except Exception:
            self.player_record_proc = None
            self.player_status.set_text("Recording failed to start.")
        play_ui_sound("click", page="epg")

    def player_stop_record(self):
        proc = getattr(self, "player_record_proc", None)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass
            self.player_record_proc = None
        if getattr(self, "player_rec_btn", None) is not None:
            self.player_rec_btn.set_label("RECORD")

    def _focus_in_player_bar(self):
        """Is keyboard focus on one of the bottom playback buttons?
        (Used so Down/Up do not close the overlay while the user is
        moving between its buttons.)"""
        focus = self.get_focus()
        bar = getattr(self, "player_overlay_revealer", None)
        if focus is None or bar is None:
            return False
        w = focus
        while w is not None:
            if w is bar:
                return True
            w = w.get_parent()
        return False

    # -- Shared options panels (top-down, per page, checkboxes) --------------
    # Every full-screen page has its OWN top-down options panel, and
    # each panel shows ONLY that page's own listings / categories
    # (context-aware): the EPG panel shows live channels, the Movies
    # panel shows movies, the Shows panel shows shows. All pickers
    # are CHECKBOXES (check / uncheck) -- no drop-downs, no complex
    # menus. Each panel also carries that page's own sound OFF button.
    def build_options_revealer(self, page_kind):
        """The top-down options panel shell for a page ('epg' /
        'movies' / 'shows'). Slides down from the top; the content
        is rebuilt fresh each time it opens."""
        revealer = Gtk.Revealer()
        revealer.set_transition_type(Gtk.RevealerTransitionType.SLIDE_DOWN)
        revealer.set_transition_duration(250)
        revealer.set_halign(Gtk.Align.CENTER)
        revealer.set_valign(Gtk.Align.START)
        revealer.set_reveal_child(False)
        self.overlay.add_overlay(revealer)
        if page_kind == "epg":
            self.epg_options_revealer = revealer
        else:
            self.title_options_revealers[page_kind] = revealer
        return revealer

    def _options_revealer(self, page_kind):
        if page_kind == "epg":
            return self.epg_options_revealer
        return self.title_options_revealers.get(page_kind)

    def build_options_content(self, page_kind):
        """Rebuild a page's options panel content (fresh each open,
        so every checkbox reflects the current state)."""
        revealer = self._options_revealer(page_kind)
        if revealer is None:
            revealer = self.build_options_revealer(page_kind)
        for child in revealer.get_children():
            revealer.remove(child)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=12)
        content.get_style_context().add_class("epg-options-panel")
        titles = {"epg": "Guide Options", "movies": "Movies Options",
                  "shows": "TV Shows Options"}
        head = Gtk.Label(label=titles.get(page_kind, "Options"))
        head.get_style_context().add_class("epg-options-title")
        head.set_halign(Gtk.Align.START)
        content.pack_start(head, False, False, 0)
        # Theme (per page, independent): swatch + checkbox per theme.
        theme_label = Gtk.Label(
            label={"epg": "Guide theme", "movies": "Movies theme",
                   "shows": "Shows theme"}.get(page_kind, "Theme"))
        theme_label.get_style_context().add_class(
            "epg-options-section")
        theme_label.set_halign(Gtk.Align.START)
        content.pack_start(theme_label, False, False, 0)
        content.pack_start(
            self._theme_section(page_kind), False, False, 0)
        # Sound (per page, independent): on/off checkbox + OFF
        # button + sound-set checkboxes.
        sound_label = Gtk.Label(label="Sound")
        sound_label.get_style_context().add_class(
            "epg-options-section")
        sound_label.set_halign(Gtk.Align.START)
        content.pack_start(sound_label, False, False, 0)
        content.pack_start(
            self._sound_section(page_kind), False, False, 0)
        if page_kind == "epg":
            self._epg_options_extra(content)
        else:
            self._title_options_extra(page_kind, content)
        close_btn = Gtk.Button(label="Close")
        close_btn.get_style_context().add_class("epg-opt-btn")
        if page_kind == "epg":
            close_btn.connect("clicked",
                              lambda w: self.epg_close_options())
        else:
            close_btn.connect(
                "clicked",
                lambda w, k=page_kind: self.title_page_close_options(k))
        content.pack_start(close_btn, False, False, 0)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER,
                          Gtk.PolicyType.AUTOMATIC)
        scroll.set_size_request(900, 860)
        scroll.set_min_content_height(860)
        scroll.add(content)
        revealer.add(scroll)
        revealer.show_all()

    def _theme_section(self, page_kind):
        """A page's theme picker: one checkbox row per theme, each
        with its colour swatch (background + border highlight) and
        name. Checking one picks that theme (exclusive)."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        cur = self.settings.get("%s_color" % page_kind, "Navy")
        btns = []

        def on_pick(name):
            if page_kind == "epg":
                self.epg_set_theme(name)
            else:
                self.title_page_set_theme(page_kind, name)

        def on_toggled(btn, name):
            if btn.get_active():
                for _n, b in btns:
                    if b is not btn:
                        b.set_active(False)
                on_pick(name)

        for name in PAGE_THEME_NAMES:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=10)
            sw = Gtk.EventBox()
            sw.get_style_context().add_class("theme-swatch")
            sw.get_style_context().add_class(
                "theme-swatch-" + name.lower())
            sw.set_size_request(64, 44)
            row.pack_start(sw, False, False, 0)
            b = Gtk.CheckButton(label=name)
            b.set_active(name == cur)
            b.connect("toggled", on_toggled, name)
            btns.append((name, b))
            row.pack_start(b, False, False, 0)
            box.pack_start(row, False, False, 0)
        return box

    def _sound_section(self, page_kind):
        """A page's sound controls: the on/off checkbox, the OFF
        button (turns that page's sound off / back on), and the
        sound-set picker (one checkbox per set, exclusive).
        page_kind is 'epg' / 'movies' / 'shows' / None (the main
        Interface, used by the Flight Deck Sound page)."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        on_key = ("%s_system_sounds" % page_kind) if page_kind \
            else "system_sounds"
        set_key = ("%s_sound_set" % page_kind) if page_kind \
            else "sound_set"
        snd_check = Gtk.CheckButton(label="System sounds")
        snd_check.set_active(bool(self.settings.get(on_key, True)))
        off_btn = Gtk.Button()

        def refresh_off():
            on = bool(self.settings.get(on_key, True))
            off_btn.set_label(
                "Turn sound OFF" if on else "Turn sound ON")
            if snd_check.get_active() != on:
                snd_check.set_active(on)

        def on_snd_toggled(btn):
            self.settings[on_key] = btn.get_active()
            save_settings(self.settings)
            refresh_off()

        snd_check.connect("toggled", on_snd_toggled)

        def on_off_clicked(btn):
            self.settings[on_key] = not bool(
                self.settings.get(on_key, True))
            save_settings(self.settings)
            refresh_off()

        off_btn.connect("clicked", on_off_clicked)
        refresh_off()
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                      spacing=16)
        row.pack_start(snd_check, False, False, 0)
        row.pack_start(off_btn, False, False, 0)
        box.pack_start(row, False, False, 0)
        set_label = Gtk.Label(label="Sound set")
        set_label.get_style_context().add_class("epg-options-section")
        set_label.set_halign(Gtk.Align.START)
        box.pack_start(set_label, False, False, 0)
        set_btns = []

        def on_set_toggled(btn, name):
            if btn.get_active():
                for _n, b in set_btns:
                    if b is not btn:
                        b.set_active(False)
                self.settings[set_key] = name
                save_settings(self.settings)
                preview_sound_set(name, page=page_kind)

        for name in SOUND_SET_NAMES:
            b = Gtk.CheckButton(label=name)
            b.set_active(self.settings.get(set_key, "Aero") == name)
            b.connect("toggled", on_set_toggled, name)
            set_btns.append((name, b))
            box.pack_start(b, False, False, 0)
        return box

    def _epg_options_extra(self, content):
        """EPG-only options: preview behavior, viewing sound, star
        this channel, the channels checklist, and the favorites list
        (check to jump to a channel)."""
        # Preview behavior: two checkboxes, exclusive.
        prev_label = Gtk.Label(label="Preview")
        prev_label.get_style_context().add_class("epg-options-section")
        prev_label.set_halign(Gtk.Align.START)
        content.pack_start(prev_label, False, False, 0)
        cur = self.settings.get("epg_preview_behavior", "change")
        prev_btns = []

        def on_prev_toggled(btn, mode):
            if btn.get_active():
                for _m, b in prev_btns:
                    if b is not btn:
                        b.set_active(False)
                self.epg_set_preview_behavior(mode)

        for mode, label in (
                ("change", "Change preview as you scroll"),
                ("stay", "Keep preview on this channel")):
            b = Gtk.CheckButton(label=label)
            b.set_active(cur == mode)
            b.connect("toggled", on_prev_toggled, mode)
            prev_btns.append((mode, b))
            content.pack_start(b, False, False, 0)
        # Viewing sound (the channel audio you are previewing).
        view_check = Gtk.CheckButton(label="Viewing sound")
        view_check.set_active(viewing_sound_on())
        view_check.connect(
            "toggled",
            lambda b: self.epg_set_viewing_sound(b.get_active()))
        content.pack_start(view_check, False, False, 0)
        # Star this channel.
        ch = self.epg_focused_channel()
        if ch is not None:
            star_check = Gtk.CheckButton(
                label="Star this channel (%s)" % ch["name"])
            star_check.set_active(is_epg_favorite(ch["name"]))
            star_check.connect(
                "toggled",
                lambda b: self._epg_star_from_options(b))
            content.pack_start(star_check, False, False, 0)
        # Channels checklist: its own separate section -- check to
        # keep a channel in the guide, uncheck to remove it.
        chan_label = Gtk.Label(
            label="Channels -- check to keep in the guide")
        chan_label.get_style_context().add_class("epg-options-section")
        chan_label.set_halign(Gtk.Align.START)
        content.pack_start(chan_label, False, False, 0)
        for ch in epg_available_channels():
            b = Gtk.CheckButton(label=ch["name"])
            b.set_active(is_epg_channel_kept(ch["name"]))
            b.connect("toggled",
                      lambda btn, n=ch["name"]:
                      self._epg_channel_check(btn, n))
            content.pack_start(b, False, False, 0)
        # Favorites: only live channels, check to jump to one.
        favs = load_epg_favorites()
        if favs:
            fav_label = Gtk.Label(
                label="Favorites -- check to jump to a channel")
            fav_label.get_style_context().add_class(
                "epg-options-section")
            fav_label.set_halign(Gtk.Align.START)
            content.pack_start(fav_label, False, False, 0)
            fav_btns = []

            def on_fav_toggled(btn, name):
                if btn.get_active():
                    for _n, b in fav_btns:
                        if b is not btn:
                            b.set_active(False)
                    self.epg_jump_to_channel(name)

            for name in favs:
                b = Gtk.CheckButton(label=name)
                b.set_active(name == self.epg_preview_name)
                b.connect("toggled", on_fav_toggled, name)
                fav_btns.append((name, b))
                content.pack_start(b, False, False, 0)

    def _epg_star_from_options(self, btn):
        ch = self.epg_focused_channel()
        if ch is None:
            return
        if btn.get_active() and not is_epg_favorite(ch["name"]):
            toggle_epg_favorite(ch["name"])
        elif not btn.get_active() and is_epg_favorite(ch["name"]):
            toggle_epg_favorite(ch["name"])
        self.epg_render()
        self.epg_update_preview()

    def _epg_channel_check(self, btn, name):
        set_epg_channel_kept(name, btn.get_active())
        self.epg_all_channels = epg_channel_list()
        self.epg_apply_search(self.epg_search_query)

    def epg_jump_to_channel(self, name):
        """Jump the guide to a channel (from the favorites list)."""
        for i, ch in enumerate(self.epg_channels):
            if ch["name"] == name:
                self.epg_focus = i
                break
        else:
            # The channel is hidden by the checklist -- bring it back
            # into the guide first, then jump to it.
            set_epg_channel_kept(name, True)
            self.epg_all_channels = epg_channel_list()
            self.epg_channels = list(self.epg_all_channels)
            for i, ch in enumerate(self.epg_channels):
                if ch["name"] == name:
                    self.epg_focus = i
                    break
        self.epg_preview_name = name
        self.epg_render()
        self.epg_update_preview()
        play_ui_sound("click", page="epg")

    def _title_options_extra(self, page_kind, content):
        """Movies / Shows options: the titles checklist and the
        categories checklist (both checkboxes, that page only)."""
        kind_label = "Movies" if page_kind == "movies" else "TV Shows"
        # Titles checklist.
        title_label = Gtk.Label(
            label="%s -- check to keep on this page" % kind_label)
        title_label.get_style_context().add_class("epg-options-section")
        title_label.set_halign(Gtk.Align.START)
        content.pack_start(title_label, False, False, 0)
        state = iptv_source_state()
        if page_kind == "movies":
            base = [(c["name"], "") for c in state["movies"]] \
                if state["initiated"] else [(n, y) for n, y in MOVIES]
        else:
            base = [(c["name"], "") for c in state["shows"]] \
                if state["initiated"] else list(SHOWS)
        for name, _meta in base:
            b = Gtk.CheckButton(label=name)
            b.set_active(is_title_kept(page_kind, name))
            b.connect("toggled",
                      lambda btn, n=name:
                      self._title_check(btn, page_kind, n))
            content.pack_start(b, False, False, 0)
        # Categories checklist.
        cat_label = Gtk.Label(label="Categories -- check to show")
        cat_label.get_style_context().add_class("epg-options-section")
        cat_label.set_halign(Gtk.Align.START)
        content.pack_start(cat_label, False, False, 0)
        shown = self.settings.get(
            "%s_categories" % page_kind, title_section_names(page_kind))
        for section in title_section_names(page_kind):
            b = Gtk.CheckButton(label=section)
            b.set_active(section in shown)
            b.connect("toggled",
                      lambda btn, s=section:
                      self._title_category_check(btn, page_kind, s))
            content.pack_start(b, False, False, 0)

    def _title_check(self, btn, kind, title):
        set_title_kept(kind, title, btn.get_active())
        self.title_page_render(kind)

    def _title_category_check(self, btn, kind, section):
        shown = list(self.settings.get(
            "%s_categories" % kind, title_section_names(kind)))
        if btn.get_active() and section not in shown:
            shown.append(section)
        elif not btn.get_active() and section in shown:
            shown.remove(section)
        # Keep the page order.
        order = title_section_names(kind)
        shown = [s for s in order if s in shown]
        self.settings["%s_categories" % kind] = shown
        save_settings(self.settings)
        self.title_page_render(kind)

    def title_page_set_theme(self, kind, name):
        self.settings["%s_color" % kind] = name
        save_settings(self.settings)
        page = self.title_pages.get(kind)
        if page is not None:
            self._apply_page_theme(page["view"], name)

    def title_page_set_system_sounds(self, kind, on):
        self.settings["%s_system_sounds" % kind] = bool(on)
        save_settings(self.settings)

    def title_page_set_sound_set(self, kind, name):
        self.settings["%s_sound_set" % kind] = name
        save_settings(self.settings)
        preview_sound_set(name, page=kind)

    # -- Dedicated Movies / Shows pages --------------------------------------
    # One separate full page per kind (like Live TV opens the EPG).
    # Sections: Popular, New, Genre, Favorites, Resume (continue
    # watching). Back returns to the main page. Games and Social do
    # NOT get pages -- they open their individual apps.
    def build_title_page(self, kind):
        title = "Movies" if kind == "movies" else "TV Shows"
        view = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        view.get_style_context().add_class("title-page")
        view.set_halign(Gtk.Align.FILL)
        view.set_valign(Gtk.Align.FILL)
        # Edge-to-edge (breathing room comes from the .title-page
        # CSS padding) so nothing underneath shows through.
        view.set_margin_start(0)
        view.set_margin_end(0)
        view.set_margin_top(0)
        view.set_margin_bottom(0)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                         spacing=16)
        back_btn = Gtk.Button(label="‹ Back")
        back_btn.get_style_context().add_class("epg-opt-btn")
        back_btn.connect("clicked", lambda w: self.close_title_page())
        header.pack_start(back_btn, False, False, 0)
        head = Gtk.Label(label=title)
        head.get_style_context().add_class("title-page-heading")
        head.set_halign(Gtk.Align.START)
        header.pack_start(head, False, False, 0)
        # This page's OWN search, at the very top center: it searches
        # ONLY this page's content (movies here, shows on the Shows
        # page, live TV in the guide) -- never the other pages.
        search = Gtk.Entry()
        search.set_placeholder_text("Search %s..." % title.lower())
        search.get_style_context().add_class("epg-search")
        search.set_halign(Gtk.Align.CENTER)
        search.set_size_request(420, -1)
        search.connect(
            "changed",
            lambda w, k=kind: self.on_title_search(k))
        search.connect(
            "activate",
            lambda w, k=kind: self.on_title_search_activate(k))
        search.connect(
            "focus-in-event",
            lambda w, e, k=kind: self.on_title_search_focus_in(k))
        header.pack_start(search, True, True, 0)
        self.title_search_entry[kind] = search
        search._navigator_field = True
        opt_btn = Gtk.Button(label="Options")
        opt_btn.get_style_context().add_class("epg-opt-btn")
        opt_btn.connect(
            "clicked",
            lambda w, k=kind: self.title_page_open_options(k))
        header.pack_start(opt_btn, False, False, 0)
        view.pack_start(header, False, False, 0)
        hint = Gtk.Label(label="")
        hint.get_style_context().add_class("epg-iptv-hint")
        hint.set_halign(Gtk.Align.START)
        hint.set_margin_top(6)
        view.pack_start(hint, False, False, 0)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER,
                          Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        scroll.set_margin_top(12)
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=28)
        scroll.add(content)
        view.pack_start(scroll, True, True, 0)
        self.title_pages[kind] = {"view": view, "scroll": scroll,
                                  "content": content, "hint": hint,
                                  "genre_sel": None}
        self.overlay.add_overlay(view)
        view.hide()
        self.build_options_revealer(kind)
        return view

    def open_title_page(self, kind, focus_title=None):
        """Open a dedicated Movies / Shows page."""
        if kind not in self.title_pages:
            self.build_title_page(kind)
        page = self.title_pages[kind]
        self._apply_page_theme(
            page["view"], self.settings.get("%s_color" % kind, "Navy"))
        # A stale detail page from another title cannot stay up
        # under this page.
        if self.title_detail_open is not None:
            self.close_title_detail()
        # Fresh search each open (like the guide).
        self.title_search[kind] = ""
        entry = self.title_search_entry.get(kind)
        if entry is not None:
            entry.set_text("")
        self.title_page_open = kind
        self.title_page_render(kind)
        page["view"].show_all()
        if focus_title:
            self.title_focus[kind] = focus_title
        play_ui_sound("open", page=kind)

    def close_title_page(self):
        """Back from a Movies / Shows page returns to the main page."""
        kind = self.title_page_open
        if kind is None:
            return
        if self.title_detail_open is not None:
            self.close_title_detail()
        if self.title_options_open is not None:
            self.title_page_close_options(self.title_options_open)
        page = self.title_pages.get(kind)
        if page is not None:
            page["view"].hide()
        self.title_page_open = None
        play_ui_sound("click", page=kind)
        self.go_home()

    def on_title_search(self, kind):
        """This page's search: filter to titles on THIS page whose
        name matches (movies here, shows on the Shows page)."""
        entry = self.title_search_entry.get(kind)
        self.title_search[kind] = (
            entry.get_text() if entry is not None else "")
        self.title_page_render(kind)

    def on_title_search_activate(self, kind):
        """Return in the page search: leave the entry; the filtered
        results are already showing."""
        self.set_focus(None)

    def on_title_search_focus_in(self, kind, event=None):
        """The page search uses the launcher's on-screen keyboard,
        like every other search entry (click / tap or A / OK only)."""
        entry = self.title_search_entry.get(kind)
        if entry is not None and _event_is_pointer():
            self.show_keyboard(entry)
        return False

    def title_page_scroll(self, delta):
        kind = self.title_page_open
        if kind is None:
            return
        page = self.title_pages.get(kind)
        if page is None:
            return
        adj = page["scroll"].get_vadjustment()
        adj.set_value(max(
            0, min(adj.get_upper() - adj.get_page_size(),
                   adj.get_value() + delta)))
        play_ui_sound("move", page=kind)

    def title_page_render(self, kind):
        """Rebuild a Movies / Shows page from its sections."""
        page = self.title_pages.get(kind)
        if page is None:
            return
        state = iptv_source_state()
        if state["initiated"]:
            page["hint"].set_text("IPTV connected: %s"
                                  % state["source_name"])
        else:
            page["hint"].set_text(
                "IPTV source not connected -- showing built-in "
                "titles. Connect it in the Flight Deck (IPTV) to "
                "load the real catalogue.")
        sections = title_sections(kind)
        shown = self.settings.get(
            "%s_categories" % kind, title_section_names(kind))
        content = page["content"]
        for child in content.get_children():
            content.remove(child)
        query = (self.title_search.get(kind) or "").strip().lower()
        if query:
            # Page search active: one results row of this page's
            # matching titles (across sections, de-duplicated), or
            # a plain "no matches" hint -- never the other pages.
            seen = set()
            matches = []
            for section in title_section_names(kind):
                items = sections.get(section, [])
                if section == "Genre":
                    items = [t for g in items.values() for t in g]
                elif section == "Resume":
                    items = [(e["title"], "") for e in items]
                for name, meta in items:
                    if query in name.lower() and name not in seen:
                        seen.add(name)
                        matches.append((name, meta))
            if matches:
                content.pack_start(
                    self._title_poster_section(
                        kind, "Results for '%s'" % query, matches),
                    False, False, 0)
            else:
                hint = Gtk.Label(
                    label="No matches for '%s' in %s."
                          % (query, "Movies" if kind == "movies"
                             else "TV Shows"))
                hint.get_style_context().add_class("epg-hint")
                hint.set_halign(Gtk.Align.START)
                content.pack_start(hint, False, False, 0)
            content.show_all()
            return
        for section in title_section_names(kind):
            if section not in shown:
                continue
            if section == "Genre":
                content.pack_start(
                    self._title_genre_section(kind, sections),
                    False, False, 0)
            elif section == "Resume":
                content.pack_start(
                    self._title_resume_section(kind, sections),
                    False, False, 0)
            else:
                items = sections.get(section, [])
                content.pack_start(
                    self._title_poster_section(kind, section, items),
                    False, False, 0)
        content.show_all()

    def _title_poster_section(self, kind, heading, items):
        """A titled horizontal poster row (Popular / New /
        Favorites). Empty sections show a hint, never a fake row."""
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=10)
        head = Gtk.Label(label=heading)
        head.get_style_context().add_class("title-section-heading")
        head.set_halign(Gtk.Align.START)
        section.pack_start(head, False, False, 0)
        if not items:
            hint = Gtk.Label(
                label="Nothing here yet." if heading != "Favorites"
                else "No favourites yet -- press F on a title, or "
                     "star it in its details, to add one.")
            hint.get_style_context().add_class("epg-hint")
            hint.set_halign(Gtk.Align.START)
            section.pack_start(hint, False, False, 0)
            return section
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC,
                          Gtk.PolicyType.NEVER)
        scroll.set_size_request(-1, 470)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                      spacing=28)
        for name, meta in items:
            row.pack_start(
                self.title_poster_tile(kind, name, meta),
                False, False, 0)
        scroll.add(row)
        section.pack_start(scroll, False, False, 0)
        return section

    def _title_genre_section(self, kind, sections):
        """Genre browsing: chips for each genre, then the selected
        genre's posters in a grid."""
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=10)
        head = Gtk.Label(label="Genre")
        head.get_style_context().add_class("title-section-heading")
        head.set_halign(Gtk.Align.START)
        section.pack_start(head, False, False, 0)
        genres = sections.get("Genre", {})
        page = self.title_pages[kind]
        if not genres:
            hint = Gtk.Label(label="No genres available.")
            hint.get_style_context().add_class("epg-hint")
            hint.set_halign(Gtk.Align.START)
            section.pack_start(hint, False, False, 0)
            return section
        if page["genre_sel"] not in genres:
            page["genre_sel"] = sorted(genres.keys())[0]
        chips = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                        spacing=12)
        for genre in sorted(genres.keys()):
            chip = Gtk.Button(label=genre)
            chip.get_style_context().add_class("genre-chip")
            if genre == page["genre_sel"]:
                chip.get_style_context().add_class("selected")
            chip.connect("clicked",
                         lambda w, g=genre:
                         self._title_pick_genre(kind, g))
            chips.pack_start(chip, False, False, 0)
        section.pack_start(chips, False, False, 0)
        flow = Gtk.FlowBox()
        flow.set_homogeneous(False)
        flow.set_max_children_per_line(5)
        flow.set_row_spacing(20)
        flow.set_column_spacing(28)
        for name, meta in genres[page["genre_sel"]]:
            flow.add(self.title_poster_tile(kind, name, meta))
        section.pack_start(flow, False, False, 0)
        return section

    def _title_pick_genre(self, kind, genre):
        page = self.title_pages.get(kind)
        if page is None:
            return
        page["genre_sel"] = genre
        play_ui_sound("click", page=kind)
        self.title_page_render(kind)

    def _title_resume_section(self, kind, sections):
        """Resume: titles stopped part-way, with where you stopped
        and a Continue button to pick up where you left off."""
        section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=10)
        head = Gtk.Label(label="Resume")
        head.get_style_context().add_class("title-section-heading")
        head.set_halign(Gtk.Align.START)
        section.pack_start(head, False, False, 0)
        entries = sections.get("Resume", [])
        if not entries:
            hint = Gtk.Label(
                label="Nothing to resume yet -- open a title and it "
                      "will wait here for you to pick up where you "
                      "left off.")
            hint.get_style_context().add_class("epg-hint")
            hint.set_halign(Gtk.Align.START)
            section.pack_start(hint, False, False, 0)
            return section
        for entry in entries:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=16)
            row.get_style_context().add_class("resume-row")
            thumb = self.load_poster_image(entry["title"], 80, 112)
            if thumb is not None:
                row.pack_start(Gtk.Image.new_from_pixbuf(thumb),
                               False, False, 0)
            texts = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                            spacing=4)
            t = Gtk.Label(label=entry["title"])
            t.get_style_context().add_class("resume-title")
            t.set_halign(Gtk.Align.START)
            texts.pack_start(t, False, False, 0)
            meta = Gtk.Label(label="%d%% watched" % entry["progress"])
            meta.get_style_context().add_class("resume-meta")
            meta.set_halign(Gtk.Align.START)
            texts.pack_start(meta, False, False, 0)
            prog = Gtk.ProgressBar()
            prog.set_fraction(entry["progress"] / 100.0)
            prog.set_size_request(220, -1)
            texts.pack_start(prog, False, False, 0)
            row.pack_start(texts, True, True, 0)
            cont = Gtk.Button(label="Continue")
            cont.get_style_context().add_class("epg-opt-btn")
            cont.connect("clicked",
                         lambda w, e=entry:
                         self.open_title_detail(
                             e["kind"], e["title"], ""))
            row.pack_start(cont, False, False, 0)
            rem = Gtk.Button(label="Remove")
            rem.get_style_context().add_class("epg-opt-btn")
            rem.connect("clicked",
                        lambda w, e=entry:
                        self._title_remove_resume(e))
            row.pack_start(rem, False, False, 0)
            section.pack_start(row, False, False, 0)
        return section

    def _title_remove_resume(self, entry):
        clear_resume(entry["kind"], entry["title"])
        play_ui_sound("click", page=entry["kind"])
        self.title_page_render(entry["kind"])

    def title_poster_tile(self, kind, name, meta):
        """A poster tile for a title page: real poster art, the
        resolution badge (4K / 1080p) only when the source knows it,
        and a star when it is a favourite. Clicking opens the title
        details (where you star it and set where you stopped)."""
        tile_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                           spacing=6)
        btn = Gtk.Button()
        btn.set_size_request(280, 392)
        btn.get_style_context().add_class("poster-tile")
        # Tagged so hold-OK can tell a poster from any other button:
        # a quick OK tap opens the detail page, a hold stars it.
        btn._title_kind = kind
        btn._title_name = name
        btn._title_meta = meta
        overlay = Gtk.Overlay()
        poster = self.load_poster_image(name, 280, 392)
        poster = self._rounded_pixbuf(poster, 28)
        if poster is not None:
            overlay.add(Gtk.Image.new_from_pixbuf(poster))
        else:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            lab = Gtk.Label()
            lab.set_markup("<span weight='bold' size='large'>%s</span>"
                           % _esc(name))
            lab.set_line_wrap(True)
            lab.set_max_width_chars(16)
            lab.set_justify(Gtk.Justification.CENTER)
            box.pack_start(lab, True, True, 0)
            overlay.add(box)
        quality = title_quality(kind, name)
        if quality:
            badge = Gtk.Label(label=quality)
            badge.get_style_context().add_class("quality-badge")
            badge.set_halign(Gtk.Align.END)
            badge.set_valign(Gtk.Align.START)
            badge.set_margin_end(10)
            badge.set_margin_top(10)
            overlay.add_overlay(badge)
        if is_title_favorite(kind, name):
            star = Gtk.Label(label="★")
            star.get_style_context().add_class("title-star")
            star.set_halign(Gtk.Align.START)
            star.set_valign(Gtk.Align.START)
            star.set_margin_start(10)
            star.set_margin_top(8)
            overlay.add_overlay(star)
        btn.add(overlay)
        btn.connect("clicked",
                    lambda w: self.open_title_detail(kind, name, meta))
        btn.connect("focus-in-event",
                    lambda w, e: self._title_note_focus(kind, name))
        tile_box.pack_start(btn, False, False, 0)
        name_label = Gtk.Label(label=name)
        # White on the dark page -- NOT app-name (dark plum, made
        # for the light frosted cells of the home screen).
        name_label.get_style_context().add_class("title-name")
        name_label.set_line_wrap(True)
        name_label.set_max_width_chars(28)
        tile_box.pack_start(name_label, False, False, 0)
        return tile_box

    def _title_note_focus(self, kind, name):
        self.title_focus[kind] = name

    def title_toggle_focused_favorite(self):
        """F on a title page: star / un-star the focused title."""
        kind = self.title_page_open
        if kind is None:
            return
        name = self.title_focus.get(kind)
        if not name:
            return
        toggle_title_favorite(kind, name)
        play_ui_sound("click", page=kind)
        self.title_page_render(kind)

    def build_title_detail_view(self):
        """The individual title detail page shell (hidden until a
        poster is opened). One shared view, rebuilt per title."""
        view = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        view.get_style_context().add_class("title-page")
        view.set_halign(Gtk.Align.FILL)
        view.set_valign(Gtk.Align.FILL)
        # Edge-to-edge (breathing room comes from the .title-page
        # CSS padding) so the page underneath never shows through.
        view.set_margin_start(0)
        view.set_margin_end(0)
        view.set_margin_top(0)
        view.set_margin_bottom(0)
        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                         spacing=16)
        back_btn = Gtk.Button(label="‹ Back")
        back_btn.get_style_context().add_class("epg-opt-btn")
        back_btn.connect("clicked", lambda w: self.close_title_detail())
        header.pack_start(back_btn, False, False, 0)
        self.title_detail_heading = Gtk.Label(label="")
        self.title_detail_heading.get_style_context().add_class(
            "title-page-heading")
        self.title_detail_heading.set_halign(Gtk.Align.START)
        header.pack_start(self.title_detail_heading, False, False, 0)
        self.title_detail_quality = Gtk.Label(label="")
        self.title_detail_quality.get_style_context().add_class(
            "quality-badge")
        # show_all() must not force this visible when there is no
        # quality to show -- visibility is set per title in render.
        self.title_detail_quality.set_no_show_all(True)
        header.pack_start(self.title_detail_quality, False, False, 0)
        view.pack_start(header, False, False, 0)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER,
                          Gtk.PolicyType.AUTOMATIC)
        scroll.set_vexpand(True)
        scroll.set_margin_top(12)
        self.title_detail_scroll = scroll
        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                          spacing=24)
        scroll.add(content)
        view.pack_start(scroll, True, True, 0)
        self.title_detail_content = content
        self.title_detail_view = view
        self.overlay.add_overlay(view)
        view.hide()
        return view

    def open_title_detail(self, kind, name, meta):
        """A title's OWN individual detail page: a bigger poster,
        runtime / cast (faces when the source gives photos) /
        description when the source knows them, favourite star,
        where you stopped, and a Play / Resume button. Opening a
        title records it in Resume as started. Back returns to the
        Movies / Shows page it came from."""
        self.title_focus[kind] = name
        existing = get_resume(kind, name)
        progress = existing["progress"] if existing else 0
        set_resume(kind, name, progress)
        if self.title_detail_view is None:
            self.build_title_detail_view()
        # The detail page is one shared view: put it on this page's
        # own theme, or it has no background at all and the Movies /
        # Shows page shows straight through it.
        self._apply_page_theme(
            self.title_detail_view,
            self.settings.get("%s_color" % kind, "Navy"))
        self.title_detail_open = (kind, name, meta)
        self.render_title_detail(kind, name, meta)
        self.title_detail_view.show_all()
        play_ui_sound("open", page=kind)

    def render_title_detail(self, kind, name, meta):
        """Rebuild the detail page content for one title. Runtime,
        cast, plot and episodes show ONLY when the source reports
        them -- the page never fakes a runtime or a cast list."""
        content = self.title_detail_content
        for child in content.get_children():
            content.remove(child)
        self.title_detail_heading.set_text(name)
        quality = title_quality(kind, name)
        self.title_detail_quality.set_text(quality or "")
        self.title_detail_quality.set_visible(bool(quality))
        det = title_details(kind, name)
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                      spacing=28)
        # Bigger poster: 360x504 (the page tiles are 280x392).
        poster = self.load_poster_image(name, 360, 504)
        poster = self._rounded_pixbuf(poster, 28)
        if poster is not None:
            top.pack_start(Gtk.Image.new_from_pixbuf(poster),
                           False, False, 0)
        else:
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            lab = Gtk.Label()
            lab.get_style_context().add_class("detail-label")
            lab.set_markup("<span weight='bold' size='x-large'>%s</span>"
                           % _esc(name))
            lab.set_line_wrap(True)
            lab.set_max_width_chars(20)
            lab.set_justify(Gtk.Justification.CENTER)
            box.pack_start(lab, True, True, 0)
            top.pack_start(box, False, False, 0)
        right = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                        spacing=10)
        # Fixed-width details column next to the poster: the column
        # must NOT expand to the full page width, or the "Where you
        # stopped" scale stretches across the whole screen.
        right.set_size_request(680, -1)
        meta_text = meta or ""
        if det.get("year"):
            meta_text = ("%s · %s" % (meta_text, det["year"])
                         if meta_text else det["year"])
        if meta_text:
            m = Gtk.Label(label=meta_text)
            m.get_style_context().add_class("detail-label")
            m.set_halign(Gtk.Align.START)
            right.pack_start(m, False, False, 0)
        runtime = _fmt_duration(det.get("runtime"))
        if runtime:
            r = Gtk.Label(label="Runtime: %s" % runtime)
            r.get_style_context().add_class("detail-label")
            r.set_halign(Gtk.Align.START)
            right.pack_start(r, False, False, 0)
        if det.get("rating"):
            r = Gtk.Label(label="Rating: %s" % det["rating"])
            r.get_style_context().add_class("detail-label")
            r.set_halign(Gtk.Align.START)
            right.pack_start(r, False, False, 0)
        cast = det.get("cast") or []
        if cast:
            c = Gtk.Label(label="Starring:")
            c.get_style_context().add_class("detail-label")
            c.set_halign(Gtk.Align.START)
            right.pack_start(c, False, False, 0)
            flow = Gtk.FlowBox()
            flow.set_halign(Gtk.Align.START)
            flow.set_max_children_per_line(4)
            flow.set_selection_mode(Gtk.SelectionMode.NONE)
            photos = det.get("cast_photos") or {}
            for member in cast:
                chip = Gtk.Box(
                    orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                photo_url = (photos.get(member)
                             if isinstance(photos, dict) else None)
                if photo_url:
                    pix = self._cast_photo_pixbuf(photo_url)
                    if pix is not None:
                        chip.pack_start(
                            Gtk.Image.new_from_pixbuf(pix),
                            False, False, 0)
                lab = Gtk.Label(label=member)
                lab.get_style_context().add_class("cast-chip")
                chip.pack_start(lab, False, False, 0)
                flow.add(chip)
            right.pack_start(flow, False, False, 0)
        if det.get("plot"):
            p = Gtk.Label(label=det["plot"])
            p.get_style_context().add_class("detail-label")
            p.set_line_wrap(True)
            p.set_max_width_chars(72)
            p.set_halign(Gtk.Align.START)
            right.pack_start(p, False, False, 0)
        fav_check = Gtk.CheckButton(label="★ Add to Favorites")
        fav_check.set_active(is_title_favorite(kind, name))
        fav_check.connect(
            "toggled",
            lambda w, k=kind, n=name:
                self._title_detail_fav_toggled(w, k, n))
        right.pack_start(fav_check, False, False, 0)
        resume_lab = Gtk.Label(label="Where you stopped")
        resume_lab.get_style_context().add_class("detail-label")
        resume_lab.set_halign(Gtk.Align.START)
        right.pack_start(resume_lab, False, False, 0)
        existing = get_resume(kind, name)
        progress = existing["progress"] if existing else 0
        scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        scale.set_value(progress)
        scale.set_draw_value(True)
        scale.set_value_pos(Gtk.PositionType.RIGHT)
        scale.connect(
            "value-changed",
            lambda w, k=kind, n=name:
                set_resume(k, n, int(w.get_value())))
        right.pack_start(scale, False, False, 0)
        self.title_detail_scale = scale
        btn_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=12)
        play_btn = Gtk.Button(
            label=("▶  Resume (%d%%)" % progress) if progress > 0
            else "▶  Play")
        play_btn.get_style_context().add_class("detail-play-btn")
        play_btn.connect(
            "clicked",
            lambda w, k=kind, n=name: self.title_play(k, n))
        btn_row.pack_start(play_btn, False, False, 0)
        self.title_detail_play_btn = play_btn
        fin_btn = Gtk.Button(label="Mark finished")
        fin_btn.get_style_context().add_class("epg-opt-btn")
        fin_btn.connect(
            "clicked",
            lambda w, k=kind, n=name, m=meta:
                self._title_detail_finished(k, n, m))
        btn_row.pack_start(fin_btn, False, False, 0)
        right.pack_start(btn_row, False, False, 0)
        status = Gtk.Label(label="")
        status.get_style_context().add_class("detail-status")
        status.set_halign(Gtk.Align.START)
        status.set_line_wrap(True)
        status.set_max_width_chars(72)
        right.pack_start(status, False, False, 0)
        self.title_detail_status = status
        top.pack_start(right, False, False, 0)
        content.pack_start(top, False, False, 0)
        if kind == "shows":
            content.pack_start(
                self._title_detail_episodes(name), False, False, 0)
        content.show_all()

    def _title_detail_fav_toggled(self, check, kind, name):
        """The detail page's favourite checkbox: star / un-star."""
        if check.get_active() and not is_title_favorite(kind, name):
            toggle_title_favorite(kind, name)
        elif not check.get_active() \
                and is_title_favorite(kind, name):
            toggle_title_favorite(kind, name)
        play_ui_sound("click", page=kind)

    def _title_detail_finished(self, kind, name, meta):
        """Mark finished: clear the Resume entry, re-render."""
        clear_resume(kind, name)
        self.render_title_detail(kind, name, meta)

    def _cast_photo_pixbuf(self, url):
        """A cast member's photo, when the source gives a URL for
        one -- downloaded once into the config dir and reused.
        None when there is no photo or the fetch fails."""
        try:
            import hashlib
            cache_dir = CONFIG_DIR / "cast"
            cache_dir.mkdir(parents=True, exist_ok=True)
            fname = hashlib.sha256(
                url.encode()).hexdigest()[:16] + ".jpg"
            path = cache_dir / fname
            if not path.exists():
                req = urllib.request.Request(
                    url, headers={"User-Agent": "AeroDeck/1.0"})
                with urllib.request.urlopen(req, timeout=4) as resp:
                    path.write_bytes(resp.read())
            return GdkPixbuf.Pixbuf.new_from_file_at_scale(
                str(path), 64, 64, True)
        except Exception:
            return None

    def _title_detail_episodes(self, name):
        """A show's episode list: the series length (seasons /
        episodes) and one row per episode (name, brief description,
        runtime). Only what the IPTV source reports -- a hint when
        it reports nothing, never a faked list."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        head = Gtk.Label(label="Episodes")
        head.get_style_context().add_class("title-section-heading")
        head.set_halign(Gtk.Align.START)
        box.pack_start(head, False, False, 0)
        eps = title_episodes(name)
        if not eps:
            hint = Gtk.Label(
                label="Episode details appear when the IPTV source "
                      "reports them.")
            hint.get_style_context().add_class("detail-label")
            hint.set_halign(Gtk.Align.START)
            box.pack_start(hint, False, False, 0)
            return box
        count = Gtk.Label(
            label="%d seasons · %d episodes"
                  % (eps["seasons"], eps["episodes"]))
        count.get_style_context().add_class("detail-label")
        count.set_halign(Gtk.Align.START)
        box.pack_start(count, False, False, 0)
        for ep in eps["list"]:
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                          spacing=12)
            row.get_style_context().add_class("episode-row")
            title = Gtk.Label(
                label="S%d E%d · %s" % (ep["season"], ep["episode"],
                                        ep["name"]))
            title.get_style_context().add_class("detail-label")
            title.set_halign(Gtk.Align.START)
            title.set_line_wrap(True)
            title.set_max_width_chars(40)
            row.pack_start(title, False, False, 0)
            if ep.get("plot"):
                desc = Gtk.Label(label=ep["plot"])
                desc.get_style_context().add_class("detail-label")
                desc.set_halign(Gtk.Align.START)
                desc.set_line_wrap(True)
                desc.set_max_width_chars(60)
                row.pack_start(desc, True, True, 0)
            runtime = _fmt_duration(ep.get("runtime"))
            if runtime:
                rt = Gtk.Label(label=runtime)
                rt.get_style_context().add_class("detail-label")
                rt.set_halign(Gtk.Align.END)
                row.pack_start(rt, False, False, 0)
            box.pack_start(row, False, False, 0)
        return box

    def close_title_detail(self):
        """Back from a title detail page returns to the Movies /
        Shows page it came from."""
        if self.title_detail_open is None:
            return
        kind = self.title_detail_open[0]
        if self.title_detail_view is not None:
            self.title_detail_view.hide()
        self.title_detail_open = None
        if self.title_page_open == kind:
            self.title_page_render(kind)
        play_ui_sound("click", page=kind)

    def title_detail_scroll_page(self, delta):
        """Up / Down on the detail page scrolls it."""
        if self.title_detail_open is None:
            return
        scroll = getattr(self, "title_detail_scroll", None)
        if scroll is None:
            return
        adj = scroll.get_vadjustment()
        adj.set_value(max(
            0, min(adj.get_upper() - adj.get_page_size(),
                   adj.get_value() + delta)))
        play_ui_sound("move", page=self.title_detail_open[0])

    def title_play(self, kind, name):
        """Play / Resume: the title's stream from the IPTV source,
        full-screen in the player (the same playback controls as
        live TV). Without a stream -- the source is not initiated
        or the title has none -- it says so instead of pretending
        to play."""
        meta = ""
        det = title_details(kind, name)
        url = ""
        state = iptv_source_state()
        if state["initiated"]:
            pool = state["movies"] if kind == "movies" \
                else state["shows"]
            entry = next((c for c in pool if c["name"] == name), None)
            if entry is not None:
                url = entry.get("url") or ""
                meta = entry.get("group") or ""
            if kind == "shows" and not url:
                eps = title_episodes(name)
                if eps and eps["list"]:
                    url = eps["list"][0].get("url") or ""
        if not url:
            if getattr(self, "title_detail_status", None) is not None:
                self.title_detail_status.set_text(
                    "Play starts when the IPTV source is connected -- "
                    "no stream for this title yet.")
            play_ui_sound("click", page=kind)
            return
        self.player_detail_return = (kind, name, meta)
        self.open_player(
            {"name": name, "program": meta or (
                "Movie" if kind == "movies" else "TV Show"),
             "url": url, "duration": det.get("runtime"),
             "page": kind},
            live=False)

    def title_page_open_options(self, kind):
        if kind not in self.title_options_revealers:
            self.build_options_revealer(kind)
        self.build_options_content(kind)
        self.title_options_revealers[kind].set_reveal_child(True)
        self.title_options_open = kind
        play_ui_sound("open", page=kind)

    def title_page_close_options(self, kind):
        revealer = self.title_options_revealers.get(kind)
        if revealer is not None:
            revealer.set_reveal_child(False)
        if self.title_options_open == kind:
            self.title_options_open = None




    def on_open_title(self, widget, name, meta):
        dialog = Gtk.MessageDialog(
            parent=self, flags=0, message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text=name)
        dialog.format_secondary_text("%s" % meta)
        dialog.run()
        dialog.destroy()

    def on_open_game(self, widget, name, meta):
        _spawn(["steam"])

    def on_open_cloud(self, widget, name, url):
        """Cloud gaming: one tap opens the service in the browser."""
        open_url(url)

    def on_watch_hero(self, widget):
        self.on_open_title(widget, "Stranger Things", "Netflix")

    def on_hero_info(self, widget):
        dialog = Gtk.MessageDialog(
            parent=self, flags=0, message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text="Stranger Things")
        dialog.format_secondary_text(
            "When a young boy vanishes, a small town uncovers a mystery "
            "involving secret experiments, terrifying supernatural forces "
            "and one strange little girl.")
        dialog.run()
        dialog.destroy()

    def on_search(self, widget):
        dialog = Gtk.Dialog(title="Search", parent=self, flags=0)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Search", Gtk.ResponseType.OK)
        entry = Gtk.Entry()
        entry.set_placeholder_text("Apps, channels, videos or a website")
        entry.set_size_request(420, 40)
        dialog.get_content_area().pack_start(entry, True, True, 12)
        dialog.show_all()
        if dialog.run() == Gtk.ResponseType.OK:
            query = entry.get_text().strip()
            if query:
                open_url("https://duckduckgo.com/?q=" + query)
        dialog.destroy()

    def on_bell(self, widget):
        dialog = Gtk.MessageDialog(
            parent=self, flags=0, message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text="Notifications")
        dialog.format_secondary_text("No new notifications.")
        dialog.run()
        dialog.destroy()

    def on_profile(self, widget):
        dialog = Gtk.MessageDialog(
            parent=self, flags=0, message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK, text="Profile")
        dialog.format_secondary_text("Signed in as Drew.")
        dialog.run()
        dialog.destroy()

# Music radio (Flight Deck -> Music instrument panel): free internet
# radio, no sign-in, no API key. (Genre, station, stream URL.)
# Radio Paradise was verified live from this sandbox (HTTP 200).
# SomaFM's ice1 URLs are their published stream pattern, and Jazz24
# / Radio Swiss Classic are their published direct streams -- but
# the sandbox proxy blocks or drops those hosts, so they could not
# be verified here; the first real play happens on the TV.
MUSIC_GENRES = [
    ("Rock", "Radio Paradise",
     "https://stream.radioparadise.com/aac-320"),
    ("Pop", "SomaFM PopTron",
     "https://ice1.somafm.com/poptron-128-mp3"),
    ("Country", "SomaFM Boot Liquor",
     "https://ice1.somafm.com/bootliquor-128-mp3"),
    ("Jazz", "Jazz24",
     "https://live.wostreaming.net/direct/knkx-jazz24mp3-ibc4"),
    ("Classical", "Radio Swiss Classic",
     "http://stream.srg-ssr.ch/m/rsc_de/mp3_128"),
    ("Hip-Hop", "SomaFM Fluid",
     "https://ice1.somafm.com/fluid-128-mp3"),
    ("Electronic", "SomaFM The Trip",
     "https://ice1.somafm.com/thetrip-128-mp3"),
    ("Ambient", "SomaFM Drone Zone",
     "https://ice1.somafm.com/dronezone-128-mp3"),
    ("Chill", "SomaFM Lush",
     "https://ice1.somafm.com/lush-128-mp3"),
    ("80s", "SomaFM Left Coast 80s",
     "https://ice1.somafm.com/leftcoast-128-mp3"),
]


class SettingsPanel(Gtk.Box):
    """Flight Deck (settings panel, slides up from the bottom). A Stack of
    instrument panels: main (clock/weather split, IPTV section,
    quick tiles, fixed bottom bar with Close / Power / Restart),
    iptv, bluetooth, wifi, background, appearance, keyboard,
    calendar, tasks, rows, sound, music, screensaver, language,
    region, cursor, power, about. Back always lands on the main
    page; closing the panel takes you home."""

    def __init__(self, launcher):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.launcher = launcher
        self.get_style_context().add_class("settings-panel")
        # Floating panel, fixed TALL height (480 wide, 980 tall):
        # bottom-to-top, most of the screen height, like the
        # reference panel. It must NOT grow with its content -- the
        # ScrolledWindow below scrolls the tall content inside this
        # height instead, so anything hidden is reachable by
        # scrolling up/down. (set_size_request is a minimum, so the
        # natural height must NOT propagate, or the panel would grow
        # to the full content height and stop being a floating card.)
        # Nov 16 fix: the height now FITS THE SCREEN. A fixed 980px
        # panel on the Steam Deck's 800px-tall panel was taller than
        # the screen: its top (Back button, page title) was cut off,
        # it covered the Navigator, and sub-pages opened scrolled to
        # an empty area -- the "blank white sheet". fit_to_screen()
        # sizes it from the window (see AltTVLauncher._on_win_size).
        self._fit = (0, 0)
        self.set_size_request(480, 680)

        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.SLIDE_LEFT)
        self.stack.set_transition_duration(200)
        # Each page keeps its own height (a short page is not padded
        # out to the tallest page's height with blank white space).
        self.stack.set_vhomogeneous(False)
        self.stack.set_hhomogeneous(True)
        self.stack.set_interpolate_size(False)

        # The panel scrolls: if there are too many tiles/sections to
        # fit in the 980px height, it glides up and down (touch,
        # trackpad, mouse wheel, remote) so every option stays
        # reachable -- nothing is cut off with no way to get to it.
        self.scrolled = Gtk.ScrolledWindow()
        self.scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.scrolled.set_kinetic_scrolling(True)
        self.scrolled.set_propagate_natural_height(False)
        self.scrolled.add(self.stack)
        self.pack_start(self.scrolled, True, True, 0)

        # Fixed bottom bar (outside the scrolled area, so it is always
        # visible at the bottom of the Flight Deck): Close on the left,
        # Power and Restart at the bottom right -- so the system can
        # be powered off or restarted with no remote. Both go through
        # the same guard as the Power instrument panel (a dialog; the
        # command never runs outright while power_commands_enabled
        # is off). No volume slider here: volume is on the remote
        # and on the keyboard; per-output volume lives on the Sound
        # instrument panel instead.
        bottom = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        bottom.set_margin_start(20)
        bottom.set_margin_end(20)
        bottom.set_margin_top(10)
        bottom.set_margin_bottom(16)
        close_btn = Gtk.Button(label="Close")
        self.close_btn = close_btn
        close_btn.connect("clicked",
                          lambda w: self.launcher.close_settings_panel())
        bottom.pack_start(close_btn, False, False, 0)
        # Console-style button hints.
        hints = Gtk.Label()
        hints.set_markup("<span size='small'><b>Ⓐ</b> Select   "
                         "<b>Ⓑ</b> Back   <b>⧉</b> Controls</span>")
        hints.get_style_context().add_class("panel-hints")
        bottom.pack_start(hints, True, True, 0)
        power_btn = Gtk.Button(label="Power")
        power_btn.connect("clicked", self.on_power_button,
                          "poweroff", "Power off")
        bottom.pack_start(power_btn, False, False, 0)
        restart_btn = Gtk.Button(label="Restart")
        restart_btn.connect("clicked", self.on_power_button,
                            "reboot", "Restart")
        bottom.pack_start(restart_btn, False, False, 0)
        self.pack_start(bottom, False, False, 0)

        self.build_main_page()
        self.build_apps_page()
        self.build_iptv_page()
        self.build_bluetooth_page()
        self.build_wifi_page()
        self.build_display_page()
        self.build_browser_page()
        self.build_updates_page()
        self.build_install_page()
        self.build_vpn_page()
        self.build_background_page()
        self.build_appearance_page()
        self._mon_build_settings()
        self.build_keyboard_page()
        self.build_ai_page()
        self.build_calendar_page()
        self.build_tasks_page()
        self.build_email_page()
        self.build_rows_page()
        self.build_sound_page()
        self.build_music_page()
        self.build_controller_page()
        self.build_screensaver_page()
        self.build_language_page()
        self.build_region_page()
        self.build_cursor_page()
        self.build_power_page()
        self.build_about_page()
        self.build_storage_page()
        self.build_controls_page()
        self.build_printers_page()
        self.build_reader_page()
        self.wire_audit_extras()
        GLib.idle_add(self._apply_compact,
                      _dz(_monitor_size()[1]) - self.NAV_CLEARANCE - self.BOTTOM_GAP)

        self.show_page("main")

    # -- navigation ---------------------------------------------------------
    def show_page(self, name):
        if name == "main":
            # The IPTV section shows the stored source details, so
            # refresh it every time the main page is shown (e.g. after
            # adding or removing a source on the IPTV page).
            self.refresh_iptv_section()
        elif name == "sound":
            # Audio outputs can appear or vanish (headphones pair),
            # so re-list the system's sinks each time the Sound
            # instrument panel is opened.
            self.refresh_sound_sinks()
        hook = getattr(self, "_on_show_" + str(name), None)
        if hook is not None:
            try:
                hook()
            except Exception:
                pass
        child = self.stack.get_child_by_name(name)
        if child is None:
            name = "main"
        else:
            # Make sure every control on the page is realised and
            # visible (pages built after show_all() would otherwise
            # stay hidden -- empty sections).
            child.show_all()
            for hidden in getattr(child, "_keep_hidden", []):
                hidden.hide()
        previous = self.stack.get_visible_child_name()
        self.stack.set_visible_child_name(name)
        if name == "main" and previous and previous != "main":
            # Back from a section: land on that section's tile again.
            tile = getattr(self, "_tile_buttons", {}).get(previous)
            if tile is not None:
                GLib.timeout_add(
                    self.stack.get_transition_duration() + 40,
                    lambda: (tile.grab_focus(), _scroll_focus_into_view(
                        self.scrolled, tile, None), False)[2])
                return
        # Every page opens at its TOP (Back button + title), never at
        # the scroll position the previous page was left at.
        self._reset_scroll()
        GLib.idle_add(self._reset_scroll)
        GLib.timeout_add(self.stack.get_transition_duration() + 30,
                         self._focus_first, name)

    def current_page(self):
        return self.stack.get_visible_child_name()

    # Space kept clear above the panel so the Navigator bar stays
    # visible and usable while the Flight Deck is open.
    NAV_CLEARANCE = 78
    BOTTOM_GAP = 16

    def fit_to_screen(self, win_w, win_h):
        """Size the Flight Deck for the current window: as tall as the
        screen allows under the Navigator (max 980px), and a width that
        reads well from 1280x800 (Steam Deck) up to 1920x1080 / 4K."""
        if win_w <= 0 or win_h <= 0:
            return
        height = max(360, min(980, win_h - self.NAV_CLEARANCE
                              - self.BOTTOM_GAP))
        width = max(440, min(620, int(win_w * 0.38)))
        if (width, height) == self._fit:
            return
        self._fit = (width, height)
        GLib.idle_add(self._apply_compact, height)
        self.set_size_request(width, height)
        self.queue_resize()

    def _apply_compact(self, height):
        # Small screens (Steam Deck 1280x800): drop the month calendar
        # from the header so the 2 x 5 toggle grid (10 at once) fits.
        compact = height < 800
        cal = getattr(self, "panel_calendar", None)
        if cal is not None:
            cal.set_no_show_all(compact)
            cal.set_visible(not compact)
        # IPTV section: only its name line on small screens.
        sec = getattr(self, "iptv_section", None)
        if sec is not None:
            (sec.get_style_context().add_class if compact else
             sec.get_style_context().remove_class)("iptv-compact")
        for lbl in getattr(self, "iptv_detail_labels", [])[1:]:
            lbl.set_no_show_all(compact)
            lbl.set_visible(not compact)
        # Toggle height so exactly 5 rows (10 toggles) show.
        tile_h = 48 if compact else 72
        for t in getattr(self, "_deck_tiles", []):
            t.set_size_request(-1, tile_h)
        sc = getattr(self, "tile_scroller", None)
        if sc is not None:
            vh = self.TILES_VISIBLE * tile_h + (self.TILES_VISIBLE - 1) * 10
            sc.set_min_content_height(vh)
            sc.set_max_content_height(vh)
            # re-measure with the real tile height once laid out
            GLib.timeout_add(400, lambda: (self._tile_glide(
                sc.get_vadjustment().get_value()), False)[1])
        return False

    def move_focus(self, direction):
        """Move the focus up/down inside the open page (or between the
        page and the bottom bar) and keep it in view."""
        page = self.stack.get_visible_child()
        if page is None:
            return False
        win = self.launcher
        focus = win.get_focus()
        if focus is None or not focus.is_ancestor(self):
            moved = page.child_focus(Gtk.DirectionType.TAB_FORWARD)
        elif focus.is_ancestor(page):
            moved = page.child_focus(direction)
            if not moved and direction == Gtk.DirectionType.DOWN:
                # Off the bottom of the page: onto the Close button.
                self.close_btn.grab_focus()
                moved = True
        else:
            # On the bottom bar: Up goes back into the page.
            if direction == Gtk.DirectionType.UP:
                moved = page.child_focus(Gtk.DirectionType.TAB_BACKWARD)
            else:
                moved = True
        if moved:
            _scroll_focus_into_view(self.scrolled, win.get_focus(), None)
        return bool(moved)

    def _reset_scroll(self):
        try:
            adj = self.scrolled.get_vadjustment()
            adj.set_value(adj.get_lower())
        except Exception:
            pass
        return False

    def _focus_first(self, page_name):
        """Put the focus on the first control of the page that was just
        opened (Back on sub-pages), so the D-pad / controller can move
        through it straight away."""
        page = self.stack.get_child_by_name(page_name)
        if page is None:
            return False
        def first(widget):
            if (widget.get_visible() and widget.get_sensitive()
                    and widget.get_can_focus()
                    and not isinstance(widget, (Gtk.ScrolledWindow,
                                                Gtk.Viewport))):
                return widget
            if isinstance(widget, Gtk.Container):
                for child in widget.get_children():
                    hit = first(child)
                    if hit is not None:
                        return hit
            return None
        try:
            target = first(page)
            if target is not None:
                target.grab_focus()
        except Exception:
            pass
        self._reset_scroll()
        return False

    def smooth_scroll_by(self, delta, duration_ms=200):
        """Glide the panel up/down by delta pixels (remote, keyboard)."""
        adj = self.scrolled.get_vadjustment()
        start = adj.get_value()
        target = max(0, min(adj.get_upper() - adj.get_page_size(),
                            start + delta))
        if target == start:
            return
        steps = max(1, duration_ms // 16)
        step = [0]

        def tick():
            step[0] += 1
            frac = min(1.0, step[0] / steps)
            eased = 1 - (1 - frac) ** 2
            adj.set_value(start + (target - start) * eased)
            return step[0] < steps

        GLib.timeout_add(16, tick)

    def refresh_clock(self):
        now = datetime.datetime.now()
        self.panel_clock.set_text(now.strftime("%-I:%M"))
        self.panel_date.set_text(now.strftime("%A, %B %-d"))
        weather = getattr(self.launcher, "weather_text", None)
        if hasattr(self, "panel_weather"):
            self.panel_weather.set_text(
                weather if weather else "Checking weather…")
        if hasattr(self, "panel_weather_icon"):
            self.panel_weather_icon.set_text(
                self._weather_icon(weather))

    @staticmethod
    def _weather_icon(text):
        """Weather condition icon (sun / cloud / rain), HTC-style --
        a visual next to the condition text, not text alone."""
        t = (text or "").lower()
        if "thunder" in t:
            return "⛈️"
        if "rain" in t:
            return "🌧️"
        if "drizzle" in t or "shower" in t:
            return "🌦️"
        if "snow" in t or "sleet" in t or "hail" in t:
            return "❄️"
        if "fog" in t or "mist" in t or "haze" in t:
            return "🌫️"
        if "clear" in t:
            return "☀️"
        if "partly" in t:
            return "⛅"
        if "cloud" in t or "overcast" in t:
            return "☁️"
        return "☁️"

    def refresh_iptv_section(self):
        """Fill the full-width IPTV section with the first stored
        source's details (name, URL, username, password). The section
        is built in build_main_page, so this is a no-op until then."""
        labels = getattr(self, "iptv_detail_labels", None)
        if not labels:
            return
        sources = load_playlists()
        if not sources:
            labels[0].set_markup(
                "<b>Name:</b>  No IPTV source yet")
            labels[1].set_markup("<b>URL:</b>  —")
            labels[2].set_markup("<b>Username:</b>  —")
            labels[3].set_markup("<b>Password:</b>  —  (tap to add one)")
            return
        src = sources[0]
        name = src.get("name") or "—"
        url = src.get("url") or "—"
        user = src.get("username") or "—"
        # Password is NEVER shown in plain text here: when one is
        # stored it reads as xxxx, so the details are visible at a
        # glance without exposing the credential on screen.
        pw = "xxxx" if src.get("password") else "—"
        labels[0].set_markup("<b>Name:</b>  %s" % _esc(name))
        labels[1].set_markup("<b>URL:</b>  %s" % _esc(url))
        labels[2].set_markup("<b>Username:</b>  %s" % _esc(user))
        labels[3].set_markup("<b>Password:</b>  %s" % _esc(pw))

    def _page_box(self, title):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_margin_start(20)
        box.set_margin_end(20)
        box.set_margin_top(16)
        box.set_margin_bottom(20)
        back = Gtk.Button(label="←  Back to Flight Deck")
        back.set_size_request(220, 44)
        back.set_halign(Gtk.Align.START)
        back.set_tooltip_text("Back (B / Esc)")
        back.connect("clicked", lambda w: self.show_page("main"))
        box.pack_start(back, False, False, 0)
        label = Gtk.Label()
        label.set_markup("<span size='x-large' weight='bold'>%s</span>" % _esc(title))
        label.set_halign(Gtk.Align.START)
        box.pack_start(label, False, False, 0)
        return box

    def _tile(self, name, sub, page):
        btn = Gtk.Button()
        btn.get_style_context().add_class("settings-tile")
        # Fill its grid cell: with homogeneous columns the left and
        # right tiles come out the same size on both sides.
        btn.set_hexpand(True)
        inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        # Center the wording in the tile: the two lines sit in the
        # middle of the tile, not up at the top.
        inner.set_valign(Gtk.Align.CENTER)
        inner.set_halign(Gtk.Align.CENTER)
        name_label = Gtk.Label()
        name_label.set_markup("<b>%s</b>" % _esc(name))
        name_label.set_halign(Gtk.Align.CENTER)
        sub_label = Gtk.Label(label=sub)
        sub_label.get_style_context().add_class("tile-sub")
        sub_label.set_halign(Gtk.Align.CENTER)
        inner.pack_start(name_label, False, False, 0)
        inner.pack_start(sub_label, False, False, 0)
        btn.add(inner)
        btn.connect("clicked", lambda w: self.show_page(page))
        if not hasattr(self, "_tile_buttons"):
            self._tile_buttons = {}
        self._tile_buttons[page] = btn
        return btn

    # -- main tiles page ------------------------------------------------------
    def build_main_page(self):
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        page.set_margin_start(20)
        page.set_margin_end(20)
        page.set_margin_top(16)
        page.set_margin_bottom(20)

        # Flight Deck title: the panel's name, small and centred
        # above the clock/weather split.
        deck_title = Gtk.Label()
        deck_title.set_markup(
            "<span size='large' weight='bold'>Flight Deck</span>")
        deck_title.set_halign(Gtk.Align.CENTER)
        page.pack_start(deck_title, False, False, 0)

        # Top row: clock on the left (date under it), a calendar
        # visual in the CENTER, weather on the right with its icon
        # (sun / cloud / rain, HTC clock/weather style) -- not just
        # text. The three parts share the row equally, so the
        # calendar sits truly centered and the weather sits at the
        # right edge. The Flight Deck title above it is the panel's
        # name; the clock is the header, like the reference panel.
        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        left = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.panel_clock = Gtk.Label()
        self.panel_clock.get_style_context().add_class("panel-clock")
        self.panel_clock.set_halign(Gtk.Align.START)
        left.pack_start(self.panel_clock, False, False, 0)
        self.panel_date = Gtk.Label()
        self.panel_date.get_style_context().add_class("panel-date")
        self.panel_date.set_halign(Gtk.Align.START)
        left.pack_start(self.panel_date, False, False, 0)
        top.pack_start(left, True, True, 0)
        # Real calendar in the center of the clock/weather area --
        # a normal-size calendar, not an emoji. Clicking a day
        # opens the Calendar page to schedule events and shows.
        cal_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.panel_calendar = Gtk.Calendar()
        self.panel_calendar.set_halign(Gtk.Align.CENTER)
        self.panel_calendar.set_valign(Gtk.Align.CENTER)
        self.panel_calendar.connect(
            "day-selected", self.on_panel_calendar_day)
        cal_box.pack_start(self.panel_calendar, True, True, 0)
        top.pack_start(cal_box, True, True, 0)
        # Weather on the right: big condition icon beside the
        # condition text, like the old HTC clock/weather widget.
        weather_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=6)
        weather_box.pack_start(Gtk.Box(), True, True, 0)  # right-align
        self.panel_weather_icon = Gtk.Label()
        self.panel_weather_icon.get_style_context().add_class(
            "panel-weather-icon")
        self.panel_weather_icon.set_valign(Gtk.Align.CENTER)
        weather_box.pack_start(self.panel_weather_icon, False, False, 0)
        self.panel_weather = Gtk.Label()
        self.panel_weather.get_style_context().add_class("panel-weather")
        self.panel_weather.set_halign(Gtk.Align.START)
        self.panel_weather.set_valign(Gtk.Align.CENTER)
        self.panel_weather.set_line_wrap(True)
        self.panel_weather.set_max_width_chars(18)
        weather_box.pack_start(self.panel_weather, False, False, 0)
        top.pack_start(weather_box, True, True, 0)
        page.pack_start(top, False, False, 0)
        self.refresh_clock()

        # IPTV: its OWN full-width section at the top, directly under
        # the clock/weather split, same width as the panel. It shows
        # the stored source's details right there -- name, URL and
        # username visible, password masked as xxxx (never plain
        # text) -- so they are visible the moment the panel opens.
        # Tapping it opens the IPTV page to add or change sources.
        # (There is NO search field in the panel: searching happens
        # from the main launcher's top search bar instead.)
        self.iptv_section = Gtk.Button()
        self.iptv_section.get_style_context().add_class("settings-tile")
        iptv_inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                             spacing=2)
        iptv_title = Gtk.Label()
        iptv_title.set_markup("<b>IPTV</b>")
        iptv_title.set_halign(Gtk.Align.CENTER)
        iptv_inner.pack_start(iptv_title, False, False, 0)
        self.iptv_detail_labels = []
        for _ in range(4):
            detail = Gtk.Label()
            detail.get_style_context().add_class("iptv-detail")
            # Centered evenly inside the section, so the info sits
            # in the middle of the IPTV tile and fits within it.
            detail.set_halign(Gtk.Align.CENTER)
            detail.set_line_wrap(True)
            iptv_inner.pack_start(detail, False, False, 0)
            self.iptv_detail_labels.append(detail)
        self.iptv_section.add(iptv_inner)
        self.iptv_section.connect(
            "clicked", lambda w: self.show_page("iptv"))
        page.pack_start(self.iptv_section, False, False, 0)
        self.refresh_iptv_section()

        grid = Gtk.Grid()
        grid.set_column_spacing(20)
        grid.set_row_spacing(20)
        grid.set_halign(Gtk.Align.FILL)
        # Even on both sides: homogeneous columns make the left and
        # right tiles the same width, and the grid fills the page
        # width so neither column is stretched or cut off at a panel
        # edge -- two even rounded rectangles per row.
        grid.set_column_homogeneous(True)
        grid.set_hexpand(True)
        tiles = [
            ("Wi-Fi", "Network / Ethernet", "wifi"),
            ("Bluetooth", "Remote", "bluetooth"),
            ("VPN", "Proton", "vpn"),
            ("Apps", "Install", "apps"),
            ("Appearance", "Theme", "appearance"),
            ("Keyboard", "Colour / Opacity", "keyboard"),
            ("Wingman", "AI co-pilot", "ai"),
            ("Display", "Resolution / Rotation", "display"),
            ("Browser", "Default: Brave", "browser"),
            ("Updates", "Launcher updates", "updates"),
            ("Install", "Install Aero Deck", "install"),
            ("Reading mode", "Books & PDFs", "reader"),
            ("Printers", "Add / Queue", "printers"),
            ("Storage", "Clear cache", "storage"),
            ("Controls", "Deck button map", "controls"),
            ("Background", "Backdrop", "background"),
            ("Calendar", "Today", "calendar"),
            ("Tasks", "To-do", "tasks"),
            ("Email", "Inbox", "email"),
            ("Row order", "1st, 2nd, 3rd", "rows"),
            ("Sound", "Output", "sound"),
            ("Music", "Radio", "music"),
            ("Controller", "Gamepads", "controller"),
            ("Screensaver", "Timeout", "screensaver"),
            ("Language", "English", "language"),
            ("Region", "Canada", "region"),
            ("Cursor", "Show / hide", "cursor"),
            ("Power", "Sleep / Restart", "power"),
            ("About", "Aero Deck 1.0", "about"),
        ]
        # Two columns, FIVE rows on screen (10 toggles at once); the
        # rest scroll smoothly inside their own window -- like the app
        # rows -- with the focus followed by the controller and the
        # scroll position kept when you come back from a section.
        grid.set_row_homogeneous(True)
        for i, (name, sub, page_name) in enumerate(tiles):
            t = self._tile(name, sub, page_name)
            t.get_style_context().add_class("deck-toggle")
            t.set_size_request(-1, self.TILE_H)
            self._deck_tiles = getattr(self, "_deck_tiles", []) + [t]
            t.connect("focus-in-event", self._on_tile_focus)
            grid.attach(t, i % 2, i // 2, 1, 1)
        self.tile_scroller = Gtk.ScrolledWindow()
        self.tile_scroller.set_policy(Gtk.PolicyType.NEVER,
                                      Gtk.PolicyType.AUTOMATIC)
        self.tile_scroller.set_kinetic_scrolling(True)
        self.tile_scroller.set_overlay_scrolling(True)
        grid.set_row_spacing(10)
        view_h = self.TILES_VISIBLE * self.TILE_H + \
            (self.TILES_VISIBLE - 1) * 10
        self.tile_scroller.set_min_content_height(view_h)
        self.tile_scroller.set_max_content_height(view_h)
        self.tile_scroller.add(grid)
        page.pack_start(self.tile_scroller, False, False, 0)

        self.stack.add_named(page, "main")

    TILE_H = 56
    TILES_VISIBLE = 5

    def _on_tile_focus(self, tile, _event):
        # Glide the tile list so the focused toggle is fully in view,
        # and the whole list itself in the panel's view.
        GLib.idle_add(lambda: (_scroll_focus_into_view(
            self.tile_scroller, tile, self._tile_glide), False)[1])
        return False

    def _tile_glide(self, target):
        adj = self.tile_scroller.get_vadjustment()
        # Snap to whole rows so 5 full rows always show.
        tiles = getattr(self, "_deck_tiles", [])
        if tiles:
            row = _dz(tiles[0].get_allocated_height()) + 10
            vh = self.TILES_VISIBLE * row - 10
            if row > 10 and _dz(self.tile_scroller.get_allocated_height()) != vh:
                self.tile_scroller.set_min_content_height(vh)
                self.tile_scroller.set_max_content_height(vh)
            if row > 10:
                import math
                target = (math.ceil(target / row) if target > adj.get_value()
                          else math.floor(target / row)) * row
                target = max(adj.get_lower(),
                             min(adj.get_upper() - adj.get_page_size(),
                                 target))
        start = adj.get_value()
        if getattr(self, "_glide_id", None):
            GLib.source_remove(self._glide_id)
        step = [0]

        def tick():
            step[0] += 1
            frac = min(1.0, step[0] / 10)
            adj.set_value(start + (target - start) * (1 - (1 - frac) ** 2))
            if frac >= 1:
                self._glide_id = None
                return False
            return True
        self._glide_id = GLib.timeout_add(16, tick)

    # -- Apps (Android + Linux, nothing blocked) --------------------------------
    def build_apps_page(self):
        page = self._page_box("Apps")
        hint = Gtk.Label(
            label="Android apps run through Waydroid, Linux apps run "
                  "natively. No Google Play Store needed -- APKs install "
                  "directly and nothing is blocked.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        apk_label = Gtk.Label(label="Install an Android app (APK)")
        apk_label.set_halign(Gtk.Align.START)
        page.pack_start(apk_label, False, False, 0)
        apk_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.apk_entry = Gtk.Entry()
        self.apk_entry.set_placeholder_text("/path/to/app.apk or https://...")
        self.apk_entry.set_hexpand(True)
        apk_btn = Gtk.Button(label="Install APK")
        apk_btn.connect("clicked", self.on_install_apk)
        apk_box.pack_start(self.apk_entry, True, True, 0)
        apk_box.pack_start(apk_btn, False, False, 0)
        page.pack_start(apk_box, False, False, 0)
        self.apk_status = Gtk.Label(label="")
        self.apk_status.set_halign(Gtk.Align.START)
        self.apk_status.set_line_wrap(True)
        page.pack_start(self.apk_status, False, False, 0)

        add_label = Gtk.Label(label="Add an app")
        add_label.set_halign(Gtk.Align.START)
        page.pack_start(add_label, False, False, 0)
        self.custom_name = Gtk.Entry()
        self.custom_name.set_placeholder_text("Name")
        self.custom_target = Gtk.Entry()
        self.custom_target.set_placeholder_text(
            "Android package, Linux command, or URL")
        self.custom_kind = Gtk.ComboBoxText()
        self.custom_kind.append_text("android")
        self.custom_kind.append_text("linux")
        self.custom_kind.append_text("web")
        self.custom_kind.set_active(0)
        # Which row it lands on: Your Apps, or Social Media (social only).
        self.custom_row = Gtk.ComboBoxText()
        self.custom_row.append_text("Your Apps")
        self.custom_row.append_text("Social Media")
        self.custom_row.set_active(0)
        add_btn = Gtk.Button(label="Add app")
        add_btn.connect("clicked", self.on_add_custom_app)
        page.pack_start(self.custom_name, False, False, 0)
        page.pack_start(self.custom_target, False, False, 0)
        page.pack_start(self.custom_kind, False, False, 0)
        page.pack_start(self.custom_row, False, False, 0)
        page.pack_start(add_btn, False, False, 0)

        # The Your Apps row, in order -- every app (built-in, custom,
        # installed). Move up / Move down reorders the row; the order
        # is saved and the row rebuilds in that order.
        order_label = Gtk.Label(
            label="Your Apps row (in order -- Move up / Move down "
                  "reorders it)")
        order_label.set_halign(Gtk.Align.START)
        page.pack_start(order_label, False, False, 0)
        # Columns: App, Source, Target, key (key is hidden -- it is
        # how a row is matched back to the ordered list).
        self.custom_store = Gtk.ListStore(str, str, str, str)
        tree = Gtk.TreeView(model=self.custom_store)
        renderer = Gtk.CellRendererText()
        tree.append_column(Gtk.TreeViewColumn("App", renderer, text=0))
        tree.append_column(Gtk.TreeViewColumn("Source", renderer, text=1))
        tree.append_column(Gtk.TreeViewColumn("Target", renderer, text=2))
        self.custom_tree = tree
        scroll = Gtk.ScrolledWindow()
        scroll.set_size_request(-1, 160)
        scroll.add(tree)
        page.pack_start(scroll, False, False, 0)
        move_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        up_btn = Gtk.Button(label="Move up")
        up_btn.connect("clicked", self.on_move_app_up)
        down_btn = Gtk.Button(label="Move down")
        down_btn.connect("clicked", self.on_move_app_down)
        remove_btn = Gtk.Button(label="Remove selected")
        remove_btn.connect("clicked", self.on_remove_custom_app)
        move_box.pack_start(up_btn, False, False, 0)
        move_box.pack_start(down_btn, False, False, 0)
        move_box.pack_start(remove_btn, False, False, 0)
        page.pack_start(move_box, False, False, 0)
        self.refresh_apps_store()

        # Social feeds: the channels whose videos populate the Social
        # Media row (YouTube / Rumble, public feeds, no sign-in).
        feeds_label = Gtk.Label(label="Social feeds (Social Media row)")
        feeds_label.set_halign(Gtk.Align.START)
        page.pack_start(feeds_label, False, False, 0)
        feeds_hint = Gtk.Label(
            label="YouTube: @handle or channel ID. Rumble: channel name. "
                  "The latest videos from these channels show in the "
                  "Social Media row.")
        feeds_hint.set_halign(Gtk.Align.START)
        feeds_hint.set_line_wrap(True)
        page.pack_start(feeds_hint, False, False, 0)
        feed_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.feed_service = Gtk.ComboBoxText()
        self.feed_service.append_text("youtube")
        self.feed_service.append_text("rumble")
        self.feed_service.set_active(0)
        self.feed_channel = Gtk.Entry()
        self.feed_channel.set_placeholder_text("@handle or channel name")
        self.feed_channel.set_hexpand(True)
        feed_add_btn = Gtk.Button(label="Add feed")
        feed_add_btn.connect("clicked", self.on_add_social_feed)
        feed_box.pack_start(self.feed_service, False, False, 0)
        feed_box.pack_start(self.feed_channel, True, True, 0)
        feed_box.pack_start(feed_add_btn, False, False, 0)
        page.pack_start(feed_box, False, False, 0)
        self.feed_store = Gtk.ListStore(str, str, str)
        for feed in load_social_feeds():
            self.feed_store.append([feed.get("service", ""),
                                    feed.get("channel", ""),
                                    feed.get("label", "")])
        feed_tree = Gtk.TreeView(model=self.feed_store)
        feed_renderer = Gtk.CellRendererText()
        feed_tree.append_column(
            Gtk.TreeViewColumn("Service", feed_renderer, text=0))
        feed_tree.append_column(
            Gtk.TreeViewColumn("Channel", feed_renderer, text=1))
        feed_tree.append_column(
            Gtk.TreeViewColumn("Label", feed_renderer, text=2))
        self.feed_tree = feed_tree
        feed_scroll = Gtk.ScrolledWindow()
        feed_scroll.set_size_request(-1, 100)
        feed_scroll.add(feed_tree)
        page.pack_start(feed_scroll, False, False, 0)
        feed_remove_btn = Gtk.Button(label="Remove selected feed")
        feed_remove_btn.connect("clicked", self.on_remove_social_feed)
        page.pack_start(feed_remove_btn, False, False, 0)

        self.stack.add_named(page, "apps")

    def refresh_apps_store(self):
        """Rebuild the Apps list from the current row order."""
        self.custom_store.clear()
        for app in assemble_apps():
            self.custom_store.append([app["name"], app["source"],
                                      app["target"], app["key"]])

    def _selected_app_key(self):
        """The app key of the selected row in the Apps list, or None."""
        selection = self.custom_tree.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return None
        return model[tree_iter][3]

    def on_move_app_up(self, widget):
        self._move_app_in_list(-1)

    def on_move_app_down(self, widget):
        self._move_app_in_list(1)

    def _move_app_in_list(self, direction):
        """Move the selected app one spot up (-1) or down (+1) in the
        Your Apps row. The order is saved and the row rebuilds in
        that order; the moved app stays selected."""
        key = self._selected_app_key()
        if key is None:
            return
        order = load_apps_order() or []
        if key not in order:
            return
        idx = order.index(key)
        new_idx = idx + direction
        if new_idx < 0 or new_idx >= len(order):
            return
        order[idx], order[new_idx] = order[new_idx], order[idx]
        save_apps_order(order)
        self.refresh_apps_store()
        self.launcher.build_rows()
        # Keep the moved app selected.
        for row in self.custom_store:
            if row[3] == key:
                self.custom_tree.get_selection().select_iter(row.iter)
                break

    def on_install_apk(self, widget):
        path = self.apk_entry.get_text().strip()
        if not path:
            return
        # A URL gets downloaded first, then installed.
        if path.startswith("http://") or path.startswith("https://"):
            import urllib.request
            import tempfile
            import os
            try:
                tmp = os.path.join(tempfile.gettempdir(),
                                   os.path.basename(path) or "app.apk")
                urllib.request.urlretrieve(path, tmp)
                path = tmp
            except Exception:
                self.apk_status.set_text("Couldn't download that APK.")
                return
        try:
            result = subprocess.run(
                ["waydroid", "app", "install", path],
                capture_output=True, timeout=120)
            if result.returncode == 0:
                self.apk_status.set_text(
                    "Installed. It's at the front of Your Apps.")
                self.apk_entry.set_text("")
                # The new app is discovered on rebuild and lands at
                # the front of the row (assemble_apps).
                self.refresh_apps_store()
                self.launcher.build_rows()
            else:
                self.apk_status.set_text(
                    "Install didn't work here (Waydroid may not be running).")
        except Exception:
            self.apk_status.set_text(
                "Waydroid isn't available on this machine.")

    def on_add_custom_app(self, widget):
        name = self.custom_name.get_text().strip()
        target = self.custom_target.get_text().strip()
        if not name or not target:
            return
        kind = self.custom_kind.get_active_text() or "web"
        row_text = self.custom_row.get_active_text() or "Your Apps"
        row = "social" if row_text == "Social Media" else "apps"
        letter = name[0].upper()
        apps = load_custom_apps()
        # New apps go to the front -- of the custom list, and (via
        # assemble_apps) of the Your Apps row itself.
        apps.insert(0, {"name": name, "letter": letter, "colour": "#5a5a6a",
                        "kind": kind, "target": target, "fallback": "",
                        "row": row})
        save_custom_apps(apps)
        self.refresh_apps_store()
        self.custom_name.set_text("")
        self.custom_target.set_text("")
        self.launcher.build_rows()

    def on_remove_custom_app(self, widget):
        selection = self.custom_tree.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return
        key = model[tree_iter][3]
        source = model[tree_iter][1]
        if source == "custom":
            # A custom app: delete the entry itself.
            apps = [a for a in load_custom_apps()
                    if "%s:%s" % (a.get("kind", "web"),
                                  a.get("target", "")) != key]
            save_custom_apps(apps)
        else:
            # A built-in or installed app: hide it from the row so it
            # doesn't come back on the next rebuild.
            hidden = load_apps_hidden()
            if key not in hidden:
                hidden.append(key)
                save_apps_hidden(hidden)
        order = [k for k in (load_apps_order() or []) if k != key]
        save_apps_order(order)
        self.refresh_apps_store()
        self.launcher.build_rows()

    def on_add_social_feed(self, widget):
        service = self.feed_service.get_active_text() or "youtube"
        channel = self.feed_channel.get_text().strip()
        if not channel:
            return
        label = channel.lstrip("@")
        feeds = load_social_feeds()
        if any(f.get("service") == service and
               f.get("channel") == channel for f in feeds):
            return
        feeds.append({"service": service, "channel": channel,
                      "label": label})
        save_social_feeds(feeds)
        self.feed_store.append([service, channel, label])
        self.feed_channel.set_text("")
        self.launcher.refresh_social_feed()

    def on_remove_social_feed(self, widget):
        selection = self.feed_tree.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return
        service = model[tree_iter][0]
        channel = model[tree_iter][1]
        model.remove(tree_iter)
        feeds = [f for f in load_social_feeds()
                 if not (f.get("service") == service and
                         f.get("channel") == channel)]
        save_social_feeds(feeds)
        self.launcher.refresh_social_feed()

    # -- IPTV sources ---------------------------------------------------------
    def build_iptv_page(self):
        page = self._page_box("IPTV Sources")
        hint = Gtk.Label(
            label="Type in an M3U playlist URL or an Xtream host, then Add.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        self.playlist_store = Gtk.ListStore(str, str, str)
        for p in load_playlists():
            self.playlist_store.append([p.get("name", ""),
                                        p.get("url", ""),
                                        p.get("type", "m3u")])
        tree = Gtk.TreeView(model=self.playlist_store)
        for i, col_name in enumerate(["Name", "URL", "Type"]):
            renderer = Gtk.CellRendererText()
            col = Gtk.TreeViewColumn(col_name, renderer, text=i)
            tree.append_column(col)
        self.playlist_tree = tree
        scroll = Gtk.ScrolledWindow()
        scroll.set_size_request(-1, 160)
        scroll.add(tree)
        page.pack_start(scroll, False, False, 0)

        add_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.new_name = Gtk.Entry()
        self.new_name.set_placeholder_text("Name (e.g. Cozy Streamz)")
        self.new_url = Gtk.Entry()
        self.new_url.set_placeholder_text("M3U URL or Xtream host")
        self.new_user = Gtk.Entry()
        self.new_user.set_placeholder_text("Username (Xtream login, optional)")
        self.new_pass = Gtk.Entry()
        self.new_pass.set_placeholder_text("Password (Xtream login, optional)")
        self.new_pass.set_visibility(False)
        self.new_type = Gtk.ComboBoxText()
        self.new_type.append_text("m3u")
        self.new_type.append_text("xtream")
        self.new_type.set_active(0)
        add_btn = Gtk.Button(label="Add source")
        add_btn.connect("clicked", self.on_add_source)
        remove_btn = Gtk.Button(label="Remove selected")
        remove_btn.connect("clicked", self.on_remove_source)
        add_box.pack_start(self.new_name, False, False, 0)
        add_box.pack_start(self.new_url, False, False, 0)
        add_box.pack_start(self.new_user, False, False, 0)
        add_box.pack_start(self.new_pass, False, False, 0)
        add_box.pack_start(self.new_type, False, False, 0)
        add_box.pack_start(add_btn, False, False, 0)
        add_box.pack_start(remove_btn, False, False, 0)
        page.pack_start(add_box, False, False, 0)

        self.stack.add_named(page, "iptv")
        self._build_iptv_page_extra()

    def on_add_source(self, widget):
        name = self.new_name.get_text().strip()
        url = self.new_url.get_text().strip()
        if not url:
            return
        type_ = self.new_type.get_active_text() or "m3u"
        user = self.new_user.get_text().strip()
        pw = self.new_pass.get_text()
        self.playlist_store.append([name or url, url, type_])
        playlists = load_playlists()
        playlists.append({"name": name or url, "url": url, "type": type_,
                          "username": user, "password": pw})
        save_playlists(playlists)
        self.new_name.set_text("")
        self.new_url.set_text("")
        self.new_user.set_text("")
        self.new_pass.set_text("")

    def on_remove_source(self, widget):
        selection = self.playlist_tree.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return
        url = model[tree_iter][1]
        model.remove(tree_iter)
        playlists = [p for p in load_playlists() if p.get("url") != url]
        save_playlists(playlists)

    # -- Bluetooth -------------------------------------------------------------
    def build_bluetooth_page(self):
        page = self._page_box("Bluetooth")
        hint = Gtk.Label(label="Pair a remote, headphones or a controller.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        self.bt_switch = Gtk.Switch()
        self.bt_switch.set_active(True)
        self.bt_switch.connect("notify::active", self.on_bluetooth_toggled)
        bt_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        bt_row.pack_start(Gtk.Label(label="Bluetooth"), False, False, 0)
        bt_row.pack_end(self.bt_switch, False, False, 0)
        page.pack_start(bt_row, False, False, 0)

        self.bt_status = Gtk.Label(label="")
        self.bt_status.set_halign(Gtk.Align.START)
        self.bt_status.set_line_wrap(True)
        page.pack_start(self.bt_status, False, False, 0)
        self.refresh_bluetooth_status()

        self.stack.add_named(page, "bluetooth")

    def refresh_bluetooth_status(self):
        try:
            out = subprocess.check_output(
                ["bluetoothctl", "devices"], timeout=5,
                stderr=subprocess.DEVNULL).decode("utf-8", "replace")
            devices = [l for l in out.strip().splitlines() if l.strip()]
            if devices:
                lines = []
                for line in devices:
                    # bluetoothctl prints: "Device AA:BB:CC:DD:EE:FF Name".
                    # The Alexa Voice Remote advertises its own name, so it
                    # shows up as an Alexa Voice Remote, not a generic
                    # Bluetooth device -- flag it as the supported remote.
                    name = line.split(None, 2)[2] if len(
                        line.split(None, 2)) > 2 else line
                    if "alexa" in name.lower():
                        lines.append(line + "  (Alexa Voice Remote -- "
                                        "supported remote)")
                    else:
                        lines.append(line)
                self.bt_status.set_text("Paired:\n" + "\n".join(lines))
            else:
                self.bt_status.set_text("No paired devices yet.")
        except Exception:
            self.bt_status.set_text(
                "Bluetooth isn't available on this machine.")

    def on_bluetooth_toggled(self, switch, _param):
        # Same control the Navigator preset uses (set_bluetooth_power).
        set_bluetooth_power(switch.get_active())
        self.refresh_bluetooth_status()

    # -- Wi-Fi ------------------------------------------------------------------
    # -- Wi-Fi (Nov 16: scanned list, password, connect / forget, saved) -------
    def build_wifi_page(self):
        page = self._page_box("Wi-Fi")
        self.wifi_switch = Gtk.Switch()
        radio = wifi_radio_enabled()
        self.wifi_switch.set_active(True if radio is None else radio)
        self.wifi_switch.connect("notify::active", self.on_wifi_toggled)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.pack_start(Gtk.Label(label="Wi-Fi"), False, False, 0)
        row.pack_end(self.wifi_switch, False, False, 0)
        page.pack_start(row, False, False, 0)

        self.wifi_status = Gtk.Label(label="")
        self.wifi_status.set_halign(Gtk.Align.START)
        self.wifi_status.set_line_wrap(True)
        page.pack_start(self.wifi_status, False, False, 0)
        # Wired too (built-in or USB-C / USB Ethernet adapters).
        self.eth_status = Gtk.Label(label="Ethernet: checking…")
        self.eth_status.set_halign(Gtk.Align.START)
        self.eth_status.get_style_context().add_class("eth-status")
        page.pack_start(self.eth_status, False, False, 0)

        head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        nets_label = Gtk.Label()
        nets_label.set_markup("<b>Available networks</b>")
        nets_label.set_halign(Gtk.Align.START)
        head.pack_start(nets_label, True, True, 0)
        self.wifi_scan_btn = Gtk.Button(label="Scan")
        self.wifi_scan_btn.connect("clicked",
                                   lambda w: self.wifi_refresh(True))
        head.pack_end(self.wifi_scan_btn, False, False, 0)
        page.pack_start(head, False, False, 0)

        self.wifi_list = Gtk.ListBox()
        self.wifi_list.get_style_context().add_class("wifi-list")
        self.wifi_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.wifi_list.set_activate_on_single_click(True)
        self.wifi_list.connect("row-activated", self.on_wifi_row)
        page.pack_start(self.wifi_list, False, False, 0)

        # Connect box: shows under the list for the picked network.
        self.wifi_target = None
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.get_style_context().add_class("wifi-connect-box")
        self.wifi_target_label = Gtk.Label()
        self.wifi_target_label.set_halign(Gtk.Align.START)
        self.wifi_target_label.set_markup("<b>Pick a network above</b>")
        box.pack_start(self.wifi_target_label, False, False, 0)
        self.wifi_ssid_entry = Gtk.Entry()
        self.wifi_ssid_entry.set_placeholder_text(
            "Network name (hidden network)")
        box.pack_start(self.wifi_ssid_entry, False, False, 0)
        self.wifi_pw_entry = Gtk.Entry()
        self.wifi_pw_entry.set_visibility(False)
        self.wifi_pw_entry.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        self.wifi_pw_entry.set_placeholder_text("Password")
        self.wifi_pw_entry.connect("activate",
                                   lambda w: self.on_wifi_connect(None))
        box.pack_start(self.wifi_pw_entry, False, False, 0)
        show_pw = Gtk.CheckButton(label="Show password")
        show_pw.connect("toggled", lambda c: self.wifi_pw_entry
                        .set_visibility(c.get_active()))
        box.pack_start(show_pw, False, False, 0)
        btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.wifi_connect_btn = Gtk.Button(label="Connect")
        self.wifi_connect_btn.connect("clicked", self.on_wifi_connect)
        btns.pack_start(self.wifi_connect_btn, True, True, 0)
        self.wifi_disconnect_btn = Gtk.Button(label="Disconnect")
        self.wifi_disconnect_btn.connect("clicked", self.on_wifi_disconnect)
        btns.pack_start(self.wifi_disconnect_btn, True, True, 0)
        hidden_btn = Gtk.Button(label="Hidden network…")
        hidden_btn.connect("clicked", self.on_wifi_hidden)
        btns.pack_start(hidden_btn, True, True, 0)
        box.pack_start(btns, False, False, 0)
        page.pack_start(box, False, False, 0)
        page._keep_hidden = [self.wifi_ssid_entry]

        saved_label = Gtk.Label()
        saved_label.set_markup("<b>Saved networks</b>")
        saved_label.set_halign(Gtk.Align.START)
        page.pack_start(saved_label, False, False, 0)
        self.wifi_saved_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                      spacing=6)
        page.pack_start(self.wifi_saved_box, False, False, 0)

        self.stack.add_named(page, "wifi")
        self._wifi_busy = False

    def _on_show_wifi(self):
        self.wifi_refresh(False)

    def refresh_wifi_status(self):
        self.wifi_refresh(False)

    def _wifi_run(self, work, done):
        """Run nmcli work off the GTK thread; done(result) on the GTK
        thread."""
        def worker():
            try:
                result = work()
            except Exception as exc:
                result = exc
            GLib.idle_add(lambda: (done(result), False)[1])
        threading.Thread(target=worker, daemon=True).start()

    def wifi_refresh(self, rescan=False):
        if self._wifi_busy:
            return
        self._wifi_busy = True
        self.wifi_status.set_text("Scanning for networks…" if rescan
                                  else "Checking Wi-Fi…")
        self.wifi_scan_btn.set_sensitive(False)

        def work():
            radio = wifi_radio_enabled()
            nets, err = wifi_scan(rescan) if radio is not False else ([], "")
            return (radio, nets, err, wifi_saved(), wifi_device(),
                    ethernet_status())

        self._wifi_run(work, self._wifi_refreshed)

    def _wifi_refreshed(self, result):
        self._wifi_busy = False
        self.wifi_scan_btn.set_sensitive(True)
        if isinstance(result, Exception):
            self.wifi_status.set_text("Wi-Fi isn't available here.")
            return
        radio, nets, err, saved, dev, eth = result
        self.eth_status.set_markup("<b>%s</b>" % _esc(eth))
        for child in self.wifi_list.get_children():
            self.wifi_list.remove(child)
        for child in self.wifi_saved_box.get_children():
            self.wifi_saved_box.remove(child)
        if radio is not None:
            self.wifi_switch.handler_block_by_func(self.on_wifi_toggled)
            self.wifi_switch.set_active(radio)
            self.wifi_switch.handler_unblock_by_func(self.on_wifi_toggled)
        saved_ssids = {p["ssid"] for p in saved}
        current = None
        if nets is None:
            self.wifi_status.set_text(
                "Can't scan: %s" % (err or "NetworkManager isn't running."))
            nets = []
        elif radio is False:
            self.wifi_status.set_text("Wi-Fi is off.")
        elif dev is None:
            self.wifi_status.set_text(
                "No Wi-Fi adapter found (check the driver / firmware).")
        for net in nets:
            if net["in_use"]:
                current = net["ssid"]
            row = Gtk.ListBoxRow()
            row.ssid = net["ssid"]
            row.secured = bool(net["security"])
            line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            line.set_margin_start(10)
            line.set_margin_end(10)
            line.set_margin_top(8)
            line.set_margin_bottom(8)
            name = Gtk.Label()
            extra = ""
            if net["in_use"]:
                extra = "  <small>Connected</small>"
            elif net["ssid"] in saved_ssids:
                extra = "  <small>Saved</small>"
            name.set_markup("<b>%s</b>%s" % (_esc(net["ssid"]), extra))
            name.set_halign(Gtk.Align.START)
            name.set_ellipsize(3)  # Pango.EllipsizeMode.END
            line.pack_start(name, True, True, 0)
            lock = Gtk.Label(label="🔒" if net["security"] and
                             not net["in_use"] else "")
            line.pack_end(lock, False, False, 0)
            bars = Gtk.Label(label=wifi_signal_bars(net["signal"]))
            bars.set_tooltip_text("%d%%" % net["signal"])
            line.pack_end(bars, False, False, 0)
            row.add(line)
            self.wifi_list.add(row)
        if not nets and radio is not False and nets is not None:
            empty = Gtk.ListBoxRow()
            empty.ssid = None
            empty.add(Gtk.Label(label="No networks found yet -- press Scan."))
            self.wifi_list.add(empty)
        if nets and radio is not False:
            self.wifi_status.set_text(
                ("Connected to: %s" % current) if current
                else "Not connected. Pick a network to join.")
        for prof in saved:
            line = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            lab = Gtk.Label()
            lab.set_markup("%s%s" % (_esc(prof["ssid"] or prof["name"]),
                                     "  <small>(active)</small>"
                                     if prof["active"] else ""))
            lab.set_halign(Gtk.Align.START)
            line.pack_start(lab, True, True, 0)
            join = Gtk.Button(label="Connect")
            join.connect("clicked", lambda w, s=prof["ssid"]:
                         self._wifi_do_connect(s, "", False))
            line.pack_end(join, False, False, 0)
            forget = Gtk.Button(label="Forget")
            forget.connect("clicked", self.on_wifi_forget, prof["uuid"],
                           prof["ssid"])
            line.pack_end(forget, False, False, 0)
            self.wifi_saved_box.pack_start(line, False, False, 0)
        if not saved:
            none = Gtk.Label(label="No saved networks yet.")
            none.set_halign(Gtk.Align.START)
            self.wifi_saved_box.pack_start(none, False, False, 0)
        self.wifi_list.show_all()
        self.wifi_saved_box.show_all()
        self.wifi_disconnect_btn.set_sensitive(current is not None)

    def on_wifi_row(self, listbox, row):
        ssid = getattr(row, "ssid", None)
        if not ssid:
            return
        self.wifi_target = ssid
        self.wifi_ssid_entry.hide()
        self.wifi_target_label.set_markup("<b>%s</b>" % _esc(ssid))
        self.wifi_pw_entry.set_text("")
        self.wifi_pw_entry.set_sensitive(getattr(row, "secured", True))
        self.wifi_pw_entry.set_placeholder_text(
            "Password" if getattr(row, "secured", True)
            else "Open network -- no password")
        if getattr(row, "secured", True):
            self.wifi_pw_entry.grab_focus()
        else:
            self.wifi_connect_btn.grab_focus()

    def on_wifi_hidden(self, widget):
        self.wifi_target = None
        self.wifi_target_label.set_markup("<b>Hidden network</b>")
        self.wifi_ssid_entry.show()
        self.wifi_pw_entry.set_sensitive(True)
        self.wifi_ssid_entry.grab_focus()

    def on_wifi_connect(self, widget):
        hidden = self.wifi_ssid_entry.get_visible()
        ssid = (self.wifi_ssid_entry.get_text().strip() if hidden
                else self.wifi_target)
        if not ssid:
            self.wifi_status.set_text("Pick a network first.")
            return
        self._wifi_do_connect(ssid, self.wifi_pw_entry.get_text(), hidden)

    def _wifi_do_connect(self, ssid, password, hidden):
        self.wifi_status.set_text("Connecting to %s…" % ssid)
        self.wifi_connect_btn.set_sensitive(False)

        def done(result):
            self.wifi_connect_btn.set_sensitive(True)
            ok, msg = ((False, str(result)) if isinstance(result, Exception)
                       else result)
            self.wifi_pw_entry.set_text("")
            self.wifi_refresh(False)
            GLib.timeout_add(1500, lambda: (
                self.wifi_status.set_text(msg), False)[1])
        self._wifi_run(lambda: wifi_connect(ssid, password, hidden), done)

    def on_wifi_forget(self, widget, uuid, ssid):
        self._wifi_run(lambda: wifi_forget(uuid),
                       lambda r: self.wifi_refresh(False))

    def on_wifi_disconnect(self, widget):
        self._wifi_run(wifi_disconnect, lambda r: self.wifi_refresh(False))

    def on_wifi_toggled(self, switch, _param):
        # Same control the Navigator preset uses (set_wifi_radio).
        set_wifi_radio(switch.get_active())
        GLib.timeout_add(2500, lambda: (self.wifi_refresh(True), False)[1])

    # -- Display (Nov 16: resolution, scaling, rotation, brightness) -----------
    def build_display_page(self):
        page = self._page_box("Display")
        self.display_status = Gtk.Label(label="")
        self.display_status.set_halign(Gtk.Align.START)
        self.display_status.set_line_wrap(True)
        page.pack_start(self.display_status, False, False, 0)

        grid = Gtk.Grid(column_spacing=12, row_spacing=10)
        labels = ["Screen", "Resolution", "Scaling", "Rotation"]
        for i, text in enumerate(labels):
            lab = Gtk.Label(label=text)
            lab.set_halign(Gtk.Align.START)
            grid.attach(lab, 0, i, 1, 1)
        self.display_output_combo = Gtk.ComboBoxText()
        self.display_output_combo.set_hexpand(True)
        self.display_output_combo.connect("changed", self._display_fill_modes)
        grid.attach(self.display_output_combo, 1, 0, 1, 1)
        self.display_mode_combo = Gtk.ComboBoxText()
        grid.attach(self.display_mode_combo, 1, 1, 1, 1)
        self.display_scale_combo = Gtk.ComboBoxText()
        for sc in DISPLAY_SCALES:
            self.display_scale_combo.append(sc, sc + "×")
        grid.attach(self.display_scale_combo, 1, 2, 1, 1)
        self.display_rot_combo = Gtk.ComboBoxText()
        for key, label in DISPLAY_TRANSFORMS:
            self.display_rot_combo.append(key, label)
        grid.attach(self.display_rot_combo, 1, 3, 1, 1)
        page.pack_start(grid, False, False, 0)

        apply_btn = Gtk.Button(label="Apply")
        apply_btn.connect("clicked", self.on_display_apply)
        page.pack_start(apply_btn, False, False, 0)
        if is_steam_deck():
            deck_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                               spacing=8)
            for hz in (60, 90):
                b = Gtk.Button(label="Deck native 1280×800 @%d Hz" % hz)
                b.connect("clicked", self.on_display_deck_native, hz)
                b._deck_hz = hz
                deck_row.pack_start(b, True, True, 0)
            self.display_deck_row = deck_row
            page.pack_start(deck_row, False, False, 0)
        self.display_keep_box = Gtk.Box(
            orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.display_keep_label = Gtk.Label(label="")
        self.display_keep_box.pack_start(self.display_keep_label,
                                         True, True, 0)
        keep = Gtk.Button(label="Keep")
        keep.connect("clicked", lambda w: self._display_keep(True))
        revert = Gtk.Button(label="Revert")
        revert.connect("clicked", lambda w: self._display_keep(False))
        self.display_keep_box.pack_end(revert, False, False, 0)
        self.display_keep_box.pack_end(keep, False, False, 0)
        page.pack_start(self.display_keep_box, False, False, 0)
        page._keep_hidden = [self.display_keep_box]

        bl = Gtk.Label()
        bl.set_markup("<b>Brightness</b>")
        bl.set_halign(Gtk.Align.START)
        page.pack_start(bl, False, False, 0)
        self.brightness_scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 5, 100, 5)
        self.brightness_scale.set_value(brightness_get() or 100)
        self.brightness_scale.connect(
            "value-changed",
            lambda s: brightness_set(s.get_value()))
        self.brightness_note = Gtk.Label(label="")
        self.brightness_note.set_halign(Gtk.Align.START)
        page.pack_start(self.brightness_scale, False, False, 0)
        page.pack_start(self.brightness_note, False, False, 0)
        self._display_outputs = []
        self._display_prev = None
        self._display_timer = None
        self.stack.add_named(page, "display")
        self._build_ui_scale_row()

    def _on_show_display(self):
        outs = display_outputs()
        self._display_outputs = outs or []
        self.display_output_combo.remove_all()
        if not outs:
            self.display_status.set_text(
                "Display controls need a wlroots compositor (labwc) and "
                "wlr-randr -- not available in this session.")
        else:
            self.display_status.set_text(
                "Pick a screen, then Apply. Changes revert in 15 s "
                "unless you press Keep.")
            for o in outs:
                label = o["name"] + (("  " + o["description"][:28])
                                     if o["description"] else "")
                self.display_output_combo.append(o["name"], label)
            self.display_output_combo.set_active(0)
        b = brightness_get()
        self.brightness_scale.set_sensitive(b is not None)
        if b is not None:
            self.brightness_scale.set_value(b)
            self.brightness_note.set_text("")
        else:
            self.brightness_note.set_text(
                "No built-in backlight (TVs use their own remote).")

    def _display_current(self):
        name = self.display_output_combo.get_active_id()
        for o in self._display_outputs:
            if o["name"] == name:
                return o
        return None

    def _display_fill_modes(self, combo=None):
        o = self._display_current()
        self.display_mode_combo.remove_all()
        if o is None:
            return
        seen = set()
        active = None
        for (w, h, hz, cur, pref) in o["modes"]:
            key = "%dx%d@%.3f" % (w, h, hz)
            if key in seen:
                continue
            seen.add(key)
            if (w, h) in ((800, 1280), (1280, 800)) and is_steam_deck():
                text = "1280 × 800  %.0f Hz  (Steam Deck native, 16:10)" % hz
            else:
                text = "%d × %d  %.0f Hz%s" % (w, h, hz,
                                               "  (native)" if pref else "")
            self.display_mode_combo.append(key, text)
            if cur:
                active = key
        if active:
            self.display_mode_combo.set_active_id(active)
        else:
            self.display_mode_combo.set_active(0)
        if getattr(self, "display_deck_row", None) is not None:
            has90 = any(round(m[2]) >= 88 for m in o["modes"])
            for b in self.display_deck_row.get_children():
                if getattr(b, "_deck_hz", 0) == 90 and not has90:
                    b.hide()
                    self.stack.get_child_by_name("display")._keep_hidden = \
                        [self.display_keep_box, b]
        scale = ("%g" % o["scale"])
        if not self.display_scale_combo.set_active_id(scale):
            self.display_scale_combo.append(scale, scale + "×")
            self.display_scale_combo.set_active_id(scale)
        self.display_rot_combo.set_active_id(o["transform"])

    def on_display_deck_native(self, _w=None, hz=None):
        """Steam Deck preset: 1280x800 16:10 landscape (panel mode
        800x1280 rotated 270), scale 1, best (or chosen) refresh."""
        o = self._display_current()
        if o is None:
            return
        modes = [m for m in o["modes"] if (m[0], m[1]) in
                 ((800, 1280), (1280, 800))]
        if hz:
            modes = [m for m in modes if round(m[2]) == hz] or modes
        if not modes:
            self.display_status.set_text("No 1280 × 800 mode on this screen.")
            return
        w, h, r, _c, _p = max(modes, key=lambda m: m[2])
        key = "%dx%d@%.3f" % (w, h, r)
        self.display_mode_combo.set_active_id(key)
        self.display_scale_combo.set_active_id("1")
        if w < h:
            self.display_rot_combo.set_active_id("270")
        self.on_display_apply(None)

    def on_display_apply(self, widget):
        o = self._display_current()
        if o is None:
            return
        cur_mode = next(((w, h, hz) for (w, h, hz, c, _p) in o["modes"]
                         if c), None)
        self._display_prev = (o["name"], cur_mode, "%g" % o["scale"],
                              o["transform"])
        mode = None
        mid = self.display_mode_combo.get_active_id()
        if mid:
            wh, hz = mid.split("@")
            w, h = wh.split("x")
            mode = (int(w), int(h), float(hz))
        ok, msg = display_apply(o["name"], mode,
                                self.display_scale_combo.get_active_id(),
                                self.display_rot_combo.get_active_id())
        self.display_status.set_text(msg)
        if ok:
            self._display_countdown = 15
            self.display_keep_box.show_all()
            self._display_tick()
            if self._display_timer:
                GLib.source_remove(self._display_timer)
            self._display_timer = GLib.timeout_add(1000, self._display_tick)

    def _display_tick(self):
        if self._display_countdown <= 0:
            self._display_keep(False)
            return False
        self.display_keep_label.set_text(
            "Keep these settings? Reverting in %d s" % self._display_countdown)
        self._display_countdown -= 1
        return True

    def _display_keep(self, keep):
        if self._display_timer:
            GLib.source_remove(self._display_timer)
            self._display_timer = None
        self.display_keep_box.hide()
        prev, self._display_prev = self._display_prev, None
        if keep:
            # Remember it so the session re-applies it next start.
            o = self._display_current()
            if o is not None:
                st = self.launcher.settings
                st.setdefault("display", {})[o["name"]] = {
                    "mode": self.display_mode_combo.get_active_id(),
                    "scale": self.display_scale_combo.get_active_id(),
                    "transform": self.display_rot_combo.get_active_id()}
                save_settings(st)
            self.display_status.set_text("Saved.")
        elif prev is not None:
            name, mode, scale, transform = prev
            display_apply(name, mode, scale, transform)
            self.display_status.set_text("Reverted.")
        GLib.timeout_add(800, lambda: (self._on_show_display(), False)[1])

    # -- Browser picker (Nov 16: Brave by default, pick any) -------------------
    def build_browser_page(self):
        page = self._page_box("Browser")
        hint = Gtk.Label(label="Web tiles (Netflix, Rumble, YouTube, ...) "
                               "and links open in this browser.")
        hint.set_line_wrap(True)
        hint.set_halign(Gtk.Align.START)
        page.pack_start(hint, False, False, 0)
        self.browser_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                   spacing=8)
        page.pack_start(self.browser_box, False, False, 0)
        self.browser_status = Gtk.Label(label="")
        self.browser_status.set_halign(Gtk.Align.START)
        self.browser_status.set_line_wrap(True)
        page.pack_start(self.browser_status, False, False, 0)
        self.stack.add_named(page, "browser")

    def _on_show_browser(self):
        for c in self.browser_box.get_children():
            self.browser_box.remove(c)
        current = current_browser()
        group = None
        installed = dict(installed_browsers())
        for key, label, _bins, _desk in BROWSERS:
            if key not in installed and key not in ("brave", "firefox",
                                                    "chrome"):
                continue
            text = label + ("" if key in installed else "  (not installed)")
            rb = Gtk.RadioButton.new_with_label_from_widget(group, text)
            group = group or rb
            rb.set_sensitive(key in installed)
            rb.set_active(key == current)
            rb.connect("toggled", self.on_browser_pick, key)
            self.browser_box.pack_start(rb, False, False, 0)
        self.browser_box.show_all()
        name = dict((k, l) for k, l, *_ in BROWSERS).get(current, current)
        self.browser_status.set_text(
            "Default: %s%s" % (name, "" if current in installed else
                               " (not installed -- using the first one "
                               "that is)"))

    def on_browser_pick(self, rb, key):
        if not rb.get_active():
            return
        set_default_browser(key)
        self.launcher.settings["browser"] = key
        name = dict((k, l) for k, l, *_ in BROWSERS).get(key, key)
        self.browser_status.set_text("Default: %s" % name)

    # -- Launcher updates (Nov 16: self-updating launcher) ---------------------
    def build_updates_page(self):
        page = self._page_box("Updates")
        info = Gtk.Label()
        info.set_line_wrap(True)
        info.set_halign(Gtk.Align.START)
        self.updates_info = info
        page.pack_start(info, False, False, 0)
        auto = Gtk.CheckButton(label="Check for a newer launcher at startup")
        auto.set_active(read_update_config().get("enabled", True))
        auto.connect("toggled", lambda c: write_update_config(
            enabled=c.get_active()))
        page.pack_start(auto, False, False, 0)
        url_label = Gtk.Label(label="Update URL (manifest JSON)")
        url_label.set_halign(Gtk.Align.START)
        page.pack_start(url_label, False, False, 0)
        self.updates_url = Gtk.Entry()
        self.updates_url.set_text(read_update_config().get("url", ""))
        page.pack_start(self.updates_url, False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        save = Gtk.Button(label="Save URL")
        save.connect("clicked", lambda w: (write_update_config(
            url=self.updates_url.get_text().strip()),
            self.updates_status.set_text("Saved.")))
        row.pack_start(save, True, True, 0)
        check = Gtk.Button(label="Check now")
        check.connect("clicked", self.on_updates_check)
        row.pack_start(check, True, True, 0)
        reset = Gtk.Button(label="Use built-in")
        reset.connect("clicked", self.on_updates_reset)
        row.pack_start(reset, True, True, 0)
        page.pack_start(row, False, False, 0)
        self.updates_status = Gtk.Label(label="")
        self.updates_status.set_line_wrap(True)
        self.updates_status.set_halign(Gtk.Align.START)
        page.pack_start(self.updates_status, False, False, 0)
        self.stack.add_named(page, "updates")

    def _on_show_updates(self):
        running = os.environ.get("AERO_DECK_RUNNING_FROM", "built-in")
        self.updates_info.set_markup(
            "Launcher version <b>%s</b> (%s copy).\n"
            "When online, Aero Deck checks the URL below at startup and "
            "loads a newer launcher if one is published. If the new one "
            "fails to start, it falls back to the built-in launcher "
            "automatically." % (_esc(AERO_DECK_VERSION), _esc(running)))

    def on_updates_check(self, widget):
        self.updates_status.set_text("Checking…")
        write_update_config(url=self.updates_url.get_text().strip())

        def work():
            try:
                res = subprocess.run(["aero-deck-update", "--check-only"],
                                     capture_output=True, text=True,
                                     timeout=60)
                return (res.stdout or res.stderr).strip()[-300:]
            except Exception as exc:
                return "Update check failed: %s" % exc
        def worker():
            msg = work()
            GLib.idle_add(lambda: (self.updates_status.set_text(
                msg or "Done. Restart the launcher to use it."), False)[1])
        threading.Thread(target=worker, daemon=True).start()

    def on_updates_reset(self, widget):
        _spawn(["aero-deck-update", "--reset"], stdout=subprocess.DEVNULL,
               stderr=subprocess.DEVNULL)
        self.updates_status.set_text(
            "Downloaded launcher removed -- the built-in one is used from "
            "the next start.")

    # -- Install Aero Deck to a drive (Nov 16) --------------------------------
    def build_install_page(self):
        page = self._page_box("Install Aero Deck")
        warn = Gtk.Label()
        warn.set_line_wrap(True)
        warn.set_halign(Gtk.Align.START)
        warn.set_markup(
            "<b>Installs Aero Deck permanently onto a drive.</b>\n"
            "<span foreground='#c0392b'><b>WARNING: the drive you pick is "
            "completely ERASED</b> -- every partition, file and other "
            "operating system on it (SteamOS / Windows) is gone for "
            "good.</span>\nBack up first. Keep the device plugged in; "
            "it takes 5-20 minutes and works offline (it copies this live system).")
        page.pack_start(warn, False, False, 0)
        self.install_disk_combo = Gtk.ComboBoxText()
        page.pack_start(self.install_disk_combo, False, False, 0)
        self.install_confirm = Gtk.CheckButton(
            label="I understand this drive will be wiped")
        page.pack_start(self.install_confirm, False, False, 0)
        go = Gtk.Button(label="Install Aero Deck…")
        go.connect("clicked", self.on_install_go)
        page.pack_start(go, False, False, 0)
        self.install_status = Gtk.Label(label="")
        self.install_status.set_line_wrap(True)
        self.install_status.set_halign(Gtk.Align.START)
        page.pack_start(self.install_status, False, False, 0)
        self.stack.add_named(page, "install")

    def _on_show_install(self):
        self.install_disk_combo.remove_all()
        self.install_confirm.set_active(False)
        disks = list_install_disks()
        for d in disks:
            self.install_disk_combo.append(d["path"], d["label"])
        if disks:
            self.install_disk_combo.set_active(0)
            self.install_status.set_text("")
        else:
            self.install_status.set_text(
                "No drive found that can be installed to (the USB stick "
                "Aero Deck booted from is left out on purpose).")

    def on_install_go(self, widget):
        disk = self.install_disk_combo.get_active_id()
        if not disk:
            self.install_status.set_text("Pick a drive first.")
            return
        if not self.install_confirm.get_active():
            self.install_status.set_text(
                "Tick 'I understand this drive will be wiped' first.")
            return
        label = self.install_disk_combo.get_active_text() or disk
        dialog = Gtk.MessageDialog(
            transient_for=self.launcher, modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.NONE,
            text="Erase %s and install Aero Deck?" % label)
        dialog.format_secondary_text(
            "EVERYTHING on this drive will be deleted. This can't be "
            "undone.")
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        dialog.add_button("Erase and install", Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.CANCEL)
        resp = dialog.run()
        dialog.destroy()
        if resp != Gtk.ResponseType.OK:
            self.install_status.set_text("Cancelled -- nothing changed.")
            return
        # Runs in a terminal so the progress (and any error) is visible;
        # the installer asks for the sudo password itself and confirms
        # the drive one more time by typing ERASE.
        term = shutil.which("foot")
        cmd = ["sudo", "/usr/local/bin/aero-deck-install", disk]
        if term:
            _spawn([term, "--title", "Install Aero Deck", "--"] + cmd)
            self.install_status.set_text(
                "Installer opened in a terminal window.")
        else:
            self.install_status.set_text(
                "No terminal (foot) found -- run: sudo aero-deck-install %s"
                % disk)

    # -- VPN (Proton) --------------------------------------------------------------
    def build_vpn_page(self):
        page = self._page_box("VPN")
        hint = Gtk.Label(label="Proton VPN -- hide the TV's IP.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        self.vpn_switch = Gtk.Switch()
        self.vpn_switch.set_active(False)
        self.vpn_switch.connect("notify::active", self.on_vpn_toggled)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.pack_start(Gtk.Label(label="VPN"), False, False, 0)
        row.pack_end(self.vpn_switch, False, False, 0)
        page.pack_start(row, False, False, 0)

        self.vpn_status = Gtk.Label(label="")
        self.vpn_status.set_halign(Gtk.Align.START)
        self.vpn_status.set_line_wrap(True)
        page.pack_start(self.vpn_status, False, False, 0)
        self.refresh_vpn_status()

        self.stack.add_named(page, "vpn")

    def refresh_vpn_status(self):
        # Proton VPN CLI first, then NetworkManager, then give up gracefully.
        try:
            out = subprocess.check_output(
                ["protonvpn-cli", "status"], timeout=5,
                stderr=subprocess.DEVNULL).decode("utf-8", "replace")
            self.vpn_status.set_text(out.strip() or "VPN off.")
            return
        except Exception:
            pass
        try:
            out = subprocess.check_output(
                ["nmcli", "-t", "-f", "NAME,TYPE", "connection", "show",
                 "--active"], timeout=5,
                stderr=subprocess.DEVNULL).decode("utf-8", "replace")
            vpn = [l for l in out.strip().splitlines()
                   if ":vpn" in l.lower()]
            if vpn:
                self.vpn_status.set_text("Connected: " + vpn[0].split(":")[0])
                return
            self.vpn_status.set_text("VPN off.")
            return
        except Exception:
            pass
        self.vpn_status.set_text("No VPN client found on this machine.")

    def on_vpn_toggled(self, switch, _param):
        on = switch.get_active()
        # Same control the Navigator preset uses (set_vpn_active).
        set_vpn_active(on)
        self.refresh_vpn_status()

    # -- Background --------------------------------------------------------------
    def build_background_page(self):
        page = self._page_box("Background")
        hint = Gtk.Label(label="The backdrop behind the home screen.")
        hint.set_halign(Gtk.Align.START)
        page.pack_start(hint, False, False, 0)
        self.bg_combo = Gtk.ComboBoxText()
        for name in ("blossom", "dark", "midnight", "custom"):
            self.bg_combo.append_text(name)
        current = self.launcher.settings.get("background", "blossom")
        choices = ("blossom", "dark", "midnight", "custom")
        self.bg_combo.set_active(
            choices.index(current) if current in choices else 0)
        self.bg_combo.connect("changed", self.on_background_changed)
        page.pack_start(self.bg_combo, False, False, 0)
        # Custom image: pick any picture on the box as the backdrop.
        choose_btn = Gtk.Button(label="Choose background image…")
        choose_btn.connect("clicked", self.on_choose_background_image)
        page.pack_start(choose_btn, False, False, 0)
        self.stack.add_named(page, "background")

    def on_choose_background_image(self, widget):
        """Pick a custom backdrop image (background becomes "custom")."""
        self.launcher.choose_background_image()

    def on_background_changed(self, combo):
        name = combo.get_active_text()
        if not name:
            return
        if name == "custom" and not self.launcher.settings.get(
                "background_image", ""):
            # No custom image picked yet -- ask for one; if Drew
            # cancels, put the combo back where it was.
            if not self.launcher.choose_background_image():
                previous = self.launcher.settings.get("background",
                                                      "blossom")
                choices = ("blossom", "dark", "midnight", "custom")
                combo.set_active(choices.index(previous)
                                 if previous in choices else 0)
                return
            return
        self.launcher.apply_background(name)

    # -- Appearance ----------------------------------------------------------------
    def build_appearance_page(self):
        page = self._page_box("Appearance")
        theme_label = Gtk.Label(label="Theme")
        theme_label.set_halign(Gtk.Align.START)
        page.pack_start(theme_label, False, False, 0)
        self.theme_combo = Gtk.ComboBoxText()
        self.theme_combo.append_text("dark")
        self.theme_combo.append_text("light")
        self.theme_combo.set_active(
            0 if self.launcher.settings.get("theme", "dark") == "dark" else 1)
        self.theme_combo.connect("changed", self.on_theme_changed)
        page.pack_start(self.theme_combo, False, False, 0)

        # Dark Mode: switches the launcher -- including the
        # Navigator -- to dark. Off by default: the Navigator is
        # light/white unless this is on. Persisted to settings.json.
        dark_label = Gtk.Label(label="Dark Mode")
        dark_label.set_halign(Gtk.Align.START)
        page.pack_start(dark_label, False, False, 0)
        self.dark_mode_switch = Gtk.Switch()
        self.dark_mode_switch.set_active(
            bool(self.launcher.settings.get("dark_mode", False)))
        self.dark_mode_switch.connect(
            "notify::active", self.on_dark_mode_changed)
        page.pack_start(self.dark_mode_switch, False, False, 0)

        accent_label = Gtk.Label(label="Accent colour")
        accent_label.set_halign(Gtk.Align.START)
        page.pack_start(accent_label, False, False, 0)
        self.accent_combo = Gtk.ComboBoxText()
        accents = {"Red": "#e50914", "Blue": "#2266ff", "Purple": "#7b2ff7"}
        self._accents = accents
        for name in accents:
            self.accent_combo.append_text(name)
        current = self.launcher.settings.get("accent", "#e50914")
        values = list(accents.values())
        self.accent_combo.set_active(
            values.index(current) if current in values else 0)
        self.accent_combo.connect("changed", self.on_accent_changed)
        page.pack_start(self.accent_combo, False, False, 0)
        self.stack.add_named(page, "appearance")

    def on_theme_changed(self, combo):
        theme = combo.get_active_text()
        if theme:
            self.launcher.apply_theme(theme)

    def on_dark_mode_changed(self, switch, _pspec):
        self.launcher.apply_dark_mode(switch.get_active())

    def on_accent_changed(self, combo):
        name = combo.get_active_text()
        if name and name in self._accents:
            self.launcher.apply_accent(self._accents[name])

    # -- Keyboard ------------------------------------------------------------------
    def build_keyboard_page(self):
        page = self._page_box("Keyboard")
        hint = Gtk.Label(
            label="Keyboard colour and opacity. Applies live. "
                  "The search, results and keyboard are mostly white "
                  "-- the background barely shows through.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        colour_label = Gtk.Label(label="Keyboard colour")
        colour_label.set_halign(Gtk.Align.START)
        page.pack_start(colour_label, False, False, 0)
        self.kb_colour_combo = Gtk.ComboBoxText()
        for name in KB_COLOR_PRESETS:
            self.kb_colour_combo.append_text(name)
        current = self.launcher.settings.get("keyboard_color", "#ffffff")
        values = list(KB_COLOR_PRESETS.values())
        self.kb_colour_combo.set_active(
            values.index(current) if current in values else 0)
        self.kb_colour_combo.connect("changed", self.on_kb_colour_changed)
        page.pack_start(self.kb_colour_combo, False, False, 0)

        opacity_label = Gtk.Label(label="Keyboard opacity")
        opacity_label.set_halign(Gtk.Align.START)
        page.pack_start(opacity_label, False, False, 0)
        self.kb_opacity_scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL,
            KB_OPACITY_MIN, KB_OPACITY_MAX, 0.05)
        self.kb_opacity_scale.set_value(
            float(self.launcher.settings.get("keyboard_opacity", 1.0)))
        self.kb_opacity_scale.set_draw_value(True)
        self.kb_opacity_scale.connect("format-value",
                                      self.on_kb_opacity_format)
        self.kb_opacity_scale.connect("value-changed",
                                      self.on_kb_opacity_changed)
        page.pack_start(self.kb_opacity_scale, False, False, 0)
        opacity_hint = Gtk.Label(
            label="100% is solid, 30% is very see-through.")
        opacity_hint.set_halign(Gtk.Align.START)
        page.pack_start(opacity_hint, False, False, 0)
        self.stack.add_named(page, "keyboard")

    def on_kb_colour_changed(self, combo):
        name = combo.get_active_text()
        if name and name in KB_COLOR_PRESETS:
            self.launcher.settings["keyboard_color"] = (
                KB_COLOR_PRESETS[name])
            self.launcher.apply_keyboard_appearance()

    def on_kb_opacity_format(self, scale, value):
        return "%d%%" % round(value * 100)

    def on_kb_opacity_changed(self, scale):
        self.launcher.settings["keyboard_opacity"] = round(
            scale.get_value(), 2)
        self.launcher.apply_keyboard_appearance()

    # -- AI (the helm: which AI the Navigator's triangle asks) --------------
    def build_ai_page(self):
        page = self._page_box("Wingman")
        hint = Gtk.Label(
            label="Wingman is the AI at the helm: the Wingman button in "
                  "the Navigator asks this AI. Nova is built-in; Grok, "
                  "ChatGPT and Gemini are listed too, and you can add "
                  "more below.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        self.ai_status = Gtk.Label(label="")
        self.ai_status.set_halign(Gtk.Align.START)
        page.pack_start(self.ai_status, False, False, 0)

        helm_label = Gtk.Label(label="Wingman (the AI at the helm)")
        helm_label.set_halign(Gtk.Align.START)
        page.pack_start(helm_label, False, False, 0)
        self.ai_combo = Gtk.ComboBoxText()
        self.ai_combo.connect("changed", self.on_ai_helm_changed)
        page.pack_start(self.ai_combo, False, False, 0)

        mode_label = Gtk.Label(label="Wingman opens as")
        mode_label.set_halign(Gtk.Align.START)
        page.pack_start(mode_label, False, False, 0)
        mode = self.launcher.settings.get("wingman_mode", "window")
        rb_win = Gtk.RadioButton.new_with_label_from_widget(
            None, "Built-in chat window (inside Aero Deck)")
        rb_app = Gtk.RadioButton.new_with_label_from_widget(
            rb_win, "Android app (Waydroid) -- installs it if missing")
        rb_win.set_active(mode != "android")
        rb_app.set_active(mode == "android")
        for rb, key in ((rb_win, "window"), (rb_app, "android")):
            rb.connect("toggled", self.on_wingman_mode, key)
            page.pack_start(rb, False, False, 0)
        try_btn = Gtk.Button(label="Open Wingman now")
        try_btn.connect("clicked", lambda w: (
            self.launcher.close_settings_panel(), self.launcher.ask_ai("")))
        page.pack_start(try_btn, False, False, 0)

        add_label = Gtk.Label(label="Add an AI")
        add_label.set_halign(Gtk.Align.START)
        page.pack_start(add_label, False, False, 0)
        self.ai_name_entry = Gtk.Entry()
        self.ai_name_entry.set_placeholder_text("Name, e.g. Supreme")
        self.ai_name_entry.set_hexpand(True)
        page.pack_start(self.ai_name_entry, False, False, 0)
        self.ai_url_entry = Gtk.Entry()
        self.ai_url_entry.set_placeholder_text(
            "Web address, e.g. https://grok.com")
        self.ai_url_entry.set_hexpand(True)
        page.pack_start(self.ai_url_entry, False, False, 0)
        self.ai_app_entry = Gtk.Entry()
        self.ai_app_entry.set_placeholder_text(
            "Android app package (optional), e.g. ai.x.grok")
        self.ai_app_entry.set_hexpand(True)
        page.pack_start(self.ai_app_entry, False, False, 0)
        add_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        add_btn = Gtk.Button(label="Add AI")
        add_btn.connect("clicked", self.on_ai_add)
        add_row.pack_start(add_btn, False, False, 0)
        self.ai_remove_btn = Gtk.Button(label="Remove selected")
        self.ai_remove_btn.connect("clicked", self.on_ai_remove)
        add_row.pack_start(self.ai_remove_btn, False, False, 0)
        page.pack_start(add_row, False, False, 0)
        self.ai_note = Gtk.Label(label="")
        self.ai_note.set_halign(Gtk.Align.START)
        self.ai_note.set_line_wrap(True)
        page.pack_start(self.ai_note, False, False, 0)
        self._ai_refreshing = False
        self.refresh_ai_page()
        self.stack.add_named(page, "ai")

    def refresh_ai_page(self):
        """Rebuild the helm chooser from settings["ais"]: the combo
        lists every AI, the active one selected, the status names
        the helm, and Remove is only live for a removable AI (Nova
        is built-in and can't be removed)."""
        ais = self.launcher.settings.get("ais") or []
        active = self.launcher.settings.get("active_ai", "Nova")
        self._ai_refreshing = True
        self.ai_combo.remove_all()
        for ai in ais:
            self.ai_combo.append_text(ai.get("name", ""))
        names = [ai.get("name", "") for ai in ais]
        self.ai_combo.set_active(
            names.index(active) if active in names else 0)
        self._ai_refreshing = False
        self.ai_status.set_text("At the helm: %s" % active)
        selected = self.ai_combo.get_active_text()
        self.ai_remove_btn.set_sensitive(
            selected not in (None, "", "Nova"))

    def on_wingman_mode(self, rb, key):
        if not rb.get_active():
            return
        self.launcher.settings["wingman_mode"] = key
        save_settings(self.launcher.settings)
        self.ai_note.set_text("Wingman opens as: %s" % (
            "the AI's Android app" if key == "android"
            else "a built-in chat window"))

    def on_ai_helm_changed(self, combo):
        if getattr(self, "_ai_refreshing", False):
            return
        name = combo.get_active_text()
        if not name:
            return
        self.launcher.settings["active_ai"] = name
        save_settings(self.launcher.settings)
        self.launcher.refresh_ai_button()
        self.ai_status.set_text("At the helm: %s" % name)
        self.ai_remove_btn.set_sensitive(name != "Nova")

    def on_ai_add(self, button):
        name = self.ai_name_entry.get_text().strip()
        url = self.ai_url_entry.get_text().strip()
        app = self.ai_app_entry.get_text().strip()
        if not name:
            self.ai_note.set_text("Give the AI a name first.")
            return
        if not url:
            self.ai_note.set_text("Give the AI a web address first.")
            return
        if "://" not in url:
            url = "https://" + url
        # Copy the list before mutating: settings["ais"] must never
        # alias the module defaults.
        ais = [dict(ai) for ai in
               (self.launcher.settings.get("ais") or [])]
        if any(ai.get("name", "").lower() == name.lower() for ai in ais):
            self.ai_note.set_text(
                "An AI called %s is already listed." % name)
            return
        ais.append({"name": name, "url": url, "app": app})
        self.launcher.settings["ais"] = ais
        # The new AI takes the helm -- he added it to use it.
        self.launcher.settings["active_ai"] = name
        save_settings(self.launcher.settings)
        self.ai_name_entry.set_text("")
        self.ai_url_entry.set_text("")
        self.ai_app_entry.set_text("")
        self.ai_note.set_text("%s added and at the helm." % name)
        self.launcher.refresh_ai_button()
        self.refresh_ai_page()

    def on_ai_remove(self, button):
        name = self.ai_combo.get_active_text()
        if not name or name == "Nova":
            return  # Nova is built-in and can't be removed
        ais = [ai for ai in (self.launcher.settings.get("ais") or [])
               if ai.get("name") != name]
        self.launcher.settings["ais"] = ais
        if self.launcher.settings.get("active_ai") == name:
            self.launcher.settings["active_ai"] = "Nova"
        save_settings(self.launcher.settings)
        self.ai_note.set_text(
            "%s removed. Nova is at the helm." % name)
        self.launcher.refresh_ai_button()
        self.refresh_ai_page()

    # -- Calendar ------------------------------------------------------------------
    def build_calendar_page(self):
        page = self._page_box("Calendar")
        cal = Gtk.Calendar()
        cal.set_hexpand(True)
        cal.set_vexpand(True)
        cal.connect("day-selected", self.on_cal_day_selected)
        self.cal_page_calendar = cal
        page.pack_start(cal, True, True, 0)
        # Selected day + add an event or a show, with a time.
        self.cal_selected_label = Gtk.Label()
        self.cal_selected_label.set_halign(Gtk.Align.START)
        page.pack_start(self.cal_selected_label, False, False, 0)
        add_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.cal_event_entry = Gtk.Entry()
        self.cal_event_entry.set_placeholder_text("Event or show name")
        self.cal_event_entry.set_hexpand(True)
        add_box.pack_start(self.cal_event_entry, True, True, 0)
        self.cal_time_entry = Gtk.Entry()
        self.cal_time_entry.set_placeholder_text("Time (e.g. 7:00 PM)")
        self.cal_time_entry.set_width_chars(14)
        add_box.pack_start(self.cal_time_entry, False, False, 0)
        self.cal_kind_combo = Gtk.ComboBoxText()
        self.cal_kind_combo.append_text("Event")
        self.cal_kind_combo.append_text("Show")
        self.cal_kind_combo.set_active(0)
        add_box.pack_start(self.cal_kind_combo, False, False, 0)
        add_btn = Gtk.Button(label="Add")
        add_btn.connect("clicked", self.on_cal_add_event)
        add_box.pack_start(add_btn, False, False, 0)
        page.pack_start(add_box, False, False, 0)
        # Events on the selected day.
        self.cal_day_list = Gtk.ListBox()
        page.pack_start(self.cal_day_list, False, False, 0)
        # Reminders: what's coming up next.
        self.cal_upcoming_label = Gtk.Label()
        self.cal_upcoming_label.set_halign(Gtk.Align.START)
        self.cal_upcoming_label.set_line_wrap(True)
        page.pack_start(self.cal_upcoming_label, False, False, 0)
        self.stack.add_named(page, "calendar")
        self.refresh_calendar_marks()
        self.on_cal_day_selected(cal)

    def _cal_selected_date(self):
        y, m, d = self.cal_page_calendar.get_date()
        return "%04d-%02d-%02d" % (y, m + 1, d)

    def on_panel_calendar_day(self, cal):
        """Top-row calendar clicked: open the Calendar page on
        that same day, so events and shows can be scheduled."""
        y, m, d = cal.get_date()
        self.cal_page_calendar.select_month(m, y)
        self.cal_page_calendar.select_day(d)
        self.show_page("calendar")

    def refresh_calendar_marks(self):
        cal = self.cal_page_calendar
        y0, m0, _d = cal.get_date()
        for ev in load_events():
            try:
                y, m, d = (int(p) for p in ev.get("date", "").split("-"))
                if (y, m) == (y0, m0 + 1) and 1 <= d <= 31:
                    cal.mark_day(d)
            except Exception:
                pass

    def on_cal_day_selected(self, cal):
        date = self._cal_selected_date()
        self.cal_selected_label.set_text("Selected: " + date)
        for child in self.cal_day_list.get_children():
            self.cal_day_list.remove(child)
        for ev in load_events():
            if ev.get("date") == date:
                row = Gtk.Label(label="%s  %s  (%s)" % (
                    ev.get("time", ""), ev.get("title", ""),
                    ev.get("kind", "Event")))
                row.set_halign(Gtk.Align.START)
                self.cal_day_list.add(row)
        self.cal_day_list.show_all()
        self.refresh_upcoming()

    def refresh_upcoming(self):
        today = datetime.date.today().isoformat()
        upcoming = sorted(
            (ev for ev in load_events()
             if ev.get("date", "") >= today),
            key=lambda e: (e.get("date", ""), e.get("time", "")))[:5]
        if upcoming:
            lines = ["Reminders:"]
            for ev in upcoming:
                lines.append("%s  %s  %s (%s)" % (
                    ev.get("date", ""), ev.get("time", ""),
                    ev.get("title", ""), ev.get("kind", "Event")))
            self.cal_upcoming_label.set_text("\n".join(lines))
        else:
            self.cal_upcoming_label.set_text(
                "Reminders: nothing scheduled yet.")

    def on_cal_add_event(self, btn):
        title = self.cal_event_entry.get_text().strip()
        if not title:
            return
        events = load_events()
        events.append({
            "date": self._cal_selected_date(),
            "time": self.cal_time_entry.get_text().strip(),
            "kind": self.cal_kind_combo.get_active_text() or "Event",
            "title": title,
        })
        save_events(events)
        self.cal_event_entry.set_text("")
        self.cal_time_entry.set_text("")
        self.refresh_calendar_marks()
        self.on_cal_day_selected(self.cal_page_calendar)

    # -- Tasks ----------------------------------------------------------------------
    def build_tasks_page(self):
        page = self._page_box("Tasks")
        self.task_store = Gtk.ListStore(bool, str)
        for t in load_tasks():
            self.task_store.append([bool(t.get("done", False)),
                                    t.get("text", "")])
        tree = Gtk.TreeView(model=self.task_store)
        done_renderer = Gtk.CellRendererToggle()
        done_renderer.connect("toggled", self.on_task_toggled)
        tree.append_column(Gtk.TreeViewColumn("Done", done_renderer, active=0))
        text_renderer = Gtk.CellRendererText()
        tree.append_column(Gtk.TreeViewColumn("Task", text_renderer, text=1))
        self.task_tree = tree
        scroll = Gtk.ScrolledWindow()
        scroll.set_size_request(-1, 180)
        scroll.add(tree)
        page.pack_start(scroll, False, False, 0)

        add_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.new_task = Gtk.Entry()
        self.new_task.set_placeholder_text("Add a task")
        self.new_task.set_hexpand(True)
        add_btn = Gtk.Button(label="Add")
        add_btn.connect("clicked", self.on_add_task)
        remove_btn = Gtk.Button(label="Remove selected")
        remove_btn.connect("clicked", self.on_remove_task)
        add_box.pack_start(self.new_task, True, True, 0)
        add_box.pack_start(add_btn, False, False, 0)
        add_box.pack_start(remove_btn, False, False, 0)
        page.pack_start(add_box, False, False, 0)
        self.stack.add_named(page, "tasks")

    def _save_tasks_from_store(self):
        tasks = [{"done": row[0], "text": row[1]}
                 for row in self.task_store]
        save_tasks(tasks)

    def on_task_toggled(self, renderer, path):
        self.task_store[path][0] = not self.task_store[path][0]
        self._save_tasks_from_store()

    def on_add_task(self, widget):
        text = self.new_task.get_text().strip()
        if not text:
            return
        self.task_store.append([False, text])
        self._save_tasks_from_store()
        self.new_task.set_text("")

    def on_remove_task(self, widget):
        selection = self.task_tree.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return
        model.remove(tree_iter)
        self._save_tasks_from_store()

    # -- Email ----------------------------------------------------------------------
    def build_email_page(self):
        page = self._page_box("Email")
        hint = Gtk.Label(label="Your inbox, from the TV.")
        hint.set_halign(Gtk.Align.START)
        page.pack_start(hint, False, False, 0)
        self.email_entry = Gtk.Entry()
        self.email_entry.set_placeholder_text("Email address")
        self.email_entry.set_text(
            self.launcher.settings.get("email", ""))
        self.email_entry.connect("changed", self.on_email_changed)
        page.pack_start(self.email_entry, False, False, 0)
        open_btn = Gtk.Button(label="Open inbox")
        open_btn.connect("clicked", self.on_open_inbox)
        page.pack_start(open_btn, False, False, 0)
        self.stack.add_named(page, "email")

    def on_email_changed(self, entry):
        self.launcher.settings["email"] = entry.get_text().strip()
        save_settings(self.launcher.settings)

    def on_open_inbox(self, widget):
        addr = self.launcher.settings.get("email", "").strip()
        if "outlook.com" in addr or "hotmail.com" in addr:
            url = "https://outlook.live.com/mail/"
        elif "gmail.com" in addr or "googlemail.com" in addr:
            url = "https://mail.google.com/"
        elif addr:
            url = "mailto:" + addr
        else:
            url = "https://mail.google.com/"
        open_url(url)

    # -- Row order -------------------------------------------------------------------
    def build_rows_page(self):
        page = self._page_box("Row Order")
        hint = Gtk.Label(
            label="Choose which row is 1st, 2nd, 3rd... (top to bottom).")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        self.order_store = Gtk.ListStore(str, str)
        self.order = load_row_order()
        for key in self.order:
            self.order_store.append([ROW_TITLES[key], key])
        order_tree = Gtk.TreeView(model=self.order_store)
        renderer = Gtk.CellRendererText()
        order_tree.append_column(
            Gtk.TreeViewColumn("Row", renderer, text=0))
        self.order_tree = order_tree
        order_scroll = Gtk.ScrolledWindow()
        order_scroll.set_size_request(-1, 180)
        order_scroll.add(order_tree)
        page.pack_start(order_scroll, False, False, 0)

        move_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        up_btn = Gtk.Button(label="Move up")
        up_btn.connect("clicked", self.on_move_up)
        down_btn = Gtk.Button(label="Move down")
        down_btn.connect("clicked", self.on_move_down)
        save_btn = Gtk.Button(label="Save row order")
        save_btn.connect("clicked", self.on_save_order)
        move_box.pack_start(up_btn, False, False, 0)
        move_box.pack_start(down_btn, False, False, 0)
        move_box.pack_start(save_btn, False, False, 0)
        page.pack_start(move_box, False, False, 0)
        self.stack.add_named(page, "rows")

    def _selected_order_row(self):
        selection = self.order_tree.get_selection()
        model, tree_iter = selection.get_selected()
        if tree_iter is None:
            return None, None
        path = model.get_path(tree_iter)
        return model, path.get_indices()[0]

    def on_move_up(self, widget):
        model, idx = self._selected_order_row()
        if model is None or idx <= 0:
            return
        self.order[idx - 1], self.order[idx] = self.order[idx], self.order[idx - 1]
        self._refresh_order_store()
        self.order_tree.get_selection().select_path(
            Gtk.TreePath.new_from_indices([idx - 1]))

    def on_move_down(self, widget):
        model, idx = self._selected_order_row()
        if model is None or idx >= len(self.order) - 1:
            return
        self.order[idx + 1], self.order[idx] = self.order[idx], self.order[idx + 1]
        self._refresh_order_store()
        self.order_tree.get_selection().select_path(
            Gtk.TreePath.new_from_indices([idx + 1]))

    def _refresh_order_store(self):
        self.order_store.clear()
        for key in self.order:
            self.order_store.append([ROW_TITLES[key], key])

    def on_save_order(self, widget):
        save_row_order(self.order)
        self.launcher.build_rows()
        self.show_page("main")

    # -- Sound -----------------------------------------------------------------------
    def build_sound_page(self):
        page = self._page_box("Sound")
        out_label = Gtk.Label(label="Audio output")
        out_label.set_halign(Gtk.Align.START)
        page.pack_start(out_label, False, False, 0)
        # The outputs listed here are the system's real sinks
        # (PulseAudio / PipeWire via pactl) -- never faked. Picking
        # one makes it the default sink.
        self.sound_combo = Gtk.ComboBoxText()
        self.sound_combo.connect("changed", self.on_sound_changed)
        page.pack_start(self.sound_combo, False, False, 0)
        self.sound_hint = Gtk.Label(label="")
        self.sound_hint.set_halign(Gtk.Align.START)
        self.sound_hint.set_line_wrap(True)
        page.pack_start(self.sound_hint, False, False, 0)

        vol_label = Gtk.Label(label="Volume for this output")
        vol_label.set_halign(Gtk.Align.START)
        page.pack_start(vol_label, False, False, 0)
        self.sink_vol = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 0, 100, 1)
        self.sink_vol.set_draw_value(True)
        self.sink_vol.connect("value-changed", self.on_sink_volume_changed)
        page.pack_start(self.sink_vol, False, False, 0)

        self.pt_switch = Gtk.Switch()
        self.pt_switch.set_active(
            bool(self.launcher.settings.get("passthrough", True)))
        self.pt_switch.connect("notify::active", self.on_passthrough_toggled)
        pt_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        pt_label = Gtk.Label(label="Audio passthrough (AC3 / E-AC3 / DTS)")
        pt_label.set_line_wrap(True)
        pt_row.pack_start(pt_label, True, True, 0)
        pt_row.pack_end(self.pt_switch, False, False, 0)
        page.pack_start(pt_row, False, False, 0)

        # Interface sounds: the main screen's own sound settings
        # (on/off + which sound set). Each full-screen page (EPG,
        # Movies, Shows) keeps its OWN sound settings in its own
        # options panel -- this page is the main Interface only.
        snd_label = Gtk.Label(label="Interface sounds")
        snd_label.set_halign(Gtk.Align.START)
        page.pack_start(snd_label, False, False, 0)
        page.pack_start(
            self.launcher._sound_section(None), False, False, 0)
        self.stack.add_named(page, "sound")
        self.sound_sinks = []
        self.refresh_sound_sinks()

    def list_audio_sinks(self):
        """Real audio outputs from the system (PulseAudio / PipeWire
        via pactl): [(sink_name, description)]. Empty when pactl is
        missing or reports none -- never faked."""
        try:
            out = subprocess.check_output(
                ["pactl", "list", "sinks"], timeout=5,
                stderr=subprocess.DEVNULL).decode("utf-8", "replace")
        except Exception:
            return []
        sinks = []
        name = desc = None
        for line in out.splitlines():
            line = line.strip()
            if line.startswith("Name: "):
                if name:
                    sinks.append((name, desc or name))
                name = line[6:].strip()
                desc = None
            elif line.startswith("Description: "):
                desc = line[13:].strip()
        if name:
            sinks.append((name, desc or name))
        return sinks

    def get_default_sink(self):
        try:
            out = subprocess.check_output(
                ["pactl", "get-default-sink"], timeout=5,
                stderr=subprocess.DEVNULL).decode("utf-8", "replace")
            return out.strip() or None
        except Exception:
            return None

    def get_sink_volume(self, sink):
        try:
            out = subprocess.check_output(
                ["pactl", "get-sink-volume", sink], timeout=5,
                stderr=subprocess.DEVNULL).decode("utf-8", "replace")
        except Exception:
            return None
        m = re.search(r"(\d+)%", out)
        return int(m.group(1)) if m else None

    def refresh_sound_sinks(self):
        """Re-list the system's outputs into the combo and put the
        volume slider on the selected sink's current volume."""
        combo = getattr(self, "sound_combo", None)
        if combo is None:
            return
        sinks = self.list_audio_sinks()
        self.sound_sinks = sinks
        combo.handler_block_by_func(self.on_sound_changed)
        combo.remove_all()
        if not sinks:
            combo.append_text("No audio outputs found")
            combo.set_active(0)
            combo.set_sensitive(False)
            self.sink_vol.set_sensitive(False)
            self.sound_hint.set_text(
                "No outputs reported -- check PulseAudio / PipeWire "
                "on the TV.")
            combo.handler_unblock_by_func(self.on_sound_changed)
            return
        combo.set_sensitive(True)
        self.sink_vol.set_sensitive(True)
        self.sound_hint.set_text("")
        for _name, desc in sinks:
            combo.append_text(desc)
        default = self.get_default_sink()
        saved = self.launcher.settings.get("sound_output")
        idx = 0
        for i, (name, desc) in enumerate(sinks):
            if name == default or desc == saved:
                idx = i
                break
        # The system default sink wins when it is known.
        for i, (name, _desc) in enumerate(sinks):
            if name == default:
                idx = i
                break
        combo.set_active(idx)
        combo.handler_unblock_by_func(self.on_sound_changed)
        self._sync_sink_volume()

    def _sync_sink_volume(self):
        """Set the volume slider to the selected sink's volume."""
        sinks = getattr(self, "sound_sinks", [])
        combo = getattr(self, "sound_combo", None)
        if not sinks or combo is None:
            return
        idx = combo.get_active()
        if idx < 0 or idx >= len(sinks):
            return
        vol = self.get_sink_volume(sinks[idx][0])
        if vol is not None:
            self.sink_vol.handler_block_by_func(
                self.on_sink_volume_changed)
            self.sink_vol.set_value(vol)
            self.sink_vol.handler_unblock_by_func(
                self.on_sink_volume_changed)

    def on_sound_changed(self, combo):
        sinks = getattr(self, "sound_sinks", [])
        idx = combo.get_active()
        if idx < 0 or idx >= len(sinks):
            return
        name, desc = sinks[idx]
        try:
            _spawn(["pactl", "set-default-sink", name],
                   stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)
        except Exception:
            pass
        self.launcher.settings["sound_output"] = desc
        save_settings(self.launcher.settings)
        self._sync_sink_volume()

    def on_sink_volume_changed(self, scale):
        sinks = getattr(self, "sound_sinks", [])
        combo = getattr(self, "sound_combo", None)
        if not sinks or combo is None:
            return
        idx = combo.get_active()
        if idx < 0 or idx >= len(sinks):
            return
        try:
            _spawn(["pactl", "set-sink-volume", sinks[idx][0],
                    "%d%%" % int(scale.get_value())],
                   stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)
        except Exception:
            pass

    def on_passthrough_toggled(self, switch, _param):
        self.launcher.settings["passthrough"] = switch.get_active()
        save_settings(self.launcher.settings)

    # -- Music (free internet radio by genre) -------------------------------
    def build_music_page(self):
        page = self._page_box("Music")
        hint = Gtk.Label(
            label="Free internet radio -- pick a genre and it plays. "
                  "No sign-in, no account.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)
        self.music_status = Gtk.Label(label="Stopped.")
        self.music_status.set_halign(Gtk.Align.START)
        self.music_status.set_line_wrap(True)
        page.pack_start(self.music_status, False, False, 0)
        grid = Gtk.Grid()
        grid.set_column_spacing(20)
        grid.set_row_spacing(20)
        grid.set_halign(Gtk.Align.FILL)
        # Even on both sides, like the main-page tiles.
        grid.set_column_homogeneous(True)
        grid.set_hexpand(True)
        for i, (genre, station, url) in enumerate(MUSIC_GENRES):
            btn = Gtk.Button()
            btn.get_style_context().add_class("settings-tile")
            inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            name_label = Gtk.Label()
            name_label.set_markup("<b>%s</b>" % _esc(genre))
            name_label.set_halign(Gtk.Align.CENTER)
            sub_label = Gtk.Label(label=station)
            sub_label.get_style_context().add_class("tile-sub")
            sub_label.set_halign(Gtk.Align.CENTER)
            inner.pack_start(name_label, False, False, 0)
            inner.pack_start(sub_label, False, False, 0)
            btn.add(inner)
            btn.connect("clicked", self.on_music_genre, genre, url)
            grid.attach(btn, i % 2, i // 2, 1, 1)
        page.pack_start(grid, True, True, 0)
        stop_btn = Gtk.Button(label="■  Stop")
        stop_btn.connect("clicked", lambda w: self.stop_music())
        page.pack_start(stop_btn, False, False, 0)
        self.stack.add_named(page, "music")
        self.music_proc = None
        self.music_genre = None

    def on_music_genre(self, widget, genre, url):
        self.play_music_genre(genre, url)

    def _music_player_cmd(self, url):
        """mpv first (it is in the TV OS image), ffplay as fallback."""
        for prog, args in (("mpv", ["--no-video", "--really-quiet"]),
                           ("ffplay", ["-nodisp", "-autoexit",
                                       "-loglevel", "quiet"])):
            if shutil.which(prog):
                return [prog] + args + [url]
        return None

    def play_music_genre(self, genre, url):
        self.stop_music()
        cmd = self._music_player_cmd(url)
        if not cmd:
            self.music_status.set_text(
                "No player found (mpv or ffplay) on this box.")
            return
        try:
            self.music_proc = _spawn(
                cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if self.music_proc is None:
                self.music_status.set_text("Couldn't start %s." % genre)
                return
            self.music_genre = genre
            self.music_status.set_text("Now playing: %s" % genre)
        except Exception:
            self.music_proc = None
            self.music_status.set_text("Couldn't start %s." % genre)

    def stop_music(self):
        proc = getattr(self, "music_proc", None)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass
            self.music_proc = None
        self.music_genre = None
        status = getattr(self, "music_status", None)
        if status is not None:
            status.set_text("Stopped.")

    # -- Controller ---------------------------------------------------------------------
    def build_controller_page(self):
        page = self._page_box("Controller")
        hint = Gtk.Label(
            label="Steam Controller, Xbox, PlayStation. Remote: the Alexa "
                  "Voice Remote (Bluetooth) -- D-pad, Back, Home, Menu, "
                  "and the Alexa button for voice.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)

        self.controller_status = Gtk.Label(label="")
        self.controller_status.set_halign(Gtk.Align.START)
        self.controller_status.set_line_wrap(True)
        page.pack_start(self.controller_status, False, False, 0)
        self.refresh_controller_status()

        self.steam_input_switch = Gtk.Switch()
        self.steam_input_switch.set_active(
            bool(self.launcher.settings.get("steam_input", True)))
        self.steam_input_switch.connect(
            "notify::active", self.on_steam_input_toggled)
        si_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        si_label = Gtk.Label(label="Steam Input (trackpads, gyro)")
        si_label.set_line_wrap(True)
        si_row.pack_start(si_label, True, True, 0)
        si_row.pack_end(self.steam_input_switch, False, False, 0)
        page.pack_start(si_row, False, False, 0)

        # Trackpads as a mouse cursor: right pad moves the pointer,
        # right pad click = left click. The controller does this itself
        # (built-in mouse mode when Steam is closed, Steam Input when
        # Steam is open), so this switch just makes it explicit and
        # keeps the cursor visible.
        self.pad_mouse_switch = Gtk.Switch()
        self.pad_mouse_switch.set_active(
            bool(self.launcher.settings.get("trackpad_mouse", True)))
        self.pad_mouse_switch.connect(
            "notify::active", self.on_pad_mouse_toggled)
        pm_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        pm_label = Gtk.Label(label="Trackpads as mouse cursor")
        pm_label.set_line_wrap(True)
        pm_row.pack_start(pm_label, True, True, 0)
        pm_row.pack_end(self.pad_mouse_switch, False, False, 0)
        page.pack_start(pm_row, False, False, 0)
        pm_hint = Gtk.Label(
            label="Right pad moves the cursor, right pad click = left click.")
        pm_hint.set_halign(Gtk.Align.START)
        pm_hint.set_line_wrap(True)
        page.pack_start(pm_hint, False, False, 0)

        pair_btn = Gtk.Button(label="Pair a controller (Bluetooth)")
        pair_btn.connect("clicked", lambda w: self.show_page("bluetooth"))
        page.pack_start(pair_btn, False, False, 0)
        remote_btn = Gtk.Button(label="Pair Alexa Voice Remote (Bluetooth)")
        remote_btn.connect("clicked", lambda w: self.show_page("bluetooth"))
        page.pack_start(remote_btn, False, False, 0)
        self.stack.add_named(page, "controller")

    def refresh_controller_status(self):
        # Joystick devices show up as /dev/input/js*. Read the friendly
        # name from sysfs so a Steam Controller shows up by name.
        import glob
        import os
        pads = sorted(glob.glob("/dev/input/js*"))
        lines = []
        for js in pads:
            name = None
            sys_name = "/sys/class/input/%s/device/name" % os.path.basename(js)
            try:
                with open(sys_name) as f:
                    name = f.read().strip()
            except Exception:
                pass
            lines.append("%s (%s)" % (name or "Gamepad", js))
        if lines:
            self.controller_status.set_text(
                "Connected:\n" + "\n".join(lines))
        else:
            self.controller_status.set_text(
                "No controller detected. Pair one over Bluetooth.")

    def on_steam_input_toggled(self, switch, _param):
        self.launcher.settings["steam_input"] = switch.get_active()
        save_settings(self.launcher.settings)

    def on_pad_mouse_toggled(self, switch, _param):
        on = switch.get_active()
        self.launcher.settings["trackpad_mouse"] = on
        save_settings(self.launcher.settings)
        write_padd_conf(self.launcher.settings)   # the padd daemon
        # The pads move the pointer, so keep the cursor visible while
        # this is on.
        self.launcher.settings["cursor_visible"] = on
        save_settings(self.launcher.settings)
        window = self.launcher.get_window()
        if window is not None:
            if on:
                window.set_cursor(None)
            else:
                blank = Gdk.Cursor.new_from_name(
                    Gdk.Display.get_default(), "none")
                window.set_cursor(blank)

    # -- Screensaver ------------------------------------------------------------------
    def build_screensaver_page(self):
        page = self._page_box("Screensaver")
        hint = Gtk.Label(label="When the screensaver kicks in.")
        hint.set_halign(Gtk.Align.START)
        page.pack_start(hint, False, False, 0)
        self.ss_combo = Gtk.ComboBoxText()
        timeouts = ("Never", "2 min", "5 min", "10 min", "30 min")
        for name in timeouts:
            self.ss_combo.append_text(name)
        current = self.launcher.settings.get("screensaver_timeout", "5 min")
        self.ss_combo.set_active(
            timeouts.index(current) if current in timeouts else 2)
        self.ss_combo.connect("changed", self.on_screensaver_changed)
        page.pack_start(self.ss_combo, False, False, 0)
        self.stack.add_named(page, "screensaver")

    def on_screensaver_changed(self, combo):
        name = combo.get_active_text()
        if name:
            self.launcher.settings["screensaver_timeout"] = name
            save_settings(self.launcher.settings)

    # -- Language -----------------------------------------------------------------------
    def build_language_page(self):
        page = self._page_box("Language")
        self.lang_combo = Gtk.ComboBoxText()
        langs = ("English", "French", "Spanish")
        for name in langs:
            self.lang_combo.append_text(name)
        current = self.launcher.settings.get("language", "English")
        self.lang_combo.set_active(
            langs.index(current) if current in langs else 0)
        self.lang_combo.connect("changed", self.on_language_changed)
        page.pack_start(self.lang_combo, False, False, 0)
        self.stack.add_named(page, "language")

    def on_language_changed(self, combo):
        name = combo.get_active_text()
        if name:
            self.launcher.settings["language"] = name
            save_settings(self.launcher.settings)

    # -- Region ---------------------------------------------------------------------------
    def build_region_page(self):
        page = self._page_box("Region")
        self.region_combo = Gtk.ComboBoxText()
        regions = ("Canada", "United States", "United Kingdom")
        for name in regions:
            self.region_combo.append_text(name)
        current = self.launcher.settings.get("region", "Canada")
        self.region_combo.set_active(
            regions.index(current) if current in regions else 0)
        self.region_combo.connect("changed", self.on_region_changed)
        page.pack_start(self.region_combo, False, False, 0)
        self.stack.add_named(page, "region")

    def on_region_changed(self, combo):
        name = combo.get_active_text()
        if name:
            self.launcher.settings["region"] = name
            save_settings(self.launcher.settings)

    # -- Cursor -----------------------------------------------------------------------------
    def build_cursor_page(self):
        page = self._page_box("Cursor")
        hint = Gtk.Label(
            label="Show or hide the mouse pointer on the TV.")
        hint.set_halign(Gtk.Align.START)
        hint.set_line_wrap(True)
        page.pack_start(hint, False, False, 0)
        self.cursor_switch = Gtk.Switch()
        self.cursor_switch.set_active(
            bool(self.launcher.settings.get("cursor_visible", True)))
        self.cursor_switch.connect("notify::active", self.on_cursor_toggled)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.pack_start(Gtk.Label(label="Show cursor"), False, False, 0)
        row.pack_end(self.cursor_switch, False, False, 0)
        page.pack_start(row, False, False, 0)
        self.stack.add_named(page, "cursor")

    def on_cursor_toggled(self, switch, _param):
        # Same control the Navigator preset uses.
        self.launcher.set_cursor_visible(switch.get_active())

    # -- Power -------------------------------------------------------------------------------
    def build_power_page(self):
        page = self._page_box("Power")
        hint = Gtk.Label(
            label="Sleep, restart or shut down the TV.")
        hint.set_halign(Gtk.Align.START)
        page.pack_start(hint, False, False, 0)
        for label, cmd in (("Sleep", "suspend"),
                           ("Restart", "reboot"),
                           ("Shut down", "poweroff")):
            btn = Gtk.Button(label=label)
            btn.connect("clicked", self.on_power_button, cmd, label)
            page.pack_start(btn, False, False, 0)
        self.stack.add_named(page, "power")

    def on_power_button(self, widget, cmd, label):
        # Power commands are OFF by default -- they only run on the TV
        # build once power_commands_enabled is set in settings.json.
        # (Never run them from a test machine.)
        if not self.launcher.settings.get("power_commands_enabled", False):
            dialog = Gtk.MessageDialog(
                parent=self.launcher, flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="%s is off in this build" % label)
            dialog.format_secondary_text(
                "Power commands are disabled here. Enable "
                "power_commands_enabled in the launcher settings on the TV.")
            dialog.run()
            dialog.destroy()
            return
        dialog = Gtk.MessageDialog(
            parent=self.launcher, flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text="%s the TV?" % label)
        if dialog.run() == Gtk.ResponseType.OK:
            try:
                _spawn(["systemctl", cmd],
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL)
            except Exception:
                pass
        dialog.destroy()

    # -- About -----------------------------------------------------------------------------------
    def build_about_page(self):
        page = self._page_box("About")
        import socket
        import shutil
        lines = ["Aero Deck 1.0",
                 "Device: %s" % socket.gethostname()]
        try:
            total, used, free = shutil.disk_usage(str(Path.home()))
            lines.append("Storage free: %.1f GB" % (free / 1e9))
        except Exception:
            pass
        info = Gtk.Label(label="\n".join(lines))
        info.set_halign(Gtk.Align.START)
        page.pack_start(info, False, False, 0)
        self.stack.add_named(page, "about")


# ---------------------------------------------------------------------------
# Flight Deck audit (Nov 16): real system actions for the sections that
# used to only save a setting. Mixed into SettingsPanel below.
# ---------------------------------------------------------------------------
PADD_CONF = Path.home() / ".config" / "aero-deck" / "padd.conf"
MPV_CONF = Path.home() / ".config" / "mpv" / "mpv.conf"
NIGHT_LIGHT_TEMPS = (6500, 2500)          # neutral .. warmest (K)


def _bg(work, done=None):
    """Run work() on a thread, hand its result to done() on the GTK
    loop (so slow CLI calls never freeze the panel)."""
    def run():
        try:
            res = work()
        except Exception as e:     # noqa: BLE001
            res = e
        if done is not None:
            GLib.idle_add(lambda: (done(res), False)[1])
    threading.Thread(target=run, daemon=True).start()


def _run(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
        return r.returncode, (r.stdout.decode("utf-8", "replace")
                              + r.stderr.decode("utf-8", "replace")).strip()
    except FileNotFoundError:
        return 127, "%s isn't installed." % cmd[0]
    except Exception as e:     # noqa: BLE001
        return 1, str(e)


def write_padd_conf(settings):
    """Flight Deck -> Controller lands in the padd daemon's user conf;
    the daemon re-reads it every 3 s."""
    conf = {
        "mode": settings.get("padd_mode", "auto"),
        "pointer_speed": float(settings.get("padd_pointer_speed", 1.0)),
        "scroll_speed": float(settings.get("padd_scroll_speed", 1.0)),
        "pad_mouse": bool(settings.get("trackpad_mouse", True)),
        # Steam Input on = Steam owns the controller while it runs.
        "pause_for_steam": bool(settings.get("steam_input", True)),
        "invert_pad_y": bool(settings.get("padd_invert_y", False)),
    }
    try:
        PADD_CONF.parent.mkdir(parents=True, exist_ok=True)
        PADD_CONF.write_text(json.dumps(conf, indent=2))
        return True
    except Exception:
        return False


def write_mpv_passthrough(on):
    """Audio passthrough for Live TV / video (mpv): bitstream AC3 /
    E-AC3 / DTS / TrueHD to the receiver instead of decoding."""
    MPV_CONF.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    if MPV_CONF.exists():
        lines = [l for l in MPV_CONF.read_text().splitlines()
                 if not l.startswith("audio-spdif=")
                 and "# aero-deck passthrough" not in l]
    if on:
        lines += ["# aero-deck passthrough",
                  "audio-spdif=ac3,eac3,dts,dts-hd,truehd"]
    MPV_CONF.write_text("\n".join(lines) + ("\n" if lines else ""))


def night_light_apply(on, temp):
    """Warm screen (blue-light cut) through a real gamma / colour
    temperature change (wlr-gamma-control via gammastep) -- no overlay
    window, no opacity, the picture stays crisp."""
    subprocess.run(["pkill", "-x", "gammastep"], capture_output=True)
    if not on:
        return True, "Night light off."
    exe = shutil.which("gammastep") or shutil.which("wlsunset")
    if not exe:
        return False, "gammastep isn't installed."
    if exe.endswith("gammastep"):
        cmd = [exe, "-P", "-O", str(int(temp))]
    else:   # wlsunset: same temperature day and night
        cmd = [exe, "-T", str(int(temp) + 1), "-t", str(int(temp))]
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
        return True, "Night light on (%d K)." % int(temp)
    except Exception as e:     # noqa: BLE001
        return False, str(e)


def list_timezones():
    rc, out = _run(["timedatectl", "list-timezones"], 10)
    zones = out.splitlines() if rc == 0 and out else []
    if not zones:
        base = Path("/usr/share/zoneinfo")
        for p in sorted(base.glob("*/*")):
            if p.is_file() and p.parent.name[0].isupper():
                zones.append("%s/%s" % (p.parent.name, p.name))
    return zones


def current_timezone():
    try:
        return os.path.realpath("/etc/localtime").split("zoneinfo/", 1)[1]
    except Exception:
        return ""


def bt_list(kind="devices"):
    """[(mac, name)] from bluetoothctl ('devices' or 'devices Paired')."""
    cmd = ["bluetoothctl"] + kind.split()
    rc, out = _run(cmd, 8)
    res = []
    for line in out.splitlines():
        parts = line.split(None, 2)
        if len(parts) >= 2 and parts[0] == "Device":
            res.append((parts[1], parts[2] if len(parts) > 2 else parts[1]))
    return res


def bt_info(mac):
    """(connected, battery % or None, icon) from bluetoothctl info."""
    rc, out = _run(["bluetoothctl", "info", mac], 5)
    m = re.search(r"Battery Percentage:.*\((\d+)\)", out)
    icon = re.search(r"Icon: (\S+)", out)
    return ("Connected: yes" in out, int(m.group(1)) if m else None,
            icon.group(1) if icon else "")


def bt_connected(mac):
    return bt_info(mac)[0]


CACHE_TARGETS = [  # (label, path relative to $HOME)
    ("Launcher artwork cache", ".cache/tv-launcher"),
    ("Brave cache", ".cache/BraveSoftware"),
    ("Firefox cache", ".cache/mozilla"),
    ("Chrome / Chromium cache", ".cache/google-chrome"),
    ("Chromium cache", ".cache/chromium"),
    ("Thumbnails", ".cache/thumbnails"),
    ("Wingman (web view) cache", ".cache/aero-deck-wingman"),
    ("Other app caches", ".cache"),
]


def _du(path):
    total = 0
    for root, _dirs, files in os.walk(path, onerror=lambda e: None):
        for f in files:
            try:
                total += os.lstat(os.path.join(root, f)).st_size
            except OSError:
                pass
    return total


def _human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return "%.0f %s" % (n, unit)
        n /= 1024.0
    return "%.1f TB" % n



# Steam Deck built-in controls (aero-deck-padd + launcher). Shown in
# Flight Deck -> Controls and in docs/DECK-CONTROLS.md.
DECK_CONTROLS = [
    ("D-pad / left stick", "Move between tiles, keys and settings"),
    ("A", "OK: select, enter a section, flip a switch, press a key "
          "(hold A on an app tile: app options)"),
    ("B", "Back one level: keyboard, then section, then Flight Deck, "
          "then home"),
    ("X", "Space / play-pause"),
    ("Y", "Show / hide the system keyboard in apps and websites"),
    ("L1 / R1", "Text cursor ◀ / ▶ while typing; previous / next item "
                "elsewhere"),
    ("L2", "Right click"),
    ("R2", "Left click"),
    ("L3 (press left stick)", "Navigator search"),
    ("R3 (press right stick)", "Wingman"),
    ("L4 / R4 (back grips)", "Back / forward in browsers and apps"),
    ("L5 / R5 (back grips)", "Volume down / up"),
    ("Right trackpad", "Mouse pointer (press = left click)"),
    ("Left trackpad", "Scroll (press = middle click)"),
    ("Right stick", "Scroll"),
    ("Sliders", "D-pad left / right adjusts"),
    ("STEAM button", "Home screen"),
    ("··· (Quick Access)", "Open / close the Flight Deck"),
    ("≡ (Menu)", "Options for the focused item"),
    ("⧉ (View)", "This Controls page"),
    ("Touchscreen", "Tap anything; swipe rows; tap outside the Flight "
                    "Deck to close it"),
    ("Keyboard Mic key", "Voice typing (offline) into the field"),
]


class _PanelExtras:
    """Methods mixed into SettingsPanel (see the loop at the end)."""

    # -- helpers -----------------------------------------------------------
    def _page(self, name):
        return self.stack.get_child_by_name(name)

    def _xlabel(self, text, cls=None):
        lbl = Gtk.Label(label=text)
        lbl.set_halign(Gtk.Align.START)
        lbl.set_line_wrap(True)
        lbl.set_xalign(0)
        if cls:
            lbl.get_style_context().add_class(cls)
        return lbl

    def _xheading(self, text):
        lbl = Gtk.Label()
        lbl.set_markup("<b>%s</b>" % _esc(text))
        lbl.set_halign(Gtk.Align.START)
        lbl.set_margin_top(8)
        return lbl

    def _xswitch_row(self, text, active, cb):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        lbl = self._xlabel(text)
        row.pack_start(lbl, True, True, 0)
        sw = Gtk.Switch()
        sw.set_active(bool(active))
        sw.set_valign(Gtk.Align.CENTER)
        sw.connect("notify::active", lambda w, _p: cb(w.get_active()))
        row.pack_end(sw, False, False, 0)
        return row, sw

    def _save(self):
        save_settings(self.launcher.settings)

    # -- wiring entry point ------------------------------------------------
    def wire_audit_extras(self):
        st = self.launcher.settings
        for fn in (self._x_controller, self._x_sound, self._x_sound_mic,
                   self._x_screensaver,
                   self._x_language, self._x_region, self._x_bluetooth,
                   self._x_vpn, self._x_keyboard, self._x_appearance,
                   self._x_display_night, self._x_power):
            try:
                fn()
            except Exception as e:     # noqa: BLE001
                print("Flight Deck extra failed:", fn.__name__, e,
                      file=sys.stderr)
        write_padd_conf(st)

    # -- Controller -------------------------------------------------------
    def _x_controller(self):
        page = self._page("controller")
        st = self.launcher.settings
        page.pack_start(self._xheading("Deck controls (no Steam needed)"),
                        False, False, 0)
        page.pack_start(self._xlabel(
            "D-pad / left stick move, A select, B back, X space, Y keyboard, "
            "right trackpad = mouse, R2 / pad click = click, L2 = right "
            "click."), False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        row.pack_start(self._xlabel("Controller mapping"), True, True, 0)
        self.padd_mode_combo = Gtk.ComboBoxText()
        modes = [("auto", "Auto (handhelds)"), ("always", "Always on"),
                 ("off", "Off")]
        for key, label in modes:
            self.padd_mode_combo.append(key, label)
        self.padd_mode_combo.set_active_id(st.get("padd_mode", "auto"))
        self.padd_mode_combo.connect("changed", self._on_padd_mode)
        row.pack_end(self.padd_mode_combo, False, False, 0)
        page.pack_start(row, False, False, 0)
        for key, text, lo, hi in (("padd_pointer_speed", "Pointer speed",
                                   0.3, 3.0),
                                  ("padd_scroll_speed", "Scroll speed",
                                   0.3, 3.0)):
            page.pack_start(self._xlabel(text), False, False, 0)
            sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,
                                          lo, hi, 0.1)
            sc.set_value(float(st.get(key, 1.0)))
            sc.set_digits(1)
            sc.connect("value-changed", self._on_padd_scale, key)
            page.pack_start(sc, False, False, 0)
        row2, _sw = self._xswitch_row(
            "Invert trackpad up/down", st.get("padd_invert_y", False),
            lambda on: self._padd_set("padd_invert_y", on))
        page.pack_start(row2, False, False, 0)
        self.padd_status = self._xlabel("")
        page.pack_start(self.padd_status, False, False, 0)
        self._padd_status()

    def _padd_status(self):
        rc, out = _run(["systemctl", "is-active", "aero-deck-padd"], 5)
        self.padd_status.set_text(
            "Controller service: %s. Changes apply within 3 s."
            % (out or "unknown"))

    def _padd_set(self, key, value):
        self.launcher.settings[key] = value
        self._save()
        write_padd_conf(self.launcher.settings)

    def _on_padd_mode(self, combo):
        self._padd_set("padd_mode", combo.get_active_id() or "auto")

    def _on_padd_scale(self, scale, key):
        self._padd_set(key, round(scale.get_value(), 1))

    # replaces the save-only handlers
    def on_steam_input_toggled(self, switch, _param):
        self._padd_set("steam_input", switch.get_active())

    def _pad_mouse_extra(self):
        write_padd_conf(self.launcher.settings)

    # -- Sound: passthrough -> mpv ---------------------------------------
    def _x_sound(self):
        write_mpv_passthrough(
            bool(self.launcher.settings.get("passthrough", True)))

    def _x_sound_mic(self):
        page = self._page("sound")
        page.pack_start(self._xheading("Microphone"), False, False, 0)
        page.pack_start(self._xlabel(
            "Used for voice typing (keyboard Mic key, hold R3) and "
            "Wingman. On the Steam Deck this is the built-in mic array."),
            False, False, 0)
        self.mic_combo = Gtk.ComboBoxText()
        self.mic_combo.connect("changed", self._on_mic_changed)
        page.pack_start(self.mic_combo, False, False, 0)
        page.pack_start(self._xlabel("Mic volume"), False, False, 0)
        self.mic_vol = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 0, 150, 5)
        self.mic_vol.connect("value-changed", self._on_mic_vol)
        page.pack_start(self.mic_vol, False, False, 0)
        self.mic_level = Gtk.LevelBar()
        self.mic_level.set_min_value(0)
        self.mic_level.set_max_value(1)
        page.pack_start(self.mic_level, False, False, 0)
        b = Gtk.Button(label="Test mic (5 s)")
        b.connect("clicked", self._on_mic_test)
        page.pack_start(b, False, False, 0)
        self.mic_msg = self._xlabel("")
        page.pack_start(self.mic_msg, False, False, 0)
        self._mic_fill()

    def _mic_fill(self):
        def work():
            rc, out = _run(["pactl", "list", "short", "sources"], 5)
            rc2, default = _run(["pactl", "get-default-source"], 5)
            names = []
            for line in out.splitlines():
                parts = line.split("\t")
                if len(parts) > 1 and not parts[1].endswith(".monitor"):
                    names.append(parts[1])
            rc3, vol = _run(["pactl", "get-source-volume",
                             "@DEFAULT_SOURCE@"], 5)
            m = re.search(r"(\d+)%", vol)
            return names, default.strip(), int(m.group(1)) if m else 100

        def done(res):
            if isinstance(res, Exception):
                return
            names, default, vol = res
            self._mic_filling = True
            self.mic_combo.remove_all()
            for n in names:
                label = n
                if "acp" in n or "sof" in n or "Mic" in n or "mic" in n:
                    label = n + "  (built-in)" if "usb" not in n else n
                self.mic_combo.append(n, label)
            if default in names:
                self.mic_combo.set_active_id(default)
            if not names:
                self.mic_msg.set_text("No microphone found.")
            self.mic_vol.set_value(vol)
            self._mic_filling = False
        _bg(work, done)

    def _on_mic_changed(self, combo):
        if getattr(self, "_mic_filling", False):
            return
        n = combo.get_active_id()
        if n:
            _bg(lambda: _run(["pactl", "set-default-source", n]))

    def _on_mic_vol(self, scale):
        if getattr(self, "_mic_filling", False):
            return
        v = int(scale.get_value())
        _bg(lambda: _run(["pactl", "set-source-volume", "@DEFAULT_SOURCE@",
                          "%d%%" % v]))

    def _on_mic_test(self, btn):
        """Live input level for 5 s from the default mic."""
        import array
        exe = shutil.which("parecord") or shutil.which("pw-record")
        if not exe:
            self.mic_msg.set_text("No recorder (parecord / pw-record).")
            return
        cmd = ([exe, "--raw", "--rate=16000", "--channels=1",
                "--format=s16le"] if exe.endswith("parecord") else
               [exe, "--rate", "16000", "--channels", "1", "--format",
                "s16", "-"])
        try:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL)
        except Exception as e:     # noqa: BLE001
            self.mic_msg.set_text(str(e))
            return
        btn.set_sensitive(False)
        self.mic_msg.set_text("Say something…")
        peak = {"max": 0.0}

        def reader():
            end = time.time() + 5
            while time.time() < end:
                data = proc.stdout.read(1600)
                if not data:
                    break
                a = array.array("h", data[:len(data) // 2 * 2])
                lvl = max((abs(x) for x in a), default=0) / 32768.0
                peak["max"] = max(peak["max"], lvl)
                GLib.idle_add(self.mic_level.set_value, min(1.0, lvl * 2))
            proc.terminate()

            def fin():
                btn.set_sensitive(True)
                self.mic_level.set_value(0)
                self.mic_msg.set_text(
                    "Mic works." if peak["max"] > 0.02 else
                    "Heard nothing -- check the mic or turn up its volume.")
            GLib.idle_add(fin)
        threading.Thread(target=reader, daemon=True).start()

    def on_passthrough_toggled(self, switch, _param):
        on = switch.get_active()
        self.launcher.settings["passthrough"] = on
        self._save()
        try:
            write_mpv_passthrough(on)
        except Exception:
            pass

    # -- Screensaver -----------------------------------------------------
    def _x_screensaver(self):
        page = self._page("screensaver")
        page.pack_start(self._xlabel(
            "After this long with no input on the home screen, the "
            "backdrop and a clock take over (any button wakes it). Never "
            "kicks in while a video or app is in front."), False, False, 0)
        btn = Gtk.Button(label="Preview screensaver")
        btn.connect("clicked",
                    lambda w: GLib.timeout_add(300, self._ss_preview))
        page.pack_start(btn, False, False, 0)

    def _ss_preview(self):
        self.launcher.close_settings_panel()
        self.launcher.screensaver_show()
        return False

    def on_screensaver_changed(self, combo):
        name = combo.get_active_text()
        if name:
            self.launcher.settings["screensaver_timeout"] = name
            self._save()
            self.launcher.screensaver_poke()

    # -- Language --------------------------------------------------------
    LANG_CODES = {"English": "en_CA:en", "French": "fr_CA:fr",
                  "Spanish": "es_ES:es"}

    def _x_language(self):
        page = self._page("language")
        page.pack_start(self._xlabel(
            "Aero Deck's own menus are English-only for now. This sets "
            "the language websites, the browser and apps you open from "
            "here ask for."), False, False, 0)
        self._apply_language(self.launcher.settings.get("language",
                                                        "English"))

    def _apply_language(self, name):
        code = self.LANG_CODES.get(name, "en_CA:en")
        os.environ["LANGUAGE"] = code
        try:
            p = Path.home() / ".config" / "environment.d"
            p.mkdir(parents=True, exist_ok=True)
            (p / "aero-language.conf").write_text("LANGUAGE=%s\n" % code)
        except Exception:
            pass

    def on_language_changed(self, combo):
        name = combo.get_active_text()
        if name:
            self.launcher.settings["language"] = name
            self._save()
            self._apply_language(name)

    # -- Region: time zone -------------------------------------------------
    def _x_region(self):
        page = self._page("region")
        page.pack_start(self._xheading("Time zone"), False, False, 0)
        self.tz_combo = Gtk.ComboBoxText.new_with_entry()
        self.tz_combo.set_wrap_width(1)
        cur = current_timezone()
        quick = ["America/Halifax", "America/St_Johns", "America/Toronto",
                 "America/Winnipeg", "America/Edmonton", "America/Vancouver",
                 "America/New_York", "America/Chicago", "America/Denver",
                 "America/Los_Angeles", "Europe/London", "UTC"]
        self._tz_all = list_timezones() or quick
        for z in ([cur] if cur and cur not in quick else []) + quick:
            self.tz_combo.append_text(z)
        entry = self.tz_combo.get_child()
        entry.set_text(cur)
        entry.set_placeholder_text("e.g. America/Halifax")
        page.pack_start(self.tz_combo, False, False, 0)
        btn = Gtk.Button(label="Set time zone")
        btn.connect("clicked", self._on_set_tz)
        page.pack_start(btn, False, False, 0)
        self.tz_status = self._xlabel("Current: %s" % (cur or "unknown"))
        page.pack_start(self.tz_status, False, False, 0)
        row, _sw = self._xswitch_row(
            "Set the clock automatically (network time)",
            True, lambda on: _bg(lambda: _run(
                ["timedatectl", "set-ntp", "true" if on else "false"])))
        page.pack_start(row, False, False, 0)

    def _on_set_tz(self, _btn):
        zone = self.tz_combo.get_child().get_text().strip()
        if zone not in self._tz_all:
            self.tz_status.set_text("Unknown time zone: %s" % zone)
            return

        def done(res):
            rc, out = res if isinstance(res, tuple) else (1, str(res))
            self.tz_status.set_text(
                "Time zone set to %s." % zone if rc == 0
                else "Couldn't set the time zone: %s" % out)
            if rc == 0:
                os.environ["TZ"] = ":" + zone
                time.tzset()
                self.refresh_clock()
        _bg(lambda: _run(["timedatectl", "set-timezone", zone]), done)

    # -- Bluetooth: scan / pair / connect / remove -------------------------
    def _x_bluetooth(self):
        page = self._page("bluetooth")
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.bt_scan_btn = Gtk.Button(label="Scan for devices")
        self.bt_scan_btn.connect("clicked", self._on_bt_scan)
        row.pack_start(self.bt_scan_btn, True, True, 0)
        refresh = Gtk.Button(label="Refresh")
        refresh.connect("clicked", lambda w: self._bt_fill())
        row.pack_start(refresh, True, True, 0)
        page.pack_start(row, False, False, 0)
        page.pack_start(self._xlabel(
            "Put the remote / headphones / controller in pairing mode, "
            "then Scan. Pick a device to pair and connect it."),
            False, False, 0)
        self.bt_msg = self._xlabel("")
        page.pack_start(self.bt_msg, False, False, 0)
        self.bt_list_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                   spacing=6)
        page.pack_start(self.bt_list_box, False, False, 0)
        self._bt_fill()

    def _bt_fill(self, found=None):
        def work():
            paired = bt_list("devices Paired")
            if not paired:
                paired = bt_list("paired-devices")
            allv = found if found is not None else bt_list("devices")
            pmacs = {m for m, _n in paired}
            return ([(m, n, True) + bt_info(m) for m, n in paired] +
                    [(m, n, False, False, None, "") for m, n in allv
                     if m not in pmacs])

        def done(rows):
            for c in self.bt_list_box.get_children():
                self.bt_list_box.remove(c)
            if isinstance(rows, Exception) or not rows:
                self.bt_list_box.pack_start(
                    self._xlabel("No devices yet -- Scan to find some."),
                    False, False, 0)
            else:
                for mac, name, paired, conn, batt, icon in rows:
                    self.bt_list_box.pack_start(
                        self._bt_row(mac, name, paired, conn, batt, icon),
                        False, False, 0)
            self.bt_list_box.show_all()
        _bg(work, done)

    BT_KIND = {"input-gaming": "Controller", "audio-headset": "Headset",
               "audio-headphones": "Headphones", "audio-card": "Speaker",
               "input-keyboard": "Keyboard", "input-mouse": "Mouse",
               "phone": "Phone"}

    def _bt_row(self, mac, name, paired, conn, batt=None, icon=""):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        state = ("Connected" if conn else "Paired") if paired else "New"
        bits = [name]
        if self.BT_KIND.get(icon):
            bits.append(self.BT_KIND[icon])
        bits.append(state)
        if batt is not None:
            bits.append("🔋 %d%%" % batt)
        row.pack_start(self._xlabel("  ·  ".join(bits)), True, True, 0)
        if not paired:
            b = Gtk.Button(label="Pair")
            b.connect("clicked", lambda w: self._bt_do(
                mac, [["--timeout", "25", "pair", mac], ["trust", mac],
                      ["connect", mac]], "Paired with %s." % name))
            row.pack_end(b, False, False, 0)
        else:
            rm = Gtk.Button(label="Forget")
            rm.connect("clicked", lambda w: self._bt_do(
                mac, [["remove", mac]], "Forgot %s." % name))
            row.pack_end(rm, False, False, 0)
            c = Gtk.Button(label="Disconnect" if conn else "Connect")
            c.connect("clicked", lambda w: self._bt_do(
                mac, [["disconnect" if conn else "connect", mac]],
                "%s %s." % (name, "disconnected" if conn else "connected")))
            row.pack_end(c, False, False, 0)
        return row

    def _bt_do(self, mac, steps, ok_msg):
        self.bt_msg.set_text("Working…")

        def work():
            for st in steps:
                rc, out = _run(["bluetoothctl", "--agent",
                                "NoInputNoOutput"] + st, 40)
                if rc != 0 and "AlreadyExists" not in out:
                    return False, out.splitlines()[-1] if out else "failed"
            return True, ok_msg

        def done(res):
            ok, msg = res if isinstance(res, tuple) else (False, str(res))
            self.bt_msg.set_text(msg if ok else "Didn't work: %s" % msg)
            self._bt_fill()
            self.refresh_bluetooth_status()
        _bg(work, done)

    def _on_bt_scan(self, btn):
        btn.set_sensitive(False)
        self.bt_msg.set_text("Scanning for 12 seconds…")

        def work():
            _run(["bluetoothctl", "power", "on"], 5)
            _run(["bluetoothctl", "--timeout", "12", "scan", "on"], 20)
            return bt_list("devices")

        def done(found):
            btn.set_sensitive(True)
            self.bt_msg.set_text("")
            self._bt_fill(found if isinstance(found, list) else None)
        _bg(work, done)

    # -- VPN: import WireGuard / OpenVPN -----------------------------------
    def _x_vpn(self):
        page = self._page("vpn")
        page.pack_start(self._xheading("Add a VPN"), False, False, 0)
        page.pack_start(self._xlabel(
            "Import a WireGuard (.conf) or OpenVPN (.ovpn) file from your "
            "VPN provider (Proton, Mullvad, ...). Put it in Downloads or "
            "on a USB stick."), False, False, 0)
        btn = Gtk.Button(label="Import VPN file…")
        btn.connect("clicked", self._on_vpn_import)
        page.pack_start(btn, False, False, 0)
        self.vpn_import_status = self._xlabel("")
        page.pack_start(self.vpn_import_status, False, False, 0)

    def _on_vpn_import(self, _btn):
        dlg = Gtk.FileChooserDialog(
            title="Choose a VPN file", transient_for=self.launcher,
            action=Gtk.FileChooserAction.OPEN)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Import", Gtk.ResponseType.OK)
        flt = Gtk.FileFilter()
        flt.set_name("VPN files (.conf, .ovpn)")
        flt.add_pattern("*.conf")
        flt.add_pattern("*.ovpn")
        dlg.add_filter(flt)
        dl = Path.home() / "Downloads"
        if dl.is_dir():
            dlg.set_current_folder(str(dl))
        resp = dlg.run()
        path = dlg.get_filename()
        dlg.destroy()
        if resp != Gtk.ResponseType.OK or not path:
            return
        kind = "openvpn" if path.lower().endswith(".ovpn") else "wireguard"

        def done(res):
            rc, out = res if isinstance(res, tuple) else (1, str(res))
            self.vpn_import_status.set_text(
                "Added: %s" % out if rc == 0 else "Import failed: %s" % out)
            self.refresh_vpn_status()
        _bg(lambda: _run(["nmcli", "connection", "import", "type", kind,
                          "file", path]), done)

    # -- Keyboard: system keyboard ----------------------------------------
    def _x_keyboard(self):
        page = self._page("keyboard")
        page.pack_start(self._xheading("System keyboard"), False, False, 0)
        page.pack_start(self._xlabel(
            "Pops up by itself in browsers and other apps' text fields. "
            "Y on the controller (or Super+K) shows / hides it anywhere. "
            "Aero Deck's own fields use the drop-down keyboard instead."),
            False, False, 0)
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        for label, mode in (("Show", "show"), ("Hide", "hide")):
            b = Gtk.Button(label=label + " system keyboard")
            b.connect("clicked", lambda w, m=mode: _spawn(
                ["aero-deck-osk", m]))
            row.pack_start(b, True, True, 0)
        page.pack_start(row, False, False, 0)
        row2, _sw = self._xswitch_row(
            "Pop up automatically in app text fields",
            self.launcher.settings.get("system_osk_auto", True),
            self._on_osk_auto)
        page.pack_start(row2, False, False, 0)

    def _on_osk_auto(self, on):
        self.launcher.settings["system_osk_auto"] = on
        self._save()
        _spawn(["gsettings", "set", "org.gnome.desktop.a11y.applications",
                "screen-keyboard-enabled", "true" if on else "false"])

    # -- Appearance: Flight Deck auto-hide ---------------------------------
    def _x_appearance(self):
        page = self._page("appearance")
        page.pack_start(self._xheading("Flight Deck auto-hide"),
                        False, False, 0)
        combo = Gtk.ComboBoxText()
        opts = [("0", "Never"), ("10", "After 10 s"), ("15", "After 15 s"),
                ("30", "After 30 s"), ("60", "After 1 min")]
        for k, v in opts:
            combo.append(k, v)
        combo.set_active_id(str(int(self.launcher.settings.get(
            "panel_autohide_s", 15))))
        if combo.get_active_id() is None:
            combo.set_active_id("15")
        combo.connect("changed", self._on_autohide)
        page.pack_start(combo, False, False, 0)

    def _on_autohide(self, combo):
        self.launcher.settings["panel_autohide_s"] = int(
            combo.get_active_id() or 15)
        self._save()
        self.launcher._panel_activity()

    # -- Display: night light (warm screen, real gamma) --------------------
    def _x_display_night(self):
        page = self._page("display")
        st = self.launcher.settings
        page.pack_start(self._xheading("Night light (warm screen)"),
                        False, False, 0)
        row, self.night_switch = self._xswitch_row(
            "Warm colours, less blue light",
            st.get("night_light", False), self._on_night_toggle)
        page.pack_start(row, False, False, 0)
        page.pack_start(self._xlabel("Warmth"), False, False, 0)
        self.night_scale = Gtk.Scale.new_with_range(
            Gtk.Orientation.HORIZONTAL, 0, 100, 5)
        self.night_scale.set_value(float(st.get("night_warmth", 50)))
        self.night_scale.set_digits(0)
        self.night_scale.connect("value-changed", self._on_night_warmth)
        page.pack_start(self.night_scale, False, False, 0)
        row2, _sw = self._xswitch_row(
            "On a schedule", st.get("night_schedule", False),
            self._on_night_sched)
        page.pack_start(row2, False, False, 0)
        times = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        times.pack_start(Gtk.Label(label="From"), False, False, 0)
        self.night_from = Gtk.ComboBoxText()
        self.night_to = Gtk.ComboBoxText()
        for h in range(24):
            self.night_from.append(str(h), "%02d:00" % h)
            self.night_to.append(str(h), "%02d:00" % h)
        self.night_from.set_active_id(str(st.get("night_from", 21)))
        self.night_to.set_active_id(str(st.get("night_to", 7)))
        self.night_from.connect("changed", self._on_night_times)
        self.night_to.connect("changed", self._on_night_times)
        times.pack_start(self.night_from, False, False, 0)
        times.pack_start(Gtk.Label(label="to"), False, False, 0)
        times.pack_start(self.night_to, False, False, 0)
        page.pack_start(times, False, False, 0)
        self.night_status = self._xlabel("")
        page.pack_start(self.night_status, False, False, 0)
        self._night_last = None
        self._night_tick()
        GLib.timeout_add_seconds(60, self._night_tick)

    def _night_temp(self):
        w = float(self.launcher.settings.get("night_warmth", 50)) / 100.0
        hi, lo = NIGHT_LIGHT_TEMPS
        return int(hi - (hi - lo) * (0.15 + 0.85 * w))

    def _night_should_be_on(self):
        st = self.launcher.settings
        if not st.get("night_light", False):
            return False
        if not st.get("night_schedule", False):
            return True
        h = datetime.datetime.now().hour
        a, b = int(st.get("night_from", 21)), int(st.get("night_to", 7))
        return (a <= h < b) if a < b else (h >= a or h < b)

    def _night_tick(self, force=False):
        want = (self._night_should_be_on(), self._night_temp())
        if force or want != self._night_last:
            self._night_last = want
            ok, msg = night_light_apply(*want)
            if want[0] is False and self.launcher.settings.get(
                    "night_light") and self.launcher.settings.get(
                    "night_schedule"):
                msg = "Scheduled -- waiting for %02d:00." % int(
                    self.launcher.settings.get("night_from", 21))
            if hasattr(self, "night_status"):
                self.night_status.set_text(msg)
        return True

    def _on_night_toggle(self, on):
        self.launcher.settings["night_light"] = on
        self._save()
        self._night_tick(True)

    def _on_night_warmth(self, scale):
        self.launcher.settings["night_warmth"] = int(scale.get_value())
        self._save()
        if getattr(self, "_night_debounce", None):
            GLib.source_remove(self._night_debounce)

        def go():
            self._night_debounce = None
            self._night_tick(True)
            return False
        self._night_debounce = GLib.timeout_add(250, go)

    def _on_night_sched(self, on):
        self.launcher.settings["night_schedule"] = on
        self._save()
        self._night_tick(True)

    def _on_night_times(self, _combo):
        st = self.launcher.settings
        st["night_from"] = int(self.night_from.get_active_id() or 21)
        st["night_to"] = int(self.night_to.get_active_id() or 7)
        self._save()
        self._night_tick(True)

    # -- Power: on by default ---------------------------------------------
    def _x_power(self):
        st = self.launcher.settings
        if not st.get("_power_default_migrated"):
            st["power_commands_enabled"] = True
            st["_power_default_migrated"] = True
            self._save()

    # -- Controls / Help ---------------------------------------------------
    def build_controls_page(self):
        page = self._page_box("Controls")
        page.pack_start(self._xlabel(
            "Everything works with the Steam Deck's own controls -- no "
            "keyboard or mouse needed."), False, False, 0)
        grid = Gtk.Grid(column_spacing=14, row_spacing=8)
        for i, (btn, what) in enumerate(DECK_CONTROLS):
            b = Gtk.Label()
            b.set_markup("<b>%s</b>" % _esc(btn))
            b.set_halign(Gtk.Align.START)
            b.set_valign(Gtk.Align.START)
            grid.attach(b, 0, i, 1, 1)
            w = self._xlabel(what)
            w.set_hexpand(True)
            grid.attach(w, 1, i, 1, 1)
        page.pack_start(grid, False, False, 0)
        self.stack.add_named(page, "controls")

    # -- Storage (Apps maintenance) ----------------------------------------
    def build_storage_page(self):
        page = self._page_box("Storage")
        page.pack_start(self._xlabel(
            "Free up space. Clearing a cache never deletes your logins, "
            "settings or downloads."), False, False, 0)
        self.storage_disk = self._xlabel("")
        page.pack_start(self.storage_disk, False, False, 0)
        page.pack_start(self._xheading("System caches"), False, False, 0)
        self.storage_sys_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                       spacing=6)
        page.pack_start(self.storage_sys_box, False, False, 0)
        page.pack_start(self._xheading("Android apps"), False, False, 0)
        self.storage_apps_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=6)
        page.pack_start(self.storage_apps_box, False, False, 0)
        self.storage_msg = self._xlabel("")
        page.pack_start(self.storage_msg, False, False, 0)
        self.stack.add_named(page, "storage")

    def _on_show_storage(self):
        def work():
            rc, df = _run(["df", "-h", "--output=used,size,avail",
                           str(Path.home())], 5)
            sizes = []
            for label, rel in CACHE_TARGETS:
                p = Path.home() / rel
                if p.exists():
                    sizes.append((label, rel, _du(p)))
            rc2, pk = _run(["waydroid", "shell", "pm", "list", "packages",
                            "-3"], 15)
            pkgs = sorted(l.split(":", 1)[1] for l in pk.splitlines()
                          if l.startswith("package:")) if rc2 == 0 else None
            return df, sizes, pkgs

        def done(res):
            if isinstance(res, Exception):
                self.storage_msg.set_text(str(res))
                return
            df, sizes, pkgs = res
            lines = df.splitlines()
            if len(lines) >= 2:
                used, size, avail = lines[1].split()[:3]
                self.storage_disk.set_text(
                    "Disk: %s used of %s  ·  %s free" % (used, size, avail))
            for c in self.storage_sys_box.get_children():
                self.storage_sys_box.remove(c)
            for label, rel, n in sizes:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=6)
                row.pack_start(self._xlabel("%s  ·  %s" % (label, _human(n))),
                               True, True, 0)
                b = Gtk.Button(label="Clear")
                b.connect("clicked", self._on_clear_cache_dir, rel, label)
                row.pack_end(b, False, False, 0)
                self.storage_sys_box.pack_start(row, False, False, 0)
            for c in self.storage_apps_box.get_children():
                self.storage_apps_box.remove(c)
            if pkgs is None:
                self.storage_apps_box.pack_start(self._xlabel(
                    "Android isn't running -- start an Android app first."),
                    False, False, 0)
            elif not pkgs:
                self.storage_apps_box.pack_start(self._xlabel(
                    "No Android apps installed yet."), False, False, 0)
            for pkg in pkgs or []:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=6)
                row.pack_start(self._xlabel(pkg), True, True, 0)
                for label, fn in (("Clear cache", clear_cache_android),
                                  ("Clear data", self._android_clear_data)):
                    b = Gtk.Button(label=label)
                    b.connect("clicked", self._on_android_clear, pkg, fn,
                              label)
                    row.pack_end(b, False, False, 0)
                self.storage_apps_box.pack_start(row, False, False, 0)
            self.stack.get_child_by_name("storage").show_all()
        self.storage_disk.set_text("Checking…")
        _bg(work, done)

    @staticmethod
    def _android_clear_data(pkg):
        rc, out, err = android_shell("pm", "clear", pkg)
        if rc is None:
            return False, "Waydroid isn't running here."
        return rc == 0, "App data cleared." if rc == 0 else (err or out)

    def _on_clear_cache_dir(self, _b, rel, label):
        target = Path.home() / rel

        def work():
            keep = {"tv-launcher"} if rel == ".cache" else set()
            for child in list(target.iterdir()):
                if child.name in keep:
                    continue
                if child.is_dir() and not child.is_symlink():
                    shutil.rmtree(child, ignore_errors=True)
                else:
                    try:
                        child.unlink()
                    except OSError:
                        pass
            return True

        def done(_r):
            self.storage_msg.set_text("%s cleared." % label)
            self._on_show_storage()
        _bg(work, done)

    def _on_android_clear(self, _b, pkg, fn, label):
        def done(res):
            ok, msg = res if isinstance(res, tuple) else (False, str(res))
            self.storage_msg.set_text("%s: %s" % (pkg, msg))
        _bg(lambda: fn(pkg), done)


for _k, _v in list(vars(_PanelExtras).items()):
    if not _k.startswith("__"):
        setattr(SettingsPanel, _k, _v)



# ---------------------------------------------------------------------------
# Screensaver (Flight Deck -> Screensaver timeout): after N minutes with
# no input while the launcher itself is in front, the backdrop photo and
# a big clock take over; any key / button / touch wakes it.
# ---------------------------------------------------------------------------
_SS_MINUTES = {"Never": 0, "2 min": 2, "5 min": 5, "10 min": 10,
               "30 min": 30}


class _ScreensaverMixin:
    def screensaver_install(self):
        self._ss_win = None
        self._ss_id = None
        self.connect("event", self._ss_event)
        self.screensaver_poke()

    def _ss_event(self, _w, event):
        if event.type in (Gdk.EventType.KEY_PRESS,
                          Gdk.EventType.BUTTON_PRESS,
                          Gdk.EventType.MOTION_NOTIFY,
                          Gdk.EventType.SCROLL,
                          Gdk.EventType.TOUCH_BEGIN):
            self.screensaver_poke()
        return False

    def screensaver_poke(self):
        if getattr(self, "_ss_id", None):
            GLib.source_remove(self._ss_id)
            self._ss_id = None
        mins = _SS_MINUTES.get(
            self.settings.get("screensaver_timeout", "5 min"), 5)
        if mins:
            self._ss_id = GLib.timeout_add_seconds(mins * 60, self._ss_fire)

    def _ss_fire(self):
        self._ss_id = None
        # Only over the launcher itself: never on top of a video / app.
        if self.is_active() and not getattr(self, "kb_visible", False):
            self.screensaver_show()
        else:
            self.screensaver_poke()
        return False

    def screensaver_show(self):
        if getattr(self, "_ss_win", None) is not None:
            return
        win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        win.set_title("Aero Deck screensaver")
        win.set_transient_for(self)
        win.set_decorated(False)
        ov = Gtk.Overlay()
        bg = Gtk.DrawingArea()
        path = ASSETS_DIR / "backdrop.jpg"
        pix = None
        try:
            pix = GdkPixbuf.Pixbuf.new_from_file(str(path))
        except Exception:
            pass

        def draw(area, cr):
            w, h = area.get_allocated_width(), area.get_allocated_height()
            cr.set_source_rgb(0, 0, 0)
            cr.paint()
            if pix is not None:
                sc = max(w / pix.get_width(), h / pix.get_height())
                cr.save()
                cr.scale(sc, sc)
                Gdk.cairo_set_source_pixbuf(
                    cr, pix, (w / sc - pix.get_width()) / 2,
                    (h / sc - pix.get_height()) / 2)
                cr.paint()
                cr.restore()
            return False
        bg.connect("draw", draw)
        ov.add(bg)
        clock = Gtk.Label()
        clock.get_style_context().add_class("ss-clock")
        clock.set_halign(Gtk.Align.START)
        clock.set_valign(Gtk.Align.END)
        clock.set_margin_start(60)
        clock.set_margin_bottom(50)
        ov.add_overlay(clock)

        def tick():
            if self._ss_win is None:
                return False
            now = datetime.datetime.now()
            clock.set_markup(
                "<span size='72000' weight='bold' foreground='white'>%s"
                "</span>\n<span size='20000' foreground='white'>%s</span>"
                % (now.strftime("%-I:%M"), now.strftime("%A, %B %-d")))
            return True
        tick()
        GLib.timeout_add_seconds(10, tick)
        win.add(ov)
        win.add_events(Gdk.EventMask.KEY_PRESS_MASK |
                       Gdk.EventMask.BUTTON_PRESS_MASK |
                       Gdk.EventMask.TOUCH_MASK |
                       Gdk.EventMask.POINTER_MOTION_MASK)
        self._ss_shown_at = time.time()

        def wake(*_a):
            # ignore the motion that comes with the window mapping
            if time.time() - self._ss_shown_at < 1.0:
                return True
            self.screensaver_hide()
            return True
        for sig in ("key-press-event", "button-press-event",
                    "touch-event", "motion-notify-event"):
            win.connect(sig, wake)
        self._ss_win = win
        win.fullscreen()
        win.show_all()

    def screensaver_hide(self):
        if getattr(self, "_ss_win", None) is not None:
            self._ss_win.destroy()
            self._ss_win = None
            self.present()
        self.screensaver_poke()


for _k, _v in list(vars(_ScreensaverMixin).items()):
    if not _k.startswith("__"):
        setattr(AltTVLauncher, _k, _v)



class _PushToTalkMixin:
    """Hold R3 (F15 from aero-deck-padd) to talk. Words go into the open
    drop-down keyboard's field, else the Navigator search (opened if
    needed), or the Wingman chat box when Wingman is up."""

    def ptt_install(self):
        self._ptt_t0 = None
        self._ptt_target = None
        self.connect("key-release-event", self._ptt_release)

    def _ptt_begin(self):
        self._ptt_id = None
        if self.entry_kb.is_open():
            self._ptt_target = "entry"
            self.entry_kb._toggle_dictation()
            return False
        wm = getattr(self, "_wm_box", None)
        if wm is not None and wm.get_visible():
            self._ptt_target = "wingman"
            self._ptt_dict = Dictation()
            self._ptt_dict.start(lambda t: None, self._ptt_wingman_text,
                                 lambda m: None)
            return False
        if not getattr(self, "kb_visible", False):
            if self.panel_open:
                self.close_settings_panel()
            self.show_keyboard(self.search_entry)
        self._ptt_target = "nav"
        self.kb.toggle_dictation()
        return False

    def _ptt_wingman_text(self, text):
        if not text:
            return
        js = ("(function(t){var e=document.activeElement;"
              "if(!e||e===document.body){e=document.querySelector("
              "'textarea,[contenteditable=true],input[type=text]');"
              "if(e)e.focus();}"
              "document.execCommand('insertText',false,t);})(%s);"
              % json.dumps(text + " "))
        try:
            self._wm_view.run_javascript(js, None, None, None)
        except Exception:
            pass

    def _ptt_release(self, _w, event):
        if event.keyval != Gdk.KEY_F15 or self._ptt_t0 is None:
            return False
        self._ptt_t0 = None
        if getattr(self, "_ptt_id", None):
            # short tap: Wingman
            GLib.source_remove(self._ptt_id)
            self._ptt_id = None
            self.ask_btn.clicked()
            return True
        tgt, self._ptt_target = self._ptt_target, None
        if tgt == "entry":
            self.entry_kb.dictation.stop()
        elif tgt == "nav":
            self.kb.dictation.stop()
        elif tgt == "wingman":
            self._ptt_dict.stop()
        return True


for _k, _v in list(vars(_PushToTalkMixin).items()):
    if not _k.startswith("__"):
        setattr(AltTVLauncher, _k, _v)

# ---------------------------------------------------------------------------
# Printers (CUPS) and Reading mode (books / PDFs) -- Nov 16.
# ---------------------------------------------------------------------------
def printers_list():
    """[(name, state, is_default)] from lpstat."""
    rc, out = _run(["lpstat", "-p", "-d"], 8)
    default = ""
    m = re.search(r"system default destination: (\S+)", out)
    if m:
        default = m.group(1)
    res = []
    for line in out.splitlines():
        mm = re.match(r"printer (\S+) (?:is )?(.*)", line)
        if mm:
            res.append((mm.group(1), mm.group(2).split(".")[0],
                        mm.group(1) == default))
    return res


def printers_discover():
    """[(uri, description)] for USB + network printers (CUPS backends,
    IPP Everywhere / AirPrint via Avahi, ipp-usb)."""
    rc, out = _run(["lpinfo", "-l", "-v", "--timeout", "8"], 30)
    res, cur = [], {}
    for line in out.splitlines() + ["Device:"]:
        line = line.strip()
        if line.startswith("Device:"):
            uri = cur.get("uri", "")
            if uri and "://" in uri and cur.get("class") != "file":
                desc = cur.get("info") or cur.get("make-and-model") or uri
                res.append((uri, desc, cur.get("make-and-model", "")))
            cur = {}
            m = re.match(r"Device: uri = (\S+)", line)
            if m:
                cur["uri"] = m.group(1)
        else:
            k, _, v = line.partition("=")
            cur[k.strip()] = v.strip()
    return res


def printer_add(uri, desc, mm):
    name = re.sub(r"[^A-Za-z0-9_-]+", "_", desc).strip("_")[:40] or "Printer"
    driverless = uri.startswith(("ipp://", "ipps://", "dnssd://")) or \
        "ipp-usb" in uri or "localhost:60000" in uri
    model = "everywhere"
    if not driverless:
        rc, out = _run(["lpinfo", "--make-and-model", mm or desc, "-m"], 30)
        first = out.splitlines()[0].split()[0] if rc == 0 and out else ""
        model = first or "everywhere"
    rc, out = _run(["lpadmin", "-p", name, "-E", "-v", uri, "-m", model],
                   60)
    if rc != 0 and model != "everywhere":
        rc, out = _run(["lpadmin", "-p", name, "-E", "-v", uri, "-m",
                        "everywhere"], 60)
    if rc == 0 and not any(d for _n, _s, d in printers_list()):
        _run(["lpadmin", "-d", name], 10)
    return rc == 0, ("Added %s." % name) if rc == 0 else out


def print_file(path, printer=None, pages=None):
    cmd = ["lp"]
    if printer:
        cmd += ["-d", printer]
    if pages:
        cmd += ["-P", pages]
    rc, out = _run(cmd + [str(path)], 30)
    return rc == 0, out


class _PrinterPage:
    def build_printers_page(self):
        page = self._page_box("Printers")
        page.pack_start(self._xlabel(
            "USB and Wi-Fi / network printers. Most newer printers work "
            "without a driver (AirPrint / IPP Everywhere)."), False, False, 0)
        page.pack_start(self._xheading("Your printers"), False, False, 0)
        self.prn_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                               spacing=6)
        page.pack_start(self.prn_box, False, False, 0)
        b = Gtk.Button(label="Find printers (USB and network)")
        b.connect("clicked", self._on_prn_find)
        page.pack_start(b, False, False, 0)
        self.prn_found_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                     spacing=6)
        page.pack_start(self.prn_found_box, False, False, 0)
        page.pack_start(self._xheading("Print queue"), False, False, 0)
        self.prn_queue_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL,
                                     spacing=6)
        page.pack_start(self.prn_queue_box, False, False, 0)
        self.prn_msg = self._xlabel("")
        page.pack_start(self.prn_msg, False, False, 0)
        self.stack.add_named(page, "printers")

    def _on_show_printers(self):
        def work():
            rc, q = _run(["lpstat", "-o"], 8)
            return printers_list(), [l for l in q.splitlines() if l.strip()]

        def done(res):
            if isinstance(res, Exception):
                self.prn_msg.set_text(str(res))
                return
            prns, queue = res
            for c in self.prn_box.get_children():
                self.prn_box.remove(c)
            if not prns:
                self.prn_box.pack_start(self._xlabel(
                    "No printers yet -- Find printers below."),
                    False, False, 0)
            for name, state, dflt in prns:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=6)
                row.pack_start(self._xlabel("%s  ·  %s%s" % (
                    name, state, "  ·  default" if dflt else "")),
                    True, True, 0)
                for label, fn in (("Remove", self._prn_remove),
                                  ("Test page", self._prn_test),
                                  ("Default", self._prn_default)):
                    if label == "Default" and dflt:
                        continue
                    bb = Gtk.Button(label=label)
                    bb.connect("clicked", lambda w, f=fn, n=name: f(n))
                    row.pack_end(bb, False, False, 0)
                self.prn_box.pack_start(row, False, False, 0)
            for c in self.prn_queue_box.get_children():
                self.prn_queue_box.remove(c)
            if not queue:
                self.prn_queue_box.pack_start(self._xlabel("Nothing printing."),
                                              False, False, 0)
            for line in queue:
                job = line.split()[0]
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=6)
                row.pack_start(self._xlabel(line), True, True, 0)
                cb = Gtk.Button(label="Cancel")
                cb.connect("clicked", lambda w, j=job: self._prn_cmd(
                    ["cancel", j], "Cancelled %s." % j))
                row.pack_end(cb, False, False, 0)
                self.prn_queue_box.pack_start(row, False, False, 0)
            self.stack.get_child_by_name("printers").show_all()
        _bg(work, done)

    def _prn_cmd(self, cmd, ok):
        def done(res):
            rc, out = res if isinstance(res, tuple) else (1, str(res))
            self.prn_msg.set_text(ok if rc == 0 else "Didn't work: %s" % out)
            self._on_show_printers()
        _bg(lambda: _run(cmd, 60), done)

    def _prn_remove(self, name):
        self._prn_cmd(["lpadmin", "-x", name], "Removed %s." % name)

    def _prn_default(self, name):
        self._prn_cmd(["lpadmin", "-d", name], "%s is the default." % name)

    def _prn_test(self, name):
        for p in ("/usr/share/cups/data/testprint",
                  "/usr/share/cups/data/default-testpage.pdf"):
            if os.path.exists(p):
                self._prn_cmd(["lp", "-d", name, p],
                              "Test page sent to %s." % name)
                return
        self.prn_msg.set_text("No CUPS test page file found.")

    def _on_prn_find(self, btn):
        btn.set_sensitive(False)
        self.prn_msg.set_text("Looking for printers (about 10 s)…")

        def done(found):
            btn.set_sensitive(True)
            self.prn_msg.set_text("")
            for c in self.prn_found_box.get_children():
                self.prn_found_box.remove(c)
            if isinstance(found, Exception) or not found:
                self.prn_found_box.pack_start(self._xlabel(
                    "No printers found. Turn the printer on, connect it by "
                    "USB or to the same Wi-Fi, then try again."),
                    False, False, 0)
            for uri, desc, mm in found if isinstance(found, list) else []:
                row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,
                              spacing=6)
                kind = "USB" if uri.startswith(("usb:", "hp:/usb")) or \
                    "ipp-usb" in uri else "Network"
                row.pack_start(self._xlabel("%s  ·  %s" % (desc, kind)),
                               True, True, 0)
                ab = Gtk.Button(label="Add")

                def add(_w, u=uri, d=desc, m=mm):
                    self.prn_msg.set_text("Adding %s…" % d)

                    def fin(res):
                        ok, msg = res if isinstance(res, tuple) else \
                            (False, str(res))
                        self.prn_msg.set_text(msg if ok else
                                              "Couldn't add: %s" % msg)
                        self._on_show_printers()
                    _bg(lambda: printer_add(u, d, m), fin)
                ab.connect("clicked", add)
                row.pack_end(ab, False, False, 0)
                self.prn_found_box.pack_start(row, False, False, 0)
            self.prn_found_box.show_all()
        _bg(printers_discover, done)

    # -- Reading mode tile -------------------------------------------------
    def build_reader_page(self):
        page = self._page_box("Reading mode")
        page.pack_start(self._xlabel(
            "A clean full-screen reader for PDFs and ebooks (EPUB, TXT). "
            "Page through with the D-pad, L1 / R1 or a swipe; A shows the "
            "reader controls (text size / zoom, page colour, print); B goes "
            "back. Your place in every book is remembered."),
            False, False, 0)
        b = Gtk.Button(label="Open Reading mode")
        b.connect("clicked", lambda w: self.launcher.open_reader())
        page.pack_start(b, False, False, 0)
        self.reader_recent_box = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL, spacing=6)
        page.pack_start(self._xheading("Continue reading"), False, False, 0)
        page.pack_start(self.reader_recent_box, False, False, 0)
        self.stack.add_named(page, "reader")

    def _on_show_reader(self):
        for c in self.reader_recent_box.get_children():
            self.reader_recent_box.remove(c)
        recent = sorted(reader_state().get("books", {}).items(),
                        key=lambda kv: -kv[1].get("t", 0))[:5]
        for path, st in recent:
            if not os.path.exists(path):
                continue
            b = Gtk.Button(label="%s  ·  %s" % (os.path.basename(path),
                                               st.get("where", "")))
            b.connect("clicked", lambda w, p=path:
                      self.launcher.open_reader(p))
            self.reader_recent_box.pack_start(b, False, False, 0)
        if not recent:
            self.reader_recent_box.pack_start(self._xlabel(
                "Nothing yet."), False, False, 0)


for _k, _v in list(vars(_PrinterPage).items()):
    if not _k.startswith("__"):
        setattr(SettingsPanel, _k, _v)


READER_STATE = CONFIG_DIR / "reader.json"
READER_DIRS = ["Books", "Documents", "Downloads", "Desktop"]
READER_EXT = (".pdf", ".epub", ".txt")
READER_COLOURS = {"White": ("#ffffff", "#1a1a1a"),
                  "Sepia": ("#f4ecd8", "#5b4636"),
                  "Dark": ("#121212", "#d6d6d6")}


def reader_state():
    try:
        return json.loads(READER_STATE.read_text())
    except Exception:
        return {}


def reader_save(st):
    try:
        READER_STATE.write_text(json.dumps(st, indent=1))
    except Exception:
        pass


def reader_library():
    roots = [Path.home() / d for d in READER_DIRS]
    roots += [Path(p) for p in sorted(
        __import__("glob").glob("/run/media/*/*"))]
    found = []
    for root in roots:
        if not root.is_dir():
            continue
        for dirpath, dirs, files in os.walk(root):
            if dirpath.count(os.sep) - str(root).count(os.sep) >= 3:
                dirs[:] = []
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for f in files:
                if f.lower().endswith(READER_EXT):
                    found.append(os.path.join(dirpath, f))
    return sorted(set(found), key=lambda p: os.path.basename(p).lower())


def epub_text(path):
    """[(chapter title, plain text)] from an EPUB, in reading order."""
    import zipfile
    import html.parser
    import posixpath
    z = zipfile.ZipFile(path)
    cont = z.read("META-INF/container.xml").decode("utf-8", "replace")
    opf_path = re.search(r'full-path="([^"]+)"', cont).group(1)
    opf = z.read(opf_path).decode("utf-8", "replace")
    base = posixpath.dirname(opf_path)
    manifest = dict(re.findall(
        r'<item\b[^>]*?id="([^"]+)"[^>]*?href="([^"]+)"', opf))
    manifest.update({i: h for h, i in re.findall(
        r'<item\b[^>]*?href="([^"]+)"[^>]*?id="([^"]+)"', opf)})
    spine = re.findall(r'<itemref\b[^>]*?idref="([^"]+)"', opf)

    class P(html.parser.HTMLParser):
        BLOCK = {"p", "div", "br", "h1", "h2", "h3", "h4", "li", "tr",
                 "section", "blockquote"}

        def __init__(self):
            super().__init__()
            self.out, self.skip, self.title = [], 0, ""
            self.in_h = False

        def handle_starttag(self, tag, a):
            if tag in ("script", "style", "head"):
                self.skip += 1
            if tag in self.BLOCK:
                self.out.append("\n")
            if tag in ("h1", "h2", "h3"):
                self.in_h = True

        def handle_endtag(self, tag):
            if tag in ("script", "style", "head"):
                self.skip = max(0, self.skip - 1)
            if tag in self.BLOCK:
                self.out.append("\n")
            if tag in ("h1", "h2", "h3"):
                self.in_h = False

        def handle_data(self, d):
            if self.skip:
                return
            if self.in_h and not self.title:
                self.title = d.strip()
            self.out.append(d)
    chapters = []
    for idref in spine:
        href = manifest.get(idref)
        if not href:
            continue
        try:
            raw = z.read(posixpath.normpath(posixpath.join(
                base, urllib.parse.unquote(href)))).decode("utf-8", "replace")
        except KeyError:
            continue
        p = P()
        p.feed(raw)
        text = re.sub(r"[ \t\r\f\v]+", " ", "".join(p.out))
        text = re.sub(r"\n\s*\n\s*(\n\s*)+", "\n\n", text).strip()
        if text:
            chapters.append((p.title or "Chapter %d" % (len(chapters) + 1),
                             text))
    return chapters


class ReaderWindow(Gtk.Window):
    """Full-screen, controller-first reader: library -> book."""

    def __init__(self, launcher, path=None):
        super().__init__(title="Aero Deck Reading mode")
        self.launcher = launcher
        self.state = reader_state()
        self.state.setdefault("books", {})
        self.colour = self.state.get("colour", "White")
        self.font = int(self.state.get("font", 20))
        self.path = None
        self.kind = None
        self.page = 0
        self.pages = 1
        self.zoom = 1.0
        self._pix_cache = {}
        self.get_style_context().add_class("reader-window")
        self.set_default_size(*_monitor_size())
        self.stack = Gtk.Stack()
        self.add(self.stack)
        self._build_library()
        self._build_book()
        self.connect("key-press-event", self._on_key)
        self.connect("destroy", lambda w: self._save())
        swipe = Gtk.GestureSwipe.new(self)
        swipe.set_touch_only(True)
        swipe.connect("swipe", self._on_swipe)
        self._swipe = swipe
        self.fullscreen()
        self.show_all()
        self.toolbar.hide()
        if path:
            self.open_book(path)
        else:
            self.show_library()

    # -- library -----------------------------------------------------------
    def _build_library(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.get_style_context().add_class("reader-library")
        box.set_margin_start(40)
        box.set_margin_end(40)
        box.set_margin_top(30)
        title = Gtk.Label()
        title.set_markup("<span size='xx-large' weight='bold'>Reading mode"
                         "</span>")
        title.set_halign(Gtk.Align.START)
        box.pack_start(title, False, False, 0)
        hint = Gtk.Label(label="Books and PDFs from Books, Documents, "
                         "Downloads and USB sticks.   Ⓐ Open   Ⓑ Close")
        hint.set_halign(Gtk.Align.START)
        box.pack_start(hint, False, False, 0)
        self.lib_list = Gtk.FlowBox()
        self.lib_list.set_selection_mode(Gtk.SelectionMode.NONE)
        self.lib_list.set_max_children_per_line(4)
        self.lib_list.set_min_children_per_line(2)
        self.lib_list.set_homogeneous(True)
        self.lib_list.set_row_spacing(12)
        self.lib_list.set_column_spacing(12)
        sc = Gtk.ScrolledWindow()
        sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sc.add(self.lib_list)
        box.pack_start(sc, True, True, 0)
        row = Gtk.Box(spacing=8)
        ob = Gtk.Button(label="Open another file…")
        ob.connect("clicked", self._on_open_file)
        row.pack_start(ob, False, False, 0)
        cb = Gtk.Button(label="Close Reading mode")
        cb.connect("clicked", lambda w: self.destroy())
        row.pack_end(cb, False, False, 0)
        box.pack_start(row, False, False, 10)
        self.stack.add_named(box, "library")

    def show_library(self):
        self._save()
        for c in self.lib_list.get_children():
            self.lib_list.remove(c)
        books = reader_library()
        first = None
        for p in books:
            st = self.state["books"].get(p, {})
            b = Gtk.Button()
            b.get_style_context().add_class("reader-book")
            lbl = Gtk.Label()
            lbl.set_markup("<b>%s</b>\n<small>%s%s</small>" % (
                _esc(os.path.splitext(os.path.basename(p))[0][:60]),
                os.path.splitext(p)[1][1:].upper(),
                ("  ·  " + _esc(st["where"])) if st.get("where") else ""))
            lbl.set_line_wrap(True)
            lbl.set_justify(Gtk.Justification.CENTER)
            b.add(lbl)
            b.set_size_request(-1, 110)
            b.connect("clicked", lambda w, q=p: self.open_book(q))
            self.lib_list.add(b)
            first = first or b
        if not books:
            self.lib_list.add(Gtk.Label(
                label="No books or PDFs found. Copy some into Books, "
                      "Documents or Downloads, or plug in a USB stick."))
        self.lib_list.show_all()
        self.stack.set_visible_child_name("library")
        if first is not None:
            first.grab_focus()

    def _on_open_file(self, _b):
        dlg = Gtk.FileChooserDialog(title="Open a book or PDF",
                                    transient_for=self,
                                    action=Gtk.FileChooserAction.OPEN)
        dlg.add_buttons("Cancel", Gtk.ResponseType.CANCEL,
                        "Open", Gtk.ResponseType.OK)
        f = Gtk.FileFilter()
        f.set_name("Books and PDFs")
        for e in READER_EXT:
            f.add_pattern("*" + e)
            f.add_pattern("*" + e.upper())
        dlg.add_filter(f)
        r = dlg.run()
        path = dlg.get_filename()
        dlg.destroy()
        if r == Gtk.ResponseType.OK and path:
            self.open_book(path)

    # -- book view ---------------------------------------------------------
    def _build_book(self):
        ov = Gtk.Overlay()
        self.book_stack = Gtk.Stack()
        self.pdf_area = Gtk.DrawingArea()
        self.pdf_area.connect("draw", self._draw_pdf)
        self.pdf_area.add_events(Gdk.EventMask.BUTTON_PRESS_MASK)
        self.pdf_area.connect("button-press-event", self._on_tap)
        self.book_stack.add_named(self.pdf_area, "pdf")
        self.text_view = Gtk.TextView()
        self.text_view.set_editable(False)
        self.text_view.set_cursor_visible(False)
        self.text_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.text_view.set_left_margin(80)
        self.text_view.set_right_margin(80)
        self.text_view.set_top_margin(40)
        self.text_view.set_bottom_margin(40)
        self.text_view.set_pixels_below_lines(6)
        self.text_view.set_can_focus(False)
        self.text_scroll = Gtk.ScrolledWindow()
        self.text_scroll.set_policy(Gtk.PolicyType.NEVER,
                                    Gtk.PolicyType.EXTERNAL)
        self.text_scroll.add(self.text_view)
        self.text_view.connect("button-press-event", self._on_tap)
        self.book_stack.add_named(self.text_scroll, "text")
        ov.add(self.book_stack)
        self.page_label = Gtk.Label()
        self.page_label.get_style_context().add_class("reader-pageno")
        self.page_label.set_halign(Gtk.Align.CENTER)
        self.page_label.set_valign(Gtk.Align.END)
        self.page_label.set_margin_bottom(8)
        ov.add_overlay(self.page_label)
        self.toolbar = Gtk.Box(spacing=8)
        self.toolbar.get_style_context().add_class("reader-toolbar")
        self.toolbar.set_halign(Gtk.Align.CENTER)
        self.toolbar.set_valign(Gtk.Align.START)
        self.toolbar.set_margin_top(14)
        for label, cb in (("◀ Page", lambda w: self.turn(-1)),
                          ("Page ▶", lambda w: self.turn(1)),
                          ("A− / Zoom −", lambda w: self.size(-1)),
                          ("A+ / Zoom +", lambda w: self.size(1)),
                          ("White", lambda w: self.set_colour("White")),
                          ("Sepia", lambda w: self.set_colour("Sepia")),
                          ("Dark", lambda w: self.set_colour("Dark")),
                          ("Print…", lambda w: self.print_dialog()),
                          ("Library", lambda w: self.show_library()),
                          ("Close", lambda w: self.destroy())):
            b = Gtk.Button(label=label)
            b.connect("clicked", cb)
            self.toolbar.pack_start(b, False, False, 0)
        ov.add_overlay(self.toolbar)
        self.stack.add_named(ov, "book")

    def open_book(self, path):
        self._save()
        self.path = path
        st = self.state["books"].get(path, {})
        ext = os.path.splitext(path)[1].lower()
        self._pix_cache = {}
        try:
            if ext == ".pdf":
                self.kind = "pdf"
                self.pages = self._pdf_pages(path)
                self.page = min(int(st.get("page", 0)), self.pages - 1)
                self.zoom = float(st.get("zoom", 1.0))
                self.book_stack.set_visible_child_name("pdf")
            else:
                self.kind = "text"
                if ext == ".epub":
                    chapters = epub_text(path)
                    text = "\n\n\n".join(
                        t if t.startswith(h) else "%s\n\n%s" % (h, t)
                        for h, t in chapters)
                else:
                    text = Path(path).read_text(errors="replace")
                self.text_view.get_buffer().set_text(text)
                self.book_stack.set_visible_child_name("text")
                self._apply_text_style()
                frac = float(st.get("frac", 0))
                GLib.timeout_add(300, self._restore_frac, frac)
        except Exception as e:     # noqa: BLE001
            self._toast("Couldn't open this file: %s" % e)
            return
        self.stack.set_visible_child_name("book")
        self.toolbar.hide()
        self.set_focus(None)
        self._update()

    def _restore_frac(self, frac):
        adj = self.text_scroll.get_vadjustment()
        adj.set_value(frac * max(0, adj.get_upper() - adj.get_page_size()))
        self._update()
        return False

    # PDF via Poppler (GI) when present, else pdftoppm.
    def _poppler(self):
        if not hasattr(self, "_pop"):
            try:
                gi.require_version("Poppler", "0.18")
                from gi.repository import Poppler
                self._pop = Poppler
            except Exception:
                self._pop = None
        return self._pop

    def _pdf_pages(self, path):
        P = self._poppler()
        if P is not None:
            self._doc = P.Document.new_from_file(
                GLib.filename_to_uri(os.path.abspath(path), None), None)
            return self._doc.get_n_pages()
        self._doc = None
        rc, out = _run(["pdfinfo", path], 15)
        m = re.search(r"Pages:\s+(\d+)", out)
        if not m:
            raise RuntimeError("not a readable PDF")
        return int(m.group(1))

    def _pdf_surface(self, w, h):
        """Page image fitted to w x h (x zoom) as a cairo surface."""
        import cairo
        key = (self.page, w, h, self.zoom)
        if key in self._pix_cache:
            return self._pix_cache[key]
        if self._doc is not None:
            pg = self._doc.get_page(self.page)
            pw, ph = pg.get_size()
            sc = min(w / pw, h / ph) * self.zoom
            surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(pw * sc),
                                      int(ph * sc))
            cr = cairo.Context(surf)
            cr.set_source_rgb(1, 1, 1)
            cr.paint()
            cr.scale(sc, sc)
            pg.render(cr)
        else:
            tmp = Path(GLib.get_tmp_dir()) / ("aero-reader-%d" % os.getpid())
            tmp.mkdir(exist_ok=True)
            out = tmp / "p"
            _run(["pdftoppm", "-f", str(self.page + 1), "-l",
                  str(self.page + 1), "-singlefile", "-png",
                  "-scale-to", str(int(max(w, h) * self.zoom)),
                  self.path, str(out)], 30)
            pix = GdkPixbuf.Pixbuf.new_from_file(str(out) + ".png")
            sc = min(w / pix.get_width(), h / pix.get_height()) * self.zoom
            pix = pix.scale_simple(max(1, int(pix.get_width() * sc)),
                                   max(1, int(pix.get_height() * sc)),
                                   GdkPixbuf.InterpType.BILINEAR)
            surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, pix.get_width(),
                                      pix.get_height())
            cr = cairo.Context(surf)
            Gdk.cairo_set_source_pixbuf(cr, pix, 0, 0)
            cr.paint()
        if len(self._pix_cache) > 6:
            self._pix_cache.clear()
        self._pix_cache[key] = surf
        return surf

    def _draw_pdf(self, area, cr):
        import cairo
        w, h = area.get_allocated_width(), area.get_allocated_height()
        bg = Gdk.RGBA()
        bg.parse(READER_COLOURS[self.colour][0])
        cr.set_source_rgb(bg.red, bg.green, bg.blue)
        cr.paint()
        if self.kind != "pdf" or not self.path:
            return False
        try:
            surf = self._pdf_surface(w, h - 30)
        except Exception as e:     # noqa: BLE001
            self._toast(str(e))
            return False
        x = (w - surf.get_width()) / 2
        y = max(0, (h - 30 - surf.get_height()) / 2)
        if surf.get_width() > w:   # zoomed: pan with the stick / pad
            x = -self._pan_x(surf.get_width() - w)
        cr.set_source_surface(surf, x, y)
        cr.paint()
        # Page colour on the page itself: sepia tint / dark invert.
        if self.colour == "Sepia":
            cr.set_operator(cairo.OPERATOR_MULTIPLY)
            cr.set_source_rgb(0.96, 0.91, 0.80)
            cr.rectangle(x, y, surf.get_width(), surf.get_height())
            cr.fill()
        elif self.colour == "Dark":
            cr.set_operator(cairo.OPERATOR_DIFFERENCE)
            cr.set_source_rgb(0.92, 0.92, 0.92)
            cr.rectangle(x, y, surf.get_width(), surf.get_height())
            cr.fill()
        return False

    def _pan_x(self, maxpan):
        self._pan = max(0, min(maxpan, getattr(self, "_pan", maxpan / 2)))
        return self._pan

    def _apply_text_style(self):
        fg_bg = READER_COLOURS[self.colour]
        css = (".reader-text, .reader-text text { background-color: %s; "
               "color: %s; font-family: serif; font-size: %dpx; }"
               % (fg_bg[0], fg_bg[1], self.font)).encode()
        if not hasattr(self, "_css"):
            self._css = Gtk.CssProvider()
            self.text_view.get_style_context().add_provider(
                self._css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 5)
            self.text_view.get_style_context().add_class("reader-text")
        self._css.load_from_data(css)

    # -- actions -----------------------------------------------------------
    def turn(self, d):
        if self.kind == "pdf":
            if getattr(self, "_pan", 0) and self.zoom > 1.0 and False:
                return
            self.page = max(0, min(self.pages - 1, self.page + d))
            self.pdf_area.queue_draw()
        elif self.kind == "text":
            adj = self.text_scroll.get_vadjustment()
            step = adj.get_page_size() - self.font * 2
            adj.set_value(max(0, min(adj.get_upper() - adj.get_page_size(),
                                     adj.get_value() + d * step)))
        self._update()

    def size(self, d):
        if self.kind == "pdf":
            self.zoom = max(1.0, min(3.0, self.zoom + 0.25 * d))
            self._pix_cache = {}
            self.pdf_area.queue_draw()
        else:
            adj = self.text_scroll.get_vadjustment()
            frac = adj.get_value() / max(1, adj.get_upper())
            self.font = max(12, min(48, self.font + 2 * d))
            self._apply_text_style()
            GLib.timeout_add(120, lambda: (adj.set_value(
                frac * adj.get_upper()), self._update(), False)[2])
        self._update()

    def set_colour(self, name):
        self.colour = name
        self._apply_text_style()
        self.pdf_area.queue_draw()
        self._save()

    def _where(self):
        if self.kind == "pdf":
            return "page %d of %d" % (self.page + 1, self.pages)
        adj = self.text_scroll.get_vadjustment()
        span = max(1, adj.get_upper() - adj.get_page_size())
        return "%d%%" % round(100 * adj.get_value() / span)

    def _update(self):
        if self.path:
            self.page_label.set_markup(
                "<small>%s</small>" % _esc(self._where()))
        self._save()

    def _save(self):
        st = self.state
        st["colour"], st["font"] = self.colour, self.font
        if self.path:
            b = st["books"].setdefault(self.path, {})
            b["t"] = time.time()
            b["where"] = self._where()
            if self.kind == "pdf":
                b["page"], b["zoom"] = self.page, self.zoom
            else:
                adj = self.text_scroll.get_vadjustment()
                span = max(1, adj.get_upper() - adj.get_page_size())
                b["frac"] = adj.get_value() / span
        reader_save(st)

    def print_dialog(self):
        dlg = Gtk.Dialog(title="Print", transient_for=self, modal=True)
        box = dlg.get_content_area()
        box.set_spacing(10)
        box.set_margin_start(20)
        box.set_margin_end(20)
        box.set_margin_top(16)
        prns = printers_list()
        combo = Gtk.ComboBoxText()
        for n, _s, d in prns:
            combo.append(n, n + ("  (default)" if d else ""))
            if d:
                combo.set_active_id(n)
        if prns and combo.get_active_id() is None:
            combo.set_active(0)
        box.pack_start(Gtk.Label(label="Printer") if prns else Gtk.Label(
            label="No printer set up -- add one in Flight Deck -> Printers."),
            False, False, 0)
        if prns:
            box.pack_start(combo, False, False, 0)
        msg = Gtk.Label(label="")
        box.pack_start(msg, False, False, 0)

        def go(pages):
            src = self.path
            if self.kind == "text" and self.path.lower().endswith(".epub"):
                src = Path(GLib.get_tmp_dir()) / "aero-reader-print.txt"
                src.write_text(self.text_view.get_buffer().props.text)
            ok, out = print_file(src, combo.get_active_id(), pages)
            msg.set_text("Sent to the printer." if ok else out)
        if prns:
            if self.kind == "pdf":
                b1 = Gtk.Button(label="Print this page")
                b1.connect("clicked", lambda w: go(str(self.page + 1)))
                box.pack_start(b1, False, False, 0)
            b2 = Gtk.Button(label="Print the whole document")
            b2.connect("clicked", lambda w: go(None))
            box.pack_start(b2, False, False, 0)
        dlg.add_button("Close", Gtk.ResponseType.CLOSE)
        dlg.show_all()
        dlg.run()
        dlg.destroy()

    def _toast(self, text):
        self.page_label.set_text(text)

    # -- input ---------------------------------------------------------------
    def _on_key(self, _w, event):
        k = event.keyval
        if self.stack.get_visible_child_name() == "library":
            if k in (Gdk.KEY_Escape, Gdk.KEY_Back):
                self.destroy()
                return True
            return False
        if self.toolbar.get_visible():
            if k in (Gdk.KEY_Escape, Gdk.KEY_Back):
                self.toolbar.hide()
                self.set_focus(None)
                return True
            return False          # D-pad / A inside the toolbar
        if k in (Gdk.KEY_Escape, Gdk.KEY_Back):
            self.show_library()
            return True
        if k in (Gdk.KEY_Return, Gdk.KEY_KP_Enter, Gdk.KEY_Menu, Gdk.KEY_F17):
            self.toolbar.show_all()
            self.toolbar.get_children()[1].grab_focus()
            return True
        if k in (Gdk.KEY_Right, Gdk.KEY_Down, Gdk.KEY_Tab, Gdk.KEY_space,
                 Gdk.KEY_Page_Down):
            self.turn(1)
            return True
        if k in (Gdk.KEY_Left, Gdk.KEY_Up, Gdk.KEY_ISO_Left_Tab,
                 Gdk.KEY_Page_Up, Gdk.KEY_BackSpace):
            self.turn(-1)
            return True
        if k in (Gdk.KEY_plus, Gdk.KEY_equal, Gdk.KEY_KP_Add):
            self.size(1)
            return True
        if k in (Gdk.KEY_minus, Gdk.KEY_KP_Subtract):
            self.size(-1)
            return True
        return False

    def _on_swipe(self, _g, vx, vy):
        if self.stack.get_visible_child_name() != "book":
            return
        if abs(vx) > abs(vy) and abs(vx) > 300:
            self.turn(1 if vx < 0 else -1)

    def _on_tap(self, _w, event):
        if self.toolbar.get_visible():
            self.toolbar.hide()
            return True
        w = self.get_allocated_width()
        if event.x < w * 0.3:
            self.turn(-1)
        elif event.x > w * 0.7:
            self.turn(1)
        else:
            self.toolbar.show_all()
        return True


def _launcher_open_reader(self, path=None):
    if self.panel_open:
        self.close_settings_panel()
    win = getattr(self, "_reader_win", None)
    if win is not None:
        try:
            win.present()
            if path:
                win.open_book(path)
            return
        except Exception:
            pass
    self._reader_win = ReaderWindow(self, path)
    self._reader_win.set_transient_for(self)
    self._reader_win.connect("destroy", lambda w: setattr(
        self, "_reader_win", None))


AltTVLauncher.open_reader = _launcher_open_reader


# ---------------------------------------------------------------------------
# Stage 1 (Nov 22 2026) launcher methods: games, hero, Live TV row,
# Back-to-Aero, IPTV auto-refresh, Interface size.
# ---------------------------------------------------------------------------
def _l_on_open_game(self, widget, name, meta):
    """Game tile: start THIS game (installed) or open its store page."""
    kind, what = game_launch_plan(name, meta)
    if kind == "steam":
        proc = _spawn(what, stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL)
        if proc is None:
            open_url("https://store.steampowered.com/app/%s/"
                     % (meta or {}).get("appid", ""))
            return
        if "rungameid" in what[-1]:
            self._remember_last("game", name, meta)
            self._steam_return_watch(int(meta["appid"]))
    elif kind == "url":
        open_url(what)
    else:
        self._show_message(name, what)


def _l_remember_last(self, kind, title, meta=None):
    meta = meta if isinstance(meta, dict) else {}
    self.settings["last_played"] = {
        "kind": kind, "title": title, "appid": meta.get("appid"),
        "url": meta.get("url", ""), "at": int(time.time())}
    try:
        save_settings(self.settings)
    except Exception:
        pass


def _game_running(appid):
    """Is a Steam game with this app id running? (Steam's reaper /
    game processes carry 'AppId=<id>' or SteamAppId=<id>.)"""
    needle = ("AppId=%d" % appid).encode()
    env_needle = ("SteamAppId=%d" % appid).encode()
    for pid in os.listdir("/proc"):
        if not pid.isdigit():
            continue
        try:
            with open("/proc/%s/cmdline" % pid, "rb") as fh:
                if needle in fh.read():
                    return True
            with open("/proc/%s/environ" % pid, "rb") as fh:
                if env_needle + b"\0" in fh.read():
                    return True
        except Exception:
            continue
    return False


def _l_steam_return_watch(self, appid):
    """When the game started from a tile exits, come back to Aero.
    Steam keeps the controller while it runs, so by default Steam is
    closed after the game (Flight Deck -> Display -> 'Close Steam after
    a game', settings 'close_steam_after_game')."""
    def worker():
        t0 = time.time()
        while time.time() - t0 < 300 and not _game_running(appid):
            time.sleep(2)
        if not _game_running(appid):
            return               # never started (update / store / error)
        while _game_running(appid):
            time.sleep(2)
        if self.settings.get("close_steam_after_game", True):
            _spawn(["steam", "-shutdown"], stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL)
        GLib.idle_add(self.back_to_aero)
    threading.Thread(target=worker, daemon=True).start()


def _l_back_to_aero(self, *args):
    """Bring Aero to the front and go home (Steam/Guide button via the
    compositor, SIGUSR1 from aero-deck-home, games ending)."""
    try:
        self.present()
        self.go_home()
    except Exception:
        pass
    return False


def _l_hero_info(self):
    """What the hero shows: the last thing played/watched, else a clean
    welcome card. Never demo content."""
    lp = self.settings.get("last_played") or {}
    if lp.get("kind") == "game" and lp.get("title"):
        return {"service": "CONTINUE PLAYING", "title": lp["title"],
                "short": "Pick up where you left off.",
                "full": "Opens the game straight from your Steam library.",
                "action": "▶  Resume", "cover": steam_cover_path(
                    int(lp["appid"])) if lp.get("appid") else None}
    if lp.get("kind") == "live" and lp.get("title"):
        return {"service": "LIVE TV", "title": lp["title"],
                "short": "Back to the channel you were watching.",
                "full": "Opens the guide on this channel.",
                "action": "▶  Watch", "cover": None}
    if load_playlists():
        return {"service": "AERO DECK", "title": "Welcome back",
                "short": "Your Live TV channels load in the background.",
                "full": "Pick a channel in Live TV, an app, or a game.",
                "action": "▶  Live TV", "cover": None}
    return {"service": "AERO DECK", "title": "Welcome",
            "short": "Add your IPTV login, sign in to Steam and your "
                     "apps -- this space then shows what you last played "
                     "or watched.",
            "full": "Flight Deck (the A button, bottom right) -> IPTV to "
                    "add a source; Your Apps and Games are below.",
            "action": "＋  Add IPTV", "cover": None}


def _l_on_watch_hero(self, widget):
    lp = self.settings.get("last_played") or {}
    if lp.get("kind") == "game" and lp.get("appid"):
        self.on_open_game(widget, lp.get("title", ""),
                          {"appid": int(lp["appid"])})
    elif lp.get("kind") == "live" and lp.get("title"):
        self.open_epg(focus_name=lp["title"])
    elif load_playlists():
        self.open_epg()
    else:
        self.open_panel_page("iptv")


def _l_on_hero_info(self, widget):
    info = self._hero_info()
    self._show_message(info["title"], info["full"])


def _l_build_row_live(self):
    """Live TV row: real channels from the IPTV source(s) only. With no
    source (or while loading) one clean tile explains what to do."""
    section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    section.pack_start(self.row_title("Live TV"), False, False, 0)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=31)
    state = iptv_source_state()
    chans = state.get("channels") or []
    for ch in chans[:24]:
        name = ch.get("name") or "Channel"
        btn = Gtk.Button()
        btn.set_size_request(302, 185)
        btn.get_style_context().add_class("live-tile")
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        live = Gtk.Label()
        live.get_style_context().add_class("live-badge")
        live.set_markup("<span color='white'>● LIVE</span>")
        live.set_halign(Gtk.Align.START)
        box.pack_start(live, False, False, 0)
        chan = Gtk.Label()
        chan.set_markup("<span weight='bold' size='large'>%s</span>"
                        % _esc(name))
        chan.set_line_wrap(True)
        chan.set_max_width_chars(22)
        box.pack_start(chan, True, True, 0)
        grp = Gtk.Label(label=ch.get("group") or "")
        grp.set_ellipsize(3)
        box.pack_start(grp, False, False, 0)
        btn.add(box)
        btn.connect("clicked", self.on_open_live, ch.get("url", ""), name)
        row.pack_start(btn, False, False, 0)
    if not chans:
        btn = Gtk.Button()
        btn.set_size_request(640, 185)
        btn.get_style_context().add_class("live-tile")
        lab = Gtk.Label()
        lab.set_line_wrap(True)
        lab.set_justify(Gtk.Justification.CENTER)
        if load_playlists():
            err = state.get("error") or "Loading channels…"
            lab.set_markup("<span weight='bold' size='large'>Live TV"
                           "</span>\n%s\n<small>Tap to open IPTV sources"
                           "</small>" % _esc(err))
        else:
            lab.set_markup("<span weight='bold' size='large'>＋ Add IPTV"
                           "</span>\nServer + username + password, or an "
                           "M3U link")
        btn.add(lab)
        btn.connect("clicked", lambda w: self.open_panel_page("iptv"))
        row.pack_start(btn, False, False, 0)
    visible = (self.ROW_VISIBLE_COUNT * 302
               + (self.ROW_VISIBLE_COUNT - 1) * 31)
    section.pack_start(self.scrollable_row(row, visible), False, False, 0)
    return section


def _l_build_row_games(self):
    return self.build_poster_row("Games", games_row_items(),
                                 self.on_open_game)


def _l_iptv_landed(self, state):
    """Background IPTV load finished: refresh rows + guide."""
    try:
        self.build_rows()
        if getattr(self, "epg_open", False):
            self.epg_channels = epg_channel_list()
            self.epg_render()
    except Exception:
        pass


def _stage1_install(self):
    """Called at the end of AltTVLauncher.__init__."""
    _IPTV_LISTENERS.append(self._iptv_landed)
    try:
        import signal
        global _SIGUSR1_SRC
        if _SIGUSR1_SRC:
            GLib.source_remove(_SIGUSR1_SRC)
        _SIGUSR1_SRC = GLib.unix_signal_add(
            GLib.PRIORITY_DEFAULT, signal.SIGUSR1, self.back_to_aero)
    except Exception:
        pass
    if load_playlists():
        iptv_source_state()     # kicks the background load if stale


for _n, _f in (("on_open_game", _l_on_open_game),
               ("_remember_last", _l_remember_last),
               ("_steam_return_watch", _l_steam_return_watch),
               ("back_to_aero", _l_back_to_aero),
               ("_hero_info", _l_hero_info),
               ("on_watch_hero", _l_on_watch_hero),
               ("on_hero_info", _l_on_hero_info),
               ("build_row_live", _l_build_row_live),
               ("build_row_games", _l_build_row_games),
               ("_iptv_landed", _l_iptv_landed),
               ("_stage1_install", _stage1_install)):
    setattr(AltTVLauncher, _n, _f)


# -- Flight Deck: IPTV add with real feedback; Display: Interface size ------
def _p_on_add_source(self, widget):
    src, err = normalize_iptv_source(
        self.new_name.get_text(), self.new_url.get_text(),
        self.new_user.get_text(), self.new_pass.get_text(),
        self.new_type.get_active_text() or "")
    status = getattr(self, "iptv_status", None)
    if err:
        if status is not None:
            status.set_text(err)
        return
    playlists = [p for p in load_playlists()
                 if not (p.get("url") == src["url"]
                         and p.get("username") == src["username"])]
    playlists.append(src)
    save_playlists(playlists)
    self.playlist_store.append([src["name"], src["url"], src["type"]])
    for e in (self.new_name, self.new_url, self.new_user, self.new_pass):
        e.set_text("")
    try:
        self.refresh_iptv_section()
    except Exception:
        pass
    self._iptv_reload()


def _p_iptv_reload(self, *args):
    status = getattr(self, "iptv_status", None)
    if status is not None:
        status.set_text("Connecting…")

    def progress(msg):
        if status is not None:
            status.set_text(msg)
        return False

    def done(state):
        if status is None:
            return
        lines = []
        for s in state.get("sources", []):
            lines.append("%s: %s" % (s["name"], "%d channels loaded" %
                                     s["channels"] if s["ok"] else
                                     "failed -- %s" % (s["error"] or "?")))
        status.set_text("\n".join(lines) or state.get("error") or "")
    iptv_refresh_async(done, progress)


def _p_build_iptv_page_extra(self):
    """Status line + Reload button under the IPTV form."""
    page = self.stack.get_child_by_name("iptv")
    if page is None:
        return
    self.iptv_status = Gtk.Label(label="")
    self.iptv_status.set_halign(Gtk.Align.START)
    self.iptv_status.set_line_wrap(True)
    st = iptv_source_state()
    if st.get("initiated"):
        self.iptv_status.set_text("%d channels loaded"
                                  % len(st.get("channels", [])))
    elif load_playlists():
        self.iptv_status.set_text(st.get("error") or "")
    page.pack_start(self.iptv_status, False, False, 0)
    reload_btn = Gtk.Button(label="Reload channels")
    reload_btn.connect("clicked", self._iptv_reload)
    page.pack_start(reload_btn, False, False, 0)
    note = Gtk.Label()
    note.set_halign(Gtk.Align.START)
    note.set_line_wrap(True)
    if _persist_targets():
        note.set_text("Sources are saved on your AERO_DATA drive and "
                      "come back after a restart.")
    else:
        note.set_text("Live USB tip: sources survive restarts once a "
                      "USB stick / SD card partition labelled AERO_DATA "
                      "is plugged in (or after Install to disk).")
    page.pack_start(note, False, False, 0)


def _p_build_ui_scale_row(self):
    """Display page: Interface size (Auto / manual) + Reset to Auto."""
    page = self.stack.get_child_by_name("display")
    if page is None:
        return
    box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    lab = Gtk.Label(label="Interface size")
    lab.set_halign(Gtk.Align.START)
    box.pack_start(lab, False, False, 0)
    combo = Gtk.ComboBoxText()
    for key, text in UI_SCALE_CHOICES:
        combo.append(key, text)
    cur = str(self.launcher.settings.get("ui_scale", "auto"))
    if not combo.set_active_id(cur):
        combo.set_active_id("auto")
    box.pack_start(combo, True, True, 0)
    apply_btn = Gtk.Button(label="Apply (restarts Aero)")
    reset_btn = Gtk.Button(label="Reset to Auto")

    def apply(_w, value=None):
        val = value or combo.get_active_id() or "auto"
        self.launcher.settings["ui_scale"] = val
        save_settings(self.launcher.settings)
        # aero-deck-loop starts the launcher again within ~2 s.
        GLib.timeout_add(300, lambda: (Gtk.main_quit(), False)[1])
    apply_btn.connect("clicked", apply)
    reset_btn.connect("clicked", apply, "auto")
    box.pack_start(apply_btn, False, False, 0)
    box.pack_start(reset_btn, False, False, 0)
    page.pack_start(box, False, False, 0)
    info = Gtk.Label(label="Now: %d%% (%s, %s)" % (
        round(UI_SCALE * 100), "auto" if cur == "auto" else "manual",
        UI_PROFILE))
    info.set_halign(Gtk.Align.START)
    page.pack_start(info, False, False, 0)
    sw = Gtk.CheckButton(label="Close Steam after a game (gives the "
                               "controller back to Aero)")
    sw.set_active(bool(self.launcher.settings.get("close_steam_after_game",
                                             True)))

    def toggled(b):
        self.launcher.settings["close_steam_after_game"] = b.get_active()
        save_settings(self.launcher.settings)
    sw.connect("toggled", toggled)
    page.pack_start(sw, False, False, 0)


for _n, _f in (("on_add_source", _p_on_add_source),
               ("_iptv_reload", _p_iptv_reload),
               ("_build_iptv_page_extra", _p_build_iptv_page_extra),
               ("_build_ui_scale_row", _p_build_ui_scale_row)):
    setattr(SettingsPanel, _n, _f)


class SplashWindow(Gtk.Window):
    """Startup screen: a retro TV with a glimmering red/blue A in the
    centre. Shows for a few seconds, then hands over to the home screen."""

    def __init__(self):
        super().__init__(title="Aero Deck")
        self.set_default_size(*_monitor_size())
        self.fullscreen()
        self.get_style_context().add_class("splash-window")
        self.connect("key-press-event", self.on_key)

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        outer.set_halign(Gtk.Align.CENTER)
        outer.set_valign(Gtk.Align.CENTER)
        self.add(outer)

        # Rabbit-ear antenna.
        antenna = Gtk.Label(label="⋀")
        antenna.get_style_context().add_class("splash-antenna")
        outer.pack_start(antenna, False, False, 0)

        # The retro TV: a bordered screen with the glimmering A inside.
        tv = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        tv.get_style_context().add_class("retro-tv")
        tv.set_size_request(520, 380)
        self.a_label = Gtk.Label(label="A")
        self.a_label.get_style_context().add_class("splash-a")
        tv.pack_start(self.a_label, True, True, 0)
        outer.pack_start(tv, False, False, 0)

        name = Gtk.Label(label="Aero Deck")
        name.get_style_context().add_class("splash-name")
        name.set_margin_top(24)
        outer.pack_start(name, False, False, 0)

        # Glimmer: pulse the A between dim and bright.
        self._glimmer_step = 0
        GLib.timeout_add(120, self._glimmer_tick)

    def _glimmer_tick(self):
        self._glimmer_step += 1
        # Sine pulse: opacity swings 0.55 -> 1.0 -> 0.55.
        import math
        opacity = 0.78 + 0.22 * math.sin(self._glimmer_step * 0.35)
        self.a_label.set_opacity(opacity)
        return True

    def on_key(self, widget, event):
        # Any key skips the splash and goes straight home.
        _show_main(self)
        return True


# Keep a module-level reference to the home window. A local variable
# inside the splash timeout is collected as soon as the callback
# returns, which destroys the window and quits the app.
_main_window = None
_main_timeout_id = None


def _show_main(splash=None):
    """Destroy the splash (if any) and show the home screen once."""
    global _main_window, _main_timeout_id
    if _main_timeout_id is not None:
        try:
            GLib.source_remove(_main_timeout_id)
        except Exception:
            pass
        _main_timeout_id = None
    if _main_window is not None:
        return False
    if splash is not None:
        try:
            splash.destroy()
        except Exception:
            pass
    _main_window = AltTVLauncher()
    try:
        _main_window.ptt_install()
    except Exception as _e:
        print("push-to-talk disabled:", _e, file=sys.stderr)
    try:
        _main_window.screensaver_install()
    except Exception as _e:
        print("screensaver disabled:", _e, file=sys.stderr)
    return False



# ---------------------------------------------------------------------------
# Nuvio Aero (Nov 22 2026): TV guide (EPG grid) -- live preview card on
# top (LIVE badge, full-screen button, title / time / channel / synopsis,
# Watch Now + Add to Library), half-hour timeline with a now-line and
# time pill, channel logo / name / number on the left. Everything is
# sized from the screen (UI_SCALE + the guide's own allocation), so it
# fits 1024x600 .. 1080p at any Interface size.
# Data: Xtream XMLTV (xmltv.php) -> per-channel get_short_epg fallback;
# M3U url-tvg / x-tvg-url XMLTV; no data -> one "Live" block per channel.
# ---------------------------------------------------------------------------
import gzip as _gzip
import hashlib as _hashlib
import xml.etree.ElementTree as _ET
try:
    gi.require_version('PangoCairo', '1.0')
    from gi.repository import Pango, PangoCairo
except Exception:          # pragma: no cover
    Pango = PangoCairo = None

GUIDE_SLOTS = 5                 # half-hour columns on screen
GUIDE_SLOT_MIN = 30
_GUIDE_EPG = {"data": {}, "at": 0.0, "busy": False}
_GUIDE_LOGOS = {}
LOGO_CACHE = Path.home() / ".cache" / "aero-deck" / "logos"


def _xmltv_time(s):
    """'20261122200000 +0000' -> epoch seconds."""
    try:
        s = s.strip()
        base = datetime.datetime.strptime(s[:14], "%Y%m%d%H%M%S")
        off = s[14:].strip()
        if off:
            sign = 1 if off[0] == "+" else -1
            off = off.lstrip("+-")
            delta = datetime.timedelta(hours=int(off[:2]),
                                       minutes=int(off[2:4] or 0))
            base = base - sign * delta
        return base.replace(tzinfo=datetime.timezone.utc).timestamp()
    except Exception:
        return None


def parse_xmltv(raw, wanted=None, t0=None, t1=None):
    """XMLTV bytes (plain or gzip) -> {channel_id: [prog, ...]}; prog =
    {"s", "e", "t", "d"}. Streams the file and keeps only programmes
    in [t0, t1] for the wanted channel ids (big guides stay cheap)."""
    if raw[:2] == b"\x1f\x8b":
        raw = _gzip.decompress(raw)
    import io
    out = {}
    names = {}
    for _ev, el in _ET.iterparse(io.BytesIO(raw), events=("end",)):
        if el.tag == "channel":
            dn = el.findtext("display-name") or ""
            names[el.get("id", "")] = dn
            el.clear()
        elif el.tag == "programme":
            cid = el.get("channel", "")
            if wanted is None or cid in wanted or \
                    names.get(cid, "").lower() in (wanted or ()):
                s = _xmltv_time(el.get("start", ""))
                e = _xmltv_time(el.get("stop", "")) or (s and s + 1800)
                if s and e and (t1 is None or s <= t1) and \
                        (t0 is None or e >= t0):
                    out.setdefault(cid, []).append({
                        "s": s, "e": e, "t": el.findtext("title") or "",
                        "d": el.findtext("desc") or ""})
            el.clear()
    for k in out:
        out[k].sort(key=lambda p: p["s"])
    out["__names__"] = names
    return out


def _b64text(v):
    import base64
    try:
        return base64.b64decode(v).decode("utf-8", "replace")
    except Exception:
        return str(v or "")


def xtream_short_epg(source, stream_id, limit=12):
    base = (source.get("url") or "").rstrip("/")
    url = ("%s/player_api.php?username=%s&password=%s&action=get_short_epg"
           "&stream_id=%s&limit=%d" % (
               base, urllib.parse.quote(source.get("username", "")),
               urllib.parse.quote(source.get("password", "")),
               stream_id, limit))
    data = json.loads(_fetch_bytes(url, 15).decode("utf-8", "replace"))
    out = []
    for e in (data or {}).get("epg_listings", []) or []:
        try:
            s = float(e.get("start_timestamp") or 0)
            en = float(e.get("stop_timestamp") or 0)
        except (TypeError, ValueError):
            continue
        if s and en:
            out.append({"s": s, "e": en, "t": _b64text(e.get("title")),
                        "d": _b64text(e.get("description"))})
    return sorted(out, key=lambda p: p["s"])


def guide_channel_key(ch):
    return ch.get("epg_id") or ("sid:%s" % ch.get("sid")) \
        if (ch.get("epg_id") or ch.get("sid") is not None) \
        else "name:" + (ch.get("name") or "")


def guide_load_epg(channels, sources, now=None):
    """Blocking EPG fetch for the given channels (worker thread).
    Returns {channel_key: [prog]}; never raises; no credentials in logs."""
    now = now or time.time()
    t0, t1 = now - 4 * 3600, now + 12 * 3600
    result = {}
    wanted = {c.get("epg_id") for c in channels if c.get("epg_id")}
    wanted |= {(c.get("name") or "").lower() for c in channels}
    for idx, src in enumerate(sources):
        stype = (src.get("type") or "").lower()
        urls = []
        if stype == "xtream":
            urls.append("%s/xmltv.php?username=%s&password=%s" % (
                (src.get("url") or "").rstrip("/"),
                urllib.parse.quote(src.get("username", "")),
                urllib.parse.quote(src.get("password", ""))))
        for c in channels:
            if c.get("src") == idx and c.get("tvg_url"):
                urls.append(c["tvg_url"])
                break
        if src.get("epg_url"):
            urls.append(src["epg_url"])
        for u in urls:
            try:
                data = parse_xmltv(_fetch_bytes(u, 60), wanted, t0, t1)
            except Exception:
                continue
            names = data.pop("__names__", {})
            byname = {}
            for cid, progs in data.items():
                byname[(names.get(cid) or "").lower()] = progs
            for c in channels:
                if c.get("src") != idx:
                    continue
                progs = data.get(c.get("epg_id") or "") or \
                    byname.get((c.get("name") or "").lower())
                if progs:
                    result[guide_channel_key(c)] = progs
            break
        if stype == "xtream":
            # Fallback per channel (only those still empty, capped).
            missing = [c for c in channels if c.get("src") == idx and
                       c.get("sid") is not None and
                       guide_channel_key(c) not in result][:60]
            for c in missing:
                try:
                    progs = xtream_short_epg(src, c["sid"])
                except Exception:
                    progs = []
                if progs:
                    result[guide_channel_key(c)] = progs
    return result


def guide_progs_for(ch, ws, we):
    """Programmes of one channel overlapping [ws, we); a channel with
    no data gets one 'Live' block so every row stays usable."""
    progs = _GUIDE_EPG["data"].get(guide_channel_key(ch)) or []
    vis = [p for p in progs if p["e"] > ws and p["s"] < we]
    if not vis:
        return [{"s": ws, "e": we, "t": "Live: %s" % (ch.get("name") or ""),
                 "d": ch.get("group") or "", "nodata": True}]
    return vis


def _logo_pixbuf(url, size):
    """Channel logo (cached on disk), or None while it downloads."""
    if not url:
        return None
    key = (url, size)
    if key in _GUIDE_LOGOS:
        return _GUIDE_LOGOS[key]
    LOGO_CACHE.mkdir(parents=True, exist_ok=True)
    path = LOGO_CACHE / (_hashlib.sha1(url.encode()).hexdigest() + ".img")
    if path.is_file():
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(str(path))
            w, h = pb.get_width(), pb.get_height()
            sc = min(size / float(w), size / float(h))
            pb = pb.scale_simple(max(1, int(w * sc)), max(1, int(h * sc)),
                                 GdkPixbuf.InterpType.BILINEAR)
        except Exception:
            pb = None
        _GUIDE_LOGOS[key] = pb
        return pb
    _GUIDE_LOGOS[key] = None

    def fetch():
        try:
            path.write_bytes(_fetch_bytes(url, 10, 2 * 1024 * 1024))
            _GUIDE_LOGOS.pop(key, None)
        except Exception:
            pass
    threading.Thread(target=fetch, daemon=True).start()
    return None


def _fmt_t(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%-I:%M")


def _fmt_t_ampm(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%-I:%M %p")


GUIDE_CSS = b"""
.nv-guide { background-color: #0d1424; padding: 24px 28px 14px 28px; }
.nv-preview { border-radius: 18px; border: 2px solid rgba(77,163,255,0.55);
              background-color: #121c33; }
.nv-live { background-color: #e0313b; color: white; font-weight: bold;
           font-size: 17px; padding: 3px 12px; border-radius: 8px; }
.nv-fs { background: rgba(0,0,0,0.45); color: white; border-radius: 10px;
         border: none; min-width: 48px; min-height: 48px; padding: 10px; }
.nv-title { color: white; font-size: 38px; font-weight: bold; }
.nv-meta { color: #b9c6df; font-size: 21px; }
.nv-desc { color: #d8e0ef; font-size: 20px; }
.nv-primary { background: #2f7cf6; color: white; font-size: 21px;
              font-weight: bold; border-radius: 14px; border: none;
              padding: 10px 28px; }
.nv-primary:focus, .nv-primary:hover { background: #4d93ff; }
.nv-secondary { background: rgba(255,255,255,0.06); color: white;
                font-size: 21px; border-radius: 14px;
                border: 1px solid rgba(255,255,255,0.22); padding: 10px 26px; }
.nv-secondary:focus, .nv-secondary:hover { background: rgba(77,147,255,0.25); }
.nv-primary, .nv-secondary, .nv-fs, .nv-primary label, .nv-secondary label {
    text-shadow: none; -gtk-icon-shadow: none; color: white; box-shadow: none; }
.nv-gridcard { background-color: rgba(255,255,255,0.035);
               border: 1px solid rgba(255,255,255,0.10); border-radius: 18px; }
.nv-hint { color: #8796b3; font-size: 16px; }
"""


def _nv_draw_fs_icon(area, cr):
    """Full-screen glyph: four corner brackets (no icon theme needed)."""
    W, H = area.get_allocated_width(), area.get_allocated_height()
    k = min(W, H) * 0.34
    cr.set_source_rgba(1, 1, 1, 1)
    cr.set_line_width(max(1.5, min(W, H) * 0.1))
    for (x, y, dx, dy) in ((1, 1, 1, 1), (W - 1, 1, -1, 1),
                           (1, H - 1, 1, -1), (W - 1, H - 1, -1, -1)):
        cr.move_to(x, y + dy * k)
        cr.line_to(x, y)
        cr.line_to(x + dx * k, y)
    cr.stroke()
    return False


def _l_build_epg_view(self):
    """Nuvio Aero guide (replaces the old TV Guide page)."""
    global _GUIDE_CSS_PROVIDER
    try:
        prov = Gtk.CssProvider()
        prov.load_from_data(GUIDE_CSS)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), prov,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
    except Exception:
        pass
    self.epg_search_entry = None
    self.epg_options_revealer = None
    self.epg_options_open = False
    view = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
    view.get_style_context().add_class("nv-guide")
    view.set_halign(Gtk.Align.FILL)
    view.set_valign(Gtk.Align.FILL)

    top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=30)
    prev = Gtk.Overlay()
    prev.get_style_context().add_class("nv-preview")
    self.nv_prev_area = Gtk.DrawingArea()
    self.nv_prev_area.connect("draw", self._nv_draw_preview)
    self.nv_prev_area.add_events(Gdk.EventMask.BUTTON_RELEASE_MASK)
    self.nv_prev_area.connect("button-release-event",
                              lambda *a: self.epg_play_focused())
    prev.add(self.nv_prev_area)
    live = Gtk.Label(label="LIVE")
    live.get_style_context().add_class("nv-live")
    live.set_halign(Gtk.Align.START)
    live.set_valign(Gtk.Align.START)
    live.set_margin_start(16)
    live.set_margin_top(14)
    prev.add_overlay(live)
    fs = Gtk.Button()
    fs_icon = Gtk.DrawingArea()
    fs_icon.set_size_request(26, 26)
    fs_icon.connect("draw", _nv_draw_fs_icon)
    fs.add(fs_icon)
    fs.get_style_context().add_class("nv-fs")
    fs.set_halign(Gtk.Align.END)
    fs.set_valign(Gtk.Align.START)
    fs.set_margin_end(14)
    fs.set_margin_top(12)
    fs.set_tooltip_text("Full screen")
    fs.connect("clicked", lambda w: self.epg_play_focused())
    prev.add_overlay(fs)
    self.nv_prev = prev
    self._nv_prev_w = 560
    prev.set_size_request(560, 315)
    top.pack_start(prev, False, False, 0)

    info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    info.set_valign(Gtk.Align.CENTER)
    self.nv_title = Gtk.Label(label="")
    self.nv_title.get_style_context().add_class("nv-title")
    self.nv_title.set_halign(Gtk.Align.START)
    self.nv_title.set_xalign(0)
    self.nv_title.set_line_wrap(True)
    self.nv_title.set_lines(2)
    self.nv_title.set_ellipsize(Pango.EllipsizeMode.END if Pango else 3)
    self.nv_meta = Gtk.Label(label="")
    self.nv_meta.get_style_context().add_class("nv-meta")
    self.nv_meta.set_halign(Gtk.Align.START)
    self.nv_meta.set_ellipsize(3)
    self.nv_desc = Gtk.Label(label="")
    self.nv_desc.get_style_context().add_class("nv-desc")
    self.nv_desc.set_halign(Gtk.Align.START)
    self.nv_desc.set_xalign(0)
    self.nv_desc.set_line_wrap(True)
    self.nv_desc.set_lines(3)
    self.nv_desc.set_ellipsize(3)
    btns = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
    btns.set_margin_top(10)
    watch = Gtk.Button(label="▶  Watch Now")
    watch.get_style_context().add_class("nv-primary")
    watch.connect("clicked", lambda w: self.epg_play_focused())
    self.nv_lib_btn = Gtk.Button(label="＋  Add to Library")
    self.nv_lib_btn.get_style_context().add_class("nv-secondary")
    self.nv_lib_btn.connect("clicked", lambda w: self.epg_toggle_favorite())
    btns.pack_start(watch, False, False, 0)
    btns.pack_start(self.nv_lib_btn, False, False, 0)
    for wdg in (self.nv_title, self.nv_meta, self.nv_desc):
        wdg.set_max_width_chars(60)
        info.pack_start(wdg, False, False, 0)
    info.pack_start(btns, False, False, 0)
    top.pack_start(info, True, True, 0)
    clock_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    self.epg_clock_label = Gtk.Label(label="")
    self.epg_clock_label.get_style_context().add_class("nv-meta")
    self.epg_clock_label.set_valign(Gtk.Align.START)
    clock_box.pack_start(self.epg_clock_label, False, False, 0)
    top.pack_end(clock_box, False, False, 0)
    view.pack_start(top, False, False, 0)

    card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    card.get_style_context().add_class("nv-gridcard")
    self.nv_head = Gtk.DrawingArea()
    self.nv_head.set_size_request(-1, 62)
    self.nv_head.connect("draw", self._nv_draw_head)
    card.pack_start(self.nv_head, False, False, 0)
    sc = Gtk.ScrolledWindow()
    sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sc.set_kinetic_scrolling(True)
    sc.set_overlay_scrolling(True)
    sc.set_vexpand(True)
    self.nv_grid = Gtk.DrawingArea()
    self.nv_grid.add_events(Gdk.EventMask.BUTTON_PRESS_MASK
                            | Gdk.EventMask.BUTTON_RELEASE_MASK
                            | Gdk.EventMask.SCROLL_MASK
                            | Gdk.EventMask.SMOOTH_SCROLL_MASK)
    self.nv_grid.connect("draw", self._nv_draw_grid)
    self.nv_grid.connect("button-press-event", self._nv_press)
    self.nv_grid.connect("button-release-event", self._nv_release)
    self.nv_grid.connect("scroll-event", self._nv_hscroll)
    sc.add(self.nv_grid)
    self.nv_scroll = sc
    card.pack_start(sc, True, True, 0)
    view.pack_start(card, True, True, 0)
    hint = Gtk.Label(label="A / OK  Watch      ◀ ▶  Programmes      "
                           "▲ ▼  Channels      Y / F  Library      B  Home")
    hint.get_style_context().add_class("nv-hint")
    hint.set_halign(Gtk.Align.START)
    view.pack_start(hint, False, False, 0)
    self.epg_iptv_hint = hint
    view.connect("size-allocate", self._nv_on_alloc)

    self.epg_view = view
    self.overlay.add_overlay(view)
    view.hide()
    self.nv_focus_row = 0
    self.nv_focus_t = None
    self.nv_ws = None
    GLib.timeout_add_seconds(30, self._nv_tick)


def _l_nv_on_alloc(self, view, alloc):
    """Preview size follows the screen (design units): ~38% of the width,
    16:9, never taller than ~27% of the height."""
    dw, dh = _dz(alloc.width), _dz(alloc.height)
    pw = int(max(300, min(640, dw * 0.38, dh * 0.27 * 16 / 9)))
    if pw != self._nv_prev_w:
        self._nv_prev_w = pw
        GLib.idle_add(lambda: (self.nv_prev.set_size_request(
            pw, int(pw * 9 / 16)), False)[1])


def _l_nv_window(self):
    now = time.time()
    if self.nv_ws is None:
        n = datetime.datetime.now().replace(second=0, microsecond=0)
        n = n.replace(minute=0 if n.minute < 30 else 30)
        self.nv_ws = n.timestamp()
    return self.nv_ws, self.nv_ws + GUIDE_SLOTS * GUIDE_SLOT_MIN * 60, now


def _nv_metrics(self, width):
    s = UI_SCALE
    chan_w = int(max(150, min(260, _dz(width) * 0.2)) * s)
    return {"s": s, "chan_w": chan_w, "row_h": int(88 * s),
            "gap": int(8 * s), "pad": int(14 * s),
            "grid_w": max(10, width - chan_w - int(14 * s))}


def _nv_text(cr, text, x, y, w, size, bold=False, color=(1, 1, 1, 1),
             align_center=False):
    if PangoCairo is None:
        return 0
    lay = PangoCairo.create_layout(cr)
    fd = Pango.FontDescription("Noto Sans %s" % ("Bold" if bold else ""))
    fd.set_absolute_size(size * Pango.SCALE)
    lay.set_font_description(fd)
    lay.set_text(text or "", -1)
    lay.set_width(int(max(1, w) * Pango.SCALE))
    lay.set_ellipsize(Pango.EllipsizeMode.END)
    if align_center:
        lay.set_alignment(Pango.Alignment.CENTER)
    cr.set_source_rgba(*color)
    cr.move_to(x, y)
    PangoCairo.show_layout(cr, lay)
    return lay.get_pixel_size()[1]


def _nv_rrect(cr, x, y, w, h, r):
    import math
    r = min(r, w / 2.0, h / 2.0)
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
    cr.close_path()


ACCENT = (0.184, 0.486, 0.965)


def _l_nv_draw_head(self, area, cr):
    W, H = area.get_allocated_width(), area.get_allocated_height()
    m = _nv_metrics(self, W)
    ws, we, now = self._nv_window()
    ppx = m["grid_w"] / float(we - ws)
    x0 = m["chan_w"]
    for i in range(GUIDE_SLOTS):
        t = ws + i * GUIDE_SLOT_MIN * 60
        x = x0 + (t - ws) * ppx
        _nv_text(cr, _fmt_t_ampm(t), x + m["pad"], H * 0.18,
                 m["grid_w"] / GUIDE_SLOTS - m["pad"], 19 * m["s"],
                 color=(0.86, 0.9, 0.97, 1))
        if i:
            cr.set_source_rgba(1, 1, 1, 0.18)
            cr.rectangle(x, H * 0.22, max(1, m["s"]), H * 0.3)
            cr.fill()
    _nv_text(cr, datetime.datetime.now().strftime("%a %-d %b"), m["pad"],
             H * 0.18, m["chan_w"] - m["pad"], 19 * m["s"], bold=True,
             color=(1, 1, 1, 0.9))
    if ws <= now < we:
        x = x0 + (now - ws) * ppx
        cr.set_source_rgba(*NOWLINE, 1)
        cr.rectangle(x - 1.5 * m["s"], H * 0.62, 3 * m["s"], H * 0.38)
        cr.fill()
        pw, ph = 108 * m["s"], 30 * m["s"]
        px = min(max(x - pw / 2, x0), W - pw - 2)
        _nv_rrect(cr, px, H - ph - 2 * m["s"], pw, ph, ph / 2)
        cr.fill()
        _nv_text(cr, _fmt_t_ampm(now), px, H - ph + 2 * m["s"], pw,
                 17 * m["s"], bold=True, align_center=True)
    cr.set_source_rgba(1, 1, 1, 0.10)
    cr.rectangle(0, H - 1, W, 1)
    cr.fill()
    return False


def _l_nv_rows(self):
    return self.epg_channels or []


def _l_nv_draw_grid(self, area, cr):
    W = area.get_allocated_width()
    m = _nv_metrics(self, W)
    rows = self._nv_rows()
    need_h = max(1, len(rows) * (m["row_h"] + m["gap"]) + m["gap"])
    if getattr(self, "_nv_grid_req", None) != need_h:
        self._nv_grid_req = need_h
        GLib.idle_add(lambda: (area.set_size_request(-1, _dz(need_h)),
                               False)[1])
    ws, we, now = self._nv_window()
    ppx = m["grid_w"] / float(we - ws)
    x0 = m["chan_w"]
    if not rows:
        _nv_text(cr, "No channels yet -- add your IPTV login in Flight "
                 "Deck -> IPTV.", m["pad"], m["pad"], W - 2 * m["pad"],
                 22 * m["s"], color=(1, 1, 1, 0.8))
        return False
    self._nv_cells = []
    clip = cr.clip_extents()
    for i, ch in enumerate(rows):
        y = m["gap"] + i * (m["row_h"] + m["gap"])
        if y > clip[3] or y + m["row_h"] < clip[1]:
            continue
        rh = m["row_h"]
        focus_row = (i == self.nv_focus_row)
        # channel cell: logo, name, number
        cr.set_source_rgba(1, 1, 1, 0.06 if not focus_row else 0.12)
        _nv_rrect(cr, m["pad"] * 0.5, y, x0 - m["pad"], rh, 12 * m["s"])
        cr.fill()
        lsz = int(rh * 0.56)
        lx, ly = m["pad"], y + (rh - lsz) / 2
        pb = _logo_pixbuf(ch.get("logo"), lsz)
        if pb is not None:
            Gdk.cairo_set_source_pixbuf(
                cr, pb, lx + (lsz - pb.get_width()) / 2,
                ly + (lsz - pb.get_height()) / 2)
            cr.paint()
        else:
            cr.set_source_rgba(*ACCENT, 0.85)
            _nv_rrect(cr, lx, ly, lsz, lsz, lsz / 2)
            cr.fill()
            _nv_text(cr, (ch.get("name") or "?")[:2].upper(), lx,
                     ly + lsz * 0.27, lsz, lsz * 0.34, bold=True,
                     align_center=True)
        tx = lx + lsz + m["pad"] * 0.8
        tw = x0 - tx - m["pad"]
        _nv_text(cr, ch.get("name"), tx, y + rh * 0.2, tw, 19 * m["s"],
                 bold=True)
        _nv_text(cr, str(ch.get("number") or i + 1), tx, y + rh * 0.52,
                 tw, 17 * m["s"], color=(0.72, 0.78, 0.9, 1))
        # programmes
        for p in guide_progs_for(ch, ws, we):
            a = max(p["s"], ws)
            b = min(p["e"], we)
            cx = x0 + (a - ws) * ppx + m["gap"] * 0.5
            cw = max(4, (b - a) * ppx - m["gap"])
            focused = focus_row and self.nv_focus_t is not None and \
                p["s"] <= self.nv_focus_t < p["e"]
            if focused:
                cr.set_source_rgba(*ACCENT, 0.95)
            else:
                cr.set_source_rgba(1, 1, 1, 0.05 if p.get("nodata")
                                   else 0.08)
            _nv_rrect(cr, cx, y, cw, rh, 12 * m["s"])
            cr.fill()
            if cw > 30 * m["s"]:
                _nv_text(cr, p["t"], cx + m["pad"], y + rh * 0.2,
                         cw - 2 * m["pad"], 19 * m["s"], bold=focused)
                if not p.get("nodata"):
                    _nv_text(cr, "%s – %s" % (_fmt_t(p["s"]),
                                              _fmt_t_ampm(p["e"])),
                             cx + m["pad"], y + rh * 0.52,
                             cw - 2 * m["pad"], 16 * m["s"],
                             color=(1, 1, 1, 0.92 if focused else 0.62))
            self._nv_cells.append((cx, y, cw, rh, i, p))
    if ws <= now < we:
        x = x0 + (now - ws) * ppx
        cr.set_source_rgba(*NOWLINE, 1)
        cr.rectangle(x - 1.5 * m["s"], 0, 3 * m["s"],
                     area.get_allocated_height())
        cr.fill()
    return False


def _l_nv_draw_preview(self, area, cr):
    W, H = area.get_allocated_width(), area.get_allocated_height()
    import math
    s = UI_SCALE
    ch, p = self._nv_focused()
    g = None
    try:
        import cairo as _c
        g = _c.LinearGradient(0, 0, W, H)
        g.add_color_stop_rgb(0, 0.09, 0.14, 0.32)
        g.add_color_stop_rgb(1, 0.20, 0.10, 0.36)
    except Exception:
        g = None
    _nv_rrect(cr, 0, 0, W, H, 18 * s)
    cr.clip()
    if g is not None:
        cr.set_source(g)
    else:
        cr.set_source_rgb(0.09, 0.14, 0.32)
    cr.paint()
    if ch is None:
        return False
    lsz = int(min(W, H) * 0.42)
    pb = _logo_pixbuf(ch.get("logo"), lsz)
    if pb is not None:
        Gdk.cairo_set_source_pixbuf(cr, pb, (W - pb.get_width()) / 2,
                                    H * 0.40 - pb.get_height() / 2)
        cr.paint()
    else:
        _nv_text(cr, ch.get("name"), 0, H * 0.30, W, 34 * s, bold=True,
                 align_center=True)
    _nv_text(cr, p["t"] if p else "", W * 0.05, H * 0.76, W * 0.9, 20 * s,
             color=(1, 1, 1, 0.85), align_center=True)
    return False


def _l_nv_focused(self):
    rows = self._nv_rows()
    if not rows:
        return None, None
    self.nv_focus_row = max(0, min(self.nv_focus_row, len(rows) - 1))
    ch = rows[self.nv_focus_row]
    ws, we, now = self._nv_window()
    if self.nv_focus_t is None:
        self.nv_focus_t = max(now, ws)
    progs = guide_progs_for(ch, ws, we)
    for p in progs:
        if p["s"] <= self.nv_focus_t < p["e"]:
            return ch, p
    return ch, progs[0] if progs else None


def _l_epg_render(self):
    if self.epg_view is None:
        return
    self.nv_grid.queue_draw()
    self.nv_head.queue_draw()
    self.epg_update_preview()


def _l_epg_update_preview(self):
    if self.epg_view is None:
        return
    ch, p = self._nv_focused()
    if ch is None:
        self.nv_title.set_text("Live TV")
        self.nv_meta.set_text("No channels yet")
        self.nv_desc.set_text("Add your IPTV login in Flight Deck -> IPTV; "
                              "the guide fills in by itself.")
    else:
        nodata = (p or {}).get("nodata")
        self.nv_title.set_text(ch.get("name") if nodata or not p
                               else p["t"])
        times = "" if nodata or not p else "%s – %s  •  " % (
            _fmt_t_ampm(p["s"]), _fmt_t_ampm(p["e"]))
        self.nv_meta.set_text("%s%s" % (times, ch.get("name") or ""))
        self.nv_desc.set_text((p or {}).get("d") or (
            "Live now on %s." % ch.get("name")))
        fav = is_epg_favorite(ch.get("name") or "")
        self.nv_lib_btn.set_label("✓  In Library" if fav
                                  else "＋  Add to Library")
    self.nv_prev_area.queue_draw()


def _l_epg_move_focus(self, delta):
    rows = self._nv_rows()
    if not rows:
        return
    self.nv_focus_row = max(0, min(len(rows) - 1, self.nv_focus_row + delta))
    self._nv_scroll_to_focus()
    self.epg_render()


def _l_nv_scroll_to_focus(self):
    m = _nv_metrics(self, self.nv_grid.get_allocated_width() or 1000)
    adj = self.nv_scroll.get_vadjustment()
    y = m["gap"] + self.nv_focus_row * (m["row_h"] + m["gap"])
    if y < adj.get_value():
        adj.set_value(max(0, y - m["gap"]))
    elif y + m["row_h"] > adj.get_value() + adj.get_page_size():
        adj.set_value(y + m["row_h"] + m["gap"] - adj.get_page_size())


def _l_epg_shift_time(self, delta_min):
    """Left / Right: previous / next programme on the focused row; the
    time window follows (half an hour at a time)."""
    ch, p = self._nv_focused()
    if ch is None or p is None:
        return
    ws, we, now = self._nv_window()
    if delta_min > 0:
        t = p["e"] + 1
        if t >= we:
            self.nv_ws += GUIDE_SLOT_MIN * 60
    else:
        t = p["s"] - 1
        if t < ws:
            floor = now - 3600
            if ws - GUIDE_SLOT_MIN * 60 >= floor - GUIDE_SLOT_MIN * 60:
                self.nv_ws -= GUIDE_SLOT_MIN * 60
            else:
                t = ws
    ws, we, _n = self._nv_window()
    self.nv_focus_t = min(max(t, ws), we - 1)
    self.epg_render()


def _l_nv_press(self, area, ev):
    self._nv_press_xy = (ev.x, ev.y)
    return False


def _l_nv_release(self, area, ev):
    px, py = getattr(self, "_nv_press_xy", (ev.x, ev.y))
    if abs(ev.x - px) > 12 or abs(ev.y - py) > 12:
        return False                 # it was a drag / swipe
    for cx, cy, cw, ch_, row, p in getattr(self, "_nv_cells", []):
        if cx <= ev.x <= cx + cw and cy <= ev.y <= cy + ch_:
            same = (row == self.nv_focus_row and self.nv_focus_t is not None
                    and p["s"] <= self.nv_focus_t < p["e"])
            self.nv_focus_row = row
            self.nv_focus_t = max(p["s"], self._nv_window()[0])
            if same:
                self.epg_play_focused()   # second tap = watch
            self.epg_render()
            return True
    m = _nv_metrics(self, area.get_allocated_width())
    if ev.x < m["chan_w"]:
        row = int((ev.y - m["gap"]) // (m["row_h"] + m["gap"]))
        if 0 <= row < len(self._nv_rows()):
            if row == self.nv_focus_row:
                self.epg_play_focused()
            self.nv_focus_row = row
            self.epg_render()
    return True


def _l_nv_hscroll(self, area, ev):
    """Horizontal wheel / two-finger / left-trackpad sideways: time."""
    dx = 0.0
    if ev.direction == Gdk.ScrollDirection.RIGHT:
        dx = 1
    elif ev.direction == Gdk.ScrollDirection.LEFT:
        dx = -1
    elif ev.direction == Gdk.ScrollDirection.SMOOTH:
        ok, ddx, ddy = ev.get_scroll_deltas()
        if abs(ddx) > abs(ddy) and abs(ddx) > 0.3:
            dx = 1 if ddx > 0 else -1
    if dx:
        self.epg_shift_time(30 if dx > 0 else -30)
        return True
    return False


def _l_epg_update_clock(self):
    if getattr(self, "epg_clock_label", None) is not None:
        self.epg_clock_label.set_text(
            datetime.datetime.now().strftime("%-I:%M %p"))
    if getattr(self, "nv_head", None) is not None:
        self.nv_head.queue_draw()
        self.nv_grid.queue_draw()


def _l_nv_tick(self):
    if getattr(self, "epg_open", False):
        self.epg_update_clock()
        if time.time() - _GUIDE_EPG["at"] > 1800:
            self._nv_fetch_epg()
    return True


def _l_nv_fetch_epg(self):
    if _GUIDE_EPG["busy"]:
        return
    _GUIDE_EPG["busy"] = True
    chans = list(self._nv_rows())
    sources = load_playlists()

    def work():
        try:
            data = guide_load_epg(chans, sources)
            if data:
                _GUIDE_EPG["data"].update(data)
            _GUIDE_EPG["at"] = time.time()
        finally:
            _GUIDE_EPG["busy"] = False
        GLib.idle_add(lambda: (self.epg_render() if self.epg_open
                               else None, False)[1])
    threading.Thread(target=work, daemon=True).start()


def _l_open_epg(self, focus_name=None):
    if self.epg_view is None:
        self.build_epg_view()
    st = iptv_source_state()
    chans = []
    for i, ch in enumerate(st.get("channels") or []):
        c = dict(ch)
        c.setdefault("number", c.get("num") or i + 1)
        c.setdefault("program", "Live TV")
        chans.append(c)
    self.epg_all_channels = chans
    self.epg_channels = chans
    self.nv_ws = None
    self.nv_focus_t = None
    self.nv_focus_row = 0
    if focus_name:
        for i, ch in enumerate(chans):
            if ch.get("name") == focus_name:
                self.nv_focus_row = i
                break
    self.epg_focus = self.nv_focus_row
    self.epg_view.show_all()
    self.epg_open = True
    self.epg_update_clock()
    self.epg_render()
    GLib.idle_add(lambda: (self._nv_scroll_to_focus(), False)[1])
    if chans and time.time() - _GUIDE_EPG["at"] > 1800:
        self._nv_fetch_epg()
    try:
        play_ui_sound("open", page="epg")
    except Exception:
        pass


def _l_epg_focused_channel(self):
    ch, p = self._nv_focused()
    if ch is None:
        return None
    out = dict(ch)
    out["program"] = (p or {}).get("t") or "Live TV"
    return out


def _l_epg_play_focused(self):
    ch = self.epg_focused_channel()
    if ch is None:
        return
    self.epg_preview_name = ch.get("name")
    self._remember_last("live", ch.get("name"), {"url": ch.get("url")})
    self.open_player(ch)


def _l_epg_toggle_favorite(self):
    ch = self.epg_focused_channel()
    if ch is None:
        return False
    starred = toggle_epg_favorite(ch["name"])
    self.epg_render()
    return starred


def _l_on_open_live(self, widget, url, name):
    """Live TV tile: play the channel full screen; Back lands in the
    guide (on that channel), Back again goes home."""
    self.open_epg(focus_name=name)
    if url:
        self.epg_play_focused()


def _l_epg_start_audio(self, ch, start_offset=0):
    return None             # no background audio from the guide


for _n, _f in (("build_epg_view", _l_build_epg_view),
               ("_nv_on_alloc", _l_nv_on_alloc),
               ("_nv_window", _l_nv_window),
               ("_nv_draw_head", _l_nv_draw_head),
               ("_nv_draw_grid", _l_nv_draw_grid),
               ("_nv_draw_preview", _l_nv_draw_preview),
               ("_nv_rows", _l_nv_rows),
               ("_nv_focused", _l_nv_focused),
               ("epg_render", _l_epg_render),
               ("epg_update_preview", _l_epg_update_preview),
               ("epg_move_focus", _l_epg_move_focus),
               ("_nv_scroll_to_focus", _l_nv_scroll_to_focus),
               ("epg_shift_time", _l_epg_shift_time),
               ("_nv_press", _l_nv_press),
               ("_nv_release", _l_nv_release),
               ("_nv_hscroll", _l_nv_hscroll),
               ("epg_update_clock", _l_epg_update_clock),
               ("_nv_tick", _l_nv_tick),
               ("_nv_fetch_epg", _l_nv_fetch_epg),
               ("open_epg", _l_open_epg),
               ("epg_focused_channel", _l_epg_focused_channel),
               ("epg_play_focused", _l_epg_play_focused),
               ("epg_toggle_favorite", _l_epg_toggle_favorite),
               ("on_open_live", _l_on_open_live),
               ("epg_start_audio", _l_epg_start_audio),
               ("epg_apply_theme", lambda self: None),
               ("epg_open_options", lambda self: None)):
    setattr(AltTVLauncher, _n, _f)


# ---------------------------------------------------------------------------
# Nuvio Aero: live Interface-size slider (Flight Deck -> Display).
# Auto stays the default; dragging the slider rescales the whole
# launcher in place (the home window is rebuilt at the new size, the
# Display page reopens) -- no restart. "Reset to Auto" goes back to the
# size picked for this screen.
# ---------------------------------------------------------------------------
_SIGUSR1_SRC = None
UI_SCALE_MIN, UI_SCALE_MAX = 0.45, 1.25


def aero_auto_scale():
    w, h = _monitor_size((1920, 1080))
    return compute_ui_scale(w, h, None)


def aero_set_ui_scale(value):
    """value: "auto" or a float. Rescale + rebuild the home window."""
    global UI_SCALE, _main_window
    w, h = _monitor_size((1920, 1080))
    new = compute_ui_scale(w, h, value)
    old = _main_window
    if old is not None:
        old.settings["ui_scale"] = value if value == "auto" else \
            "%.3g" % float(value)
        save_settings(old.settings)
    if abs(new - UI_SCALE) < 0.004 and old is not None:
        return False
    UI_SCALE = new
    try:
        Gtk.Settings.get_default().set_property(
            "gtk-xft-dpi", int(96 * 1024 * UI_SCALE))
    except Exception:
        pass
    _GUIDE_LOGOS.clear()
    if old is None:
        return False
    win = AltTVLauncher()
    _main_window = win
    for fn in ("ptt_install", "screensaver_install"):
        try:
            getattr(win, fn)()
        except Exception:
            pass
    try:
        old.disconnect_by_func(Gtk.main_quit)
    except Exception:
        pass
    try:
        _IPTV_LISTENERS.remove(old._iptv_landed)
    except Exception:
        pass
    try:
        if getattr(old, "_ss_id", None):
            GLib.source_remove(old._ss_id)
            old._ss_id = None
    except Exception:
        pass
    old._aero_dead = True
    old.destroy()
    try:
        win.open_panel_page("display")
    except Exception:
        pass
    print("aero-deck: ui_scale now %s (%s)" % (UI_SCALE, value),
          file=sys.stderr, flush=True)
    return False


def _p_build_ui_scale_row(self):
    """Display page: Interface size slider (live) + Reset to Auto."""
    page = self.stack.get_child_by_name("display")
    if page is None:
        return
    cur = str(self.launcher.settings.get("ui_scale", "auto"))
    head = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    lab = Gtk.Label(label="Interface size")
    lab.set_halign(Gtk.Align.START)
    head.pack_start(lab, False, False, 0)
    val = Gtk.Label(label="")
    val.set_halign(Gtk.Align.END)
    head.pack_end(val, False, False, 0)
    page.pack_start(head, False, False, 0)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
    scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL,
                                     UI_SCALE_MIN * 100, UI_SCALE_MAX * 100,
                                     5)
    scale.set_draw_value(False)
    scale.set_hexpand(True)
    scale.set_value(round(UI_SCALE * 100))
    auto_pct = round(aero_auto_scale() * 100)
    scale.add_mark(auto_pct, Gtk.PositionType.BOTTOM, "Auto")
    row.pack_start(scale, True, True, 0)
    reset_btn = Gtk.Button(label="Reset to Auto")
    reset_btn.set_sensitive(cur != "auto")
    row.pack_start(reset_btn, False, False, 0)
    page.pack_start(row, False, False, 0)
    self.ui_scale_slider = scale

    def show(pct, mode):
        val.set_text("%d%%  (%s)" % (pct, mode))
    show(round(UI_SCALE * 100), "auto" if cur == "auto" else "manual")
    state = {"id": None}

    def commit():
        state["id"] = None
        pct = int(round(scale.get_value() / 5.0) * 5)
        GLib.idle_add(aero_set_ui_scale, pct / 100.0)
        return False

    def changed(s):
        show(int(round(s.get_value())), "manual")
        if state["id"]:
            GLib.source_remove(state["id"])
        state["id"] = GLib.timeout_add(700, commit)
    scale.connect("value-changed", changed)
    reset_btn.connect("clicked", lambda b: GLib.idle_add(
        aero_set_ui_scale, "auto"))
    info = Gtk.Label(label="Auto fits this screen (%d%%, %s). Changes "
                           "apply live." % (auto_pct, UI_PROFILE))
    info.set_halign(Gtk.Align.START)
    info.set_line_wrap(True)
    page.pack_start(info, False, False, 0)
    sw = Gtk.CheckButton(label="Close Steam after a game (gives the "
                               "controller back to Aero)")
    sw.set_active(bool(self.launcher.settings.get("close_steam_after_game",
                                                  True)))

    def toggled(b):
        self.launcher.settings["close_steam_after_game"] = b.get_active()
        save_settings(self.launcher.settings)
    sw.connect("toggled", toggled)
    page.pack_start(sw, False, False, 0)


SettingsPanel._build_ui_scale_row = _p_build_ui_scale_row


def _l_iptv_landed2(self, state):
    """Background IPTV load finished: refresh rows + the guide."""
    if getattr(self, "_aero_dead", False):
        return
    try:
        self.build_rows()
        if getattr(self, "epg_open", False):
            ch = self.epg_focused_channel()
            keep = self.nv_focus_t
            self.open_epg(focus_name=(ch or {}).get("name"))
            self.nv_focus_t = keep
            self.epg_render()
    except Exception:
        pass


AltTVLauncher._iptv_landed = _l_iptv_landed2




# ---------------------------------------------------------------------------
# Aero OS Monday Night (launcher 1.4.0, Nov 23 2026)
#  * Live TV guide: "Live TV" heading, ~5 rows fill the grid, purple
#    now-line, live muted preview in the panel (GStreamer), preview on/off
#    + size (Settings -> Appearance).
#  * Trailers: Xtream youtube_trailer -> yt-dlp YouTube search; muted
#    trailer inside a focused poster card (card grows a little), Trailer
#    button on the details page (mpv, full screen).
#  * Hero: 6-dot carousel (1 = last watched/played, 2-6 = IPTV movies /
#    shows / installed Steam games), full + split slides; the hero follows
#    the focused poster.
#  * Live Tiles (animated art) first in Live TV / Movies / TV Shows.
#  * Movies / TV Shows rows = the IPTV source's VOD (no demo titles).
#  * Look & feel: accent colour, background static/dynamic + blur + dim,
#    panel opacity -- each with a Default button.
#  * Aero Start menu (A button, opposite Wingman): Linux Apps / Droid Apps.
#  * Long-press / right-click on app tiles; "Remove from home".
#  * Remote: Play/Pause, Home, Search/voice -> Aero voice search.
# Everything is sized in design px (UI_SCALE patches set_size_request), so
# it still fits 1024x600 .. 1080p at any Interface size.
# ---------------------------------------------------------------------------
try:
    gi.require_version("Gst", "1.0")
    from gi.repository import Gst
    Gst.init(None)
except Exception:            # pragma: no cover
    Gst = None

AERO_DECK_MONDAY = True
MONDAY_DEFAULTS = {
    "aero_accent": "#2b6fe3",
    "mon_bg_mode": "static",          # static | dynamic
    "mon_bg_blur": 0,                 # 0..10
    "mon_bg_dim": 0,                  # 0..70 (%)
    "mon_panel_opacity": 20,          # 0..90 (%) frosted cards / tiles
    "mon_guide_preview": True,
    "mon_guide_preview_size": "medium",   # small | medium | large
    "mon_card_trailers": True,
}
ACCENT_CHOICES = [("Aero blue", "#2b6fe3"), ("Sky", "#4da3ff"),
                  ("Teal", "#2bb673"), ("Purple", "#8b5cf6"),
                  ("Pink", "#e85d8a"), ("Red", "#e50914"),
                  ("Amber", "#f5a623"), ("Aluminum", "#aab4c3")]
NOWLINE = (0.545, 0.361, 0.965)       # StreamOn-style purple now-line
GUIDE_PREVIEW_SIZES = {"small": 0.30, "medium": 0.38, "large": 0.46}
ART_CACHE = Path.home() / ".cache" / "aero-deck" / "art"
_ART_MEM = {}
_TRAILER_IDS = {}
_LOOK_PROVIDER = None
_SIGUSR2_SRC = None


def mset(settings, key):
    v = (settings or {}).get(key)
    return MONDAY_DEFAULTS[key] if v is None else v


def _hex_rgb(h):
    h = (h or "#2b6fe3").lstrip("#")
    try:
        return tuple(int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    except Exception:
        return (0.17, 0.43, 0.89)


def _rgba_css(h, a):
    r, g, b = _hex_rgb(h)
    return "rgba(%d,%d,%d,%.2f)" % (r * 255, g * 255, b * 255, a)


def _lighter(h, f=0.25):
    r, g, b = _hex_rgb(h)
    return "#%02x%02x%02x" % tuple(int(255 * min(1, c + (1 - c) * f))
                                   for c in (r, g, b))


# -- art (posters / backdrops / logos) ---------------------------------------
def _cover_crop(pb, w, h):
    if pb is None or w <= 0 or h <= 0:
        return pb
    sw, sh = pb.get_width(), pb.get_height()
    sc = max(w / float(sw), h / float(sh))
    dw, dh = max(1, int(sw * sc + 0.5)), max(1, int(sh * sc + 0.5))
    s = pb.scale_simple(dw, dh, GdkPixbuf.InterpType.BILINEAR)
    return s.new_subpixbuf((dw - w) // 2, (dh - h) // 2, min(w, dw),
                           min(h, dh))


def _round_pb(pb, r):
    """Rounded corners (cairo); returns the input on any failure."""
    if pb is None or r <= 0:
        return pb
    try:
        import cairo as _c
        import math
        w, h = pb.get_width(), pb.get_height()
        surf = _c.ImageSurface(_c.FORMAT_ARGB32, w, h)
        cr = _c.Context(surf)
        r = min(r, w / 2.0, h / 2.0)
        cr.new_sub_path()
        cr.arc(w - r, r, r, -math.pi / 2, 0)
        cr.arc(w - r, h - r, r, 0, math.pi / 2)
        cr.arc(r, h - r, r, math.pi / 2, math.pi)
        cr.arc(r, r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()
        cr.clip()
        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
        cr.paint()
        out = Gdk.pixbuf_get_from_surface(surf, 0, 0, w, h)
        return out or pb
    except Exception:
        return pb


def art_pixbuf_now(src):
    """Full-size pixbuf if the art (URL or local path) is already here."""
    if not src:
        return None
    src = str(src)
    if src in _ART_MEM:
        return _ART_MEM[src]
    path = Path(src) if not src.startswith(("http://", "https://")) else \
        ART_CACHE / (_hashlib.sha1(src.encode()).hexdigest() + ".img")
    if path.is_file():
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(str(path))
            _ART_MEM[src] = pb
            return pb
        except Exception:
            return None
    return None


_ART_WAIT = {}


def art_load(src, cb):
    """cb(pixbuf) on the main loop -- right away when cached, else after
    one shared background download (atomic write, every waiting caller
    is called back). Never raises; cb never gets None."""
    pb = art_pixbuf_now(src)
    if pb is not None:
        cb(pb)
        return
    if not src or not str(src).startswith(("http://", "https://")):
        return
    src = str(src)
    if src in _ART_WAIT:
        _ART_WAIT[src].append(cb)
        return
    _ART_WAIT[src] = [cb]

    def done():
        cbs = _ART_WAIT.pop(src, [])
        pb = art_pixbuf_now(src)
        if pb is not None:
            for f in cbs:
                try:
                    f(pb)
                except Exception:
                    pass
        return False

    def work():
        try:
            ART_CACHE.mkdir(parents=True, exist_ok=True)
            p = ART_CACHE / (_hashlib.sha1(src.encode()).hexdigest() + ".img")
            tmp = p.with_name(p.name + ".%d.part" % threading.get_ident())
            tmp.write_bytes(_fetch_bytes(src, 12, 6 * 1024 * 1024))
            os.replace(str(tmp), str(p))
        except Exception:
            pass
        GLib.idle_add(done)
    threading.Thread(target=work, daemon=True).start()


def _px(v):
    return max(1, int(v * UI_SCALE))


# -- video (GStreamer playbin -> gtksink widget) -----------------------------
class AeroVideo(object):
    """A muted (by default) video widget. .ok is False when GStreamer or
    gtksink is missing -- callers then simply keep the still art."""

    def __init__(self, muted=True, on_playing=None, on_end=None):
        self.ok = False
        self.widget = None
        self.pipe = None
        self.uri = None
        self.on_playing = on_playing
        self.on_end = on_end
        if Gst is None:
            return
        try:
            sink = Gst.ElementFactory.make("gtksink", None)
            pipe = Gst.ElementFactory.make("playbin", None)
            if sink is None or pipe is None:
                return
            pipe.set_property("video-sink", sink)
            pipe.set_property("mute", bool(muted))
            sink.set_property("force-aspect-ratio", True)
            self.widget = sink.get_property("widget")
            self.pipe = pipe
            bus = pipe.get_bus()
            bus.add_signal_watch()
            bus.connect("message", self._on_msg)
            self.ok = True
        except Exception:
            self.ok = False

    def play(self, uri):
        if not self.ok or not uri:
            return False
        try:
            self.pipe.set_state(Gst.State.NULL)
            self.uri = uri
            self.pipe.set_property("uri", uri)
            self.pipe.set_state(Gst.State.PLAYING)
            return True
        except Exception:
            return False

    def stop(self):
        self.uri = None
        if self.ok:
            try:
                self.pipe.set_state(Gst.State.NULL)
            except Exception:
                pass

    def _on_msg(self, bus, msg):
        t = msg.type
        if t == Gst.MessageType.STATE_CHANGED and msg.src == self.pipe:
            old, new, _p = msg.parse_state_changed()
            if new == Gst.State.PLAYING and self.on_playing:
                self.on_playing()
        elif t in (Gst.MessageType.ERROR, Gst.MessageType.EOS):
            # Never print the URI (IPTV stream URLs carry the login).
            self.stop()
            if self.on_end:
                self.on_end()


# -- trailers ----------------------------------------------------------------
def _yt_id(v):
    v = str(v or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", v):
        return v
    m = re.search(r"(?:v=|youtu\.be/|/embed/|/shorts/)([A-Za-z0-9_-]{11})", v)
    return m.group(1) if m else None


def _xtream_vod_trailer(kind, vod_id):
    """get_vod_info / get_series_info -> youtube_trailer (any Xtream
    source that answers). Blocking; never raises; no credentials logged."""
    action = "get_vod_info&vod_id" if kind == "movies" else \
        "get_series_info&series_id"
    for src in load_playlists():
        if (src.get("type") or "").lower() != "xtream":
            continue
        try:
            url = "%s/player_api.php?username=%s&password=%s&action=%s=%s" % (
                (src.get("url") or "").rstrip("/"),
                urllib.parse.quote(src.get("username", "")),
                urllib.parse.quote(src.get("password", "")), action,
                urllib.parse.quote(str(vod_id)))
            data = json.loads(_fetch_bytes(url, 15, 4 * 1024 * 1024)
                              .decode("utf-8", "replace"))
            info = (data or {}).get("info") or {}
            vid = _yt_id(info.get("youtube_trailer") or info.get("trailer"))
            if vid:
                return vid
        except Exception:
            continue
    return None


def trailer_find(kind, name, year=""):
    """YouTube video id of the title's official trailer, or None.
    Order: the IPTV entry's youtube_trailer, Xtream get_*_info, then a
    YouTube search "<title> <year> official trailer" (yt-dlp)."""
    key = (kind, name)
    if key in _TRAILER_IDS:
        return _TRAILER_IDS[key]
    det = TITLE_DETAILS.get(key) or {}
    vid = _yt_id(det.get("trailer"))
    if not vid and det.get("vod_id") is not None and kind in ("movies",
                                                              "shows"):
        vid = _xtream_vod_trailer(kind, det["vod_id"])
    if not vid and shutil.which("yt-dlp"):
        year = year or det.get("year") or ""
        word = "game trailer" if kind == "games" else "official trailer"
        q = re.sub(r"\s+", " ", "%s %s %s" % (name, year, word)).strip()
        try:
            out = subprocess.run(
                ["yt-dlp", "--no-warnings", "--skip-download", "--get-id",
                 "--no-playlist", "ytsearch1:" + q],
                capture_output=True, text=True, timeout=30).stdout
            vid = _yt_id(out.strip().splitlines()[0] if out.strip() else "")
        except Exception:
            vid = None
    _TRAILER_IDS[key] = vid
    return vid


def trailer_stream_url(vid):
    """Direct (progressive, <=480p) stream URL for the in-card preview."""
    if not vid or not shutil.which("yt-dlp"):
        return None
    try:
        out = subprocess.run(
            ["yt-dlp", "--no-warnings", "-g", "-f",
             "best[height<=480][ext=mp4]/best[height<=480]/best",
             "https://www.youtube.com/watch?v=" + vid],
            capture_output=True, text=True, timeout=40).stdout
        lines = [l for l in out.splitlines() if l.startswith("http")]
        return lines[0] if lines else None
    except Exception:
        return None


# -- look & feel -------------------------------------------------------------
def aero_apply_look(win):
    """Accent colour, panel opacity (frosted cards / tiles) and the
    guide's accent, from the settings. One provider, replaced each time."""
    global _LOOK_PROVIDER, ACCENT
    st = win.settings if win is not None else {}
    acc = mset(st, "aero_accent")
    op = max(0, min(90, int(mset(st, "mon_panel_opacity")))) / 100.0
    ACCENT = _hex_rgb(acc)
    css = """
button.app-tile:focus, button.poster-tile:focus, button.live-tile:focus,
button.mon-live-tile:focus, button.mon-start-item:focus {
    box-shadow: 0 0 0 4px %(acc)s, 0 0 22px %(glow)s; }
.card { background: rgba(255,255,255,%(op).2f); }
button.app-tile:not(.app-tile-icon) { background: rgba(255,255,255,%(op).2f); }
.nv-primary { background: %(acc)s; }
.nv-primary:focus, .nv-primary:hover { background: %(light)s; }
.nv-preview { border-color: %(half)s; }
button.mon-dot { min-width: 12px; min-height: 12px; padding: 0;
    border-radius: 7px; border: none; box-shadow: none;
    background: rgba(255,255,255,0.55); }
button.mon-dot.on { background: %(acc)s; min-width: 30px; }
button.mon-swatch { min-width: 40px; min-height: 40px; padding: 0;
    border-radius: 20px; border: 3px solid rgba(255,255,255,0.7); }
button.mon-swatch.on { border: 4px solid #ffffff;
    box-shadow: 0 0 0 3px %(acc)s; }
.mon-trailer-on { box-shadow: 0 0 0 4px %(acc)s, 0 10px 30px rgba(0,0,0,0.45); }
label.mon-hero-service { color: %(light)s; font-weight: bold; font-size: 22px;
    text-shadow: 0 1px 4px rgba(0,0,0,0.8); }
label.mon-hero-title { color: white; font-weight: bold; font-size: 44px;
    text-shadow: 0 2px 8px rgba(0,0,0,0.85); }
label.mon-hero-sub { color: rgba(255,255,255,0.92); font-size: 19px;
    text-shadow: 0 1px 4px rgba(0,0,0,0.85); }
button.mon-hero-btn { background: %(acc)s; color: white; border: none;
    font-size: 18px; padding: 8px 22px; }
button.mon-hero-btn label { color: white; text-shadow: none; }
button.mon-start-btn { padding: 2px 12px; }
label.mon-start-label { color: #1d2733; font-weight: bold; font-size: 16px; }
popover.mon-start { background: rgba(236,240,246,0.97); border-radius: 22px;
    border: 1px solid rgba(255,255,255,0.9); padding: 16px; }
popover.mon-start label { color: #1d2733; text-shadow: none; }
label.mon-start-head { font-size: 20px; font-weight: bold; color: #1d2733; }
button.mon-start-item { background: rgba(255,255,255,0.85); border-radius: 16px;
    border: 1px solid rgba(160,172,190,0.6); box-shadow: none; padding: 6px; }
button.mon-start-item:hover { background: #ffffff; }
label.mon-start-name { font-size: 14px; color: #1d2733; }
label.mon-guide-head { color: white; font-size: 26px; font-weight: bold; }
""" % {"acc": acc, "glow": _rgba_css(acc, 0.55), "light": _lighter(acc),
       "half": _rgba_css(acc, 0.55), "op": op}
    try:
        prov = Gtk.CssProvider()
        prov.load_from_data(css.encode())
        screen = Gdk.Screen.get_default()
        if _LOOK_PROVIDER is not None:
            Gtk.StyleContext.remove_provider_for_screen(screen, _LOOK_PROVIDER)
        _LOOK_PROVIDER = prov
        Gtk.StyleContext.add_provider_for_screen(
            screen, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 3)
    except Exception:
        pass
    if win is not None:
        try:
            win._backdrop_alloc = (0, 0)
            a = win.backdrop_image.get_allocation()
            if win.backdrop_pixbuf is not None and a.width > 1:
                win._scale_backdrop(a.width, a.height)
            win._update_backdrop_visibility()
            if getattr(win, "epg_view", None) is not None:
                win.epg_render()
                win._nv_apply_prefs()
        except Exception:
            pass


def _l_scale_backdrop(self, width, height):
    """Backdrop: cover-crop + optional blur (down/up-scale) + dim."""
    src = self.backdrop_pixbuf
    if src is None:
        return
    cropped = _cover_crop(src, width, height)
    if cropped is None:
        return
    blur = int(mset(self.settings, "mon_bg_blur"))
    if blur > 0:
        # Smooth blur: halve a few times, then double back up (bilinear
        # at 2x steps never shows blocks).
        steps = 1 + (blur + 1) // 2
        w2, h2, cur = width, height, cropped
        sizes = []
        for _i in range(steps):
            sizes.append((w2, h2))
            w2, h2 = max(4, w2 // 2), max(4, h2 // 2)
            cur = cur.scale_simple(w2, h2, GdkPixbuf.InterpType.BILINEAR)
        for (sw, sh) in reversed(sizes):
            cur = cur.scale_simple(sw, sh, GdkPixbuf.InterpType.BILINEAR)
        cropped = cur
    dim = max(0, min(70, int(mset(self.settings, "mon_bg_dim"))))
    if dim > 0:
        out = cropped.copy()
        black = GdkPixbuf.Pixbuf.new(GdkPixbuf.Colorspace.RGB, False, 8,
                                     out.get_width(), out.get_height())
        black.fill(0x000000ff)
        black.composite(out, 0, 0, out.get_width(), out.get_height(),
                        0, 0, 1, 1, GdkPixbuf.InterpType.NEAREST,
                        int(255 * dim / 100.0))
        cropped = out
    self.backdrop_image.set_from_pixbuf(cropped)


_orig_update_backdrop_visibility = AltTVLauncher._update_backdrop_visibility


def _l_update_backdrop_visibility(self):
    if mset(self.settings, "mon_bg_mode") == "dynamic" and \
            getattr(self, "_mon_dyn_pb", None) is not None:
        self.backdrop_image.set_visible(True)
        return
    _orig_update_backdrop_visibility(self)


def _l_mon_dynamic_backdrop(self, pb):
    """Background "Dynamic": the backdrop follows the focused title."""
    if pb is None or mset(self.settings, "mon_bg_mode") != "dynamic":
        return
    if getattr(self, "_mon_static_pb", None) is None:
        self._mon_static_pb = self.backdrop_pixbuf
    self._mon_dyn_pb = pb
    self.backdrop_pixbuf = pb
    self._backdrop_alloc = (0, 0)
    a = self.backdrop_image.get_allocation()
    if a.width > 1:
        self._scale_backdrop(a.width, a.height)
    self._update_backdrop_visibility()


def _mon_restore_static_backdrop(win):
    if getattr(win, "_mon_static_pb", None) is not None:
        win.backdrop_pixbuf = win._mon_static_pb
    win._mon_dyn_pb = None
    win._mon_static_pb = None


# -- Settings -> Appearance: Look & feel, Live TV guide, Trailers -------------
def _p_mon_build_settings(self):
    page = self.stack.get_child_by_name("appearance")
    if page is None:
        return
    win = self.launcher
    st = win.settings

    def save(key, value, relook=True):
        st[key] = value
        save_settings(st)
        if relook:
            aero_apply_look(win)

    def heading(text):
        lab = Gtk.Label()
        lab.set_markup("<b>%s</b>" % _esc(text))
        lab.set_halign(Gtk.Align.START)
        lab.set_margin_top(14)
        page.pack_start(lab, False, False, 0)

    def default_btn(cb):
        b = Gtk.Button(label="Default")
        b.connect("clicked", lambda w: cb())
        return b

    def line(label, widget, reset):
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        lab = Gtk.Label(label=label)
        lab.set_halign(Gtk.Align.START)
        lab.set_size_request(170, -1)
        lab.set_xalign(0)
        row.pack_start(lab, False, False, 0)
        row.pack_start(widget, True, True, 0)
        if reset is not None:
            row.pack_end(default_btn(reset), False, False, 0)
        page.pack_start(row, False, False, 0)
        return row

    heading("Look & feel")
    # Accent colour swatches
    sw_box = Gtk.FlowBox()
    sw_box.set_selection_mode(Gtk.SelectionMode.NONE)
    sw_box.set_max_children_per_line(8)
    sw_box.set_min_children_per_line(4)
    swatches = []

    def mark_on():
        cur = mset(st, "aero_accent")
        for b, hx in swatches:
            ctx = b.get_style_context()
            (ctx.add_class if hx == cur else ctx.remove_class)("on")
    for name, hx in ACCENT_CHOICES:
        b = Gtk.Button()
        b.get_style_context().add_class("mon-swatch")
        b.set_tooltip_text(name)
        prov = Gtk.CssProvider()
        prov.load_from_data(("button { background: %s; }" % hx).encode())
        b.get_style_context().add_provider(
            prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 4)
        b.connect("clicked", lambda w, h=hx: (win.apply_accent(h),
                                              save("aero_accent", h),
                                              mark_on()))
        swatches.append((b, hx))
        sw_box.add(b)
    mark_on()
    line("Accent colour", sw_box,
         lambda: (win.apply_accent("#e50914"),
                  save("aero_accent", MONDAY_DEFAULTS["aero_accent"]),
                  mark_on()))
    # One accent control: the older Red / Blue / Purple combo is folded
    # into the swatches above (it set the same hero / LIVE accent).
    try:
        old = getattr(self, "accent_combo", None)
        if old is not None:
            for c in page.get_children():
                if isinstance(c, Gtk.Label) and c.get_text() in ("Accent colour", tr("Accent colour")):
                    c.set_no_show_all(True)
                    c.hide()
            old.set_no_show_all(True)
            old.hide()
    except Exception:
        pass

    mode = Gtk.ComboBoxText()
    for key, text in (("static", "Static (your backdrop)"),
                      ("dynamic", "Dynamic (follows the focused title)")):
        mode.append(key, text)
    mode.set_active_id(mset(st, "mon_bg_mode"))

    def mode_changed(c):
        v = c.get_active_id() or "static"
        if v != "dynamic":
            _mon_restore_static_backdrop(win)
        save("mon_bg_mode", v)
    mode.connect("changed", mode_changed)
    line("Background", mode,
         lambda: mode.set_active_id(MONDAY_DEFAULTS["mon_bg_mode"]))

    def slider(label, key, lo, hi, step, fmt):
        sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, lo, hi,
                                      step)
        sc.set_value(float(mset(st, key)))
        sc.set_hexpand(True)
        sc.connect("format-value", lambda s, v: fmt % v)
        state = {"id": None}

        def commit():
            state["id"] = None
            save(key, int(round(sc.get_value())))
            return False

        def changed(s):
            if state["id"]:
                GLib.source_remove(state["id"])
            state["id"] = GLib.timeout_add(350, commit)
        sc.connect("value-changed", changed)
        line(label, sc, lambda: sc.set_value(float(MONDAY_DEFAULTS[key])))
        return sc
    self.mon_blur = slider("Background blur", "mon_bg_blur", 0, 10, 1, "%.0f")
    self.mon_dim = slider("Background dim", "mon_bg_dim", 0, 70, 5, "%.0f%%")
    self.mon_opacity = slider("Panel opacity", "mon_panel_opacity", 0, 90, 5,
                              "%.0f%%")

    heading("Live TV guide")
    prev_sw = Gtk.Switch()
    prev_sw.set_active(bool(mset(st, "mon_guide_preview")))
    prev_sw.set_halign(Gtk.Align.START)
    prev_sw.connect("notify::active",
                    lambda s, p: save("mon_guide_preview", s.get_active()))
    line("Preview panel", prev_sw,
         lambda: prev_sw.set_active(MONDAY_DEFAULTS["mon_guide_preview"]))
    size = Gtk.ComboBoxText()
    for key, text in (("small", "Small"), ("medium", "Medium"),
                      ("large", "Large")):
        size.append(key, text)
    size.set_active_id(mset(st, "mon_guide_preview_size"))
    size.connect("changed", lambda c: save("mon_guide_preview_size",
                                           c.get_active_id() or "medium"))
    line("Preview size", size,
         lambda: size.set_active_id(MONDAY_DEFAULTS["mon_guide_preview_size"]))

    heading("Trailers")
    tr_sw = Gtk.Switch()
    tr_sw.set_active(bool(mset(st, "mon_card_trailers")))
    tr_sw.set_halign(Gtk.Align.START)
    tr_sw.connect("notify::active",
                  lambda s, p: save("mon_card_trailers", s.get_active(), False))
    line("Trailer in the card", tr_sw,
         lambda: tr_sw.set_active(MONDAY_DEFAULTS["mon_card_trailers"]))
    hint = Gtk.Label(label="Rest on a movie or show poster for a moment and "
                           "its trailer plays inside the card, muted. The "
                           "Trailer button on a title's page plays it full "
                           "screen with sound.")
    hint.set_line_wrap(True)
    hint.set_xalign(0)
    hint.set_halign(Gtk.Align.START)
    page.pack_start(hint, False, False, 0)


SettingsPanel._mon_build_settings = _p_mon_build_settings
AltTVLauncher._scale_backdrop = _l_scale_backdrop
AltTVLauncher._update_backdrop_visibility = _l_update_backdrop_visibility
AltTVLauncher._mon_dynamic_backdrop = _l_mon_dynamic_backdrop


# -- Live TV guide (StreamOn-style, Aero colours) ----------------------------
def _l_nv_metrics5(self, width):
    """~5 channel rows fill the grid whatever the screen / Interface size."""
    s = UI_SCALE
    chan_w = int(max(150, min(260, _dz(width) * 0.2)) * s)
    gap = int(8 * s)
    vis_h = 0
    try:
        vis_h = self.nv_scroll.get_allocated_height()
    except Exception:
        vis_h = 0
    row_h = int((vis_h - gap) / 5.0 - gap) if vis_h > 100 else int(88 * s)
    row_h = max(int(52 * s), min(int(170 * s), row_h))
    return {"s": s, "chan_w": chan_w, "row_h": row_h, "gap": gap,
            "pad": int(14 * s), "grid_w": max(10, width - chan_w - int(14 * s))}


_orig_build_epg_view_nv = AltTVLauncher.build_epg_view


def _l_build_epg_view_mon(self):
    _orig_build_epg_view_nv(self)
    # "Live TV" heading top-left of the clock column (not "Guide").
    try:
        box = self.epg_clock_label.get_parent()
        head = Gtk.Label(label="Live TV")
        head.get_style_context().add_class("mon-guide-head")
        head.set_halign(Gtk.Align.END)
        box.pack_start(head, False, False, 0)
        box.reorder_child(head, 0)
    except Exception:
        pass
    # Live muted preview inside the panel (behind the LIVE badge and the
    # expand button). Falls back to the channel logo when GStreamer
    # cannot play the stream.
    self.nv_video = AeroVideo(muted=True,
                              on_playing=lambda: self._nv_video_show(True),
                              on_end=lambda: self._nv_video_show(False))
    if self.nv_video.ok:
        w = self.nv_video.widget
        w.set_no_show_all(True)
        w.hide()
        self.nv_prev.add_overlay(w)
        try:
            self.nv_prev.reorder_overlay(w, 0)
        except Exception:
            pass
        w.add_events(Gdk.EventMask.BUTTON_RELEASE_MASK)
        w.connect("button-release-event", lambda *a: self.epg_play_focused())
    self._nv_prev_timer = None
    self._nv_apply_prefs()
    # Scrolled height changes -> row height changes.
    self.nv_scroll.connect("size-allocate", lambda w, a: (
        self.nv_grid.queue_draw(), self._nv_scroll_to_focus()))


def _l_nv_video_show(self, on):
    v = getattr(self, "nv_video", None)
    if v is None or not v.ok:
        return
    if on and getattr(self, "epg_open", False):
        v.widget.show()
    else:
        v.widget.hide()


def _l_nv_apply_prefs(self):
    """Preview panel on/off + size (Settings -> Appearance)."""
    if getattr(self, "nv_prev", None) is None:
        return
    on = bool(mset(self.settings, "mon_guide_preview"))
    self.nv_prev.set_visible(on)
    if not on:
        self._nv_preview_stop()
    self._nv_prev_w = -1
    try:
        a = self.epg_view.get_allocation()
        if a.width > 1:
            self._nv_on_alloc(self.epg_view, a)
    except Exception:
        pass


def _l_nv_on_alloc_mon(self, view, alloc):
    f = GUIDE_PREVIEW_SIZES.get(mset(self.settings, "mon_guide_preview_size"),
                                0.38)
    dw, dh = _dz(alloc.width), _dz(alloc.height)
    pw = int(max(260, min(820, dw * f, dh * (f * 0.72) * 16 / 9)))
    if pw != self._nv_prev_w:
        self._nv_prev_w = pw
        GLib.idle_add(lambda: (self.nv_prev.set_size_request(
            pw, int(pw * 9 / 16)), False)[1])


_orig_epg_update_preview_nv = AltTVLauncher.epg_update_preview


def _l_epg_update_preview_mon(self):
    _orig_epg_update_preview_nv(self)
    if not getattr(self, "epg_open", False) or \
            not mset(self.settings, "mon_guide_preview"):
        return
    if getattr(self, "_nv_prev_timer", None):
        GLib.source_remove(self._nv_prev_timer)
    self._nv_prev_timer = GLib.timeout_add(900, self._nv_preview_start)


def _l_nv_preview_start(self):
    self._nv_prev_timer = None
    v = getattr(self, "nv_video", None)
    if v is None or not v.ok or not getattr(self, "epg_open", False):
        return False
    ch, _p = self._nv_focused()
    url = (ch or {}).get("url") or ""
    if not url or getattr(self, "player_open", False):
        return False
    if v.uri != url:
        self._nv_video_show(False)
        v.play(url)
    return False


def _l_nv_preview_stop(self):
    if getattr(self, "_nv_prev_timer", None):
        GLib.source_remove(self._nv_prev_timer)
        self._nv_prev_timer = None
    v = getattr(self, "nv_video", None)
    if v is not None and v.ok:
        v.stop()
        v.widget.hide()


_orig_epg_play_focused_nv = AltTVLauncher.epg_play_focused
_orig_close_epg = AltTVLauncher.close_epg


def _l_epg_play_focused_mon(self):
    # One IPTV connection at a time: stop the preview first.
    self._nv_preview_stop()
    return _orig_epg_play_focused_nv(self)


def _l_close_epg_mon(self):
    self._nv_preview_stop()
    return _orig_close_epg(self)


_nv_metrics = _l_nv_metrics5          # module-level helper used by the grid
for _n, _f in (("build_epg_view", _l_build_epg_view_mon),
               ("_nv_video_show", _l_nv_video_show),
               ("_nv_apply_prefs", _l_nv_apply_prefs),
               ("_nv_on_alloc", _l_nv_on_alloc_mon),
               ("epg_update_preview", _l_epg_update_preview_mon),
               ("_nv_preview_start", _l_nv_preview_start),
               ("_nv_preview_stop", _l_nv_preview_stop),
               ("epg_play_focused", _l_epg_play_focused_mon),
               ("close_epg", _l_close_epg_mon)):
    setattr(AltTVLauncher, _n, _f)


# -- Live Tiles (animated art) -----------------------------------------------
class LiveTileArt(Gtk.DrawingArea):
    """Slow pan + cross-fade through a few pictures (posters, channel
    logos), with the row name and a LIVE badge. Animates only while
    mapped (and at ~12 fps), so idle rows cost nothing."""

    def __init__(self, title, subtitle_list, art_list, logo_mode=False,
                 live_badge=False):
        super().__init__()
        self.title = title
        self.subs = subtitle_list or [""]
        self.arts = [a for a in (art_list or []) if a][:8]
        self.logo_mode = logo_mode
        self.live_badge = live_badge
        self.pbs = {}
        self.t0 = time.time()
        self.tick_id = None
        self.connect("draw", self._draw)
        self.connect("map", lambda w: self._start())
        self.connect("unmap", lambda w: self._stop())
        for a in self.arts:
            art_load(a, lambda pb, a=a: (self.pbs.__setitem__(a, pb),
                                         self.queue_draw()))

    def _start(self):
        if self.tick_id is None:
            self.tick_id = GLib.timeout_add(80, self._tick)

    def _stop(self):
        if self.tick_id is not None:
            GLib.source_remove(self.tick_id)
            self.tick_id = None

    def _tick(self):
        self.queue_draw()
        return True

    def _paint_pb(self, cr, pb, W, H, prog, alpha):
        if pb is None:
            return
        pw, ph = pb.get_width(), pb.get_height()
        if self.logo_mode:
            sc = min(W * 0.46 / pw, H * 0.5 / ph)
            x = (W - pw * sc) / 2
            y = H * 0.40 - ph * sc / 2
        else:
            sc = max(W / float(pw), H / float(ph)) * (1.08 + 0.06 * prog)
            x = (W - pw * sc) / 2 - (W * 0.04) * (prog - 0.5)
            y = (H - ph * sc) / 2
        cr.save()
        cr.translate(x, y)
        cr.scale(sc, sc)
        Gdk.cairo_set_source_pixbuf(cr, pb, 0, 0)
        cr.paint_with_alpha(alpha)
        cr.restore()

    def _draw(self, w, cr):
        W, H = self.get_allocated_width(), self.get_allocated_height()
        s = UI_SCALE
        _nv_rrect(cr, 0, 0, W, H, 18 * s)
        cr.clip()
        r, g, b = ACCENT
        try:
            import cairo as _c
            grad = _c.LinearGradient(0, 0, W, H)
            grad.add_color_stop_rgb(0, r * 0.35, g * 0.35, b * 0.45)
            grad.add_color_stop_rgb(1, 0.06, 0.08, 0.14)
            cr.set_source(grad)
        except Exception:
            cr.set_source_rgb(0.08, 0.1, 0.16)
        cr.paint()
        n = len(self.arts)
        el = time.time() - self.t0
        per = 5.0
        idx = int(el // per)
        prog = (el % per) / per
        if n:
            cur = self.arts[idx % n]
            self._paint_pb(cr, self.pbs.get(cur), W, H, prog, 1.0)
            if prog > 0.8 and n > 1:
                nxt = self.arts[(idx + 1) % n]
                self._paint_pb(cr, self.pbs.get(nxt), W, H, 0.0,
                               (prog - 0.8) / 0.2)
        try:
            import cairo as _c
            sh = _c.LinearGradient(0, H * 0.45, 0, H)
            sh.add_color_stop_rgba(0, 0, 0, 0, 0)
            sh.add_color_stop_rgba(1, 0, 0, 0, 0.78)
            cr.set_source(sh)
            cr.rectangle(0, 0, W, H)
            cr.fill()
        except Exception:
            pass
        sub = self.subs[idx % len(self.subs)] if self.subs else ""
        _nv_text(cr, self.title, 16 * s, H - 66 * s, W - 32 * s, 26 * s,
                 bold=True)
        _nv_text(cr, sub, 16 * s, H - 34 * s, W - 32 * s, 17 * s,
                 color=(1, 1, 1, 0.85))
        if self.live_badge:
            cr.set_source_rgba(0.88, 0.19, 0.23, 1)
            _nv_rrect(cr, 14 * s, 14 * s, 74 * s, 28 * s, 8 * s)
            cr.fill()
            _nv_text(cr, "● LIVE", 14 * s, 17 * s, 74 * s, 16 * s,
                     bold=True, align_center=True)
        else:
            cr.set_source_rgba(1, 1, 1, 0.9)
            _nv_rrect(cr, 14 * s, 14 * s, 64 * s, 26 * s, 8 * s)
            cr.fill()
            _nv_text(cr, "LIVE TILE", 14 * s, 18 * s, 64 * s, 12 * s,
                     bold=True, color=(0.1, 0.12, 0.18, 1),
                     align_center=True)
        return False


def _mon_live_tile_button(title, subs, arts, w, h, on_click, logo_mode=False,
                          live_badge=False):
    btn = Gtk.Button()
    btn.get_style_context().add_class("live-tile")
    btn.get_style_context().add_class("mon-live-tile")
    btn.set_size_request(w, h)
    art = LiveTileArt(title, subs, arts, logo_mode, live_badge)
    btn.add(art)
    btn.connect("clicked", lambda b: on_click())
    btn._mon_live_tile = True
    return btn


# -- VOD rows (Movies / TV Shows from the IPTV source) -----------------------
def mon_vod_items(kind, limit=40):
    st = iptv_source_state()
    out = []
    for e in (st.get(kind) or [])[:limit]:
        name = e.get("name") or ""
        if not name:
            continue
        det = TITLE_DETAILS.get((kind, name)) or {}
        out.append((name, e.get("group") or "", det))
    return out


def _l_mon_vod_row(self, kind, title, page_cb):
    section = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    tb = Gtk.EventBox()
    tb.add(self.row_title(title))
    tb.connect("button-press-event", lambda w, e: page_cb(w))
    section.pack_start(tb, False, False, 0)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=60)
    items = mon_vod_items(kind)
    if items:
        arts = [d.get("backdrop") or d.get("cover") for _n, _g, d in items]
        row.pack_start(_mon_live_tile_button(
            title, [n for n, _g, _d in items[:8]], arts, 280, 392,
            lambda: page_cb(None)), False, False, 0)
    for name, group, det in items[:30]:
        row.pack_start(self._mon_poster_tile(kind, name, group, det),
                       False, False, 0)
    if not items:
        btn = Gtk.Button()
        btn.get_style_context().add_class("live-tile")
        btn.set_size_request(640, 185)
        lab = Gtk.Label()
        lab.set_line_wrap(True)
        lab.set_justify(Gtk.Justification.CENTER)
        lab.set_markup("<span weight='bold' size='large'>%s</span>\n%s" % (
            _esc(title), _esc("Your IPTV source's %s show up here."
                              % title.lower()) if load_playlists() else
            "Add your IPTV login in Flight Deck -> IPTV"))
        btn.add(lab)
        btn.connect("clicked", lambda w: self.open_panel_page("iptv")
                    if not load_playlists() else page_cb(w))
        row.pack_start(btn, False, False, 0)
    visible = (self.ROW_VISIBLE_COUNT * 280
               + (self.ROW_VISIBLE_COUNT - 1) * 60)
    section.pack_start(self.scrollable_row(row, visible), False, False, 0)
    return section


def _l_mon_poster_tile(self, kind, name, group, det):
    cell = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
    btn = Gtk.Button()
    btn.get_style_context().add_class("poster-tile")
    btn.set_size_request(280, 392)
    ov = Gtk.Overlay()
    img = Gtk.Image()
    lab = Gtk.Label()
    lab.set_markup("<span weight='bold' size='large'>%s</span>" % _esc(name))
    lab.set_line_wrap(True)
    lab.set_max_width_chars(14)
    lab.set_justify(Gtk.Justification.CENTER)
    base = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
    base.pack_start(lab, True, True, 0)
    base.pack_start(img, True, True, 0)
    ov.add(base)
    btn.add(ov)
    btn._title_kind = kind
    btn._title_name = name
    btn._title_meta = group
    btn._mon_det = det
    btn._mon_ov = ov
    cover = det.get("cover")

    def got(pb):
        pw, ph = _px(280), _px(392)
        img.set_from_pixbuf(_round_pb(_cover_crop(pb, pw, ph), _px(28)))
        lab.hide()
        lab.set_no_show_all(True)
    if cover:
        art_load(cover, got)
    btn.connect("clicked", lambda b: self.open_title_detail(kind, name, group))
    btn.connect("focus-in-event", lambda b, e: (self._mon_poster_focus(b),
                                                False)[1])
    btn.connect("focus-out-event", lambda b, e: (self._mon_poster_blur(b),
                                                 False)[1])
    cell.pack_start(btn, False, False, 0)
    nl = Gtk.Label(label=name)
    nl.get_style_context().add_class("app-name")
    nl.set_line_wrap(True)
    nl.set_max_width_chars(28)
    cell.pack_start(nl, False, False, 0)
    return cell


def _l_mon_poster_focus(self, btn):
    det = getattr(btn, "_mon_det", {}) or {}
    art = det.get("backdrop") or det.get("cover")
    kind, name = btn._title_kind, btn._title_name
    # Hero follows focus; Dynamic background follows too.
    self._mon_hero_follow(kind, name, btn._title_meta, det)
    if art:
        art_load(art, lambda pb: self._mon_dynamic_backdrop(pb)
                 if self.get_focus() is btn else None)
    self._mon_trailer_cancel()
    if mset(self.settings, "mon_card_trailers"):
        self._mon_tr_timer = GLib.timeout_add(
            1500, lambda: self._mon_trailer_start(btn))


def _l_mon_poster_blur(self, btn):
    self._mon_trailer_cancel()


def _l_mon_trailer_cancel(self):
    if getattr(self, "_mon_tr_timer", None):
        GLib.source_remove(self._mon_tr_timer)
    self._mon_tr_timer = None
    self._mon_tr_token = getattr(self, "_mon_tr_token", 0) + 1
    cur = getattr(self, "_mon_tr", None)
    self._mon_tr = None
    if cur is not None:
        btn, vid = cur
        vid.stop()
        try:
            btn._mon_ov.remove(vid.widget)
        except Exception:
            pass
        btn.set_size_request(280, 392)
        btn.get_style_context().remove_class("mon-trailer-on")


def _l_mon_trailer_start(self, btn):
    self._mon_tr_timer = None
    token = self._mon_tr_token = getattr(self, "_mon_tr_token", 0) + 1
    kind, name = btn._title_kind, btn._title_name
    year = (getattr(btn, "_mon_det", {}) or {}).get("year", "")

    def work():
        vid = trailer_find(kind, name, year)
        url = trailer_stream_url(vid) if vid else None
        GLib.idle_add(lambda: (self._mon_trailer_show(btn, url, token),
                               False)[1])
    threading.Thread(target=work, daemon=True).start()
    return False


def _l_mon_trailer_show(self, btn, url, token):
    if not url or token != getattr(self, "_mon_tr_token", 0) or \
            self.get_focus() is not btn:
        return
    v = AeroVideo(muted=True, on_end=lambda: self._mon_trailer_cancel())
    if not v.ok:
        return
    v.widget.set_size_request(int(280 * 1.08), int(392 * 1.08))
    btn._mon_ov.add_overlay(v.widget)
    v.widget.show()
    btn.set_size_request(int(280 * 1.08), int(392 * 1.08))
    btn.get_style_context().add_class("mon-trailer-on")
    self._mon_tr = (btn, v)
    v.play(url)


def _l_mon_play_trailer_full(self, kind, name, year=""):
    """Trailer button: the exact YouTube video, full screen in mpv."""
    self._show_toast_safe("Finding the trailer…")

    def work():
        vid = trailer_find(kind, name, year)
        GLib.idle_add(lambda: (self._mon_trailer_full_go(vid, name), False)[1])
    threading.Thread(target=work, daemon=True).start()


def _l_mon_trailer_full_go(self, vid, name):
    if not vid:
        self._show_message("No trailer found",
                           "No trailer was found for %s." % name)
        return
    self._mon_trailer_cancel()
    if not _spawn(["mpv", "--fs", "--force-window=immediate",
                   "--ytdl-format=bestvideo[height<=1080]+bestaudio/best",
                   "https://www.youtube.com/watch?v=" + vid],
                  stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL):
        open_url("https://www.youtube.com/watch?v=" + vid)


def _l_show_toast_safe(self, text):
    try:
        self._voice_status(text)
    except Exception:
        pass


_orig_render_title_detail = AltTVLauncher.render_title_detail


def _l_render_title_detail_mon(self, kind, name, meta):
    _orig_render_title_detail(self, kind, name, meta)
    try:
        top = self.title_detail_content.get_children()[0]
        right = top.get_children()[-1]
        btn = Gtk.Button(label="▶  Trailer")
        btn.get_style_context().add_class("mon-hero-btn")
        btn.set_halign(Gtk.Align.START)
        year = (title_details(kind, name) or {}).get("year", "")
        btn.connect("clicked", lambda w: self._mon_play_trailer_full(
            kind, name, year))
        right.pack_start(btn, False, False, 6)
        right.reorder_child(btn, 1)
        btn.show()
        # The page's poster comes from the IPTV art when no local one.
        det = TITLE_DETAILS.get((kind, name)) or {}
        kids = top.get_children()
        if det.get("cover") and kids and isinstance(kids[0], Gtk.Box):
            holder = kids[0]

            def got(pb):
                for c in holder.get_children():
                    holder.remove(c)
                holder.pack_start(Gtk.Image.new_from_pixbuf(_round_pb(
                    _cover_crop(pb, _px(360), _px(504)), _px(28))),
                    False, False, 0)
                holder.show_all()
            art_load(det["cover"], got)
    except Exception:
        pass


for _n, _f in (("_mon_vod_row", _l_mon_vod_row),
               ("_mon_poster_tile", _l_mon_poster_tile),
               ("_mon_poster_focus", _l_mon_poster_focus),
               ("_mon_poster_blur", _l_mon_poster_blur),
               ("_mon_trailer_cancel", _l_mon_trailer_cancel),
               ("_mon_trailer_start", _l_mon_trailer_start),
               ("_mon_trailer_show", _l_mon_trailer_show),
               ("_mon_play_trailer_full", _l_mon_play_trailer_full),
               ("_mon_trailer_full_go", _l_mon_trailer_full_go),
               ("_show_toast_safe", _l_show_toast_safe),
               ("render_title_detail", _l_render_title_detail_mon),
               ("build_row_movies", lambda self: self._mon_vod_row(
                   "movies", "Movies", self.on_open_movies_page)),
               ("build_row_shows", lambda self: self._mon_vod_row(
                   "shows", "TV Shows", self.on_open_shows_page))):
    setattr(AltTVLauncher, _n, _f)


# Remove demo content: the built-in sample movies / shows (Oppenheimer,
# The Bear, ...) are gone everywhere (pages, search). Movies / Shows come
# only from the IPTV source now; with none set up the rows say so.
MOVIES[:] = []
SHOWS[:] = []
MOVIE_GENRES.clear()


# -- Live TV row: a Live Tile first -------------------------------------------
_orig_build_row_live_mon = AltTVLauncher.build_row_live


def _mon_find_tile_row(widget):
    if isinstance(widget, Gtk.Box) and \
            widget.get_orientation() == Gtk.Orientation.HORIZONTAL:
        for c in widget.get_children():
            if isinstance(c, Gtk.Button) and \
                    c.get_style_context().has_class("live-tile"):
                return widget
    if isinstance(widget, Gtk.Container):
        for c in widget.get_children():
            r = _mon_find_tile_row(c)
            if r is not None:
                return r
    return None


def _l_build_row_live_mon(self):
    section = _orig_build_row_live_mon(self)
    chans = (iptv_source_state().get("channels") or [])[:12]
    if not chans:
        return section
    row = _mon_find_tile_row(section)
    if row is None:
        return section
    tile = _mon_live_tile_button(
        "Live TV", [c.get("name") or "" for c in chans],
        [c.get("logo") for c in chans], 302, 185,
        lambda: self.open_epg(), logo_mode=True, live_badge=True)
    row.pack_start(tile, False, False, 0)
    row.reorder_child(tile, 0)
    return section


# -- Hero: 6-dot carousel, full + split slides, follows focus -----------------
HERO_ROTATE_S = 9


def _steam_hero_art(appid):
    for root in STEAM_ROOTS:
        base = root / "appcache" / "librarycache"
        for cand in (base / ("%d_library_hero.jpg" % appid),
                     base / str(appid) / "library_hero.jpg"):
            if cand.is_file():
                return str(cand)
    p = steam_cover_path(appid)
    return str(p) if p else None


def mon_hero_candidates():
    """Up to 5 featured slides: IPTV movies / shows with art and installed
    Steam games, interleaved. Never demo titles."""
    movies = [("movies", n, g, d) for n, g, d in mon_vod_items("movies", 80)
              if d.get("backdrop") or d.get("cover")][:6]
    shows = [("shows", n, g, d) for n, g, d in mon_vod_items("shows", 80)
             if d.get("backdrop") or d.get("cover")][:6]
    games = []
    try:
        for name, meta in games_row_items():
            if meta.get("installed") and meta.get("appid"):
                art = _steam_hero_art(int(meta["appid"]))
                if art:
                    games.append(("games", name, meta, {"backdrop": art}))
    except Exception:
        pass
    out = []
    pools = [movies, shows, games[:4]]
    while len(out) < 5 and any(pools):
        for pool in pools:
            if pool and len(out) < 5:
                out.append(pool.pop(0))
    return out


class _ArtArea(Gtk.DrawingArea):
    """Paints one picture cover-cropped with rounded corners; asks for no
    size, so the hero layout (full / split) stays exactly as designed."""

    def __init__(self, radius=30):
        super().__init__()
        self.pb = None
        self.radius = radius
        self.set_hexpand(True)
        self.set_vexpand(True)
        self.connect("draw", self._draw)

    def set_pixbuf(self, pb):
        self.pb = pb
        self.queue_draw()

    def _draw(self, w, cr):
        if self.pb is None:
            return False
        W, H = self.get_allocated_width(), self.get_allocated_height()
        pw, ph = self.pb.get_width(), self.pb.get_height()
        sc = max(W / float(pw), H / float(ph))
        _nv_rrect(cr, 0, 0, W, H, self.radius * UI_SCALE)
        cr.clip()
        cr.translate((W - pw * sc) / 2, (H - ph * sc) / 2)
        cr.scale(sc, sc)
        Gdk.cairo_set_source_pixbuf(cr, self.pb, 0, 0)
        cr.paint()
        return False


def _l_mon_hero_slide(self, kind, name, meta, det, layout):
    """One featured slide. layout "full": art fills the hero, service +
    title + button on the left (no synopsis). "split": text panel left
    (service, title, synopsis, button), art on the right."""
    service = {"movies": "IPTV · MOVIE", "shows": "IPTV · SERIES",
               "games": "STEAM"}.get(kind, "AERO")
    art_src = det.get("backdrop") or det.get("cover")
    art = _ArtArea()
    if art_src:
        art_load(art_src, art.set_pixbuf)

    def act(*a):
        if kind == "games":
            self.on_open_game(None, name, meta)
        else:
            self.open_title_detail(kind, name, meta if isinstance(meta, str)
                                   else "")
    btn = Gtk.Button(label="▶  Play" if kind == "games" else "ⓘ  Details")
    btn.get_style_context().add_class("mon-hero-btn")
    btn.set_halign(Gtk.Align.START)
    btn.connect("clicked", act)
    srv = Gtk.Label(label=service)
    srv.get_style_context().add_class("mon-hero-service")
    srv.set_halign(Gtk.Align.START)
    ttl = Gtk.Label(label=name)
    ttl.get_style_context().add_class("mon-hero-title")
    ttl.set_halign(Gtk.Align.START)
    ttl.set_line_wrap(True)
    ttl.set_max_width_chars(22)
    ttl.set_lines(2)
    ttl.set_ellipsize(3)
    ttl.set_xalign(0)
    if layout == "full":
        ov = Gtk.Overlay()
        ov.add(art)
        txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        txt.set_valign(Gtk.Align.END)
        txt.set_halign(Gtk.Align.START)
        txt.set_margin_start(40)
        txt.set_margin_bottom(36)
        for w in (srv, ttl, btn):
            txt.pack_start(w, False, False, 0)
        ov.add_overlay(txt)
        root = ov
    else:
        root = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=24)
        root.set_homogeneous(True)
        txt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        txt.set_margin_start(30)
        txt.set_valign(Gtk.Align.CENTER)
        syn = Gtk.Label(label=(det.get("plot") or "")[:260])
        syn.get_style_context().add_class("mon-hero-sub")
        syn.set_line_wrap(True)
        syn.set_max_width_chars(48)
        syn.set_lines(4)
        syn.set_ellipsize(3)
        syn.set_xalign(0)
        syn.set_halign(Gtk.Align.START)
        for w in (srv, ttl, syn, btn):
            txt.pack_start(w, False, False, 0)
        root.pack_start(txt, True, True, 0)
        root.pack_start(art, True, True, 0)
    return root


_orig_build_hero_mon = AltTVLauncher.build_hero


def _l_build_hero_mon(self):
    _orig_build_hero_mon(self)
    hero = self.hero_card
    slide1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=0)
    for k in hero.get_children():
        expand, fill, pad, _pt = hero.query_child_packing(k)
        hero.remove(k)
        slide1.pack_start(k, expand, fill, pad)
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
    stack = Gtk.Stack()
    stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
    stack.set_transition_duration(600)
    stack.set_homogeneous(True)
    slide1.show_all()
    stack.add_named(slide1, "s0")
    col.pack_start(stack, True, True, 0)
    dots = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    dots.set_halign(Gtk.Align.CENTER)
    dots.set_margin_bottom(12)
    dots.set_margin_top(4)
    col.pack_start(dots, False, False, 0)
    hero.pack_start(col, True, True, 0)
    col.show_all()
    self._mon_stack = stack
    self._mon_dots = dots
    self._mon_slide_i = 0
    self._mon_hold_until = 0
    self._mon_refresh_hero()
    if getattr(self, "_mon_rot_id", None):
        GLib.source_remove(self._mon_rot_id)
    self._mon_rot_id = GLib.timeout_add_seconds(HERO_ROTATE_S,
                                                self._mon_hero_rotate)


def _l_mon_refresh_hero(self):
    stack = getattr(self, "_mon_stack", None)
    if stack is None:
        return
    for c in stack.get_children():
        if stack.child_get_property(c, "name") != "s0":
            stack.remove(c)
            c.destroy()
    cands = mon_hero_candidates()
    for i, (kind, name, meta, det) in enumerate(cands):
        layout = "full" if i % 2 == 0 else "split"
        sl = self._mon_hero_slide(kind, name, meta, det, layout)
        sl.show_all()
        stack.add_named(sl, "s%d" % (i + 1))
    self._mon_n = 1 + len(cands)
    for c in self._mon_dots.get_children():
        self._mon_dots.remove(c)
    self._mon_dot_btns = []
    for i in range(self._mon_n):
        d = Gtk.Button()
        d.get_style_context().add_class("mon-dot")
        d.set_can_focus(False)
        d.connect("clicked", lambda w, i=i: self._mon_hero_show(i, True))
        self._mon_dots.pack_start(d, False, False, 0)
        self._mon_dot_btns.append(d)
    self._mon_dots.set_visible(self._mon_n > 1)
    self._mon_dots.show_all()
    self._mon_hero_show(min(self._mon_slide_i, self._mon_n - 1))


def _l_mon_hero_show(self, i, user=False):
    self._mon_slide_i = i
    self._mon_stack.set_visible_child_name("s%d" % i)
    for j, d in enumerate(getattr(self, "_mon_dot_btns", [])):
        ctx = d.get_style_context()
        (ctx.add_class if j == i else ctx.remove_class)("on")
    if user:
        self._mon_hold_until = time.time() + 20


def _l_mon_hero_rotate(self):
    if getattr(self, "_aero_dead", False):
        return False
    if time.time() < getattr(self, "_mon_hold_until", 0) or \
            getattr(self, "_mon_tr", None) is not None or \
            getattr(self, "_mon_n", 1) < 2:
        return True
    self._mon_hero_show((self._mon_slide_i + 1) % self._mon_n)
    return True


def _l_mon_hero_follow(self, kind, name, meta, det):
    """Hero follows the focused poster (a full slide for that title)."""
    stack = getattr(self, "_mon_stack", None)
    if stack is None or not (det.get("backdrop") or det.get("cover")):
        return
    old = stack.get_child_by_name("focus")
    sl = self._mon_hero_slide(kind, name, meta, det, "full")
    sl.show_all()
    stack.add_named(sl, "focus")
    stack.set_visible_child(sl)
    if old is not None:
        GLib.timeout_add(700, lambda: (stack.remove(old) if old.get_parent()
                                       else None, old.destroy(), False)[2])
    for d in getattr(self, "_mon_dot_btns", []):
        d.get_style_context().remove_class("on")
    self._mon_hold_until = time.time() + 15


_orig_iptv_landed_mon = AltTVLauncher._iptv_landed


def _l_iptv_landed_mon(self, state):
    _orig_iptv_landed_mon(self, state)
    if getattr(self, "_aero_dead", False):
        return
    try:
        self._mon_refresh_hero()
    except Exception:
        pass


for _n, _f in (("build_row_live", _l_build_row_live_mon),
               ("_mon_hero_slide", _l_mon_hero_slide),
               ("build_hero", _l_build_hero_mon),
               ("_mon_refresh_hero", _l_mon_refresh_hero),
               ("_mon_hero_show", _l_mon_hero_show),
               ("_mon_hero_rotate", _l_mon_hero_rotate),
               ("_mon_hero_follow", _l_mon_hero_follow),
               ("_iptv_landed", _l_iptv_landed_mon)):
    setattr(AltTVLauncher, _n, _f)


# -- Aero Start menu (A button, opposite Wingman) -----------------------------
def _l_mon_start_button(self):
    btn = Gtk.Button()
    btn.get_style_context().add_class("ask-nova-btn")
    btn.get_style_context().add_class("mon-start-btn")
    inner = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
    try:
        # The real Aero symbol (A + orbit swish), same size as the
        # Wingman helmet so the bar buttons match.
        mark = self.mark_image("aero-a-blue.png", "#2b6fe3", size=22)
    except Exception:
        mark = Gtk.Label(label="A")
    inner.pack_start(mark, False, False, 0)
    lab = Gtk.Label(label="Apps")
    lab.get_style_context().add_class("wingman-label")
    inner.pack_start(lab, False, False, 0)
    inner.set_halign(Gtk.Align.CENTER)
    btn.add(inner)
    btn.set_tooltip_text("Aero Start menu: Linux Apps / Droid Apps")
    btn.connect("clicked", lambda w: self.mon_open_start_menu())
    self.mon_start_btn = btn
    return btn


def _l_mon_open_start_menu(self):
    btn = self.mon_start_btn
    pop = Gtk.Popover.new(btn)
    pop.set_position(Gtk.PositionType.BOTTOM)
    pop.get_style_context().add_class("mon-start")
    a = self.get_allocation()
    sc = Gtk.ScrolledWindow()
    sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sc.set_propagate_natural_height(True)
    sc.set_min_content_width(min(_dz(a.width) * 0.8, 980) if a.width > 1
                             else 900)
    maxh = int(a.height * 0.72) if a.height > 1 else 560
    sc.set_max_content_height(maxh)
    sc.set_min_content_height(min(maxh, int(a.height * 0.55)) if a.height > 1
                              else 420)
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
    box.set_margin_start(8)
    box.set_margin_end(8)
    apps = assemble_apps()
    linux = [x for x in apps if x["kind"] in ("linux", "web")]
    droid = [x for x in apps if x["kind"] == "android"]
    first = None
    flows = []
    search = Gtk.SearchEntry()
    search.set_placeholder_text("Search apps")
    search.get_style_context().add_class("mon-start-search")
    for head, items in (("Linux Apps", linux), ("Droid Apps", droid)):
        h = Gtk.Label(label=head)
        h.get_style_context().add_class("mon-start-head")
        h.set_halign(Gtk.Align.START)
        box.pack_start(h, False, False, 4)
        flow = Gtk.FlowBox()
        flow.set_selection_mode(Gtk.SelectionMode.NONE)
        flow.set_max_children_per_line(6)
        flow.set_min_children_per_line(3)
        flow.set_homogeneous(True)
        flow.set_column_spacing(12)
        flow.set_row_spacing(12)
        for app in items:
            b = Gtk.Button()
            b.get_style_context().add_class("mon-start-item")
            v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            icon = None
            try:
                icon = self.load_app_icon(app["name"], app["target"],
                                          app["kind"], width=112, height=80,
                                          icon_name=app.get("icon", ""))
            except Exception:
                icon = None
            if icon is not None:
                v.pack_start(CoverImage(icon, 112, 80), False, False, 0)
            else:
                ll = Gtk.Label()
                ll.set_markup("<span size='xx-large' weight='bold' "
                              "color='%s'>%s</span>" % (
                                  _esc(app.get("colour") or "#2b6fe3"),
                                  _esc(app.get("letter") or "?")))
                ll.set_size_request(112, 80)
                v.pack_start(ll, False, False, 0)
            nl = Gtk.Label(label=app["name"])
            nl.get_style_context().add_class("mon-start-name")
            nl.set_ellipsize(3)
            nl.set_max_width_chars(14)
            v.pack_start(nl, False, False, 0)
            b.add(v)
            b._mon_name = app["name"].lower()
            b.connect("clicked", lambda w, ap=app: (
                pop.popdown(), self.on_open_app(
                    w, ap["kind"], ap["target"], ap["fallback"], ap["name"])))
            flow.add(b)
            first = first or b
        if not items:
            e = Gtk.Label(label="Nothing here yet." if head == "Linux Apps"
                          else "Android apps you install (Aurora Store, "
                               "Downloader) show up here.")
            e.set_halign(Gtk.Align.START)
            box.pack_start(e, False, False, 0)
        else:
            box.pack_start(flow, False, False, 0)
            flows.append(flow)

    def match(child):
        q = search.get_text().strip().lower()
        b = child.get_child()
        return not q or q in getattr(b, "_mon_name", "")
    for f in flows:
        f.set_filter_func(match)
    search.connect("search-changed",
                   lambda e: [f.invalidate_filter() for f in flows])
    sc.add(box)
    outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
    search.set_margin_start(8)
    search.set_margin_end(8)
    search.set_margin_top(6)
    outer.pack_start(search, False, False, 0)
    outer.pack_start(sc, True, True, 0)
    pop.add(outer)
    pop.show_all()
    pop.popup()
    if first is not None:
        GLib.idle_add(lambda: (first.grab_focus(), False)[1])
    self.mon_start_pop = pop


_orig_nav_bar_open = AltTVLauncher._nav_bar_open


def _l_nav_bar_open_mon(self, widget, event):
    try:
        b = self.mon_start_btn
        pos = b.translate_coordinates(widget, 0, 0)
        al = b.get_allocation()
        if pos is not None and pos[0] <= event.x < pos[0] + al.width and \
                pos[1] <= event.y < pos[1] + al.height:
            return False      # the Start button handles its own click
    except Exception:
        pass
    return _orig_nav_bar_open(self, widget, event)


# -- App tiles: long-press / right-click menu, Remove from home ---------------
_orig_options_for_app = AltTVLauncher.options_for_app
_orig_on_option_chosen = AltTVLauncher.on_option_chosen
_orig_build_row_apps = AltTVLauncher.build_row_apps


def _l_options_for_app_mon(self, app):
    opts = list(_orig_options_for_app(self, app))
    i = 1 if opts and opts[0][1] == "move" else 0
    opts.insert(i, ("Remove from home", "remove"))
    return opts


def _l_on_option_chosen_mon(self, widget, action):
    if action != "remove":
        return _orig_on_option_chosen(self, widget, action)
    app = self.options_app
    self.close_options_panel(restore=False)
    if app is None:
        return
    hidden = list(load_apps_hidden())
    if app["key"] not in hidden:
        hidden.append(app["key"])
        save_apps_hidden(hidden)
    try:
        play_ui_sound("click")
    except Exception:
        pass
    GLib.idle_add(lambda: (self.build_rows(), False)[1])


def _l_build_row_apps_mon(self):
    section = _orig_build_row_apps(self)
    for btn in getattr(self, "app_tile_buttons", []):
        g = Gtk.GestureLongPress.new(btn)
        g.set_propagation_phase(Gtk.PropagationPhase.CAPTURE)
        g.set_touch_only(False)

        def pressed(gest, x, y, b=btn):
            gest.set_state(Gtk.EventSequenceState.CLAIMED)
            self.open_options_panel(b._app, b)
        g.connect("pressed", pressed)
        btn._mon_lp = g
        btn.connect("button-press-event", lambda b, e: (
            self.open_options_panel(b._app, b), True)[1]
            if e.button == 3 else False)
    return section


# -- Remote (G10S etc.): Play/Pause, Home, Search/voice ------------------------
_orig_on_key_mon = AltTVLauncher.on_key
_VOICE_KEYS = {getattr(Gdk, n) for n in ("KEY_Search", "KEY_Voice",
                                         "KEY_AudioMicMute")
               if hasattr(Gdk, n)}


def _l_on_key_mon(self, widget, event):
    k = event.keyval
    play_keys = {getattr(Gdk, n) for n in ("KEY_AudioPlay", "KEY_AudioPause",
                                           "KEY_AudioMedia") if hasattr(Gdk, n)}
    if k in play_keys:
        if getattr(self, "player_open", False):
            self.player_toggle_pause()
            return True
        return False
    if k == getattr(Gdk, "KEY_HomePage", -1):
        try:
            if getattr(self, "epg_open", False):
                self.close_epg()
            if self.panel_open:
                self.close_settings_panel()
        except Exception:
            pass
        self.back_to_aero()
        return True
    if k in _VOICE_KEYS and not self.kb_visible:
        self.on_voice_button()
        return True
    return _orig_on_key_mon(self, widget, event)


def _l_on_voice_button_mon(self):
    """Remote mic / Search key: Aero voice search (Navigator + dictation
    from the default microphone -- the G10S USB dongle mic is made the
    default source by WirePlumber). Finds channels, apps and titles."""
    try:
        if self.panel_open:
            self.close_settings_panel()
        if getattr(self, "epg_open", False):
            self.close_epg()
        self.show_keyboard(self.search_entry)
        GLib.timeout_add(300, lambda: (self.kb.toggle_dictation(), False)[1])
    except Exception:
        pass


# -- Cloud gaming row: native apps first, Chrome web apps as fallback ---------
CLOUD_LAUNCH = {
    "GeForce Now": "aero-gfn",
    "Boosteroid": "aero-boosteroid",
    "Xbox Cloud Gaming": "aero-webapp xbox",
    "Amazon Luna": "aero-webapp luna",
}


def _l_on_open_cloud_mon(self, widget, name, url):
    cmd = CLOUD_LAUNCH.get(name)
    if cmd and _spawn(cmd.split()):
        return
    open_url(url)


_orig_stage1_install_mon = AltTVLauncher._stage1_install


def _l_stage1_install_mon(self):
    _orig_stage1_install_mon(self)
    aero_apply_look(self)
    try:
        import signal
        global _SIGUSR2_SRC
        if _SIGUSR2_SRC:
            GLib.source_remove(_SIGUSR2_SRC)
        _SIGUSR2_SRC = GLib.unix_signal_add(
            GLib.PRIORITY_DEFAULT, signal.SIGUSR2,
            lambda: (self.present(), self.on_voice_button(), True)[2])
    except Exception:
        pass


for _n, _f in (("_mon_start_button", _l_mon_start_button),
               ("mon_open_start_menu", _l_mon_open_start_menu),
               ("_nav_bar_open", _l_nav_bar_open_mon),
               ("options_for_app", _l_options_for_app_mon),
               ("on_option_chosen", _l_on_option_chosen_mon),
               ("build_row_apps", _l_build_row_apps_mon),
               ("on_key", _l_on_key_mon),
               ("on_voice_button", _l_on_voice_button_mon),
               ("on_open_cloud", _l_on_open_cloud_mon),
               ("_stage1_install", _l_stage1_install_mon)):
    setattr(AltTVLauncher, _n, _f)


# ===========================================================================
# Aero OS Monday Night (2): docked / floating keyboard
# ===========================================================================
# Centred (default, Andrew Nov 23 6:58 PM): the full key grid pops up in
# the middle of the screen; the panel being typed in moves above it.
# Search boxes get the Fire TV-style search keyboard instead (query and
# live results inside the keyboard panel) -- see popup_for.
# Docked: full-width bar at the bottom like the Steam Deck
# keyboard, keys fitted (centred, never stretched past ~1400 px design),
# height adjustable (drag the top bar or use the ▲ ▼ keys), and the panel
# being typed in moves up so the field stays visible.
# Floating: a small keyboard you drag by its top bar and resize from the
# corner; it remembers its size and place. The ⇱ / ⇲ key switches modes.
# Fields in other windows (reader, dialogs) keep the old drop-down.
MONDAY_DEFAULTS.update({"kb_mode": "centered", "kb_dock_frac": 0.40,
                        "kb_float_x": -1, "kb_float_y": -1,
                        "kb_float_w": 0})

_OrigEntryKeyboard = EntryKeyboard


def _R(v):
    """Real px (from allocations / getters) -> design px for the setters,
    which scale by UI_SCALE themselves."""
    try:
        return _dz(v) if v > 0 else v
    except Exception:
        return v


class DockKeyboard(_OrigEntryKeyboard):

    def __init__(self, launcher):
        super().__init__(launcher)
        self.card = self.get_child()
        self._lifted = None          # (widget, old margin_bottom)
        self._in_host = False
        host = Gtk.EventBox()
        host.get_style_context().add_class("mon-kb-host")
        host.set_no_show_all(True)
        host.connect("key-press-event", self._on_key)
        col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.get_style_context().add_class("mon-kb-bar")
        self.grip = Gtk.EventBox()
        gl = Gtk.Label(label="⠿  " + tr("Keyboard"))
        gl.get_style_context().add_class("mon-kb-grip")
        self.grip.add(gl)
        bar.pack_start(self.grip, True, True, 0)
        self.up_btn = Gtk.Button(label="▲")
        self.down_btn = Gtk.Button(label="▼")
        self.mode_btn = Gtk.Button()
        hide_btn = Gtk.Button(label=tr("Hide") + " ▾")
        for b in (self.up_btn, self.down_btn, self.mode_btn, hide_btn):
            b.get_style_context().add_class("mon-kb-tool")
            b.set_can_focus(True)
            bar.pack_end(b, False, False, 0)
        hide_btn.connect("clicked", lambda b: self.popdown())
        self.mode_btn.connect("clicked", lambda b: self.toggle_mode())
        self.up_btn.connect("clicked", lambda b: self._bump_height(+0.05))
        self.down_btn.connect("clicked", lambda b: self._bump_height(-0.05))
        col.pack_start(bar, False, False, 0)
        self.slot = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        col.pack_start(self.slot, True, True, 0)
        self.resize = Gtk.EventBox()
        rl = Gtk.Label(label="◢")
        rl.get_style_context().add_class("mon-kb-resize")
        self.resize.add(rl)
        self.resize.set_halign(Gtk.Align.END)
        col.pack_start(self.resize, False, False, 0)
        host.add(col)
        self.host = host
        self._col = col
        # Drag (move / docked height) and resize gestures.
        self._g_move = Gtk.GestureDrag.new(self.grip)
        self._g_move.connect("drag-begin", self._drag_begin)
        self._g_move.connect("drag-update", self._drag_update)
        self._g_move.connect("drag-end", lambda g, x, y: save_settings(
            self.launcher.settings))
        self._g_size = Gtk.GestureDrag.new(self.resize)
        self._g_size.connect("drag-begin", self._size_begin)
        self._g_size.connect("drag-update", self._size_update)
        self._g_size.connect("drag-end", lambda g, x, y: save_settings(
            self.launcher.settings))

    # -- mode / geometry -----------------------------------------------------
    def mode(self):
        m = mset(self.launcher.settings, "kb_mode")
        return m if m in ("centered", "docked", "floating") else "centered"

    def _win(self):
        a = self.launcher.get_allocation()
        return max(a.width, 320), max(a.height, 240)

    def _apply_geometry(self):
        W, H = self._win()
        st = self.launcher.settings
        mode = self.mode()
        nxt = {"centered": "⇲ " + tr("Dock"), "docked": "⇱ " + tr("Float"),
               "floating": "⊡ " + tr("Centre")}[mode]
        if mode == "centered":
            w = min(W - 24, int(W * 0.72), int(1400 * UI_SCALE))
            h = int(H * 0.50)
            self.host.set_halign(Gtk.Align.CENTER)
            self.host.set_valign(Gtk.Align.CENTER)
            self.host.set_margin_start(0)
            self.host.set_margin_top(0)
            self.host.set_size_request(_R(w), _R(h))
            self.card.set_size_request(-1, -1)
            self.card.set_halign(Gtk.Align.FILL)
            self.up_btn.hide()
            self.down_btn.hide()
            self.resize.hide()
            ctx = self.host.get_style_context()
            ctx.add_class("mon-kb-floating")
            ctx.remove_class("mon-kb-docked")
            # the panel being typed in sits above the keyboard
            self._dock_h = (H + h) // 2
        elif mode == "docked":
            h = int(H * max(0.25, min(0.6, float(mset(st, "kb_dock_frac")))))
            self.host.set_halign(Gtk.Align.FILL)
            self.host.set_valign(Gtk.Align.END)
            self.host.set_margin_start(0)
            self.host.set_margin_top(0)
            self.host.set_size_request(-1, _R(h))
            self.card.set_size_request(_R(min(W - 24, int(1400 * UI_SCALE))), -1)
            self.card.set_halign(Gtk.Align.CENTER)
            self.up_btn.show()
            self.down_btn.show()
            self.resize.hide()
            self.host.get_style_context().add_class("mon-kb-docked")
            self.host.get_style_context().remove_class("mon-kb-floating")
            self._dock_h = h
        else:
            w = int(st.get("kb_float_w") or 0) or int(W * 0.48)
            w = max(360, min(W, w))
            x, y = int(st.get("kb_float_x", -1)), int(st.get("kb_float_y", -1))
            if x < 0 or y < 0:
                x, y = (W - w) // 2, int(H * 0.40)
            x = max(0, min(W - 120, x))
            y = max(0, min(H - 80, y))
            self.host.set_halign(Gtk.Align.START)
            self.host.set_valign(Gtk.Align.START)
            self.host.set_margin_start(_R(x))
            self.host.set_margin_top(_R(y))
            self.host.set_size_request(_R(w), -1)
            self.card.set_size_request(-1, -1)
            self.card.set_halign(Gtk.Align.FILL)
            self.up_btn.hide()
            self.down_btn.hide()
            self.resize.show_all()
            self.host.get_style_context().add_class("mon-kb-floating")
            self.host.get_style_context().remove_class("mon-kb-docked")
            self._dock_h = 0
        self.mode_btn.set_label(nxt)
        homog = mode in ("docked", "centered")
        self.grid.set_row_homogeneous(homog)
        self.grid.set_vexpand(homog)

    def toggle_mode(self):
        self.launcher.settings["kb_mode"] = {
            "centered": "docked", "docked": "floating",
            "floating": "centered"}[self.mode()]
        save_settings(self.launcher.settings)
        if self.is_open() and self.entry is not None:
            e = self.entry
            self.popdown()
            self.popup_for(e)

    def _bump_height(self, d):
        st = self.launcher.settings
        st["kb_dock_frac"] = round(max(0.25, min(0.6, float(
            mset(st, "kb_dock_frac")) + d)), 2)
        save_settings(st)
        self._apply_geometry()
        self._lift()

    def _drag_begin(self, g, x, y):
        self._d0 = (self.host.get_margin_start(), self.host.get_margin_top(),
                    float(mset(self.launcher.settings, "kb_dock_frac")))

    def _drag_update(self, g, dx, dy):
        W, H = self._win()
        st = self.launcher.settings
        x0, y0, f0 = getattr(self, "_d0", (0, 0, 0.4))
        if self.mode() == "docked":
            st["kb_dock_frac"] = round(max(0.25, min(0.6, f0 - dy / H)), 3)
            self._apply_geometry()
            self._lift()
        else:
            st["kb_float_x"] = int(max(0, min(W - 120, x0 + dx)))
            st["kb_float_y"] = int(max(0, min(H - 80, y0 + dy)))
            self.host.set_margin_start(_R(st["kb_float_x"]))
            self.host.set_margin_top(_R(st["kb_float_y"]))

    def _size_begin(self, g, x, y):
        self._s0 = self.host.get_allocated_width()

    def _size_update(self, g, dx, dy):
        W, _H = self._win()
        st = self.launcher.settings
        st["kb_float_w"] = int(max(360, min(W, getattr(self, "_s0", 600) + dx)))
        self.host.set_size_request(_R(st["kb_float_w"]), -1)

    # -- the panel being typed in moves up ------------------------------------
    def _overlay_child_of(self, w):
        ov = self.launcher.overlay
        while w is not None and w.get_parent() is not None:
            if w.get_parent() is ov:
                return w
            w = w.get_parent()
        return None

    def _unlift(self):
        if self._lifted is not None:
            w, old = self._lifted[0], self._lifted[1]
            try:
                w.set_margin_bottom(_R(old))
            except Exception:
                pass
        self._unshrink()
        self._lifted = None

    def _unshrink(self):
        for wd, req in getattr(self, "_shrunk", []):
            try:
                wd.set_size_request(*[_R(v) for v in req])
            except Exception:
                pass
        self._shrunk = []

    def _lift(self):
        e = self.entry
        h = getattr(self, "_dock_h", 0)
        if h and self.host.get_visible() and self.mode() == "docked":
            h = max(h, self.host.get_allocated_height())
        if e is None:
            return
        top = self._overlay_child_of(e)
        if self._lifted is not None and self._lifted[0] is not top:
            self._unlift()
        if top is not None and top is not getattr(self.launcher, "main", None):
            if self._lifted is None:
                self._lifted = (top, top.get_margin_bottom())
            top.set_margin_bottom(_R(self._lifted[1] + h))
            # Never push the panel's top off the screen: shrink it (its
            # content scrolls) so it fits above the keyboard.
            _W, H = self._win()
            room = max(160, H - h - self._lifted[1] - top.get_margin_top() - 8)
            self._unshrink()
            if h:
                ws = [top]
                if isinstance(top, Gtk.Bin) and top.get_child() is not None:
                    ws.append(top.get_child())
                for wd in ws:
                    rw, rh = wd.get_size_request()
                    if rh > room or (wd is top and
                                     top.get_allocated_height() > room):
                        self._shrunk.append((wd, (rw, rh)))
                        wd.set_size_request(_R(rw), _R(room))
        GLib.timeout_add(260, self._scroll_entry_into_view)

    def _scroll_entry_into_view(self):
        e = self.entry
        if e is None:
            return False
        p = e.get_parent()
        while p is not None and not isinstance(p, Gtk.ScrolledWindow):
            p = p.get_parent()
        if p is None:
            return False
        try:
            child = p.get_child()
            r = e.translate_coordinates(child, 0, 0)
            if r is None:
                return False
            y = r[1]
            adj = p.get_vadjustment()
            page = adj.get_page_size()
            if y < adj.get_value() or y + e.get_allocated_height() > \
                    adj.get_value() + page:
                adj.set_value(max(0, min(adj.get_upper() - page,
                                         y - page / 3)))
        except Exception:
            pass
        return False

    # -- show / hide -------------------------------------------------------
    def _move_card_to_host(self):
        if self._in_host:
            return
        if self.card.get_parent() is self:
            self.remove(self.card)
        self.slot.pack_start(self.card, True, True, 0)
        self._in_host = True

    def _move_card_to_popover(self):
        if not self._in_host:
            return
        self.slot.remove(self.card)
        self.add(self.card)
        self._in_host = False

    def popup_for(self, entry):
        if entry is None:
            return
        if entry.get_toplevel() is not self.launcher:
            self.host.hide()
            self._move_card_to_popover()
            return super().popup_for(entry)
        self.entry = entry
        self._move_card_to_host()
        ov = self.launcher.overlay
        if self.host.get_parent() is ov:
            ov.remove(self.host)
        ov.add_overlay(self.host)
        try:
            ov.set_overlay_pass_through(self.host, False)
        except Exception:
            pass
        self._apply_geometry()
        self.host.show()
        self._col.show()
        for wdg in self._col.get_children():
            wdg.show_all()
        self.voice_label.set_visible(bool(self.voice_label.get_text()))
        docked = self.mode() == "docked"
        self.resize.set_visible(self.mode() == "floating")
        self.up_btn.set_visible(docked)
        self.down_btn.set_visible(docked)
        self._lift()
        # once the keyboard has its real height, fit the panel to it
        GLib.timeout_add(220, lambda: (self._lift()
                                       if self.host.get_visible() else None,
                                       False)[1])
        if self.first_key is not None:
            self.first_key.grab_focus()

    def popdown(self):
        if self._in_host:
            was = self.host.get_visible()
            self.host.hide()
            self._unlift()
            if was:
                self._on_closed(self)
            return
        super().popdown()

    def is_open(self):
        return self.host.get_visible() or super().is_open()


EntryKeyboard = DockKeyboard


def _l_build_keyboard_page_mon(self):
    _orig_build_keyboard_page(self)
    page = self.stack.get_child_by_name("keyboard")
    if page is None:
        return
    st = self.launcher.settings
    head = Gtk.Label(label=tr("Keyboard style"))
    head.set_halign(Gtk.Align.START)
    head.get_style_context().add_class("mon-set-head")
    page.pack_start(head, False, False, 6)
    row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    rb_c = Gtk.RadioButton.new_with_label_from_widget(
        None, tr("Centred (full keys, middle of the screen)"))
    rb_d = Gtk.RadioButton.new_with_label_from_widget(
        rb_c, tr("Docked (full width at the bottom)"))
    rb_f = Gtk.RadioButton.new_with_label_from_widget(
        rb_d, tr("Floating (drag and resize)"))
    cur = mset(st, "kb_mode")
    {"floating": rb_f, "docked": rb_d}.get(cur, rb_c).set_active(True)

    def setm(rb, m):
        if rb.get_active():
            st["kb_mode"] = m
            save_settings(st)
    rb_c.connect("toggled", setm, "centered")
    rb_d.connect("toggled", setm, "docked")
    rb_f.connect("toggled", setm, "floating")
    row.pack_start(rb_c, False, False, 0)
    row.pack_start(rb_d, False, False, 0)
    row.pack_start(rb_f, False, False, 0)
    page.pack_start(row, False, False, 0)
    hl = Gtk.Label(label=tr("Docked keyboard height"))
    hl.set_halign(Gtk.Align.START)
    page.pack_start(hl, False, False, 0)
    hrow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    sc = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 25, 60, 1)
    sc.set_value(float(mset(st, "kb_dock_frac")) * 100)
    sc.connect("format-value", lambda s, v: "%d%%" % v)

    def seth(s):
        st["kb_dock_frac"] = round(s.get_value() / 100.0, 2)
        save_settings(st)
    sc.connect("value-changed", seth)
    hrow.pack_start(sc, True, True, 0)
    dflt = Gtk.Button(label=tr("Default"))

    def reset(b):
        for k in ("kb_mode", "kb_dock_frac", "kb_float_x", "kb_float_y",
                  "kb_float_w"):
            st.pop(k, None)
        save_settings(st)
        rb_c.set_active(True)
        sc.set_value(MONDAY_DEFAULTS["kb_dock_frac"] * 100)
    dflt.connect("clicked", reset)
    hrow.pack_start(dflt, False, False, 0)
    page.pack_start(hrow, False, False, 0)
    tip = Gtk.Label(label=tr("Tip: the mode key on the keyboard's top bar "
                             "switches Centred -> Docked -> Floating. "
                             "Floating remembers where you put it and its "
                             "size. Search boxes always get the Fire TV-"
                             "style search keyboard."))
    tip.set_line_wrap(True)
    tip.set_halign(Gtk.Align.START)
    page.pack_start(tip, False, False, 0)
    page.show_all()


_orig_build_keyboard_page = SettingsPanel.build_keyboard_page
SettingsPanel.build_keyboard_page = _l_build_keyboard_page_mon

_MON_KB_CSS = b"""
.mon-kb-host { background: rgba(236,240,246,0.96); }
.mon-kb-docked { border-top: 1px solid rgba(0,0,0,0.12);
                 box-shadow: 0 -6px 24px rgba(0,0,0,0.18); }
.mon-kb-floating { border-radius: 18px; border: 1px solid rgba(0,0,0,0.15);
                   box-shadow: 0 10px 34px rgba(0,0,0,0.30); }
.mon-kb-bar { padding: 4px 10px 0 10px; }
.mon-kb-grip { color: #4a5568; font-weight: bold; padding: 6px; }
.mon-kb-resize { color: #4a5568; padding: 0 8px 4px 0; }
.mon-kb-tool { padding: 2px 10px; min-height: 0; border-radius: 10px; }
"""


def _mon_kb_css_install():
    prov = Gtk.CssProvider()
    prov.load_from_data(_MON_KB_CSS)
    scr = Gdk.Screen.get_default()
    if scr is not None:
        Gtk.StyleContext.add_provider_for_screen(
            scr, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 3)


_mon_kb_css_install()


# ===========================================================================
# Aero OS Monday Night (2): French / Spanish menus + EPUB pictures
# ===========================================================================
# Flight Deck -> Language picks English / French / Spanish for Aero's own
# menus (Aero restarts in ~2 s). Strings live in i18n/strings.tsv
# (English <TAB> French <TAB> Spanish); anything not in the table stays in
# English. Settings values (combo choices etc.) are never translated, so
# nothing that compares text breaks.
_I18N = {}
_I18N_EN = {
    "Aero Deck's own menus are English-only for now. This sets the "
    "language websites, the browser and apps you open from here ask for.":
    "Aero Deck's menus follow this language (Aero restarts in about 2 s). "
    "It also sets the language websites, the browser and apps you open "
    "from here ask for.",
}
_LANG_COL = {"French": 1, "Spanish": 2}


def _i18n_load():
    try:
        lang = (load_settings() or {}).get("language", "English")
    except Exception:
        lang = "English"
    col = _LANG_COL.get(lang)
    if not col:
        return
    for d in (ASSETS_DIR.parent / "i18n", Path(__file__).resolve().parent / "i18n",
              Path("/usr/local/share/aero-deck/i18n")):
        f = d / "strings.tsv"
        if f.is_file():
            for line in f.read_text(encoding="utf-8").splitlines():
                parts = line.split("\t")
                if len(parts) == 3 and parts[0] and parts[col]:
                    _I18N[parts[0]] = parts[col]
            break


def tr(s):
    if not isinstance(s, str) or not s:
        return s
    if not _I18N:
        return _I18N_EN.get(s, s)
    t = _I18N.get(s)
    if t is not None:
        return t
    st = s.strip()
    if st != s and st in _I18N:
        return s.replace(st, _I18N[st])
    return _I18N_EN.get(s, s)


def _tr_markup(m):
    if not isinstance(m, str) or "<" not in m:
        return tr(m)
    return re.sub(r">([^<>]+)<", lambda g: ">" + tr(g.group(1)) + "<", m)


_i18n_load()


def _i18n_patch():
    def wrap_init(cls):
        orig = cls.__init__

        def init(self, *a, **kw):
            if "label" in kw:
                kw["label"] = tr(kw["label"])
            elif a and isinstance(a[0], str):
                a = (tr(a[0]),) + tuple(a[1:])
            orig(self, *a, **kw)
        cls.__init__ = init

    def wrap_m(cls, name, fn=tr):
        orig = getattr(cls, name)

        def m(self, s, *a):
            return orig(self, fn(s), *a)
        setattr(cls, name, m)
    for cls in (Gtk.Label, Gtk.Button, Gtk.CheckButton, Gtk.ToggleButton):
        wrap_init(cls)
    wrap_m(Gtk.Label, "set_text")
    wrap_m(Gtk.Label, "set_label")
    wrap_m(Gtk.Label, "set_markup", _tr_markup)
    wrap_m(Gtk.Button, "set_label")
    wrap_m(Gtk.Widget, "set_tooltip_text")
    wrap_m(Gtk.Entry, "set_placeholder_text")
    orig_rb = Gtk.RadioButton.new_with_label_from_widget

    def rb(group, label):
        return orig_rb(group, tr(label))
    Gtk.RadioButton.new_with_label_from_widget = staticmethod(rb)


if _I18N:
    _i18n_patch()


def _l_on_language_changed_mon(self, combo):
    before = self.launcher.settings.get("language", "English")
    _orig_on_language_changed(self, combo)
    after = self.launcher.settings.get("language", "English")
    if after != before:
        save_settings(self.launcher.settings)
        try:
            _l_show_toast_safe(self.launcher,
                               "Language: %s -- Aero restarts…" % after)
        except Exception:
            pass
        GLib.timeout_add(1500, lambda: (Gtk.main_quit(), False)[1])


_orig_on_language_changed = SettingsPanel.on_language_changed


def _l_x_language_mon(self):
    page = self._page("language")
    page.pack_start(self._xlabel(
        "Aero Deck's menus follow this language (Aero restarts in about "
        "2 s). It also sets the language websites, the browser and apps "
        "you open from here ask for."), False, False, 0)
    self._apply_language(self.launcher.settings.get("language", "English"))


SettingsPanel._x_language = _l_x_language_mon
SettingsPanel.on_language_changed = _l_on_language_changed_mon


# -- EPUB pictures -------------------------------------------------------------
def epub_content(path):
    """[(chapter title, [("text", str) | ("img", bytes)])] in reading order.
    Pictures (<img>, SVG <image>) come out where they sit in the text."""
    import zipfile
    import html.parser
    import posixpath
    z = zipfile.ZipFile(path)
    cont = z.read("META-INF/container.xml").decode("utf-8", "replace")
    opf_path = re.search(r'full-path="([^"]+)"', cont).group(1)
    opf = z.read(opf_path).decode("utf-8", "replace")
    base = posixpath.dirname(opf_path)
    manifest = dict(re.findall(
        r'<item\b[^>]*?id="([^"]+)"[^>]*?href="([^"]+)"', opf))
    manifest.update({i: h for h, i in re.findall(
        r'<item\b[^>]*?href="([^"]+)"[^>]*?id="([^"]+)"', opf)})
    spine = re.findall(r'<itemref\b[^>]*?idref="([^"]+)"', opf)

    class P(html.parser.HTMLParser):
        BLOCK = {"p", "div", "br", "h1", "h2", "h3", "h4", "li", "tr",
                 "section", "blockquote"}

        def __init__(self, here):
            super().__init__()
            self.here = here
            self.segs, self.buf, self.skip, self.title = [], [], 0, ""
            self.in_h = False

        def _flush(self):
            if self.buf:
                self.segs.append(("text", "".join(self.buf)))
                self.buf = []

        def handle_starttag(self, tag, a):
            if tag in ("script", "style", "head"):
                self.skip += 1
            if tag in self.BLOCK:
                self.buf.append("\n")
            if tag in ("h1", "h2", "h3"):
                self.in_h = True
            if tag in ("img", "image") and not self.skip:
                ad = dict(a)
                src = ad.get("src") or ad.get("xlink:href") or ad.get("href")
                if src and not src.startswith(("http:", "https:", "data:")):
                    p = posixpath.normpath(posixpath.join(
                        self.here, urllib.parse.unquote(src.split("#")[0])))
                    try:
                        data = z.read(p)
                        if len(data) < 15 * 1024 * 1024:
                            self._flush()
                            self.segs.append(("img", data))
                    except KeyError:
                        pass

        def handle_endtag(self, tag):
            if tag in ("script", "style", "head"):
                self.skip = max(0, self.skip - 1)
            if tag in self.BLOCK:
                self.buf.append("\n")
            if tag in ("h1", "h2", "h3"):
                self.in_h = False

        def handle_data(self, d):
            if self.skip:
                return
            if self.in_h and not self.title:
                self.title = d.strip()
            self.buf.append(d)

    chapters = []
    for idref in spine:
        href = manifest.get(idref)
        if not href:
            continue
        full = posixpath.normpath(posixpath.join(base,
                                                 urllib.parse.unquote(href)))
        try:
            raw = z.read(full).decode("utf-8", "replace")
        except KeyError:
            continue
        p = P(posixpath.dirname(full))
        p.feed(raw)
        p._flush()
        segs = []
        for kind, v in p.segs:
            if kind == "text":
                v = re.sub(r"[ \t\r\f\v]+", " ", v)
                v = re.sub(r"\n\s*\n\s*(\n\s*)+", "\n\n", v)
                if v.strip():
                    segs.append(("text", v))
            else:
                segs.append((kind, v))
        if segs:
            chapters.append((p.title or "Chapter %d" % (len(chapters) + 1),
                             segs))
    return chapters


def _epub_pixbuf(data, max_w, max_h):
    try:
        loader = GdkPixbuf.PixbufLoader()
        loader.write(data)
        loader.close()
        pb = loader.get_pixbuf()
    except Exception:
        return None
    if pb is None:
        return None
    w, h = pb.get_width(), pb.get_height()
    sc = min(1.0, max_w / float(w), max_h / float(h))
    if sc < 1.0:
        pb = pb.scale_simple(max(1, int(w * sc)), max(1, int(h * sc)),
                             GdkPixbuf.InterpType.BILINEAR)
    return pb


def _l_open_book_mon(self, path):
    _orig_open_book(self, path)
    if getattr(self, "kind", "") != "text" or \
            not str(path).lower().endswith(".epub"):
        return
    try:
        chapters = epub_content(path)
    except Exception:
        return
    if not any(k == "img" for _h, segs in chapters for k, _v in segs):
        return       # text-only book: the plain view is already right
    a = self.text_view.get_allocation()
    W = (a.width if a.width > 100 else self.get_allocated_width() or 1280)
    H = (a.height if a.height > 100 else self.get_allocated_height() or 800)
    max_w, max_h = max(200, W - 200), max(200, int(H * 0.8))
    buf = self.text_view.get_buffer()
    buf.set_text("")
    ctag = buf.get_tag_table().lookup("epub-img") or buf.create_tag(
        "epub-img", justification=Gtk.Justification.CENTER)
    it = buf.get_end_iter()
    first = True
    for title, segs in chapters:
        joined = "".join(v for k, v in segs if k == "text").lstrip()
        if not first:
            buf.insert(it, "\n\n\n")
        first = False
        if not joined.startswith(title):
            buf.insert(it, title + "\n\n")
        for kind, v in segs:
            if kind == "text":
                buf.insert(it, v)
            else:
                pb = _epub_pixbuf(v, max_w, max_h)
                if pb is not None:
                    buf.insert(it, "\n")
                    mark = buf.create_mark(None, it, True)
                    buf.insert_pixbuf(it, pb)
                    buf.insert(it, "\n")
                    buf.apply_tag(ctag, buf.get_iter_at_mark(mark), it)
                    buf.delete_mark(mark)
    self._epub_has_images = True


_orig_open_book = ReaderWindow.open_book
ReaderWindow.open_book = _l_open_book_mon


# ===========================================================================
# Aero OS Monday Night (2): the "next time" list
#   new tiles (Fibe TV, Muse, Grok Bot, Proton VPN, Phone, Web Apps), a logo
#   on every tile, Web Apps page, Game Mode switch + "Start in" + first-boot
#   question, Task Manager, Speed Test, moving screensaver with photo
#   categories.
# ===========================================================================
APPS.extend([
    ("Web Apps", "W", "#2b6fe3", "linux", "aero:webapps", ""),
    ("Fibe TV", "F", "#00549a", "linux", "aero-webapp fibe",
     "https://tv.bell.ca"),
    ("Muse", "M", "#0866ff", "linux", "aero-webapp muse", "https://muse.ai"),
    ("Grok Bot", "G", "#111111", "linux", "aero-grokbot",
     "https://cursor.com/download/bot"),
    ("Proton VPN", "P", "#6d4aff", "linux", "aero-protonvpn",
     "https://protonvpn.com"),
    ("Phone", "P", "#1d99f3", "linux", "aero-phone", ""),
])
MONDAY_DEFAULTS.update({"ss_cats": ["nova-scotia", "canada", "mountains",
                                    "wildlife", "tropical", "cities", "usa"],
                        "ss_pan": True, "ss_every": 20})
SS_CATEGORIES = [("nova-scotia", "Nova Scotia"), ("canada", "Canada"),
                 ("usa", "United States"), ("mountains", "Mountains"),
                 ("wildlife", "Wildlife"), ("tropical", "Tropical"),
                 ("cities", "Cities")]
AERO_CFG = Path.home() / ".config" / "aero-deck"
WEBAPPS_FILE = CONFIG_DIR / "webapps.json"
WEBAPPS_DEFAULT = [
    {"name": "Google", "url": "https://www.google.com/"},
    {"name": "Gmail", "url": "https://mail.google.com/"},
    {"name": "Google Maps", "url": "https://maps.google.com/"},
    {"name": "Weather", "url": "https://weather.gc.ca/"},
    {"name": "Wikipedia", "url": "https://en.wikipedia.org/"},
    {"name": "MyBell", "url": "https://www.bell.ca/MyBell"},
]
FAVICON_DIR = Path.home() / ".cache" / "aero-deck" / "favicons"


def load_webapps():
    try:
        d = json.loads(WEBAPPS_FILE.read_text())
        if isinstance(d, list):
            return [x for x in d if isinstance(x, dict) and x.get("url")]
    except Exception:
        pass
    return [dict(x) for x in WEBAPPS_DEFAULT]


def save_webapps(lst):
    try:
        WEBAPPS_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = WEBAPPS_FILE.with_suffix(".part")
        tmp.write_text(json.dumps(lst, indent=1))
        os.replace(tmp, WEBAPPS_FILE)
    except Exception:
        pass


def _norm_url(u):
    u = (u or "").strip()
    if u and not re.match(r"^[a-z]+://", u, re.I):
        u = "https://" + u
    return u


def _host(u):
    try:
        return urllib.parse.urlparse(_norm_url(u)).hostname or ""
    except Exception:
        return ""


_FAV_BUSY = set()


def favicon_path(url):
    h = _host(url)
    return FAVICON_DIR / (re.sub(r"[^a-z0-9.-]+", "-", h.lower()) + ".png") \
        if h else None


def favicon_fetch(url, done=None):
    """The site's own icon (apple-touch-icon / <link rel=icon> / favicon.ico),
    fetched once in the background and cached as PNG."""
    p = favicon_path(url)
    if p is None or p.exists() or str(p) in _FAV_BUSY:
        return
    _FAV_BUSY.add(str(p))

    def job():
        ua = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AeroDeck/1.4"}
        base = _norm_url(url)
        cands = []
        try:
            html = urllib.request.urlopen(urllib.request.Request(
                base, headers=ua), timeout=10).read(400000).decode(
                    "utf-8", "replace")
            for m in re.finditer(r"<link\b[^>]*>", html, re.I):
                tag = m.group(0)
                rel = re.search(r'rel=["\']([^"\']+)', tag, re.I)
                href = re.search(r'href=["\']([^"\']+)', tag, re.I)
                if not rel or not href or "icon" not in rel.group(1).lower():
                    continue
                sz = re.search(r'sizes=["\'](\d+)', tag)
                score = int(sz.group(1)) if sz else (
                    180 if "apple" in rel.group(1).lower() else 32)
                cands.append((score, urllib.parse.urljoin(base,
                                                          href.group(1))))
        except Exception:
            pass
        cands.sort(reverse=True)
        root = "https://%s" % _host(url)
        urls = [u for _s, u in cands] + [root + "/apple-touch-icon.png",
                                          root + "/favicon.ico"]
        for u in urls:
            try:
                data = urllib.request.urlopen(urllib.request.Request(
                    u, headers=ua), timeout=10).read(2000000)
                loader = GdkPixbuf.PixbufLoader()
                loader.write(data)
                loader.close()
                pb = loader.get_pixbuf()
                if pb is None or pb.get_width() < 16:
                    continue
                FAVICON_DIR.mkdir(parents=True, exist_ok=True)
                tmp = str(p) + ".part"
                pb.savev(tmp, "png", [], [])
                os.replace(tmp, p)
                break
            except Exception:
                continue
        _FAV_BUSY.discard(str(p))
        if done is not None:
            GLib.idle_add(done)
    threading.Thread(target=job, daemon=True).start()


def _pb_from_file(path, w, h):
    try:
        return GdkPixbuf.Pixbuf.new_from_file_at_scale(str(path), w, h, True)
    except Exception:
        return None


# -- a logo on every tile ----------------------------------------------------
def _l_load_app_icon_mon(self, name, target, kind, size=96, width=None,
                         height=None, icon_name=None):
    pb = _orig_load_app_icon(self, name, target, kind, size, width, height,
                             icon_name)
    if pb is not None:
        return pb
    w = width or size
    h = height or size
    if kind == "android" and target:
        # Waydroid keeps each installed app's own icon here.
        for d in (Path.home() / ".local/share/waydroid/data/icons",
                  Path("/var/lib/waydroid/data/icons")):
            f = d / (target + ".png")
            if f.exists():
                pb = _pb_from_file(f, w, h)
                if pb is not None:
                    return pb
    url = ""
    if kind == "web":
        url = target
    elif kind == "linux" and target.startswith("aero-webapp "):
        url = target.split(None, 1)[1]
        if not url.startswith("http"):
            url = ""
    if url:
        fp = favicon_path(url)
        if fp is not None and fp.exists():
            pb = _pb_from_file(fp, w, h)
            if pb is not None:
                return pb
        favicon_fetch(url)
    # Last resort: the theme's generic icon for the kind of app.
    theme = Gtk.IconTheme.get_default()
    for cand in (("android",) if kind == "android" else ()) + (
            "web-browser" if kind == "web" else "application-x-executable",
            "applications-other", "system-run"):
        try:
            info = theme.lookup_icon(cand, max(w, h), 0)
            if info is not None:
                return info.load_icon()
        except Exception:
            continue
    return None


_orig_load_app_icon = AltTVLauncher.load_app_icon
AltTVLauncher.load_app_icon = _l_load_app_icon_mon


# -- internal tiles (Web Apps, Game Mode) -----------------------------------
def _l_on_open_app_mon(self, widget, kind, target, fallback, name):
    if target == "aero:webapps":
        return self.mon_open_webapps()
    if target == "aero:gamemode":
        return self.mon_switch_gamemode()
    return _orig_on_open_app(self, widget, kind, target, fallback, name)


_orig_on_open_app = AltTVLauncher.on_open_app
AltTVLauncher.on_open_app = _l_on_open_app_mon


# -- Web Apps page -------------------------------------------------------------
_WEBAPPS_CSS = b"""
.mon-webapps { background: rgba(14,18,28,0.97); }
.mon-wa-title { font-size: 30px; font-weight: bold; color: white; }
.mon-wa-search { font-size: 22px; min-height: 52px; border-radius: 26px;
                 padding: 0 22px; }
.mon-wa-tile { border-radius: 18px; padding: 14px; min-width: 150px;
               background: rgba(255,255,255,0.08); color: white; }
.mon-wa-tile:focus, .mon-wa-tile:hover { background: rgba(80,140,255,0.45); }
.mon-wa-name { color: white; font-size: 17px; }
.mon-wa-tile label { color: white; font-size: 19px; font-weight: bold; }
.mon-wa-btn { font-size: 17px; padding: 8px 18px; border-radius: 12px; }
"""


def _l_mon_open_webapps(self):
    if getattr(self, "mon_wa_page", None) is not None:
        self.mon_wa_page.show()
        self._mon_wa_fill()
        return
    page = Gtk.EventBox()
    page.get_style_context().add_class("mon-webapps")
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
    for m in ("start", "end"):
        getattr(col, "set_margin_" + m)(60)
    col.set_margin_top(30)
    col.set_margin_bottom(30)
    top = Gtk.Box(spacing=12)
    t = Gtk.Label(label="Web Apps")
    t.get_style_context().add_class("mon-wa-title")
    top.pack_start(t, False, False, 0)
    back = Gtk.Button(label="‹ " + tr("Back"))
    back.get_style_context().add_class("mon-wa-btn")
    back.connect("clicked", lambda b: self.mon_close_webapps())
    self.mon_wa_edit = Gtk.ToggleButton(label="Edit")
    self.mon_wa_edit.get_style_context().add_class("mon-wa-btn")
    self.mon_wa_edit.connect("toggled", lambda b: self._mon_wa_fill())
    add = Gtk.Button(label="+ " + tr("Add"))
    add.get_style_context().add_class("mon-wa-btn")
    add.connect("clicked", lambda b: self._mon_wa_form(None))
    for b in (back, self.mon_wa_edit, add):
        top.pack_end(b, False, False, 0)
    col.pack_start(top, False, False, 0)
    se = Gtk.Entry()
    se.set_placeholder_text("Search Google or type a web address")
    se.get_style_context().add_class("mon-wa-search")
    se.set_halign(Gtk.Align.CENTER)
    se.set_size_request(760, -1)

    def go(e):
        q = e.get_text().strip()
        if not q:
            return
        if " " not in q and "." in q:
            url = _norm_url(q)
        else:
            url = "https://www.google.com/search?q=" + urllib.parse.quote_plus(q)
        _spawn(["aero-webapp", url])
        e.set_text("")
    se.connect("activate", go)
    self.mon_wa_search = se
    col.pack_start(se, False, False, 6)
    self.mon_wa_form_box = Gtk.Box(spacing=10)
    self.mon_wa_form_box.set_halign(Gtk.Align.CENTER)
    self.mon_wa_form_box.set_no_show_all(True)
    col.pack_start(self.mon_wa_form_box, False, False, 0)
    flow = Gtk.FlowBox()
    flow.set_selection_mode(Gtk.SelectionMode.NONE)
    flow.set_max_children_per_line(6)
    flow.set_min_children_per_line(3)
    flow.set_column_spacing(18)
    flow.set_row_spacing(18)
    flow.set_homogeneous(True)
    flow.set_valign(Gtk.Align.START)
    self.mon_wa_flow = flow
    sc = Gtk.ScrolledWindow()
    sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
    sc.add(flow)
    col.pack_start(sc, True, True, 0)
    hint = Gtk.Label(label="Pick a logo to open the site full screen. "
                           "Home / Steam button comes back to Aero.")
    hint.get_style_context().add_class("mon-wa-name")
    col.pack_start(hint, False, False, 0)
    page.add(col)
    self.overlay.add_overlay(page)
    self.mon_wa_page = page
    page.show_all()
    self._mon_wa_fill()


def _mon_wa_css():
    prov = Gtk.CssProvider()
    prov.load_from_data(_WEBAPPS_CSS)
    scr = Gdk.Screen.get_default()
    if scr is not None:
        Gtk.StyleContext.add_provider_for_screen(
            scr, prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 2)


_mon_wa_css()


def _l_mon_wa_fill(self):
    flow = self.mon_wa_flow
    for c in flow.get_children():
        flow.remove(c)
    editing = self.mon_wa_edit.get_active()
    lst = load_webapps()
    first = None
    for i, app in enumerate(lst):
        b = Gtk.Button()
        b.get_style_context().add_class("mon-wa-tile")
        v = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        fp = favicon_path(app["url"])
        pb = _pb_from_file(fp, 96, 96) if fp is not None and fp.exists() \
            else None
        if pb is None:
            favicon_fetch(app["url"], done=lambda: (
                self._mon_wa_fill() if getattr(self, "mon_wa_page", None)
                and self.mon_wa_page.get_visible() else None, False)[1])
            ll = Gtk.Label()
            ll.set_markup("<span size='40000' weight='bold' color='white'>%s"
                          "</span>" % _esc((app.get("name") or "?")[:1].upper()))
            ll.set_size_request(96, 96)
            v.pack_start(ll, False, False, 0)
        else:
            v.pack_start(Gtk.Image.new_from_pixbuf(pb), False, False, 0)
        nl = Gtk.Label(label=app.get("name") or _host(app["url"]))
        nl.get_style_context().add_class("mon-wa-name")
        nl.set_ellipsize(3)
        nl.set_max_width_chars(16)
        v.pack_start(nl, False, False, 0)
        if editing:
            row = Gtk.Box(spacing=6, halign=Gtk.Align.CENTER)
            ed = Gtk.Button(label="✎")
            rm = Gtk.Button(label="✕")
            ed.connect("clicked", lambda w, k=i: self._mon_wa_form(k))

            def remove(w, k=i):
                cur = load_webapps()
                if 0 <= k < len(cur):
                    cur.pop(k)
                    save_webapps(cur)
                self._mon_wa_fill()
            rm.connect("clicked", remove)
            row.pack_start(ed, False, False, 0)
            row.pack_start(rm, False, False, 0)
            v.pack_start(row, False, False, 0)
        b.add(v)
        b.connect("clicked", lambda w, u=app["url"]: (
            None if self.mon_wa_edit.get_active()
            else _spawn(["aero-webapp", _norm_url(u)])))
        flow.add(b)
        first = first or b
    flow.show_all()
    if first is not None and not self.mon_wa_search.has_focus():
        first.grab_focus()


def _l_mon_wa_form(self, idx):
    box = self.mon_wa_form_box
    for c in box.get_children():
        box.remove(c)
    lst = load_webapps()
    cur = lst[idx] if idx is not None and 0 <= idx < len(lst) else {}
    ne = Gtk.Entry()
    ne.set_placeholder_text("Name")
    ne.set_text(cur.get("name", ""))
    ue = Gtk.Entry()
    ue.set_placeholder_text("Web address (e.g. tv.bell.ca)")
    ue.set_text(cur.get("url", ""))
    ue.set_size_request(380, -1)
    save = Gtk.Button(label="Save")
    cancel = Gtk.Button(label="Cancel")

    def do_save(*_a):
        url = _norm_url(ue.get_text())
        if not _host(url):
            ue.grab_focus()
            return
        name = ne.get_text().strip() or _host(url).replace("www.", "")
        cur2 = load_webapps()
        if idx is not None and 0 <= idx < len(cur2):
            cur2[idx] = {"name": name, "url": url}
        else:
            cur2.append({"name": name, "url": url})
        save_webapps(cur2)
        box.hide()
        self._mon_wa_fill()
    save.connect("clicked", do_save)
    ue.connect("activate", do_save)
    cancel.connect("clicked", lambda b: box.hide())
    for w in (ne, ue, save, cancel):
        box.pack_start(w, False, False, 0)
        w.show()
    box.show()
    ne.grab_focus()


def _l_mon_close_webapps(self):
    if getattr(self, "mon_wa_page", None) is not None:
        self.mon_wa_page.hide()
    try:
        self.entry_kb.popdown()
    except Exception:
        pass


for _n, _f in (("mon_open_webapps", _l_mon_open_webapps),
               ("_mon_wa_fill", _l_mon_wa_fill),
               ("_mon_wa_form", _l_mon_wa_form),
               ("mon_close_webapps", _l_mon_close_webapps)):
    setattr(AltTVLauncher, _n, _f)


def _l_on_key_mon_i(self, widget, event):
    page = getattr(self, "mon_wa_page", None)
    if page is not None and page.get_visible() and \
            event.keyval in (Gdk.KEY_Escape, Gdk.KEY_BackSpace) and \
            not (getattr(self, "entry_kb", None) is not None
                 and self.entry_kb.is_open()) and \
            not isinstance(self.get_focus(), Gtk.Entry):
        self.mon_close_webapps()
        return True
    return _orig_on_key_mon_i(self, widget, event)


_orig_on_key_mon_i = AltTVLauncher.on_key
AltTVLauncher.on_key = _l_on_key_mon_i


# -- Game Mode ---------------------------------------------------------------
def gamemode_available():
    return bool(shutil.which("gamescope") and shutil.which("steam"))


def _start_in_get():
    try:
        v = (AERO_CFG / "start-in").read_text().strip()
        return v if v in ("aero", "gamemode") else ""
    except Exception:
        return ""


def _start_in_set(v):
    try:
        AERO_CFG.mkdir(parents=True, exist_ok=True)
        (AERO_CFG / "start-in").write_text(v + "\n")
    except Exception:
        pass


def is_handheld():
    try:
        prod = Path("/sys/class/dmi/id/product_name").read_text().strip()
    except Exception:
        prod = ""
    return prod in ("Jupiter", "Galileo") or "ROG Ally" in prod or \
        "Legion Go" in prod


def _l_mon_switch_gamemode(self):
    if not gamemode_available():
        _l_show_toast_safe(self, "Game Mode needs gamescope + Steam "
                                 "(not in this build)")
        return
    _l_show_toast_safe(self, "Switching to Game Mode…")
    GLib.timeout_add(250, lambda: (_spawn(["aero-deck-gamemode"]), False)[1])


AltTVLauncher.mon_switch_gamemode = _l_mon_switch_gamemode


def _l_mon_open_start_menu_i(self):
    _orig_mon_open_start_menu_i(self)
    pop = getattr(self, "mon_start_pop", None)
    if pop is None:
        return
    outer = pop.get_child()
    row = Gtk.Box(spacing=10)
    row.set_margin_start(8)
    row.set_margin_end(8)
    for label, fn in (("🎮 " + tr("Game Mode"), self.mon_switch_gamemode),
                      ("🌐 " + tr("Web Apps"), self.mon_open_webapps),
                      ("⚙ " + tr("Task Manager"),
                       lambda: _spawn(["aero-deck-taskman"]))):
        b = Gtk.Button(label=label)
        b.get_style_context().add_class("mon-start-item")
        b.connect("clicked", lambda w, f=fn: (pop.popdown(), f()))
        if label.startswith("🎮") and not gamemode_available():
            b.set_sensitive(False)
        row.pack_start(b, False, False, 0)
    outer.pack_start(row, False, False, 0)
    outer.reorder_child(row, 0)
    row.show_all()


_orig_mon_open_start_menu_i = AltTVLauncher.mon_open_start_menu
AltTVLauncher.mon_open_start_menu = _l_mon_open_start_menu_i


def _l_x_power_mon(self):
    _orig_x_power(self)
    page = self._page("power")
    if page is None:
        return
    page.pack_start(self._xheading("Game Mode (Steam, like a Steam Deck)"),
                    False, False, 0)
    ok = gamemode_available()
    page.pack_start(self._xlabel(
        "Start in: what Aero opens to when it turns on. Steam's power menu "
        "-> Switch to Desktop comes back to Aero; Aero's Start menu -> Game "
        "Mode goes the other way." if ok else
        "Game Mode isn't in this build (needs gamescope + Steam)."),
        False, False, 0)
    row = Gtk.Box(spacing=12)
    rb_a = Gtk.RadioButton.new_with_label_from_widget(None, "Aero")
    rb_g = Gtk.RadioButton.new_with_label_from_widget(rb_a, "Game Mode")
    (rb_g if _start_in_get() == "gamemode" else rb_a).set_active(True)
    rb_a.connect("toggled", lambda b: b.get_active() and _start_in_set("aero"))
    rb_g.connect("toggled", lambda b: b.get_active() and
                 _start_in_set("gamemode"))
    go = Gtk.Button(label="Switch to Game Mode now")
    go.connect("clicked", lambda b: self.launcher.mon_switch_gamemode())
    for w in (rb_a, rb_g, go):
        w.set_sensitive(ok)
        row.pack_start(w, False, False, 0)
    page.pack_start(row, False, False, 0)
    page.pack_start(self._xheading("Tools"), False, False, 0)
    trow = Gtk.Box(spacing=12)
    for label, cmd in (("Task Manager", "aero-deck-taskman"),
                       ("Speed Test", "aero-deck-speedtest")):
        b = Gtk.Button(label=label)
        b.connect("clicked", lambda w, c=cmd: _spawn([c]))
        trow.pack_start(b, False, False, 0)
    page.pack_start(trow, False, False, 0)
    page.pack_start(self._xlabel(
        "Task Manager also opens with Ctrl+Alt+Delete or Super+Escape."),
        False, False, 0)
    page.show_all()


_orig_x_power = SettingsPanel._x_power
SettingsPanel._x_power = _l_x_power_mon


def _l_mon_first_boot_ask(self):
    """First start: Steam Deck style (Game Mode) or Desktop (Aero)?"""
    if _start_in_get() or not gamemode_available() or \
            self.settings.get("start_in_asked"):
        return False
    hand = is_handheld()
    box = Gtk.EventBox()
    box.get_style_context().add_class("mon-webapps")
    col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=18)
    col.set_halign(Gtk.Align.CENTER)
    col.set_valign(Gtk.Align.CENTER)
    t = Gtk.Label(label="How should Aero start?")
    t.get_style_context().add_class("mon-wa-title")
    col.pack_start(t, False, False, 0)
    s = Gtk.Label(label="You can change this any time: Flight Deck -> "
                        "Power -> Start in.")
    s.get_style_context().add_class("mon-wa-name")
    col.pack_start(s, False, False, 0)
    row = Gtk.Box(spacing=18, halign=Gtk.Align.CENTER)

    def pick(v):
        _start_in_set(v)
        self.settings["start_in_asked"] = True
        save_settings(self.settings)
        box.destroy()
        if v == "gamemode":
            self.mon_switch_gamemode()
    bg = Gtk.Button(label="Steam Deck style (Game Mode)")
    ba = Gtk.Button(label="Desktop (Aero)")
    for b, v in ((bg, "gamemode"), (ba, "aero")):
        b.get_style_context().add_class("mon-wa-tile")
        b.connect("clicked", lambda w, vv=v: pick(vv))
        row.pack_start(b, False, False, 0)
    col.pack_start(row, False, False, 0)
    box.add(col)
    self.overlay.add_overlay(box)
    box.show_all()
    (bg if hand else ba).grab_focus()
    return False


AltTVLauncher.mon_first_boot_ask = _l_mon_first_boot_ask


# -- Speed test in Flight Deck -> Network ------------------------------------
def _l_settings_init_mon_i(self, *a, **kw):
    _orig_settings_init_i(self, *a, **kw)
    eth = getattr(self, "eth_status", None)
    page = eth.get_parent() if eth is not None else None
    if page is None:
        return
    row = Gtk.Box(spacing=12)
    b = Gtk.Button(label="Speed Test")
    res = Gtk.Label(label="")
    res.set_halign(Gtk.Align.START)

    def run(_b):
        b.set_sensitive(False)
        res.set_text(tr("Testing… (about 20 s)"))

        def job():
            try:
                out = subprocess.run(["aero-deck-speedtest", "--json"],
                                     capture_output=True, text=True,
                                     timeout=90).stdout
                r = json.loads(out.strip().splitlines()[-1])
                if "error" in r:
                    txt = tr("Speed test failed") + ": " + r["error"][:80]
                else:
                    txt = "↓ %.1f Mbps   ↑ %.1f Mbps   %s %.0f ms" % (
                        r["down_mbps"], r["up_mbps"], tr("Ping"), r["ping_ms"])
            except Exception as e:     # noqa: BLE001
                txt = tr("Speed test failed") + ": %s" % e
            GLib.idle_add(res.set_text, txt)
            GLib.idle_add(b.set_sensitive, True)
        threading.Thread(target=job, daemon=True).start()
    b.connect("clicked", run)
    row.pack_start(b, False, False, 0)
    row.pack_start(res, True, True, 0)
    page.pack_start(row, False, False, 0)
    kids = page.get_children()
    if eth in kids:
        page.reorder_child(row, kids.index(eth) + 1)
    row.show_all()


_orig_settings_init_i = SettingsPanel.__init__
SettingsPanel.__init__ = _l_settings_init_mon_i


# -- Screensaver: photo categories, slow pan, cross-fade, moving clock -------
SS_DIRS = [Path(os.environ.get("AERO_DECK_SCREENSAVER",
                               "/usr/local/share/aero-deck/screensaver"))]


def screensaver_photos(cats):
    out = []
    for base in SS_DIRS:
        for c in cats:
            d = base / c
            if d.is_dir():
                out += sorted(str(p) for p in d.glob("*.jp*g"))
    own = Path.home() / "Pictures" / "Screensaver"
    if own.is_dir():
        out += sorted(str(p) for p in own.glob("*")
                      if p.suffix.lower() in (".jpg", ".jpeg", ".png"))
    return out


def _l_screensaver_show_mon(self):
    if getattr(self, "_ss_win", None) is not None:
        return
    st = self.settings
    cats = mset(st, "ss_cats") or []
    photos = screensaver_photos(cats)
    if not photos:
        photos = [str(ASSETS_DIR / "backdrop.jpg")]
    import random
    random.shuffle(photos)
    pan = bool(mset(st, "ss_pan"))
    every = max(8, int(mset(st, "ss_every") or 20))
    win = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
    win.set_title("Aero Deck screensaver")
    win.set_transient_for(self)
    win.set_decorated(False)
    ov = Gtk.Overlay()
    area = Gtk.DrawingArea()
    S = {"i": 0, "cur": None, "prev": None, "t0": time.time(),
         "fade0": 0.0, "dir": 1, "size": (0, 0)}

    def load(i, w, h):
        try:
            pb = GdkPixbuf.Pixbuf.new_from_file(photos[i % len(photos)])
        except Exception:
            return None
        zoom = 1.12 if pan else 1.0
        sc = max(w * zoom / pb.get_width(), h * zoom / pb.get_height())
        pb = pb.scale_simple(max(1, int(pb.get_width() * sc)),
                             max(1, int(pb.get_height() * sc)),
                             GdkPixbuf.InterpType.BILINEAR)
        surf = Gdk.cairo_surface_create_from_pixbuf(pb, 1, None)
        return (surf, pb.get_width(), pb.get_height(), random.random())

    def paint_one(cr, img, w, h, t, alpha):
        surf, iw, ih, seed = img
        ex, ey = iw - w, ih - h
        f = min(1.0, t / float(every + 2)) if pan else 0.5
        # each photo drifts a different way
        dx = ex * (f if seed < 0.5 else 1 - f)
        dy = ey * ((seed * 2) % 1.0 if not pan else
                   (f if seed < 0.25 or seed > 0.75 else 1 - f))
        cr.set_source_surface(surf, -dx, -dy)
        cr.paint_with_alpha(alpha)

    def draw(_a, cr):
        w, h = area.get_allocated_width(), area.get_allocated_height()
        cr.set_source_rgb(0, 0, 0)
        cr.paint()
        if S["size"] != (w, h) or S["cur"] is None:
            S["size"] = (w, h)
            S["cur"] = load(S["i"], w, h)
            S["prev"] = None
        now = time.time()
        fa = min(1.0, (now - S["fade0"]) / 1.5)
        if S["prev"] is not None and fa < 1.0:
            paint_one(cr, S["prev"], w, h, now - S["t0"] + every, 1.0)
        if S["cur"] is not None:
            paint_one(cr, S["cur"], w, h, now - S["t0"],
                      fa if S["prev"] is not None else 1.0)
        return False
    area.connect("draw", draw)
    ov.add(area)
    clock = Gtk.Label()
    clock.get_style_context().add_class("ss-clock")
    ov.add_overlay(clock)
    spots = [(Gtk.Align.START, Gtk.Align.END), (Gtk.Align.END, Gtk.Align.END),
             (Gtk.Align.END, Gtk.Align.START), (Gtk.Align.START,
                                                Gtk.Align.START)]

    def place(k):
        ha, va = spots[k % len(spots)]
        clock.set_halign(ha)
        clock.set_valign(va)
        for m in ("start", "end", "top", "bottom"):
            getattr(clock, "set_margin_" + m)(56)
        clock.set_justify(Gtk.Justification.RIGHT if ha == Gtk.Align.END
                          else Gtk.Justification.LEFT)
    place(0)
    self._ss_win = win

    def tick():
        if self._ss_win is not win:
            return False
        now = datetime.datetime.now()
        clock.set_markup(
            "<span size='72000' weight='bold' foreground='white'>%s</span>\n"
            "<span size='20000' foreground='white'>%s</span>"
            % (now.strftime("%-I:%M"), _esc(now.strftime("%A, %B %-d"))))
        return True
    tick()
    GLib.timeout_add_seconds(10, tick)

    def frame():
        if self._ss_win is not win:
            return False
        if time.time() - S["t0"] >= every and len(photos) > 1:
            S["i"] += 1
            S["prev"] = S["cur"]
            w, h = S["size"]
            S["cur"] = load(S["i"], w, h) if w else None
            S["t0"] = S["fade0"] = time.time()
            place(S["i"])        # the clock moves too (no burn-in)
        area.queue_draw()
        return True
    GLib.timeout_add(50 if pan else 500, frame)
    win.add(ov)
    win.add_events(Gdk.EventMask.KEY_PRESS_MASK |
                   Gdk.EventMask.BUTTON_PRESS_MASK |
                   Gdk.EventMask.TOUCH_MASK |
                   Gdk.EventMask.POINTER_MOTION_MASK)
    self._ss_shown_at = time.time()

    def wake(*_a):
        if time.time() - self._ss_shown_at < 1.0:
            return True
        self.screensaver_hide()
        return True
    for sig in ("key-press-event", "button-press-event", "touch-event",
                "motion-notify-event"):
        win.connect(sig, wake)
    self._ss_win = win
    a = self.get_allocation()
    if a.width > 1:
        win.set_default_size(a.width, a.height)
    win.fullscreen()
    win.show_all()


AltTVLauncher.screensaver_show = _l_screensaver_show_mon


def _l_x_screensaver_mon(self):
    _orig_x_screensaver(self)
    page = self._page("screensaver")
    st = self.launcher.settings
    page.pack_start(self._xheading("Photos"), False, False, 0)
    grid = Gtk.FlowBox()
    grid.set_selection_mode(Gtk.SelectionMode.NONE)
    grid.set_max_children_per_line(4)
    cur = list(mset(st, "ss_cats") or [])

    def tog(b, key):
        c = list(mset(st, "ss_cats") or [])
        if b.get_active() and key not in c:
            c.append(key)
        elif not b.get_active() and key in c:
            c.remove(key)
        st["ss_cats"] = c
        save_settings(st)
    for key, label in SS_CATEGORIES:
        cb = Gtk.CheckButton(label=label)
        cb.set_active(key in cur)
        cb.connect("toggled", tog, key)
        grid.add(cb)
    page.pack_start(grid, False, False, 0)
    page.pack_start(self._xswitch_row(
        "Slow pan + cross-fade", bool(mset(st, "ss_pan")),
        lambda on: (st.__setitem__("ss_pan", bool(on)),
                    save_settings(st)))[0], False, False, 0)
    page.pack_start(self._xlabel(
        "Your own photos: put them in Pictures/Screensaver and they join "
        "the show. The clock moves to a new corner with every photo."),
        False, False, 0)
    page.show_all()


_orig_x_screensaver = SettingsPanel._x_screensaver
SettingsPanel._x_screensaver = _l_x_screensaver_mon


def _l_launcher_init_mon_i(self, *a, **kw):
    _orig_launcher_init_i(self, *a, **kw)
    GLib.timeout_add(2500, lambda: self.mon_first_boot_ask())


_orig_launcher_init_i = AltTVLauncher.__init__
AltTVLauncher.__init__ = _l_launcher_init_mon_i


# ===========================================================================
# Aero OS Monday Night (2): input device rules, AI (Wingman) key, remote mic
# ===========================================================================
# Last used input decides the on-screen keyboard (aero-deck-inputwatch
# writes /run/aero-deck/last-input from evdev device types):
#   touchscreen finger -> keyboard pops up; touchpad / mouse click or a
#   real keyboard -> no pop-up; remote / controller -> pops up, D-pad
#   highlight + OK types.
LAST_INPUT_FILE = Path("/run/aero-deck/last-input")


def last_input():
    try:
        return LAST_INPUT_FILE.read_text().strip()
    except Exception:
        return ""


def _desk_input():
    return last_input() in ("keyboard", "touchpad", "mouse")


def _l_on_entry_tapped_mon(self, entry, event):
    src = None
    try:
        src = event.get_source_device().get_source()
    except Exception:
        pass
    if src is not None and src != Gdk.InputSource.TOUCHSCREEN and \
            LAST_INPUT_FILE.exists():
        return False     # touchpad / mouse click: no on-screen keyboard
    return _orig_on_entry_tapped(self, entry, event)


_orig_on_entry_tapped = AltTVLauncher._on_entry_tapped
AltTVLauncher._on_entry_tapped = _l_on_entry_tapped_mon

_orig_dock_popup_for = DockKeyboard.popup_for


def _l_dock_popup_for(self, entry):
    ev = Gtk.get_current_event()
    if ev is not None and ev.type == Gdk.EventType.KEY_PRESS and \
            last_input() == "keyboard":
        return           # Enter on a real keyboard: just type, no pop-up
    return _orig_dock_popup_for(self, entry)


DockKeyboard.popup_for = _l_dock_popup_for


def _l_show_keyboard_mon(self, target_entry):
    _orig_show_keyboard_mon(self, target_entry)
    try:   # desk input: the search panel without the key grid
        card = self.kb.grid.get_parent()
        card.set_visible(not _desk_input())
    except Exception:
        pass


_orig_show_keyboard_mon = AltTVLauncher.show_keyboard
AltTVLauncher.show_keyboard = _l_show_keyboard_mon


def _helmet_image(px):
    p = ASSETS_DIR / "wingman-helmet.png"
    try:
        return Gtk.Image.new_from_pixbuf(
            GdkPixbuf.Pixbuf.new_from_file_at_scale(str(p), px, px, True))
    except Exception:
        return None


# Wingman = the flight helmet (bar button + both keyboards).
_orig_init_j = AltTVLauncher.__init__


def _l_init_j(self, *a, **kw):
    _orig_init_j(self, *a, **kw)
    try:
        inner = self.ask_btn.get_child()
        old = inner.get_children()[0]
        img = _helmet_image(22)
        if img is not None:
            inner.remove(old)
            inner.pack_start(img, False, False, 0)
            inner.reorder_child(img, 0)
            img.show()
    except Exception:
        pass
    try:   # Navigator (bar search) keyboard: helmet = ask Wingman
        bar = self.kb.entry.get_parent()
        b = Gtk.Button()
        img = _helmet_image(20)
        b.add(img if img is not None else Gtk.Label(label="Wingman"))
        b.set_tooltip_text("Ask Wingman (the AI) with what's typed")
        b.set_can_focus(False)
        b.connect("clicked", lambda w: self.on_ask_ai_button(w))
        bar.pack_start(b, False, False, 0)
        b.show_all()
    except Exception:
        pass


AltTVLauncher.__init__ = _l_init_j

# Full grid keyboard: helmet key = talk to the AI. Type, speak (Mic / the
# remote's mic) or mix both, then Enter sends it to Wingman.
_orig_dock_init = DockKeyboard.__init__


def _l_dock_init(self, launcher):
    _orig_dock_init(self, launcher)
    self.ai_mode = False
    self.ai_btn = Gtk.Button()
    img = _helmet_image(18)
    box = Gtk.Box(spacing=4)
    if img is not None:
        box.pack_start(img, False, False, 0)
    box.pack_start(Gtk.Label(label="AI"), False, False, 0)
    self.ai_btn.add(box)
    self.ai_btn.get_style_context().add_class("mon-kb-tool")
    self.ai_btn.set_tooltip_text("Talk to Wingman: type or speak, Enter sends")
    self.ai_btn.connect("clicked", lambda b: self.toggle_ai())
    bar = self.mode_btn.get_parent()
    bar.pack_end(self.ai_btn, False, False, 0)


def _l_toggle_ai(self):
    self.ai_mode = not self.ai_mode
    ctx = self.ai_btn.get_style_context()
    (ctx.add_class if self.ai_mode else ctx.remove_class)("osk-mic-live")
    self._voice_status("Wingman: type or speak (Mic), Enter sends"
                       if self.ai_mode else "")


_orig_dock_press = DockKeyboard._press


def _l_dock_press(self, button, action):
    if getattr(self, "ai_mode", False) and action == "done" and \
            self.entry is not None:
        q = self.entry.get_text()
        self.ai_mode = False
        self.ai_btn.get_style_context().remove_class("osk-mic-live")
        self.popdown()
        self.launcher.ask_ai(q)
        return
    return _orig_dock_press(self, button, action)


DockKeyboard.__init__ = _l_dock_init
DockKeyboard.toggle_ai = _l_toggle_ai
DockKeyboard._press = _l_dock_press


# Remote mic (G10S) / Search key: voice typing into whichever keyboard is
# open; otherwise Aero voice search as before.
_orig_on_voice_button_j = AltTVLauncher.on_voice_button


def _l_on_voice_button_j(self):
    kb = getattr(self, "entry_kb", None)
    if kb is not None and kb.is_open():
        kb._toggle_dictation()
        return
    if getattr(self, "kb_visible", False):
        self.kb.toggle_dictation()
        return
    return _orig_on_voice_button_j(self)


AltTVLauncher.on_voice_button = _l_on_voice_button_j

# Settings tile (Linux Apps) -> the Flight Deck.
_orig_on_open_app_j = AltTVLauncher.on_open_app


def _l_on_open_app_j(self, widget, kind, target, fallback, name):
    if target == "aero:settings":
        return self.open_settings_panel()
    return _orig_on_open_app_j(self, widget, kind, target, fallback, name)


AltTVLauncher.on_open_app = _l_on_open_app_j



if __name__ == "__main__":
    apply_css()
    splash = SplashWindow()
    splash.show_all()

    # Splash for ~2.5 seconds, then the home screen.
    _main_timeout_id = GLib.timeout_add(2500, lambda: _show_main(splash))
    Gtk.main()
