# Aero Deck assets

This folder is intentionally empty in this build. Andrew will add the
real artwork here (the launcher looks for it next to
/usr/local/share/aero-deck/aero-deck-launcher.py):

- backdrop.jpg (cherry-blossom backdrop)
- aero-deck-logo.png (flight-helmet logo)
- aero-a-white.png, a-triangle-white.png, a-triangle-dark.png
- hero-kids.jpg (hero art)
- icons/<slug>.png, posters/<slug>.*, logos/<slug>.*

Until then the launcher falls back to its built-in placeholders.
