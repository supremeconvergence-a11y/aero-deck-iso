# Waydroid (Android apps) on Aero Deck

On first boot, aero-deck-waydroid-init.service runs `waydroid init`
using the bundled image (waydroid-image) and starts the container.
On the live ISO this happens every boot (nothing persists).
Check: `systemctl status aero-deck-waydroid-init`, `waydroid status`.
Re-run by hand: `sudo waydroid init -f && sudo systemctl start waydroid-container`.
