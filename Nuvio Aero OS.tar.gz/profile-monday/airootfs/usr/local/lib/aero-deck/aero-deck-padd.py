#!/usr/bin/env python3
"""Aero Deck controller daemon (aero-deck-padd).

Turns a game controller into TV-remote input for the whole system: the
launcher, the PIN pad, the Flight Deck, browsers -- everything sees normal
keyboard / mouse events from a virtual "Aero Deck Pad" device (uinput).

  D-pad / left stick ... arrow keys (with auto-repeat)
  A ..................... Enter (select)        B ...... Escape (back)
  X ..................... Space (play / pause)  Y ...... on-screen keyboard (F13)
  L1 / R1 ............... Shift+Tab / Tab (text cursor ◀ / ▶ while typing)
  Steam / Guide ......... Home                  ··· (Quick Access) ... Menu (Flight Deck)
  ≡ (Menu / Start) ...... F17: options for the focused item
  ⧉ (View / Select) ..... F16: Controls page
  L3 (left stick click) . F14: Navigator search R3 ... F15: Wingman
  L4 / R4 (back grips) .. Alt+Left / Alt+Right (back / forward in browsers)
  L5 / R5 (back grips) .. volume down / up
  Right trackpad ........ mouse pointer         R2 / right-pad click ... left click
  L2 .................... right click           left-pad press ... right click
  light tap on the right trackpad = left click; a short buzz on pad presses
  left trackpad / right stick ... scroll
  (controllers without trackpads: the right stick moves the pointer)

Only active where it should be:
  * handhelds (Steam Deck LCD "Jupiter" / OLED "Galileo", ROG Ally, Legion
    Go, ...): on automatically;
  * anything else (desktop PC, TV box): OFF unless /etc/aero-deck/padd.conf
    (or the Flight Deck -> Controller page) sets "mode": "always";
  * it pauses itself while Steam is running, so games get the raw
    controller and nothing is typed twice.

Never logs key contents beyond device names.

Stage 1 (Nov 22 2026) -- why the sticks did nothing on the Deck:
the kernel's hid-steam driver starts the Deck in "lizard mode" (the
firmware fakes a keyboard + mouse: D-pad/A/B/right pad only) and MUTES
the real gamepad device, so this daemon never saw the sticks. While the
daemon runs it switches lizard mode off (/sys/module/hid_steam/
parameters/lizard_mode = N) and does all the mapping itself (sticks,
both trackpads, every button); when it stops, lizard mode goes back on
(ExecStopPost) so the Deck is never left without a mouse. When Steam
opens the controller, hid-steam removes the gamepad device by itself
(Steam Input takes over, no double input) and brings it back when
Steam closes -- so there is no need to pause for Steam any more.
"""
import json
import os
import select
import subprocess
import sys
import time

try:
    import evdev
    from evdev import ecodes as E, UInput, InputDevice, ff
except ImportError:  # python-evdev missing: nothing to do
    print("aero-deck-padd: python-evdev not installed", file=sys.stderr)
    sys.exit(0)

CONF_PATHS = ["/etc/aero-deck/padd.conf",
              "/home/aero/.config/aero-deck/padd.conf"]
HANDHELD_PRODUCTS = {
    "Jupiter", "Galileo",                       # Steam Deck LCD / OLED
    "ROG Ally RC71L", "ROG Ally RC71L_RC71L",   # ASUS ROG Ally
    "ROG Ally X RC72LA", "RC71L", "RC72LA",
    "83E1", "83N0", "83N1",                     # Lenovo Legion Go / Go S
    "G1618-04", "G1617-01",                     # GPD Win 4 / Mini
}
VIRTUAL_NAME = "Aero Deck Pad"


def load_conf():
    conf = {"mode": "auto", "pointer_speed": 1.0, "invert_pad_y": False,
            "scroll_speed": 1.0, "pause_for_steam": False, "pad_mouse": True,
            "stick_deadzone": 0.18}
    for path in CONF_PATHS:
        try:
            with open(path) as fh:
                data = json.load(fh)
            if isinstance(data, dict):
                conf.update(data)
        except Exception:
            pass
    return conf


def is_handheld():
    try:
        with open("/sys/class/dmi/id/product_name") as fh:
            product = fh.read().strip()
    except Exception:
        return False
    return product in HANDHELD_PRODUCTS or product.startswith("ROG Ally")


def steam_running():
    try:
        return subprocess.run(["pgrep", "-x", "steam"],
                              stdout=subprocess.DEVNULL).returncode == 0
    except Exception:
        return False


LIZARD_PARAM = "/sys/module/hid_steam/parameters/lizard_mode"


def set_lizard_mode(on):
    """hid-steam lizard mode (firmware keyboard/mouse emulation)."""
    try:
        with open(LIZARD_PARAM) as fh:
            cur = fh.read().strip().upper() in ("Y", "1")
        if cur == bool(on):
            return True
        with open(LIZARD_PARAM, "w") as fh:
            fh.write("Y" if on else "N")
        print("aero-deck-padd: hid-steam lizard mode %s"
              % ("on" if on else "off"), flush=True)
        return True
    except OSError:
        return False


def is_gamepad(dev):
    if dev.name == VIRTUAL_NAME:
        return False
    caps = dev.capabilities()
    keys = set(caps.get(E.EV_KEY, []))
    abs_codes = {a[0] if isinstance(a, tuple) else a
                 for a in caps.get(E.EV_ABS, [])}
    return E.BTN_SOUTH in keys and (E.ABS_X in abs_codes
                                    or E.BTN_DPAD_UP in keys
                                    or E.ABS_HAT0X in abs_codes)


class Pad:
    """State for one physical controller."""

    def __init__(self, dev):
        self.dev = dev
        self.absinfo = {}
        for code, info in dev.capabilities(absinfo=True).get(E.EV_ABS, []):
            self.absinfo[code] = info
        self.values = {}
        self.is_deck = "steam deck" in dev.name.lower() or \
            (dev.info.vendor == 0x28de)
        self.has_pads = self.is_deck and E.ABS_HAT1X in self.absinfo
        self.prev_rpad = None
        self.prev_lpad = None
        self.rtap = None          # (t0, travel, clicked) while touching
        self.redge = False        # right-pad touch began on the edge strip
        self.lvel = (0.0, 0.0)    # left-pad scroll velocity
        self.momentum = None      # gliding after lift-off
        self.ff_id = None
        if self.is_deck:
            try:
                if E.FF_RUMBLE in dev.capabilities().get(E.EV_FF, []):
                    eff = ff.Effect(E.FF_RUMBLE, -1, 0, ff.Trigger(0, 0),
                                    ff.Replay(28, 0), ff.EffectType(
                                        ff_rumble_effect=ff.Rumble(
                                            strong_magnitude=0x4000,
                                            weak_magnitude=0x6000)))
                    self.ff_id = dev.upload_effect(eff)
            except Exception:
                self.ff_id = None

    def buzz(self):
        """Short haptic tick on the Deck (hid-steam force feedback)."""
        if self.ff_id is None:
            return
        try:
            self.dev.write(E.EV_FF, self.ff_id, 1)
        except Exception:
            pass

    def norm(self, code):
        """-1..1 (sticks / pads) or 0..1 (triggers) for an axis."""
        info = self.absinfo.get(code)
        val = self.values.get(code, 0)
        if info is None or info.max == info.min:
            return 0.0
        if info.min < 0:
            return max(-1.0, min(1.0, val / float(max(abs(info.min),
                                                      info.max))))
        return (val - info.min) / float(info.max - info.min)


class Daemon:
    REPEAT_DELAY = 0.40
    REPEAT_RATE = 0.11

    def __init__(self):
        self.conf = load_conf()
        self.pads = {}
        self.ui = UInput({
            E.EV_KEY: [E.KEY_UP, E.KEY_DOWN, E.KEY_LEFT, E.KEY_RIGHT,
                       E.KEY_ENTER, E.KEY_ESC, E.KEY_SPACE, E.KEY_TAB,
                       E.KEY_LEFTSHIFT, E.KEY_LEFTALT, E.KEY_MENU,
                       E.KEY_HOME, E.KEY_F13, E.KEY_BACKSPACE,
                       E.KEY_LEFTMETA,
                       E.KEY_F14, E.KEY_F15, E.KEY_F16, E.KEY_F17,
                       E.KEY_VOLUMEDOWN, E.KEY_VOLUMEUP,
                       E.BTN_LEFT, E.BTN_RIGHT, E.BTN_MIDDLE],
            E.EV_REL: [E.REL_X, E.REL_Y, E.REL_WHEEL, E.REL_HWHEEL],
        }, name=VIRTUAL_NAME)
        self.held_dir = None      # arrow key currently auto-repeating
        self.next_repeat = 0.0
        self.trig_state = {"r": False, "l": False}
        self.scroll_acc = [0.0, 0.0]
        self.last_scan = 0.0
        self.paused = False

    # -- output helpers ------------------------------------------------
    def tap(self, *keys):
        for k in keys:
            self.ui.write(E.EV_KEY, k, 1)
        self.ui.syn()
        for k in reversed(keys):
            self.ui.write(E.EV_KEY, k, 0)
        self.ui.syn()

    def key(self, code, down):
        self.ui.write(E.EV_KEY, code, 1 if down else 0)
        self.ui.syn()

    # -- device management ---------------------------------------------
    def scan(self):
        self.last_scan = time.time()
        for path in evdev.list_devices():
            if path in self.pads:
                continue
            try:
                dev = InputDevice(path)
                if is_gamepad(dev):
                    self.pads[path] = Pad(dev)
                    if self.pads[path].is_deck:
                        set_lizard_mode(False)
                    print("aero-deck-padd: using %s" % dev.name, flush=True)
                else:
                    dev.close()
            except Exception:
                continue

    def drop(self, path):
        pad = self.pads.pop(path, None)
        if pad is not None:
            try:
                pad.dev.close()
            except Exception:
                pass

    def drop_all(self):
        for path in list(self.pads):
            self.drop(path)

    # -- mapping ---------------------------------------------------------
    BUTTONS = {
        E.BTN_SOUTH: ("key", E.KEY_ENTER),
        E.BTN_EAST: ("key", E.KEY_ESC),
        E.BTN_NORTH: ("key", E.KEY_SPACE),   # evdev NORTH = X on Xbox/Deck
        E.BTN_WEST: ("key", E.KEY_F13),      # evdev WEST = Y on Xbox/Deck
        E.BTN_TL: ("combo", (E.KEY_LEFTSHIFT, E.KEY_TAB)),
        E.BTN_TR: ("key", E.KEY_TAB),
        E.BTN_START: ("key", E.KEY_F17),       # ≡: focused item's options
        E.BTN_SELECT: ("key", E.KEY_F16),      # ⧉: Controls page
        E.BTN_MODE: ("combo", (E.KEY_LEFTMETA, E.KEY_HOME)),  # Steam: back to Aero
        0x126: ("key", E.KEY_MENU),            # ··· (BTN_BASE): Flight Deck
        E.BTN_THUMBL: ("key", E.KEY_F14),      # L3: Navigator search
        E.BTN_THUMBR: ("key", E.KEY_F15),      # R3: Wingman
        # Back grips: hid-steam >= 6.11 BTN_GRIPL/R(2), older kernels
        # BTN_TRIGGER_HAPPY1-4 (L4, R4, L5, R5).
        0x224: ("combo", (E.KEY_LEFTALT, E.KEY_LEFT)),    # L4: back
        0x225: ("combo", (E.KEY_LEFTALT, E.KEY_RIGHT)),   # R4: forward
        0x226: ("key", E.KEY_VOLUMEDOWN),                 # L5
        0x227: ("key", E.KEY_VOLUMEUP),                   # R5
        0x2c0: ("combo", (E.KEY_LEFTALT, E.KEY_LEFT)),
        0x2c1: ("combo", (E.KEY_LEFTALT, E.KEY_RIGHT)),
        0x2c2: ("key", E.KEY_VOLUMEDOWN),
        0x2c3: ("key", E.KEY_VOLUMEUP),
        E.BTN_THUMB: ("mouse", E.BTN_RIGHT),   # Deck left pad press: right click
        E.BTN_THUMB2: ("mouse", E.BTN_LEFT),   # Deck right pad click
        E.BTN_TR2: ("mouse", E.BTN_LEFT),
        E.BTN_TL2: ("mouse", E.BTN_RIGHT),
    }
    DPAD = {E.BTN_DPAD_UP: E.KEY_UP, E.BTN_DPAD_DOWN: E.KEY_DOWN,
            E.BTN_DPAD_LEFT: E.KEY_LEFT, E.BTN_DPAD_RIGHT: E.KEY_RIGHT}

    def on_key(self, pad, code, value):
        if code in self.DPAD:
            self.set_dir(self.DPAD[code] if value else None, source=code)
            return
        action = self.BUTTONS.get(code)
        if action is None:
            return
        kind, target = action
        if kind == "mouse":
            if code in (E.BTN_TR2, E.BTN_TL2) and pad.is_deck:
                return  # Deck triggers handled from the analog axes
            if code in (E.BTN_THUMB, E.BTN_THUMB2) and value == 1:
                pad.buzz()
                if code == E.BTN_THUMB2 and pad.rtap is not None:
                    pad.rtap[2] = True   # a real press: no extra tap-click
            self.key(target, value != 0)
            return
        if value == 1:
            if kind == "combo":
                self.tap(*target)
            else:
                self.key(target, True)
        elif value == 0 and kind == "key":
            self.key(target, False)

    def set_dir(self, keycode, source=None):
        if keycode == self.held_dir:
            return
        self.held_dir = keycode
        if keycode is not None:
            self.tap(keycode)
            self.next_repeat = time.time() + self.REPEAT_DELAY

    def on_abs(self, pad, code, value):
        pad.values[code] = value
        if code in (E.ABS_HAT0X, E.ABS_HAT0Y) and not pad.has_pads:
            # Generic pads report the D-pad as a hat.
            x = pad.values.get(E.ABS_HAT0X, 0)
            y = pad.values.get(E.ABS_HAT0Y, 0)
            self.set_dir(E.KEY_LEFT if x < 0 else E.KEY_RIGHT if x > 0 else
                         E.KEY_UP if y < 0 else E.KEY_DOWN if y > 0 else None)
            return
        if code in (E.ABS_X, E.ABS_Y):
            x, y = pad.norm(E.ABS_X), pad.norm(E.ABS_Y)
            # Linux convention (hid-steam / xpad): up is negative.
            d = None
            if max(abs(x), abs(y)) > 0.55:
                if abs(x) > abs(y):
                    d = E.KEY_RIGHT if x > 0 else E.KEY_LEFT
                else:
                    d = E.KEY_DOWN if y > 0 else E.KEY_UP
            if d is not None or self.held_dir in (E.KEY_LEFT, E.KEY_RIGHT,
                                                  E.KEY_UP, E.KEY_DOWN):
                self.set_dir(d)
            return
        # Deck analog triggers (hid-steam: ABS_HAT2X = R2, ABS_HAT2Y = L2)
        if pad.is_deck and code in (E.ABS_HAT2X, E.ABS_HAT2Y):
            side = "r" if code == E.ABS_HAT2X else "l"
            pressed = pad.norm(code) > 0.5
            if pressed != self.trig_state[side]:
                self.trig_state[side] = pressed
                self.key(E.BTN_LEFT if side == "r" else E.BTN_RIGHT, pressed)
            return
        if not pad.is_deck and code in (E.ABS_RZ, E.ABS_Z):
            side = "r" if code == E.ABS_RZ else "l"
            pressed = pad.norm(code) > 0.5
            if pressed != self.trig_state[side]:
                self.trig_state[side] = pressed
                self.key(E.BTN_LEFT if side == "r" else E.BTN_RIGHT, pressed)

    def on_syn(self, pad):
        speed = float(self.conf.get("pointer_speed", 1.0))
        if pad.has_pads and self.conf.get("pad_mouse", True):
            # Right trackpad -> relative pointer (untouched pad reads 0,0)
            rx = pad.values.get(E.ABS_HAT1X, 0)
            ry = pad.values.get(E.ABS_HAT1Y, 0)
            if self.conf.get("invert_pad_y"):
                ry = -ry
            if rx == 0 and ry == 0:
                pad.prev_rpad = None
                # Light tap (short touch, barely moved, not pressed) = click
                if pad.rtap is not None:
                    t0, travel, clicked = pad.rtap
                    pad.rtap = None
                    if (not clicked and time.time() - t0 < 0.20
                            and travel < 1800):
                        self.tap(E.BTN_LEFT)
            else:
                if pad.rtap is None:
                    pad.rtap = [time.time(), 0, False]
                elif pad.prev_rpad is not None:
                    pad.rtap[1] += abs(rx - pad.prev_rpad[0]) + \
                        abs(ry - pad.prev_rpad[1])
                if pad.prev_rpad is None:
                    # Touch that starts on the right edge = scroll strip
                    # (one-handed scrolling with the right pad).
                    pad.redge = rx > 0.75 * 32767
                if pad.prev_rpad is not None and pad.redge:
                    self.scroll(-(ry - pad.prev_rpad[1]) / 32767.0 * 12, 0)
                elif pad.prev_rpad is not None:
                    dx = (rx - pad.prev_rpad[0]) / 32767.0 * 900 * speed
                    dy = (ry - pad.prev_rpad[1]) / 32767.0 * 900 * speed
                    if abs(dx) < 200 and abs(dy) < 200:
                        self.move(dx, dy)
                pad.prev_rpad = (rx, ry)
            # Left trackpad -> scroll
            lx = pad.values.get(E.ABS_HAT0X, 0)
            ly = pad.values.get(E.ABS_HAT0Y, 0)
            if lx == 0 and ly == 0:
                if pad.prev_lpad is not None:
                    # Lift-off: keep gliding (Steam Deck style momentum).
                    pad.momentum = list(pad.lvel)
                pad.prev_lpad = None
            else:
                if pad.prev_lpad is not None:
                    vy = -(ly - pad.prev_lpad[1]) / 32767.0 * 12
                    hx = (lx - pad.prev_lpad[0]) / 32767.0 * 12
                    self.scroll(vy, hx)
                    pad.lvel = (0.6 * pad.lvel[0] + 0.4 * vy,
                                0.6 * pad.lvel[1] + 0.4 * hx)
                else:
                    pad.lvel = (0.0, 0.0)
                pad.momentum = None
                pad.prev_lpad = (lx, ly)

    def move(self, dx, dy):
        ix, iy = int(round(dx)), int(round(dy))
        if ix:
            self.ui.write(E.EV_REL, E.REL_X, ix)
        if iy:
            self.ui.write(E.EV_REL, E.REL_Y, iy)
        if ix or iy:
            self.ui.syn()

    def scroll(self, vy, hx):
        sp = float(self.conf.get("scroll_speed", 1.0))
        self.scroll_acc[0] += vy * sp
        self.scroll_acc[1] += hx * sp
        for idx, code in ((0, E.REL_WHEEL), (1, E.REL_HWHEEL)):
            steps = int(self.scroll_acc[idx])
            if steps:
                self.scroll_acc[idx] -= steps
                self.ui.write(E.EV_REL, code, steps)
                self.ui.syn()

    def tick(self):
        """Periodic work: key repeat, right stick pointer / scroll."""
        now = time.time()
        if self.held_dir is not None and now >= self.next_repeat:
            self.tap(self.held_dir)
            self.next_repeat = now + self.REPEAT_RATE
        speed = float(self.conf.get("pointer_speed", 1.0))
        for pad in self.pads.values():
            m = getattr(pad, "momentum", None)
            if m is not None and now - getattr(pad, "mom_t", 0) >= 0.016:
                pad.mom_t = now
                self.scroll(m[0], m[1])
                m[0] *= 0.92
                m[1] *= 0.92
                if abs(m[0]) < 0.02 and abs(m[1]) < 0.02:
                    pad.momentum = None
        for pad in self.pads.values():
            rx, ry = pad.norm(E.ABS_RX), pad.norm(E.ABS_RY)
            dz = float(self.conf.get("stick_deadzone", 0.18))
            if abs(rx) < dz:
                rx = 0
            if abs(ry) < dz:
                ry = 0
            if not rx and not ry:
                continue
            if pad.has_pads:
                self.scroll(-ry * 0.6, rx * 0.6)
            else:
                self.move(rx * 14 * speed, ry * 14 * speed)

    # -- main loop -------------------------------------------------------
    def run(self):
        self.scan()
        while True:
            if self.conf.get("pause_for_steam", True) and steam_running():
                if not self.paused:
                    print("aero-deck-padd: Steam is running, pausing",
                          flush=True)
                    self.paused = True
                    self.drop_all()
                time.sleep(2)
                continue
            if self.paused:
                self.paused = False
                self.scan()
            if time.time() - self.last_scan > 3:
                # Flight Deck -> Controller changes apply within 3 s.
                self.conf = load_conf()
                if not wanted(self.conf):
                    self.drop_all()
                    return
                self.scan()
            fds = {pad.dev.fd: path for path, pad in self.pads.items()}
            try:
                ready, _, _ = select.select(list(fds), [], [], 0.016)
            except (OSError, ValueError):
                ready = []
                for path in list(self.pads):
                    self.drop(path)
            for fd in ready:
                path = fds.get(fd)
                pad = self.pads.get(path)
                if pad is None:
                    continue
                try:
                    for ev in pad.dev.read():
                        if ev.type == E.EV_KEY:
                            self.on_key(pad, ev.code, ev.value)
                        elif ev.type == E.EV_ABS:
                            self.on_abs(pad, ev.code, ev.value)
                        elif ev.type == E.EV_SYN:
                            self.on_syn(pad)
                except (OSError, IOError):
                    self.drop(path)   # unplugged
            self.tick()
            if not self.pads:
                time.sleep(0.5)


def wanted(conf):
    mode = str(conf.get("mode", "auto")).lower()
    return mode == "always" or (mode == "auto" and is_handheld())


def main():
    import atexit
    import signal
    atexit.register(set_lizard_mode, True)
    signal.signal(signal.SIGTERM, lambda *a: sys.exit(0))
    daemon = None
    announced = None
    while True:
        conf = load_conf()
        on = wanted(conf)
        if on != announced:
            print("aero-deck-padd: %s (mode=%s, handheld=%s)" % (
                "active" if on else "off", conf.get("mode"),
                is_handheld()), flush=True)
            announced = on
        if on:
            if daemon is None:
                daemon = Daemon()
            daemon.conf = conf
            daemon.run()          # returns when switched off
        time.sleep(3)


if __name__ == "__main__":
    sys.exit(main())
