#!/usr/bin/env python3
"""Aero Deck input watcher: which kind of device was used LAST.

Reads every /dev/input/event* read-only (never grabs, so nothing is taken
away from labwc / the apps) and classifies each device from its evdev
capabilities (the same properties libinput uses):

  touch       touchscreen      INPUT_PROP_DIRECT + ABS_MT_POSITION_X
  touchpad    laptop touchpad  INPUT_PROP_POINTER / BTN_TOOL_FINGER, not direct
  remote      TV remote        G10S / 2.4G air-mouse dongles, Fire TV / Google
                               TV remotes, consumer-control devices
  controller  game controller  BTN_SOUTH / BTN_GAMEPAD, or the Aero Deck Pad
                               virtual device made by aero-deck-padd
  keyboard    real keyboard    letter keys + space, not a remote
  mouse       mouse            REL_X/REL_Y + BTN_LEFT

Writes the class to /run/aero-deck/last-input (one word) when it changes.

Grid keyboard over other apps (Chrome, web pages): while the Aero grid
keyboard is up it creates /run/aero-deck/user/osk-open; then the remote's
and controller's D-pad / OK / Back / mic are taken from the app (EVIOCGRAB)
and sent to the keyboard as words (up down left right ok back bksp mic)
through the FIFO /run/aero-deck/user/osk-nav, so the highlight moves over
the keys and OK types the highlighted key into the app. Released as soon
as the keyboard closes.
Only key/button presses and touch-downs count (no motion noise). A touchpad
tap is a touchpad, never a touchscreen touch. Nothing typed is recorded --
only the device kind."""
import os, re, select, time
import evdev
from evdev import ecodes as E

OUT_DIR = "/run/aero-deck"
OUT = OUT_DIR + "/last-input"
REMOTE_RE = re.compile(r"g10s|2\.4g|air ?mouse|remote|fire ?tv|amazon|"
                       r"google tv|chromecast|consumer control|mx3|"
                       r"composite devic|wechip|bluetooth le remote", re.I)
PAD_NAME = "Aero Deck Pad"


def classify(dev):
    name = dev.name or ""
    try:
        caps = dev.capabilities()
        props = dev.input_props()
    except Exception:
        return None
    keys = set(caps.get(E.EV_KEY, []))
    abses = {a[0] if isinstance(a, tuple) else a for a in caps.get(E.EV_ABS, [])}
    rels = set(caps.get(E.EV_REL, []))
    if name == PAD_NAME:
        return "controller"
    if E.ABS_MT_POSITION_X in abses or E.BTN_TOUCH in keys:
        if E.INPUT_PROP_DIRECT in props:
            return "touch"
        if E.INPUT_PROP_POINTER in props or E.BTN_TOOL_FINGER in keys:
            return "touchpad"
    if REMOTE_RE.search(name):
        return "remote"
    if E.BTN_SOUTH in keys or E.BTN_GAMEPAD in keys or E.BTN_JOYSTICK in keys:
        return "controller"
    if E.KEY_Q in keys and E.KEY_A in keys and E.KEY_SPACE in keys:
        return "keyboard"
    if E.REL_X in rels and E.BTN_LEFT in keys:
        return "mouse"
    if keys & {E.KEY_HOMEPAGE, E.KEY_SEARCH, E.KEY_BACK, E.KEY_MENU,
               E.KEY_PLAYPAUSE, E.KEY_VOLUMEUP, E.KEY_SELECT, E.KEY_OK}:
        return "remote"
    return None


def write(kind):
    try:
        os.makedirs(OUT_DIR, exist_ok=True)
        os.chmod(OUT_DIR, 0o755)
        tmp = OUT + ".part"
        with open(tmp, "w") as f:
            f.write(kind + "\n")
        os.chmod(tmp, 0o644)
        os.replace(tmp, OUT)
    except Exception:
        pass


USER_DIR = OUT_DIR + "/user"
FLAG = USER_DIR + "/osk-open"
FIFO = USER_DIR + "/osk-nav"
NAV = {E.KEY_UP: "up", E.KEY_DOWN: "down", E.KEY_LEFT: "left",
       E.KEY_RIGHT: "right", E.KEY_ENTER: "ok", E.KEY_KPENTER: "ok",
       E.KEY_SELECT: "ok", E.KEY_OK: "ok", E.BTN_SOUTH: "ok",
       E.KEY_ESC: "back", E.KEY_BACK: "back", E.BTN_EAST: "back",
       E.KEY_BACKSPACE: "bksp", E.BTN_WEST: "bksp",
       E.KEY_MICMUTE: "mic", E.KEY_SEARCH: "mic", E.KEY_VOICECOMMAND: "mic",
       E.KEY_F15: "mic", E.BTN_THUMBR: "mic",
       E.BTN_DPAD_UP: "up", E.BTN_DPAD_DOWN: "down",
       E.BTN_DPAD_LEFT: "left", E.BTN_DPAD_RIGHT: "right"}


def setup_user_dir():
    """/run/aero-deck/user belongs to the Aero user (uid 1000)."""
    try:
        os.makedirs(USER_DIR, exist_ok=True)
        os.chown(USER_DIR, 1000, 1000)
        os.chmod(USER_DIR, 0o755)
        if not os.path.exists(FIFO):
            os.mkfifo(FIFO, 0o644)
        os.chown(FIFO, 0, 1000)
        os.chmod(FIFO, 0o640)
    except Exception:
        pass


class Nav:
    def __init__(self):
        self.grabbed = set()
        self.fd = None

    def send(self, word):
        try:
            if self.fd is None:
                self.fd = os.open(FIFO, os.O_WRONLY | os.O_NONBLOCK)
            os.write(self.fd, (word + "\n").encode())
        except Exception:
            self.fd = None     # keyboard not reading yet / closed

    def sync(self, devs, kinds):
        want = os.path.exists(FLAG)
        for p, d in devs.items():
            if kinds.get(p) not in ("remote", "controller"):
                continue
            if want and p not in self.grabbed:
                try:
                    d.grab(); self.grabbed.add(p)
                except Exception:
                    pass
            elif not want and p in self.grabbed:
                try:
                    d.ungrab()
                except Exception:
                    pass
                self.grabbed.discard(p)
        if not want and self.fd is not None:
            try:
                os.close(self.fd)
            except Exception:
                pass
            self.fd = None
        return want


def main():
    devs, kinds = {}, {}
    last, last_scan = None, 0
    setup_user_dir()
    nav = Nav()
    while True:
        now = time.time()
        if now - last_scan > 3:
            last_scan = now
            for path in evdev.list_devices():
                if path in devs:
                    continue
                try:
                    d = evdev.InputDevice(path)
                except Exception:
                    continue
                k = classify(d)
                if k is None:
                    d.close()
                    continue
                devs[path], kinds[path] = d, k
        grabbing = nav.sync(devs, kinds)
        fds = {d.fd: p for p, d in devs.items()}
        try:
            r, _w, _x = select.select(list(fds), [], [],
                                      0.25 if grabbing else 1.0) if fds else \
                ([], [], time.sleep(1))
        except Exception:
            r = []
        for fd in r:
            p = fds[fd]
            try:
                evs = list(devs[p].read())
            except Exception:       # unplugged
                try:
                    devs[p].close()
                except Exception:
                    pass
                devs.pop(p, None)
                kinds.pop(p, None)
                continue
            for ev in evs:
                if p in nav.grabbed:
                    if ev.type == E.EV_KEY and ev.value in (1, 2) and ev.code in NAV:
                        nav.send(NAV[ev.code])
                    elif ev.type == E.EV_ABS and ev.code in (E.ABS_HAT0X, E.ABS_HAT0Y) and ev.value:
                        nav.send({(E.ABS_HAT0X, -1): "left", (E.ABS_HAT0X, 1): "right",
                                  (E.ABS_HAT0Y, -1): "up", (E.ABS_HAT0Y, 1): "down"}
                                 [(ev.code, 1 if ev.value > 0 else -1)])
                if ev.type == E.EV_KEY and ev.value == 1:
                    k = kinds[p]
                    if k != last:
                        last = k
                        write(k)


if __name__ == "__main__":
    main()
