# Aero Deck -- Secure Boot hook, sourced by the patched mkarchiso copy that
# build-aero-deck.sh makes (/root/mkarchiso-aero). Never edit /usr/bin/mkarchiso.
#
# Boot chain on the USB (UEFI, Secure Boot ON):
#   EFI/BOOT/BOOTX64.EFI  = shim (signed by Microsoft's UEFI CA, from Fedora)
#   EFI/BOOT/mmx64.efi    = MokManager (the one-time "enroll key" screen)
#   EFI/BOOT/grubx64.efi  = systemd-boot, signed with Aero's own MOK key
#   /aero/boot/x86_64/vmlinuz-linux-cachyos   signed with Aero's MOK key
#   EFI/aero-mok.cer      = Aero's public key, picked in MokManager once
# Needs: AERO_SB_DIR with aero-mok.key, aero-mok.crt, aero-mok.cer,
#        shimx64.efi, mmx64.efi  (made by build-aero-deck.sh step 4).

aero_sb_on() { [[ -n "${AERO_SB_DIR:-}" && -f "${AERO_SB_DIR}/aero-mok.key" ]]; }

aero_sb_sign() {   # file -> signed in place (idempotent)
    local f="$1"
    if sbverify --cert "${AERO_SB_DIR}/aero-mok.crt" "$f" >/dev/null 2>&1; then
        return 0
    fi
    # Drop any existing signature first (one clean Aero signature).
    sbattach --remove "$f" >/dev/null 2>&1 || true
    # Explicit error checks: errexit is not reliable inside functions.
    if ! sbsign --key "${AERO_SB_DIR}/aero-mok.key" --cert "${AERO_SB_DIR}/aero-mok.crt" \
            --output "$f.aero-signed" "$f" >/dev/null 2>&1; then
        echo "[aero-secureboot] ERROR: could not sign $f" >&2; exit 1
    fi
    mv -f "$f.aero-signed" "$f" || exit 1
    if ! sbverify --cert "${AERO_SB_DIR}/aero-mok.crt" "$f" >/dev/null 2>&1; then
        echo "[aero-secureboot] ERROR: signature check failed on $f" >&2; exit 1
    fi
    echo "[aero-secureboot] signed ${f##*/}"
}

# After the kernels are copied out of the airootfs (before they go onto
# the ISO 9660 tree and the EFI partition image).
aero_sb_sign_kernels() {
    aero_sb_on || return 0
    local k
    for k in "${boot_dir}/vmlinuz-"*; do
        if [[ -f "$k" && "$k" != *.sig ]]; then
            aero_sb_sign "$k"
        fi
    done
    return 0
}

# Right after mkarchiso put systemd-boot at EFI/BOOT/BOOT<ARCH>.EFI.
aero_sb_shim() {
    aero_sb_on || return 0
    [[ "${1:-}" == "X64" ]] || return 0
    local d="${isofs_dir}/EFI/BOOT"
    [[ -f "$d/BOOTX64.EFI" ]] || { echo "[aero-secureboot] ERROR: no systemd-boot at $d/BOOTX64.EFI" >&2; exit 1; }
    install -m 0644 -- "$d/BOOTX64.EFI" "$d/grubx64.efi"
    aero_sb_sign "$d/grubx64.efi"
    install -m 0644 -- "${AERO_SB_DIR}/shimx64.efi" "$d/BOOTX64.EFI"
    install -m 0644 -- "${AERO_SB_DIR}/mmx64.efi" "$d/mmx64.efi"
    install -m 0644 -- "${AERO_SB_DIR}/aero-mok.cer" "${isofs_dir}/EFI/aero-mok.cer"
    echo "[aero-secureboot] shim + MokManager + signed systemd-boot in EFI/BOOT"
    return 0
}

# mkarchiso copies airootfs with --no-preserve=mode, which strips the
# execute bits from the big programs unpacked under /opt (Chrome,
# Boosteroid, Nuvio) and from Flatpak apps. Put them back from the
# profile copy (setuid only for chrome-sandbox).
aero_fix_modes() {   # $1 = profile airootfs, $2 = pacstrap dir
    local src="$1" dst="$2" f
    [[ -d "$src" ]] || return 0
    while IFS= read -r -d '' f; do
        [[ -e "$dst/$f" ]] && chmod 755 -- "$dst/$f"
    done < <(cd "$src" && find opt var/lib/flatpak usr/local/bin -type f -perm /111 -print0 2>/dev/null)
    if [[ -f "$dst/opt/google/chrome/chrome-sandbox" ]]; then
        chown 0:0 "$dst/opt/google/chrome/chrome-sandbox"
        chmod 4755 "$dst/opt/google/chrome/chrome-sandbox"
    fi
    echo "[aero] restored execute bits under /opt, /var/lib/flatpak, /usr/local/bin"
    return 0
}
