AERO OS MONDAY NIGHT (Monday Nov 23, 2026)  ->  aero-deck-2026.11.23-monday  (launcher v1.4.0)
=============================================================================================
Built on Nuvio Aero (1.3.0). Aero's aluminum look is unchanged; this adds the
items from "Aero updates" (see CHANGES-MONDAY-NIGHT.txt) and SECURE BOOT:
the USB now boots with Secure Boot left ON. Nobody changes the BIOS.
Target: Steam Deck LCD (1280x800) first; also fits 1024x600 .. 1080p.

!! BEFORE YOU TOUCH ANY BIOS / UEFI SETTING ON ANY PC (you should not need to):
   make sure the owner knows his Microsoft account password and has his
   BitLocker recovery key (aka.ms/myrecoverykey, signed in with his Microsoft
   account). Turning Secure Boot off is what wiped your son's Windows Hello
   PIN last time. With this build you do NOT turn it off.
   The build itself needs no BIOS change at all -- only the boot order or
   the one-time boot menu (F12 on the Dell) to start live CachyOS / the USB.

WHAT'S IN THE TARBALL
  profile-monday/           the full ISO profile (launcher v1.4.0 included)
  build-aero-deck.sh        one script: Secure Boot signing, fetches + checks
                            Chrome / Boosteroid / GeForce NOW / Nuvio, builds the ISO
  aero-sb-prepare.sh        Secure Boot: makes Aero's key once, gets shim (pinned hash)
  aero-sb-hook.sh           Secure Boot: signs the boot loader + kernel during the build
  aero-fetch-apps.sh        Chrome (repo signature + SHA-256), Boosteroid (md5), GeForce NOW (Flatpak)
  aero-deck-launcher.py     the new launcher on its own
  src/                      the patch (apply_monday.py + blocks) and tests
  screenshots/              test screenshots of the new screens (fake test data)
  CHANGES-MONDAY-NIGHT.txt  what changed

BUILD IT (live CachyOS on the Dell, ~35-60 min, needs internet)
 1. Boot live CachyOS, connect to the internet, copy "Nuvio Aero OS.tar.gz"
    to ~/Downloads.
 2. Mount drive D read-write at /mnt/d (same as last time):
       lsblk -f                      (find D: the big NTFS partition, e.g. nvme0n1p3)
       sudo mkdir -p /mnt/d
       sudo mount -t ntfs3 /dev/nvme0n1p3 /mnt/d
       sudo mkdir -p /mnt/d/Aero
 3. Get the build script out of the tarball and run it:
       cd ~/Downloads
       tar xzf "Nuvio Aero OS.tar.gz" build-aero-deck.sh
       sudo bash build-aero-deck.sh ~/Downloads/"Nuvio Aero OS.tar.gz"
    What it downloads (each one is checked; the build stops if a check fails):
      - shim 15.8 (Fedora's Microsoft-signed Secure Boot loader), pinned SHA-256
      - Google Chrome stable (Google's signed repo; includes Widevine for Netflix/Prime)
      - Boosteroid's Linux app (checked against Boosteroid's .md5)
      - NVIDIA GeForce NOW (NVIDIA's Flatpak repo; optional -- if it fails the
        tile opens play.geforcenow.com instead and the build carries on)
      - Nuvio 0.1.38-alpha, same pinned hash as last time
    The FIRST run makes Aero's Secure Boot key in D:\Aero\secureboot.
    KEEP THAT FOLDER and never share it (aero-mok.key is the private key).
    Every later build reuses it, so a machine that enrolled it once never
    sees the blue MOK screen again. The key is never put in the ISO.
    work.img from last time is reused and grown to 30 GB.
 4. The ISO lands in D:\Aero\aero-deck-2026.11.23-monday-x86_64.iso.
    The script's last step checks it is a HYBRID ISO with shim in its EFI
    partition ("Hybrid ISO: OK"), which is what makes Rufus / Etcher sticks
    boot with Secure Boot ON. Reboot into Windows to burn it.

BURN THE USB STICK IN WINDOWS (pick ONE -- not Ventoy)
 Both erase the whole stick. Unplug other USB drives first so you can't pick
 the wrong one.

 A) Rufus (rufus.ie)
   1. Plug in the stick, open Rufus.
   2. Device: your USB stick (check the size).
   3. Boot selection: SELECT -> D:\Aero\aero-deck-2026.11.23-monday-x86_64.iso
   4. Leave Partition scheme / Target system / File system as Rufus sets
      them (with DD mode they are ignored anyway).
   5. START. Rufus says "ISOHybrid image detected" and asks which mode:
      choose  "Write in DD Image mode"  -> OK.  (NOT "ISO Image mode":
      that copies files instead of the exact image, and the stick may not
      find its own files or keep the signed Secure Boot loader intact.)
   6. OK to the "all data will be destroyed" warning. Wait for READY, Close.
   (Windows may then say the stick "needs to be formatted" -- click Cancel.
    That is normal for a Linux stick; do NOT format it.)

 B) balenaEtcher (etcher.balena.io)
   1. Flash from file -> D:\Aero\aero-deck-2026.11.23-monday-x86_64.iso
   2. Select target -> your USB stick.
   3. Flash! (Windows asks for admin permission -- Yes.) Etcher writes the
      exact image and verifies it. Done when it says "Flash Completed!".
   (Same "needs to be formatted" popup may appear -- Cancel.)

 Optional check before burning: in PowerShell
     Get-FileHash D:\Aero\aero-deck-2026.11.23-monday-x86_64.iso
 must match D:\Aero\aero-deck-2026.11.23-monday-x86_64.iso.sha256.

BOOT IT
 Steam Deck: power off, hold Volume Down + Power, pick the USB stick.
 Dell / other PC: plug the stick in, restart, tap F12 (one-time boot menu)
 and pick the USB (the "UEFI" entry). No BIOS setting is changed.

FIRST BOOT WITH SECURE BOOT ON (once per machine, about 1 minute)
 Steam Deck: Secure Boot is off there by default, so it just boots -- no
 blue screen. On a PC with Secure Boot on (the Dell, your son's PC), pick the
 USB from the one-time boot menu (F12 on the Dell). The very first time:
  1. A blue screen says "Verification failed: (0x1A) Security Violation".
     Press Enter (OK). This is normal: the PC doesn't know Aero's key yet.
  2. "Shim UEFI key management -- Press any key to perform MOK management".
     Press any key within 10 seconds. (Missed it? It reboots; just boot the
     USB again.)
  3. Menu: pick "Enroll key from disk".
  4. Pick the USB's volume (ARCHISO_EFI ...), then "EFI/", then "aero-mok.cer".
  5. "[Enroll MOK]": pick "Continue".  ("View key 0" shows
     "Aero Deck Secure Boot (MOK)" if you want to check it.)
  6. "Enroll the key(s)?": pick "Yes". (No password is asked for this way.)
  7. Pick "Reboot", then boot the USB again (F12). From now on it goes
     straight to the Aero menu, with Secure Boot still ON.
 Nothing in the BIOS changes and Windows is not touched. To take the key out
 again later: in Aero run  sudo mokutil --delete /usr/local/share/aero-deck/secureboot/aero-mok.cer
 (it asks for a one-time password, then confirm on the blue screen).
 Optional helper inside Aero: "aero-deck-secureboot" shows whether Secure
 Boot is on and the Aero key is enrolled. You do not need it to boot.
 With Secure Boot ON the "UEFI Shell" and "Memtest" menu entries won't start
 (they aren't signed); the Aero entries do.

KEEP SETTINGS AFTER A REBOOT (live USB): same as before -- a stick / SD card
partition labelled AERO_DATA (Chrome web-app sign-ins are kept there too).

THE G10S REMOTE (USB dongle)
 D-pad = move, OK = select, Back = back, Home = Aero home, Play/Pause works
 in the players, air mouse = pointer. Mic button (or Search) = Aero voice
 search; the dongle's microphone is picked automatically.

"YOUTUBE TV" -- NOTE
 The YouTube tile opens YouTube's TV interface (youtube.com/tv, the
 remote-friendly big-screen version). It is NOT the paid "YouTube TV" cable
 service (US only). If you meant that one, say so and it gets its own tile.

TEST CHECKLIST (pass / fail for each)
  [ ] Dell or son's PC with Secure Boot ON: blue MOK screen once, then Aero
      boots; Windows still starts normally afterwards, PIN intact
  [ ] Home fits 1280x800: hero with 6 dots, full + split slides
  [ ] Rest on a movie/show poster ~2 s: muted trailer plays in the card
      (card grows a little); Flight Deck -> Appearance -> Trailers turns it off
  [ ] Hero backdrop follows the focused poster; title page has "Trailer"
  [ ] Live TV opens the guide: ~5 channel rows, purple now-line, preview
      panel with expand / Watch Now / Add to Library; preview size + on/off
      in Flight Deck -> Appearance
  [ ] Live Tiles at the start of Live TV / Movies / TV Shows
  [ ] Appearance: accent colour, background static/dynamic/blur/dim, panel
      opacity -- each has a Default button
  [ ] Apps button (top bar): Linux Apps / Droid Apps
  [ ] Hold OK (or right-click) on an app tile: Move / Remove / Uninstall
  [ ] Netflix, Prime Video, YouTube (TV), YouTube Music, Amazon Music,
      Rumble, Amazon Luna open full screen in Chrome and play (DRM)
  [ ] GeForce NOW and Boosteroid open their native apps
  [ ] Downloader (Droid Apps) -- install it once from the Play Store in Waydroid
  [ ] G10S remote: d-pad, OK, Back, Home, Play/Pause, air mouse, mic search
